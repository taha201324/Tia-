-- کد ۲ از ۵: ارسال بی‌صدا (پیام بدون اعلان). باید بعد از supabase_push.sql اجرا شود.
alter table public.messages add column if not exists silent boolean not null default false;
alter table public.group_messages add column if not exists silent boolean not null default false;

create or replace function public.push_on_message() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
declare nm text; prev boolean;
begin
  begin
    if new.silent then return new; end if;
    if new.sender_id = new.receiver_id then return new; end if;
    if public.blocked_pair(new.sender_id, new.receiver_id) then return new; end if;
    if exists (select 1 from chat_prefs where user_id = new.receiver_id and scope = 'd'
               and target = new.sender_id::text and muted) then return new; end if;
    if not exists (select 1 from push_devices where user_id = new.receiver_id and active) then return new; end if;
    select name into nm from profiles where id = new.sender_id;
    select coalesce((select value from push_config where key = 'include_preview'), 'true') = 'true' into prev;
    perform public.push_enqueue('dm:' || new.id, array[new.receiver_id], jsonb_build_object(
      'event_id', 'dm:' || new.id, 'kind', 'dm', 'peer', new.sender_id, 'msg_id', new.id,
      'title', coalesce(nm, 'Tia'),
      'body', public.push_label(new.kind, new.text, new.file_name, prev),
      'ts', extract(epoch from new.created_at)::bigint));
  exception when others then
    null;
  end;
  return new;
end $$;

create or replace function public.push_on_group_message() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
declare gt text; nm text; rec uuid[]; prev boolean;
begin
  begin
    if new.silent then return new; end if;
    select title into gt from groups where id = new.group_id;
    select coalesce(array_agg(m.user_id), '{}') into rec from (
      select gm.user_id from group_members gm
       where gm.group_id = new.group_id and gm.user_id <> new.sender_id
         and (gm.muted_until is null or gm.muted_until <= now())
         and not exists (select 1 from chat_prefs cp where cp.user_id = gm.user_id and cp.scope = 'g'
                         and cp.target = new.group_id::text and cp.muted)
         and not public.blocked_pair(gm.user_id, new.sender_id)
       limit 2000) m;
    if coalesce(array_length(rec, 1), 0) = 0 then return new; end if;
    select name into nm from profiles where id = new.sender_id;
    select coalesce((select value from push_config where key = 'include_preview'), 'true') = 'true' into prev;
    perform public.push_enqueue('g:' || new.id, rec, jsonb_build_object(
      'event_id', 'g:' || new.id, 'kind', 'group', 'gid', new.group_id, 'msg_id', new.id,
      'title', coalesce(gt, 'Tia'),
      'body', case when prev then coalesce(nm, '') || ': ' else '' end || public.push_label(new.kind, new.text, new.file_name, prev),
      'ts', extract(epoch from new.created_at)::bigint));
  exception when others then
    null;
  end;
  return new;
end $$;
