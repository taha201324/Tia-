-- اجرا شود فقط اگر قبلاً supabase_cron.sql (pg_cron) روی پروژه کار کرده است
-- هر ۵ دقیقه پیام‌های منقضی‌شده و استوری‌های قدیمی را پاک می‌کند
select cron.schedule('tia-purge', '*/5 * * * *', $$select public.purge_expired();$$);
