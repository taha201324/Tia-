-- کد ۴ از ۵: اعلان واکنش (وقتی کسی به پیام شما ایموجی می‌زند). به supabase_push.sql و supabase_extras.sql نیاز دارد.
create or replace function public.push_on_reaction() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
declare owner uuid; gid bigint; nm text; gt text;
begin
  begin
    if new.scope = 'd' then
      select sender_id into owner from messages where id = new.message_id;
    else
      select sender_id, group_id into owner, gid from group_messages where id = new.message_id;
    end if;
    if owner is null or owner = new.user_id then return new; end if;
    if public.blocked_pair(owner, new.user_id) then return new; end if;
    select name into nm from profiles where id = new.user_id;
    if new.scope = 'd' then
      perform public.push_enqueue('r:d:' || new.message_id || ':' || new.user_id, array[owner], jsonb_build_object(
        'event_id', 'r:d:' || new.message_id || ':' || new.user_id, 'kind', 'dm', 'peer', new.user_id, 'msg_id', new.message_id,
        'title', coalesce(nm, 'Tia'), 'body', new.emoji || ' به پیام شما واکنش نشان داد', 'ts', extract(epoch from now())::bigint));
    else
      select title into gt from groups where id = gid;
      perform public.push_enqueue('r:g:' || new.message_id || ':' || new.user_id, array[owner], jsonb_build_object(
        'event_id', 'r:g:' || new.message_id || ':' || new.user_id, 'kind', 'group', 'gid', gid, 'msg_id', new.message_id,
        'title', coalesce(gt, 'Tia'), 'body', coalesce(nm, '') || ': ' || new.emoji || ' به پیام شما واکنش نشان داد', 'ts', extract(epoch from now())::bigint));
    end if;
  exception when others then
    null;
  end;
  return new;
end $$;
drop trigger if exists push_on_reaction on public.reactions;
create trigger push_on_reaction after insert on public.reactions for each row execute function public.push_on_reaction();
