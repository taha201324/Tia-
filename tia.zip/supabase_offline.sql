-- اجرا شود در Supabase > SQL Editor
-- جلوگیری از ارسال تکراری پیام هنگام تلاش دوباره (صف ارسال آفلاین)

alter table public.messages add column if not exists client_id text;
create unique index if not exists messages_client_id_uq on public.messages (sender_id, client_id) where client_id is not null;

alter table public.group_messages add column if not exists client_id text;
create unique index if not exists group_messages_client_id_uq on public.group_messages (sender_id, client_id) where client_id is not null;
