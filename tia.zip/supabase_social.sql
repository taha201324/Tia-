-- اجرا شود بعد از supabase.sql و supabase_files.sql

-- پروفایل
alter table profiles add column if not exists username text unique;
alter table profiles add column if not exists bio text not null default '';
alter table profiles add column if not exists avatar_path text;
alter table profiles add column if not exists is_private boolean not null default false;
alter table profiles add column if not exists verified boolean not null default false;

-- کاربران نمی‌توانند نشان تایید را خودشان بزنند
revoke update on profiles from authenticated;
grant update (name, username, bio, avatar_path, is_private) on profiles to authenticated;
revoke insert on profiles from authenticated;
grant insert (id, phone, name, username) on profiles to authenticated;

-- بررسی آزاد بودن شماره و نام کاربری قبل از ثبت‌نام
create or replace function public.signup_available(p_phone text, p_username text)
returns boolean language sql security definer set search_path = public as $$
  select not exists (select 1 from profiles where phone = p_phone or username = p_username);
$$;
grant execute on function public.signup_available(text, text) to anon, authenticated;

-- وضعیت خوانده‌شدن پیام
alter table messages add column if not exists read_at timestamptz;
revoke update on messages from authenticated;
grant update (read_at) on messages to authenticated;
create policy "messages mark read" on messages for update to authenticated
  using (receiver_id = auth.uid()) with check (receiver_id = auth.uid());

-- دنبال کردن
create table follows (
  follower_id uuid not null references profiles(id) on delete cascade,
  followee_id uuid not null references profiles(id) on delete cascade,
  status text not null default 'accepted' check (status in ('pending', 'accepted')),
  created_at timestamptz not null default now(),
  primary key (follower_id, followee_id)
);
alter table follows enable row level security;
create policy "follows read" on follows for select to authenticated using (true);
create policy "follows insert" on follows for insert to authenticated with check (
  follower_id = auth.uid() and follower_id <> followee_id and
  status = case when (select is_private from profiles where id = follows.followee_id) then 'pending' else 'accepted' end
);
revoke update on follows from authenticated;
grant update (status) on follows to authenticated;
create policy "follows accept" on follows for update to authenticated
  using (followee_id = auth.uid()) with check (followee_id = auth.uid());
create policy "follows delete" on follows for delete to authenticated
  using (follower_id = auth.uid() or followee_id = auth.uid());

-- پست‌ها
create table posts (
  id bigint generated always as identity primary key,
  author_id uuid not null references profiles(id) on delete cascade,
  body text not null default '',
  image_path text,
  repost_of bigint references posts(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table likes (
  post_id bigint not null references posts(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  primary key (post_id, user_id)
);
create table saves (
  post_id bigint not null references posts(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  primary key (post_id, user_id)
);
create table comments (
  id bigint generated always as identity primary key,
  post_id bigint not null references posts(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);
alter table posts enable row level security;
alter table likes enable row level security;
alter table saves enable row level security;
alter table comments enable row level security;

create policy "posts read" on posts for select to authenticated using (
  author_id = auth.uid()
  or exists (select 1 from profiles p where p.id = posts.author_id and not p.is_private)
  or exists (select 1 from follows f where f.follower_id = auth.uid() and f.followee_id = posts.author_id and f.status = 'accepted')
);
create policy "posts insert" on posts for insert to authenticated with check (author_id = auth.uid());
create policy "posts delete" on posts for delete to authenticated using (author_id = auth.uid());

create policy "likes read" on likes for select to authenticated using (exists (select 1 from posts p where p.id = likes.post_id));
create policy "likes insert" on likes for insert to authenticated with check (user_id = auth.uid() and exists (select 1 from posts p where p.id = likes.post_id));
create policy "likes delete" on likes for delete to authenticated using (user_id = auth.uid());

create policy "saves own" on saves for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "comments read" on comments for select to authenticated using (exists (select 1 from posts p where p.id = comments.post_id));
create policy "comments insert" on comments for insert to authenticated with check (user_id = auth.uid() and exists (select 1 from posts p where p.id = comments.post_id));
create policy "comments delete" on comments for delete to authenticated using (user_id = auth.uid());

-- حافظه‌ی عکس‌ها
insert into storage.buckets (id, name, public, file_size_limit) values ('avatars', 'avatars', true, 5242880) on conflict (id) do nothing;
insert into storage.buckets (id, name, public, file_size_limit) values ('post-images', 'post-images', false, 10485760) on conflict (id) do nothing;

create policy "avatars upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "post images upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'post-images' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "post images read" on storage.objects for select to authenticated using (
  bucket_id = 'post-images' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (select 1 from public.posts p where p.image_path = storage.objects.name)
  )
);
