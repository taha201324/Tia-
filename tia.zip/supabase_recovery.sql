-- اجرا شود در Supabase > SQL Editor
-- بازیابی رمز با کد بازیابی + بررسی وجود حساب هنگام ورود

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.recovery_codes (
  user_id uuid primary key references auth.users(id) on delete cascade,
  code_hash text not null,
  failed int not null default 0,
  locked_until timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.recovery_codes enable row level security;
-- عمداً هیچ policy ای ندارد: فقط توابع زیر به آن دسترسی دارند.

-- آیا حسابی با این ایمیل (شماره) وجود دارد؟
create or replace function public.account_exists(p_email text)
returns boolean
language sql
security definer
set search_path = public, auth
as $$
  select exists (select 1 from auth.users where email = lower(p_email));
$$;
revoke all on function public.account_exists(text) from public;
grant execute on function public.account_exists(text) to anon, authenticated;

-- ساخت یا تعویض کد بازیابی (فقط برای کاربر واردشده)
create or replace function public.set_recovery_code(p_code text)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if auth.uid() is null then
    raise exception 'not authenticated';
  end if;
  if length(coalesce(p_code, '')) < 12 then
    raise exception 'code too short';
  end if;
  insert into public.recovery_codes (user_id, code_hash)
  values (auth.uid(), crypt(upper(p_code), gen_salt('bf')))
  on conflict (user_id) do update
    set code_hash = excluded.code_hash, failed = 0, locked_until = null, updated_at = now();
end;
$$;
revoke all on function public.set_recovery_code(text) from public;
grant execute on function public.set_recovery_code(text) to authenticated;

-- آیا کاربر کد بازیابی دارد؟
create or replace function public.has_recovery_code()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (select 1 from public.recovery_codes where user_id = auth.uid());
$$;
revoke all on function public.has_recovery_code() from public;
grant execute on function public.has_recovery_code() to authenticated;

-- تعویض رمز با کد بازیابی (بدون ورود). پس از ۵ کد اشتباه، ۳۰ دقیقه قفل می‌شود.
create or replace function public.reset_password_with_code(p_email text, p_code text, p_new text)
returns boolean
language plpgsql
security definer
set search_path = public, auth, extensions
as $$
declare
  uid uuid;
  rc public.recovery_codes%rowtype;
begin
  if length(coalesce(p_new, '')) < 6 then
    raise exception 'weak password';
  end if;
  select id into uid from auth.users where email = lower(p_email);
  if uid is null then
    perform pg_sleep(1);
    return false;
  end if;
  select * into rc from public.recovery_codes where user_id = uid for update;
  if not found then
    perform pg_sleep(1);
    return false;
  end if;
  if rc.locked_until is not null and rc.locked_until > now() then
    return false;
  end if;
  if rc.code_hash = crypt(upper(p_code), rc.code_hash) then
    update auth.users
      set encrypted_password = crypt(p_new, gen_salt('bf')), updated_at = now()
      where id = uid;
    update public.recovery_codes set failed = 0, locked_until = null where user_id = uid;
    begin
      delete from auth.sessions where user_id = uid;
    exception when others then
      null;
    end;
    return true;
  end if;
  update public.recovery_codes
    set failed = case when failed + 1 >= 5 then 0 else failed + 1 end,
        locked_until = case when failed + 1 >= 5 then now() + interval '30 minutes' else locked_until end
    where user_id = uid;
  perform pg_sleep(1);
  return false;
end;
$$;
revoke all on function public.reset_password_with_code(text, text, text) from public;
grant execute on function public.reset_password_with_code(text, text, text) to anon, authenticated;
