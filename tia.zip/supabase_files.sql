-- اجرا شود بعد از supabase.sql (برای ارسال عکس، فایل و صدا)
alter table messages add column if not exists kind text not null default 'text';
alter table messages add column if not exists file_path text;
alter table messages add column if not exists file_name text;
alter table messages alter column text set default '';

insert into storage.buckets (id, name, public, file_size_limit)
values ('chat-files', 'chat-files', false, 26214400)
on conflict (id) do nothing;

create policy "chat files upload" on storage.objects for insert to authenticated
with check (bucket_id = 'chat-files' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "chat files read" on storage.objects for select to authenticated
using (
  bucket_id = 'chat-files' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (
      select 1 from public.messages m
      where m.file_path = storage.objects.name
        and (m.sender_id = auth.uid() or m.receiver_id = auth.uid())
    )
  )
);
