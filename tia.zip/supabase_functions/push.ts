import { createClient } from "npm:@supabase/supabase-js@2";
import { SignJWT, importPKCS8 } from "npm:jose@5";

const SECRET = Deno.env.get("PUSH_SECRET") ?? "";
const sa = JSON.parse(Deno.env.get("FIREBASE_SERVICE_ACCOUNT") ?? "{}");
const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

let cached: { token: string; exp: number } | null = null;

async function accessToken(): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (cached && cached.exp - 60 > now) return cached.token;
  const key = await importPKCS8(sa.private_key, "RS256");
  const jwt = await new SignJWT({ scope: "https://www.googleapis.com/auth/firebase.messaging" })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(sa.client_email)
    .setSubject(sa.client_email)
    .setAudience("https://oauth2.googleapis.com/token")
    .setIssuedAt(now)
    .setExpirationTime(now + 3600)
    .sign(key);
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt }),
  });
  const j = await r.json();
  cached = { token: j.access_token, exp: now + (j.expires_in ?? 3600) };
  return cached.token;
}

const preview = (r: any) =>
  r.kind === "image" ? "📷 عکس" : r.kind === "audio" ? "🎤 پیام صوتی" : r.kind === "file" ? "📎 فایل" : r.kind === "poll" ? "📊 نظرسنجی" : (r.text ?? "");

async function nameOf(id: string): Promise<string> {
  const { data } = await db.from("profiles").select("name").eq("id", id).maybeSingle();
  return data?.name ?? "کاربر";
}

async function send(tokens: any[], title: string, body: string, data: Record<string, string>, canHide: boolean) {
  if (!tokens.length) return;
  const at = await accessToken();
  for (const t of tokens) {
    const res = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
      method: "POST",
      headers: { Authorization: `Bearer ${at}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        message: {
          token: t.token,
          notification: { title, body: canHide && !t.preview ? "پیام جدید" : body },
          data,
          android: { priority: "HIGH", notification: { tag: data.tag } },
        },
      }),
    });
    if (!res.ok) {
      const e = await res.text();
      if (e.includes("UNREGISTERED") || e.includes("NOT_FOUND")) await db.from("device_tokens").delete().eq("token", t.token);
      else console.error("fcm error", e);
    }
  }
}

async function onMessage(r: any) {
  if (r.sender_id === r.receiver_id) return;
  const { data: pref } = await db.from("chat_prefs").select("muted").eq("user_id", r.receiver_id).eq("scope", "d").eq("target", r.sender_id).maybeSingle();
  if (pref?.muted) return;
  const { data: toks } = await db.from("device_tokens").select("token,preview").eq("user_id", r.receiver_id).eq("n_messages", true);
  await send(toks ?? [], await nameOf(r.sender_id), preview(r), { type: "d", id: r.sender_id, tag: "d:" + r.sender_id }, true);
}

async function onGroupMessage(r: any) {
  const { data: g } = await db.from("groups").select("title").eq("id", r.group_id).maybeSingle();
  const { data: mem } = await db.from("group_members").select("user_id").eq("group_id", r.group_id).neq("user_id", r.sender_id);
  const ids = (mem ?? []).map((m: any) => m.user_id);
  if (!ids.length) return;
  const { data: muted } = await db.from("chat_prefs").select("user_id").eq("scope", "g").eq("target", String(r.group_id)).eq("muted", true).in("user_id", ids);
  const mutedSet = new Set((muted ?? []).map((m: any) => m.user_id));
  const rec = ids.filter((i: string) => !mutedSet.has(i));
  if (!rec.length) return;
  const { data: toks } = await db.from("device_tokens").select("token,preview").in("user_id", rec).eq("n_groups", true);
  await send(toks ?? [], g?.title ?? "گروه", `${await nameOf(r.sender_id)}: ${preview(r)}`, { type: "g", id: String(r.group_id), tag: "g:" + r.group_id }, true);
}

async function onNotification(r: any) {
  const phrases: Record<string, string> = {
    like: "پست شما را پسندید",
    comment: "برای پست شما نظر گذاشت",
    follow: "شما را دنبال کرد",
    follow_request: "درخواست دنبال‌کردن فرستاد",
    follow_accept: "درخواست دنبال‌کردن شما را پذیرفت",
    mention: "شما را منشن کرد",
  };
  const { data: toks } = await db.from("device_tokens").select("token,preview").eq("user_id", r.user_id).eq("n_social", true);
  await send(toks ?? [], await nameOf(r.actor_id), phrases[r.kind] ?? "فعالیت جدید", { type: "social", id: String(r.id), tag: "n:" + r.id }, false);
}

Deno.serve(async (req) => {
  if (!SECRET || req.headers.get("x-push-secret") !== SECRET) return new Response("forbidden", { status: 403 });
  try {
    const { table, record } = await req.json();
    if (table === "messages") await onMessage(record);
    else if (table === "group_messages") await onGroupMessage(record);
    else if (table === "notifications") await onNotification(record);
  } catch (e) {
    console.error(e);
  }
  return new Response("ok");
});
