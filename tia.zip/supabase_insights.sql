-- آمار بازدید پست‌ها (بعد از supabase_social.sql اجرا شود)
create table if not exists post_views (
  post_id bigint not null references posts(id) on delete cascade,
  viewer_id uuid not null references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, viewer_id)
);
alter table post_views enable row level security;

drop policy if exists "post views add" on post_views;
create policy "post views add" on post_views for insert to authenticated
  with check (viewer_id = auth.uid() and exists (select 1 from posts p where p.id = post_views.post_id and p.author_id <> auth.uid()));

drop policy if exists "post views read" on post_views;
create policy "post views read" on post_views for select to authenticated
  using (exists (select 1 from posts p where p.id = post_views.post_id and p.author_id = auth.uid()));
