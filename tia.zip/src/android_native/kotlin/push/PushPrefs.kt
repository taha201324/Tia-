package com.example.tia.push

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Small JSON file in noBackupFilesDir (so device id / token are never restored onto another phone
 * through Android backup). All access is synchronized.
 */
object PushPrefs {
    private const val FILE = "tia_push.json"
    private const val MAX_SEEN = 200
    private val lock = Any()

    data class Config(
        val deviceId: String,
        val url: String?,          // Supabase project URL (https://xxxx.supabase.co)
        val anon: String?,         // Supabase anon (public) key
        val token: String?,
        val userId: String?,
        val enabled: Boolean,
        val authFailed: Boolean,
    ) {
        val configured: Boolean get() = !url.isNullOrEmpty() && !anon.isNullOrEmpty() && !token.isNullOrEmpty()
    }

    private fun file(c: Context) = File(c.applicationContext.noBackupFilesDir, FILE)

    private fun load(c: Context): JSONObject = try {
        val f = file(c)
        if (f.exists()) JSONObject(f.readText()) else JSONObject()
    } catch (_: Exception) {
        JSONObject()
    }

    private fun store(c: Context, o: JSONObject) {
        val f = file(c)
        val tmp = File(f.parentFile, "$FILE.tmp")
        tmp.writeText(o.toString())
        if (!tmp.renameTo(f)) { f.writeText(o.toString()); tmp.delete() }
    }

    fun read(c: Context): Config = synchronized(lock) {
        val o = load(c)
        var id = o.optString("device_id", "")
        if (id.isEmpty()) {
            id = UUID.randomUUID().toString()
            o.put("device_id", id)
            store(c, o)
        }
        Config(
            id,
            o.optString("url").ifEmpty { null },
            o.optString("anon").ifEmpty { null },
            o.optString("token").ifEmpty { null },
            o.optString("user_id").ifEmpty { null },
            o.optBoolean("enabled", true),
            o.optBoolean("auth_failed", false),
        )
    }

    fun deviceId(c: Context): String = read(c).deviceId

    fun save(c: Context, url: String, anon: String, token: String, userId: String?, enabled: Boolean) = synchronized(lock) {
        val o = load(c)
        o.put("url", url).put("anon", anon).put("token", token).put("user_id", userId ?: "")
            .put("enabled", enabled).put("auth_failed", false)
        store(c, o)
    }

    fun setEnabled(c: Context, enabled: Boolean) = synchronized(lock) {
        store(c, load(c).put("enabled", enabled))
    }

    fun setAuthFailed(c: Context, v: Boolean) = synchronized(lock) {
        store(c, load(c).put("auth_failed", v))
    }

    /** Forget account credentials (logout). The device id stays; seen-events are dropped. */
    fun clear(c: Context) = synchronized(lock) {
        val o = load(c)
        o.remove("url"); o.remove("anon"); o.remove("token"); o.remove("user_id"); o.remove("seen")
        o.put("auth_failed", false)
        store(c, o)
    }

    fun hasSeen(c: Context, eventId: String): Boolean = synchronized(lock) {
        val a = load(c).optJSONArray("seen") ?: return false
        for (i in 0 until a.length()) if (a.optString(i) == eventId) return true
        false
    }

    fun markSeen(c: Context, eventId: String) = synchronized(lock) {
        val o = load(c)
        val old = o.optJSONArray("seen") ?: JSONArray()
        val list = ArrayList<String>()
        for (i in 0 until old.length()) list.add(old.optString(i))
        list.add(eventId)
        val trimmed = if (list.size > MAX_SEEN) list.subList(list.size - MAX_SEEN, list.size) else list
        o.put("seen", JSONArray(trimmed))
        store(c, o)
    }
}
