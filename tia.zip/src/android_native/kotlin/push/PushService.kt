package com.example.tia.push

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Tia Push without any own server.
 *
 *  - Notifications are stored in the Supabase table push_outbox (by a database trigger).
 *  - This foreground service keeps a WebSocket to Supabase Realtime. A tiny content-less "hint" arrives on the
 *    device's private channel; the service then downloads the pending notifications (RPC push_fetch),
 *    shows them and confirms them (RPC push_ack).
 *  - Nothing is lost while the phone is offline: on every (re)connect, network change, alarm tick and
 *    app start the service drains the queue again. If Realtime is unreachable the periodic HTTPS polling still works.
 */
class PushService : Service() {
    companion object {
        private const val TAG = "TiaPush"
        const val ACTION_START = "com.example.tia.push.START"
        const val ACTION_TICK = "com.example.tia.push.TICK"
        const val ACTION_RECONNECT = "com.example.tia.push.RECONNECT"
        private const val TICK_MS = 5 * 60 * 1000L
        private const val HEARTBEAT_MS = 25_000L
        private const val MAX_BACKOFF_MS = 60_000L

        fun start(c: Context, reconnect: Boolean = false) {
            val cfg = PushPrefs.read(c)
            if (!cfg.configured || !cfg.enabled || cfg.authFailed || !cfg.instant) return
            val i = Intent(c, PushService::class.java).setAction(if (reconnect) ACTION_RECONNECT else ACTION_START)
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) {          // e.g. ForegroundServiceStartNotAllowedException on Android 12+ from background
                Log.w(TAG, "cannot start service now: ${e.javaClass.simpleName}")
                PushState.lastError = "start_not_allowed"
            }
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, PushService::class.java))
            PushState.state = "stopped"
        }

        fun topicFor(token: String): String {
            val h = MessageDigest.getInstance("SHA-256").digest(token.toByteArray()).joinToString("") { "%02x".format(it) }
            return "push:" + h.substring(0, 32)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var ws: OkHttpClient? = null
    private var socket: WebSocket? = null
    private var gen = 0
    private var attempt = 0
    private var joined = false
    private var destroyed = false
    private var hbPending = false
    private var refCounter = 0
    private var joinRef = ""
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private val draining = AtomicBoolean(false)
    @Volatile private var drainAgain = false

    private val reconnectRunnable = Runnable { connect() }
    private val heartbeat = object : Runnable {
        override fun run() {
            if (destroyed || socket == null) return
            if (hbPending) {                       // no reply to the last heartbeat: the socket is half-dead
                Log.i(TAG, "heartbeat missed, reconnecting")
                socket?.cancel()                   // -> onFailure -> disconnected() -> backoff reconnect
                return
            }
            hbPending = true
            socket?.send(JSONObject().put("topic", "phoenix").put("event", "heartbeat").put("payload", JSONObject()).put("ref", nextRef()).toString())
            main.postDelayed(this, HEARTBEAT_MS)
        }
    }

    // ------------------------------------------------------------------ lifecycle
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val base = OkHttpClient.Builder()
        ws = base.pingInterval(25, TimeUnit.SECONDS).connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS).retryOnConnectionFailure(true).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!promoteToForeground()) { stopSelf(); return START_NOT_STICKY }
        val cfg = PushPrefs.read(this)
        if (!cfg.configured || !cfg.enabled || !cfg.instant) {
            PushState.state = if (cfg.configured) "polling" else "not_configured"
            stopSelf()
            return START_NOT_STICKY
        }
        registerNetworkCallback()
        scheduleTick()
        when (intent?.action) {
            ACTION_TICK -> { drain(); if (!joined) { attempt = 0; connect() } }
            ACTION_RECONNECT -> { attempt = 0; connect(); drain() }       // new credentials: replaces the old socket
            else -> { if (!joined && socket == null) connect(); drain() }
        }
        return START_STICKY
    }

    private fun promoteToForeground(): Boolean = try {
        val n = Notifier.foreground(this)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(Notifier.FGS_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(Notifier.FGS_ID, n)
        }
        true
    } catch (e: Exception) {
        Log.w(TAG, "startForeground refused: ${e.javaClass.simpleName}")
        PushState.lastError = "foreground_refused"
        false
    }

    override fun onDestroy() {
        destroyed = true
        gen++
        main.removeCallbacksAndMessages(null)
        socket?.cancel(); socket = null
        unregisterNetworkCallback()
        cancelTick()
        if (PushState.state != "auth_failed") PushState.state = "stopped"
        ws?.dispatcher?.executorService?.shutdown()
        super.onDestroy()
    }

    private fun nextRef(): String = (++refCounter).toString()

    // ------------------------------------------------------------------ Realtime connection
    @Synchronized private fun connect() {
        if (destroyed) return
        val cfg = PushPrefs.read(this)
        if (!cfg.configured || !cfg.enabled) { PushState.state = "not_configured"; stopSelf(); return }
        if (cfg.authFailed) { PushState.state = "auth_failed"; return }
        val base = cfg.url!!
        if (!base.startsWith("https://")) { PushState.state = "not_configured"; PushState.lastError = "insecure_url"; stopSelf(); return }

        main.removeCallbacks(reconnectRunnable)
        main.removeCallbacks(heartbeat)
        socket?.cancel()                               // never keep two sockets
        socket = null
        joined = false
        val myGen = ++gen
        PushState.state = "connecting"
        val url = "wss://" + base.removePrefix("https://") + "/realtime/v1/websocket?apikey=" + cfg.anon + "&vsn=1.0.0"
        socket = ws!!.newWebSocket(Request.Builder().url(url).build(), Listener(myGen, topicFor(cfg.token!!), cfg.anon!!))
    }

    private fun scheduleReconnect() {
        if (destroyed) return
        val base = minOf(MAX_BACKOFF_MS, 1000L shl minOf(attempt, 6))     // 1,2,4,8,16,32,60 s
        val delay = (base * (0.8 + 0.4 * Math.random())).toLong()        // ±20% jitter
        attempt++
        main.removeCallbacks(reconnectRunnable)
        main.postDelayed(reconnectRunnable, delay)
    }

    private inner class Listener(private val g: Int, private val topic: String, private val anon: String) : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (g != gen) { webSocket.cancel(); return }
            joinRef = nextRef()
            val cfg = JSONObject()
                .put("broadcast", JSONObject().put("self", false).put("ack", false))
                .put("presence", JSONObject().put("key", ""))
                .put("private", false)
            val payload = JSONObject().put("config", cfg).put("access_token", anon)
            webSocket.send(JSONObject().put("topic", "realtime:$topic").put("event", "phx_join").put("payload", payload).put("ref", joinRef).put("join_ref", joinRef).toString())
            main.post { if (g == gen) { hbPending = false; main.removeCallbacks(heartbeat); main.postDelayed(heartbeat, HEARTBEAT_MS) } }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (g != gen) return
            val o = try { JSONObject(text) } catch (_: Exception) { return }
            when (o.optString("event")) {
                "phx_reply" -> {
                    val status = o.optJSONObject("payload")?.optString("status")
                    if (o.optString("topic") == "phoenix") {
                        main.post { if (g == gen) hbPending = false }
                    } else if (o.optString("ref") == joinRef) {
                        if (status == "ok") {
                            main.post {
                                if (g != gen) return@post
                                joined = true; attempt = 0
                                PushState.state = "connected"
                                PushState.lastConnectedAt = System.currentTimeMillis()
                                PushState.lastError = ""
                            }
                            drain()                       // catch up on everything missed while offline
                        } else {
                            PushState.lastError = "join_$status"
                            webSocket.close(1000, null)
                        }
                    }
                }
                "broadcast" -> drain()                   // content-less hint: go and fetch
                "phx_error", "phx_close" -> webSocket.close(1000, null)
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            disconnected(g, code, reason)
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            disconnected(g, -1, t.javaClass.simpleName)
        }
    }

    private fun disconnected(g: Int, code: Int, reason: String) {
        main.post {
            if (g != gen || destroyed) return@post
            joined = false
            socket = null
            main.removeCallbacks(heartbeat)
            PushState.lastError = "$code $reason".trim()
            PushState.state = "disconnected"
            scheduleReconnect()
            drain()            // even if Realtime is blocked, plain HTTPS polling keeps delivering
        }
    }

    private fun markAuthFailed() {
        main.post {
            // token rejected (logout elsewhere / device unregistered): stop until Flutter registers again
            PushPrefs.setAuthFailed(this, true)
            PushState.state = "auth_failed"
            joined = false
            gen++
            socket?.cancel(); socket = null
            main.removeCallbacks(reconnectRunnable)
            main.removeCallbacks(heartbeat)
        }
    }

    // ------------------------------------------------------------------ queue: fetch -> show -> ack
    private fun drain() {
        if (!draining.compareAndSet(false, true)) { drainAgain = true; return }
        val app = applicationContext
        Thread {
            try {
                do {
                    drainAgain = false
                    val r = PushSync.drainBlocking(app)
                    if (r == PushSync.Result.AUTH) markAuthFailed()
                    if (r == PushSync.Result.SKIPPED) main.postDelayed({ drain() }, 2000)   // another sync (poller) was running
                } while (drainAgain && !destroyed)
            } catch (e: Exception) {
                PushState.lastError = "drain_" + e.javaClass.simpleName
            } finally {
                draining.set(false)
            }
        }.start()
    }

    // ------------------------------------------------------------------ periodic check (works in Doze, no special permission)
    private fun tickIntent(): PendingIntent {
        val i = Intent(this, PushService::class.java).setAction(ACTION_TICK)
        val f = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, 77, i, f)
        else PendingIntent.getService(this, 77, i, f)
    }

    private fun scheduleTick() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + TICK_MS, tickIntent())
        } catch (e: Exception) { Log.w(TAG, "alarm refused") }
    }

    private fun cancelTick() {
        try { (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent()) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ network changes
    private fun registerNetworkCallback() {
        if (netCb != null) return
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                main.post {
                    if (destroyed || PushState.state == "auth_failed") return@post
                    drain()                                           // internet is back: fetch what was missed
                    if (!joined) { attempt = 0; connect() }
                }
            }
        }
        try { cm.registerDefaultNetworkCallback(cb); netCb = cb } catch (e: Exception) { Log.w(TAG, "network callback refused") }
    }

    private fun unregisterNetworkCallback() {
        val cb = netCb ?: return
        try { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(cb) } catch (_: Exception) {}
        netCb = null
    }
}
