package com.example.tia.push

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.tia.MainActivity
import com.example.tia.R

object Notifier {
    const val CH_MESSAGES = "tia_messages"
    const val CH_STATUS = "tia_push_status"
    const val FGS_ID = 1
    private const val MAX_LINES = 5
    private val lines = HashMap<String, ArrayList<String>>()

    fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_MESSAGES, "پیام‌های جدید", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "اعلان پیام‌های دریافتی"
                enableVibration(true)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "اتصال اعلان تیا", NotificationManager.IMPORTANCE_MIN).apply {
                description = "نمایش دائمی کوچک برای دریافت آنی اعلان‌ها"
                setShowBadge(false)
            }
        )
    }

    @Suppress("DEPRECATION")
    private fun builder(c: Context, channel: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, channel) else Notification.Builder(c)

    private fun openIntent(c: Context, kind: String, id: String, req: Int): PendingIntent {
        val i = Intent(c, MainActivity::class.java).apply {
            action = "com.example.tia.OPEN_CHAT"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("tia_kind", kind)
            putExtra("tia_id", id)
        }
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun foreground(c: Context): Notification {
        ensureChannels(c)
        val launch = Intent(c, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP }
        val pi = PendingIntent.getActivity(c, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return builder(c, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_tia)
            .setContentTitle("Tia")
            .setContentText("اعلان‌ها فعال است")
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_SECRET)
            .setShowWhen(false)
            .setContentIntent(pi)
            .also { if (Build.VERSION.SDK_INT < 26) it.setPriority(Notification.PRIORITY_MIN) }
            .build()
    }

    fun areEnabled(c: Context): Boolean =
        c.getSystemService(NotificationManager::class.java).areNotificationsEnabled()

    /** Stable id per conversation so new messages update the same notification instead of stacking. */
    private fun idFor(key: String) = (key.hashCode() and 0x3fffffff) + 100

    fun showMessage(c: Context, kind: String, peer: String?, gid: Long?, title: String, body: String, tsSec: Long) {
        ensureChannels(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val key = if (kind == "group") "g:$gid" else "d:$peer"
        val openId = if (kind == "group") (gid ?: 0L).toString() else (peer ?: "")
        val nid = idFor(key)

        val list: ArrayList<String>
        synchronized(lines) {
            list = lines.getOrPut(key) { ArrayList() }
            // if the previous notification of this chat was dismissed/opened, start a fresh list
            val active = try { nm.activeNotifications.any { it.id == nid } } catch (_: Exception) { true }
            if (!active) list.clear()
            list.add(body)
            while (list.size > MAX_LINES) list.removeAt(0)
        }

        val b = builder(c, CH_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_tia)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setWhen(if (tsSec > 0) tsSec * 1000 else System.currentTimeMillis())
            .setShowWhen(true)
            .setContentIntent(openIntent(c, if (kind == "group") "group" else "dm", openId, nid))
        if (list.size > 1) {
            val st = Notification.InboxStyle().setBigContentTitle(title)
            synchronized(lines) { list.forEach { st.addLine(it) } }
            b.setStyle(st)
        } else {
            b.setStyle(Notification.BigTextStyle().bigText(body))
        }
        if (Build.VERSION.SDK_INT < 26) {
            @Suppress("DEPRECATION")
            b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
        }
        nm.notify(nid, b.build())
    }

    fun cancelAll(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        try { nm.activeNotifications.filter { it.id != FGS_ID }.forEach { nm.cancel(it.id) } } catch (_: Exception) {}
        synchronized(lines) { lines.clear() }
    }
}
