package com.example.tia.push

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock

/**
 * "Polling mode" (default): no foreground service and therefore NO permanent notification.
 * The system wakes the app every few minutes (AlarmManager, works in Doze) and every ~15 min as a backup (JobScheduler,
 * survives reboot) to download pending notifications.
 */
object Poller {
    const val ACTION_POLL = "com.example.tia.push.POLL"
    private const val EVERY_MS = 2 * 60 * 1000L
    private const val JOB_ID = 4177

    private fun pi(c: Context): PendingIntent = PendingIntent.getBroadcast(
        c, 78, Intent(c, PollReceiver::class.java).setAction(ACTION_POLL),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(c: Context) {
        try {
            (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                .setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + EVERY_MS, pi(c))
        } catch (_: Exception) {}
    }

    fun cancel(c: Context) {
        try { (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c)) } catch (_: Exception) {}
    }

    fun scheduleJob(c: Context) {
        try {
            val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            if (js.getPendingJob(JOB_ID) != null) return
            js.schedule(
                JobInfo.Builder(JOB_ID, ComponentName(c, PollJobService::class.java))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(15 * 60 * 1000L)
                    .setPersisted(true)
                    .build()
            )
        } catch (_: Exception) {}
    }

    fun cancelJob(c: Context) {
        try { (c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).cancel(JOB_ID) } catch (_: Exception) {}
    }
}

class PollReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Poller.ACTION_POLL) return
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                val cfg = PushPrefs.read(app)
                if (cfg.configured && cfg.enabled && !cfg.authFailed && !cfg.instant) {
                    PushSync.drainBlocking(app)
                    Poller.schedule(app)
                }
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }.start()
    }
}

class PollJobService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val app = applicationContext
        Thread {
            try {
                val cfg = PushPrefs.read(app)
                if (cfg.configured && cfg.enabled && !cfg.authFailed && !cfg.instant) PushSync.drainBlocking(app)
            } catch (_: Exception) {
            } finally {
                jobFinished(params, false)
            }
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}
