package com.example.tia.push

import android.content.Context

/**
 * Chooses how notifications are received:
 *  - polling (default): no foreground service, no permanent notification
 *  - instant (user switch): foreground service with a live Realtime connection
 */
object PushMode {
    fun apply(c: Context) {
        val app = c.applicationContext
        val cfg = PushPrefs.read(app)
        if (!cfg.configured || !cfg.enabled || cfg.authFailed || !Notifier.areEnabled(app)) {
            stopAll(app)
            return
        }
        if (cfg.instant) {
            Poller.cancel(app); Poller.cancelJob(app)
            PushService.start(app)
        } else {
            PushService.stop(app)
            Poller.schedule(app)
            Poller.scheduleJob(app)
            PushState.state = "polling"
            PushSync.drainAsync(app)         // catch up right now
        }
    }

    fun stopAll(c: Context) {
        val app = c.applicationContext
        PushService.stop(app)
        Poller.cancel(app)
        Poller.cancelJob(app)
    }
}
