package com.example.tia.push

import android.content.Context
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Downloads pending notifications from Supabase (RPC push_fetch), shows them and confirms them (push_ack). */
object PushSync {
    private const val TAG = "TiaPush"
    private const val PAGE = 50
    private val JSON = "application/json; charset=utf-8".toMediaType()
    private val busy = AtomicBoolean(false)

    enum class Result { OK, AUTH, ERROR, SKIPPED }

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS)
            .callTimeout(25, TimeUnit.SECONDS).build()
    }

    private fun rpc(cfg: PushPrefs.Config, fn: String, body: JSONObject): Response =
        http.newCall(
            Request.Builder().url("${cfg.url}/rest/v1/rpc/$fn")
                .header("apikey", cfg.anon!!).header("Authorization", "Bearer ${cfg.anon}")
                .post(body.toString().toRequestBody(JSON)).build()
        ).execute()

    /** Blocking; call from a background thread. Only one drain runs at a time. */
    fun drainBlocking(ctx: Context): Result {
        if (!busy.compareAndSet(false, true)) return Result.SKIPPED
        try {
            var pages = 0
            while (pages++ < 10) {
                val cfg = PushPrefs.read(ctx)
                if (!cfg.configured || !cfg.enabled || cfg.authFailed) return Result.OK
                val req = JSONObject().put("p_device_id", cfg.deviceId).put("p_token", cfg.token)
                val items: JSONArray = rpc(cfg, "push_fetch", req).use { r ->
                    if (r.code == 401 || r.code == 403) {
                        // token rejected (logout elsewhere / device unregistered): stop until the app registers again
                        PushPrefs.setAuthFailed(ctx, true)
                        PushState.state = "auth_failed"
                        return Result.AUTH
                    }
                    if (!r.isSuccessful) { PushState.lastError = "fetch_${r.code}"; return Result.ERROR }
                    JSONArray(r.body?.string() ?: "[]")
                }
                PushState.lastError = ""
                if (items.length() == 0) return Result.OK
                val done = JSONArray()
                for (i in 0 until items.length()) {
                    val row = items.getJSONObject(i)
                    try {
                        handleItem(ctx, row.getJSONObject("payload"))
                        done.put(row.getLong("id"))
                    } catch (e: Exception) {
                        Log.w(TAG, "show failed: ${e.javaClass.simpleName}")      // not acked => fetched again later
                    }
                }
                if (done.length() > 0) {
                    rpc(cfg, "push_ack", JSONObject().put("p_device_id", cfg.deviceId).put("p_token", cfg.token).put("p_ids", done)).use { r ->
                        if (!r.isSuccessful) { PushState.lastError = "ack_${r.code}"; return Result.ERROR }
                    }
                }
                if (items.length() < PAGE) return Result.OK
            }
            return Result.OK
        } catch (e: Exception) {
            PushState.lastError = "sync_" + e.javaClass.simpleName
            return Result.ERROR
        } finally {
            busy.set(false)
        }
    }

    fun drainAsync(ctx: Context) {
        val app = ctx.applicationContext
        Thread { drainBlocking(app) }.start()
    }

    private fun handleItem(ctx: Context, p: JSONObject) {
        val event = p.optString("event_id")
        val cfg = PushPrefs.read(ctx)
        val skip = (event.isNotEmpty() && PushPrefs.hasSeen(ctx, event)) ||   // already shown (lost ACK / retry)
            !cfg.enabled ||
            PushState.foreground ||                                          // app is open: in-app UI already shows it
            !Notifier.areEnabled(ctx)                                        // notifications off in system settings
        if (skip) return
        Notifier.showMessage(
            ctx, p.optString("kind"),
            p.optString("peer").ifEmpty { null },
            if (p.has("gid")) p.optLong("gid") else null,
            p.optString("title").ifEmpty { "Tia" },
            p.optString("body"),
            p.optLong("ts", 0L),
        )
        if (event.isNotEmpty()) PushPrefs.markSeen(ctx, event)
    }
}
