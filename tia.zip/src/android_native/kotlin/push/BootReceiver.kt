package com.example.tia.push

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the push connection after reboot or app update (only if the user is logged in and push is enabled). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> PushService.start(context.applicationContext)
        }
    }
}
