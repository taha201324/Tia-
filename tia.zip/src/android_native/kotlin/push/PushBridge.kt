package com.example.tia.push

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/** Flutter <-> native bridge. Channel name: tia/push */
class PushBridge(messenger: BinaryMessenger, private val activity: Activity) : MethodChannel.MethodCallHandler {
    companion object {
        const val PERM_REQ = 7701
        private const val POST_NOTIFICATIONS = "android.permission.POST_NOTIFICATIONS"
    }

    private val channel = MethodChannel(messenger, "tia/push")
    private var permResult: MethodChannel.Result? = null

    init { channel.setMethodCallHandler(this) }

    fun dispose() { channel.setMethodCallHandler(null) }

    fun onPermissionResult(requestCode: Int, grants: IntArray) {
        if (requestCode != PERM_REQ) return
        permResult?.success(grants.isNotEmpty() && grants[0] == PackageManager.PERMISSION_GRANTED)
        permResult = null
    }

    private fun status(): Map<String, Any?> {
        val ctx = activity.applicationContext
        val cfg = PushPrefs.read(ctx)
        val pm = ctx.getSystemService(PowerManager::class.java)
        return mapOf(
            "state" to PushState.state,
            "configured" to cfg.configured,
            "userId" to cfg.userId,
            "enabled" to cfg.enabled,
            "authFailed" to cfg.authFailed,
            "notificationsAllowed" to Notifier.areEnabled(ctx),
            "ignoringBatteryOptimizations" to pm.isIgnoringBatteryOptimizations(ctx.packageName),
            "lastConnectedAt" to PushState.lastConnectedAt,
            "lastError" to PushState.lastError,
            "sdk" to Build.VERSION.SDK_INT,
            "manufacturer" to Build.MANUFACTURER,
        )
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        val ctx = activity.applicationContext
        try {
            when (call.method) {
                "deviceId" -> result.success(PushPrefs.deviceId(ctx))
                "configure" -> {
                    val url = (call.argument<String>("url") ?: "").trimEnd('/')
                    val anon = call.argument<String>("anon") ?: ""
                    val token = call.argument<String>("token") ?: ""
                    if (!url.startsWith("https://")) { result.error("insecure_url", "only https:// is allowed", null); return }
                    if (anon.length < 20) { result.error("bad_key", "anon key missing", null); return }
                    if (token.length < 16) { result.error("bad_token", "token too short", null); return }
                    PushPrefs.save(ctx, url, anon, token, call.argument<String>("userId"), call.argument<Boolean>("enabled") ?: true)
                    Notifier.ensureChannels(ctx)
                    // the service replaces its socket (never two connections at the same time)
                    if (Notifier.areEnabled(ctx)) PushService.start(ctx, reconnect = true) else PushState.state = "stopped"
                    result.success(status())
                }
                "setEnabled" -> {
                    val on = call.argument<Boolean>("enabled") ?: true
                    PushPrefs.setEnabled(ctx, on)
                    if (on) { if (Notifier.areEnabled(ctx)) PushService.start(ctx) } else PushService.stop(ctx)
                    result.success(status())
                }
                "clear" -> {
                    PushService.stop(ctx)
                    PushPrefs.clear(ctx)
                    Notifier.cancelAll(ctx)
                    PushState.state = "stopped"
                    result.success(true)
                }
                "start" -> { PushService.start(ctx); result.success(status()) }
                "status" -> result.success(status())
                "requestNotificationPermission" -> {
                    if (Build.VERSION.SDK_INT < 33 || activity.checkSelfPermission(POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        result.success(Notifier.areEnabled(ctx))
                    } else if (permResult != null) {
                        result.error("busy", "permission request in progress", null)
                    } else {
                        permResult = result
                        activity.requestPermissions(arrayOf(POST_NOTIFICATIONS), PERM_REQ)
                    }
                }
                "openNotificationSettings" -> {
                    activity.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
                    result.success(true)
                }
                "openChannelSettings" -> {
                    Notifier.ensureChannels(ctx)
                    val i = if (Build.VERSION.SDK_INT >= 26)
                        Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).putExtra(Settings.EXTRA_CHANNEL_ID, Notifier.CH_STATUS)
                    else
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    activity.startActivity(i)
                    result.success(true)
                }
                "openBatterySettings" -> {
                    // opens the system list of battery-optimization exemptions (needs no extra permission)
                    try {
                        activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (_: Exception) {
                        activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                    }
                    result.success(true)
                }
                "takePendingOpen" -> {
                    val k = PushState.pendingKind; val id = PushState.pendingId
                    PushState.pendingKind = null; PushState.pendingId = null
                    result.success(if (k != null && id != null) mapOf("kind" to k, "id" to id) else null)
                }
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("native_error", e.javaClass.simpleName, null)
        }
    }
}
