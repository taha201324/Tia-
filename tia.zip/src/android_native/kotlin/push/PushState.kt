package com.example.tia.push

/** In-process state shared between the activity, the bridge and the service. */
object PushState {
    @Volatile var foreground: Boolean = false          // true while MainActivity is started (visible)
    @Volatile var state: String = "stopped"            // stopped | connecting | connected | disconnected | auth_failed | not_configured
    @Volatile var lastConnectedAt: Long = 0
    @Volatile var lastError: String = ""

    // chat the user tapped a notification for, waiting for Flutter to open it
    @Volatile var pendingKind: String? = null
    @Volatile var pendingId: String? = null
}
