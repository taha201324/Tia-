package com.example.tia

import android.content.Intent
import android.os.Bundle
import com.example.tia.push.PushBridge
import com.example.tia.push.PushMode
import com.example.tia.push.PushState
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {
    private var bridge: PushBridge? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readOpenIntent(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        bridge = PushBridge(flutterEngine.dartExecutor.binaryMessenger, this)
    }

    override fun cleanUpFlutterEngine(flutterEngine: FlutterEngine) {
        bridge?.dispose(); bridge = null
        super.cleanUpFlutterEngine(flutterEngine)
    }

    override fun onStart() {
        super.onStart()
        PushState.foreground = true
        PushMode.apply(applicationContext)         // no-op unless logged in with push enabled; also catches up on missed notifications
    }

    override fun onStop() {
        PushState.foreground = false
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readOpenIntent(intent)
    }

    private fun readOpenIntent(i: Intent?) {
        val kind = i?.getStringExtra("tia_kind") ?: return
        val id = i.getStringExtra("tia_id") ?: return
        PushState.pendingKind = kind
        PushState.pendingId = id
        i.removeExtra("tia_kind"); i.removeExtra("tia_id")
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        bridge?.onPermissionResult(requestCode, grantResults)
    }
}
