import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'gif.dart';
import 'main.dart';

const emojiCats = <String, String>{
  '😀': '😀😃😄😁😆😅🤣😂🙂🙃😉😊😇🥰😍🤩😘😗😚😋😛😜🤪😝🤑🤗🤭🤫🤔🤐🤨😐😑😶😏😒🙄😬😌😔😪🤤😴😷🤒🤕🤢🤮🤧🥵🥶😵🤯🤠🥳😎🤓🧐😕😟🙁😮😯😲😳🥺😦😧😨😰😥😢😭😱😖😣😞😓😩😫🥱😤😡😠🤬😈👿💀💩🤡👻👽🤖',
  '👍': '👍👎👌✌️🤞🤟🤘🤙👈👉👆👇☝️✋🤚🖖👋🤝🙏💪🙌👏🤲🤜🤛✊👊',
  '❤️': '❤️🧡💛💚💙💜🖤🤍🤎💔💕💞💓💗💖💘💝💟✨⭐🌟💫🔥💥🎉🎊',
  '🐱': '🐶🐱🐭🐹🐰🦊🐻🐼🐨🐯🦁🐮🐷🐸🐵🙈🙉🙊🐔🐧🐦🐤🦆🦅🦉🦇🐺🐗🐴🦄🐝🐛🦋🐌🐞🐢🐍🐙🐠🐬🐳🦈🌹🌸🌼🌻🌲🌴🍀',
  '🍕': '🍎🍐🍊🍋🍌🍉🍇🍓🍒🍑🥭🍍🥥🥝🍅🥑🍆🥕🌽🥔🍞🧀🍗🍔🍟🍕🌭🥪🌮🌯🍝🍜🍣🍤🍩🍪🎂🍰🍫🍬🍭☕🍵🥤🍺🍷',
  '⚽': '⚽🏀🏈⚾🎾🏐🏉🎱🏓🏸🥊🥋🎯🎮🎲🎸🎹🎤🎧🚗🚕🚀✈️🚢🏠🏖️🌍🌙☀️☁️🌈⚡❄️',
};

const stickerPack = '😀😂🥰😍😎🤩😭😡🥳🤯😴🤗👍👏🙏💪🔥❤️💔🎉🌹🍕☕⚽🎁🚀🐱🐶🦄🙈😱🤝🥺😘🎂🌙';

class EmojiPanel extends StatefulWidget {
  final void Function(String) onEmoji, onSticker;
  final void Function(GifEntry) onGif;
  final VoidCallback onPickGifFile;
  const EmojiPanel({super.key, required this.onEmoji, required this.onSticker, required this.onGif, required this.onPickGifFile});
  @override
  State<EmojiPanel> createState() => _EmojiPanelState();
}

class _EmojiPanelState extends State<EmojiPanel> with SingleTickerProviderStateMixin {
  late final TabController tab = TabController(length: 3, vsync: this);
  int cat = 1;
  List<String> recent = [];

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => recent = p.getStringList('recent_emoji') ?? []);
    });
  }

  @override
  void dispose() {
    tab.dispose();
    super.dispose();
  }

  Future<void> remember(String e) async {
    recent = [e, ...recent.where((x) => x != e)].take(24).toList();
    final p = await SharedPreferences.getInstance();
    await p.setStringList('recent_emoji', recent);
  }

  @override
  Widget build(BuildContext context) {
    final keys = ['🕘', ...emojiCats.keys];
    final list = cat == 0 ? recent : emojiCats[keys[cat]]!.characters.toList();
    return Container(
      color: card,
      child: Column(children: [
        TabBar(controller: tab, tabs: const [Tab(text: 'ایموجی'), Tab(text: 'استیکر'), Tab(text: 'گیف')]),
        Expanded(
          child: TabBarView(controller: tab, children: [
            Column(children: [
              SizedBox(
                height: 44,
                child: ListView(scrollDirection: Axis.horizontal, children: [
                  for (var i = 0; i < keys.length; i++)
                    InkWell(
                      onTap: () => setState(() => cat = i),
                      child: Container(
                        width: 46,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(border: Border(bottom: BorderSide(color: cat == i ? primary : Colors.transparent, width: 3))),
                        child: Text(keys[i], style: const TextStyle(fontSize: 22)),
                      ),
                    ),
                ]),
              ),
              Expanded(
                child: list.isEmpty
                    ? const Center(child: Text('هنوز ایموجی استفاده نکرده‌اید'))
                    : GridView.builder(
                        padding: const EdgeInsets.all(6),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
                        itemCount: list.length,
                        itemBuilder: (c, i) => InkWell(
                          onTap: () {
                            widget.onEmoji(list[i]);
                            remember(list[i]);
                          },
                          child: Center(child: Text(list[i], style: const TextStyle(fontSize: 26))),
                        ),
                      ),
              ),
            ]),
            GridView.builder(
              padding: const EdgeInsets.all(8),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 5),
              itemCount: stickerPack.characters.length,
              itemBuilder: (c, i) {
                final e = stickerPack.characters.elementAt(i);
                return InkWell(onTap: () => widget.onSticker(e), child: Center(child: Text(e, style: const TextStyle(fontSize: 40))));
              },
            ),
            GifPanel(onGif: widget.onGif, onPickFile: widget.onPickGifFile),
          ]),
        ),
      ]),
    );
  }
}
