import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'cyber.dart';
import 'l10n.dart';
import 'main.dart';
import 'ui_kit.dart';

// ===========================================================================
// تاریخ شمسی و جداکننده‌ی روزها در گفتگو
// ===========================================================================
List<int> toJalali(int gy, int gm, int gd) {
  const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  final gy2 = gm > 2 ? gy + 1 : gy;
  var days = 355666 + 365 * gy + (gy2 + 3) ~/ 4 - (gy2 + 99) ~/ 100 + (gy2 + 399) ~/ 400 + gd + gdm[gm - 1];
  var jy = -1595 + 33 * (days ~/ 12053);
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    jy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  final jm = days < 186 ? 1 + days ~/ 31 : 7 + (days - 186) ~/ 30;
  final jd = days < 186 ? 1 + days % 31 : 1 + (days - 186) % 30;
  return [jy, jm, jd];
}

const _jMonths = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
const _enMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

String _faNum(int n) {
  const d = '۰۱۲۳۴۵۶۷۸۹';
  return n.toString().split('').map((c) => d[int.parse(c)]).join();
}

String dayLabel(DateTime t) {
  final now = DateTime.now();
  final a = DateTime(t.year, t.month, t.day), b = DateTime(now.year, now.month, now.day);
  final diff = b.difference(a).inDays;
  if (diff == 0) return trn('امروز');
  if (diff == 1) return trn('دیروز');
  if (appLang == 'en') return '${_enMonths[t.month - 1]} ${t.day}, ${t.year}';
  final j = toJalali(t.year, t.month, t.day);
  return '${_faNum(j[2])} ${_jMonths[j[1] - 1]} ${_faNum(j[0])}';
}

/// اگر پیام اول یک روز جدید است برچسب روز را برمی‌گرداند (prev = پیام قدیمی‌تر)
String? dayBreak(Map<String, dynamic> m, Map<String, dynamic>? prev) {
  final a = DateTime.tryParse('${m['created_at'] ?? ''}')?.toLocal();
  if (a == null) return null;
  if (prev != null) {
    final b = DateTime.tryParse('${prev['created_at'] ?? ''}')?.toLocal();
    if (b != null && a.year == b.year && a.month == b.month && a.day == b.day) return null;
  }
  return dayLabel(a);
}

Widget daySeparator(String label) => Center(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(color: Color.lerp(card, Colors.black, 0.25)!.withOpacity(0.75), borderRadius: BorderRadius.circular(12)),
        child: Text(label, style: TextStyle(color: cTextDim, fontSize: 11.5, fontWeight: FontWeight.w600)),
      ),
    );

/// پیام فقط ایموجی (حداکثر چند ایموجی) بزرگ نشان داده می‌شود
final RegExp _emojiRe = RegExp(r'^(?:[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}\u{20E3}]|\s)+$', unicode: true);
bool emojiOnly(String s) {
  final t = s.trim();
  return t.isNotEmpty && t.runes.length <= 8 && _emojiRe.hasMatch(t);
}

// ===========================================================================
// کشیدن پیام به چپ = پاسخ (مثل تلگرام)
// ===========================================================================
class SwipeToReply extends StatefulWidget {
  final Widget child;
  final VoidCallback onReply;
  final bool enabled;
  const SwipeToReply({super.key, required this.child, required this.onReply, this.enabled = true});
  @override
  State<SwipeToReply> createState() => _SwipeToReplyState();
}

class _SwipeToReplyState extends State<SwipeToReply> with SingleTickerProviderStateMixin {
  double dx = 0, _from = 0;
  bool fired = false;
  late final AnimationController _ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 200))
    ..addListener(() => setState(() => dx = _from * (1 - Curves.easeOut.transform(_ac.value))));

  @override
  void dispose() {
    _ac.dispose();
    super.dispose();
  }

  void _release({required bool commit}) {
    if (commit && fired) widget.onReply();
    fired = false;
    _from = dx;
    _ac.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.enabled) return widget.child;
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onHorizontalDragUpdate: (d) {
        _ac.stop();
        setState(() {
          dx = (dx + d.delta.dx).clamp(-84.0, 0.0).toDouble();
          if (dx <= -56 && !fired) {
            fired = true;
            HapticFeedback.mediumImpact();
          }
        });
      },
      onHorizontalDragEnd: (_) => _release(commit: true),
      onHorizontalDragCancel: () => _release(commit: false),
      child: Stack(clipBehavior: Clip.none, children: [
        Positioned(
          right: 6,
          top: 0,
          bottom: 0,
          child: Center(
            child: Opacity(
              opacity: (-dx / 56).clamp(0.0, 1.0).toDouble(),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(shape: BoxShape.circle, color: Color.lerp(card, accent, 0.3)),
                child: Icon(Icons.reply_rounded, size: 18, color: accent),
              ),
            ),
          ),
        ),
        Transform.translate(offset: Offset(dx, 0), child: widget.child),
      ]),
    );
  }
}

// ===========================================================================
// دعوت دوستان
// ===========================================================================
String inviteText() {
  final un = (store.people[me]?['username'] as String?) ?? '';
  final who = un.isEmpty ? '' : (appLang == 'en' ? ' My username: @$un.' : ' نام کاربری من: @$un.');
  return appLang == 'en'
      ? 'Hi! I use Tia, a private messenger with translation, summaries and end-to-end encrypted chats.$who Come chat with me 👋'
      : 'سلام! من از «تیا» استفاده می‌کنم؛ پیام‌رسانی امن با ترجمه، خلاصه‌ی پیام و رمزنگاری سرتاسری.$who بیا اینجا گفتگو کنیم 👋';
}

class InviteFriendsPage extends StatelessWidget {
  const InviteFriendsPage({super.key});

  Future<void> _open(BuildContext context, Uri u) async {
    var ok = false;
    try {
      ok = await launchUrl(u, mode: LaunchMode.externalApplication);
    } catch (_) {}
    if (!ok && context.mounted) snack(context, trn('برنامه‌ی مورد نظر روی گوشی پیدا نشد. متن را کپی کنید.'));
  }

  Widget _btn(BuildContext context, IconData i, String t, Color c, VoidCallback f) => Expanded(
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: f,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(color: Color.lerp(card, c, 0.18), borderRadius: BorderRadius.circular(16), border: Border.all(color: c.withOpacity(0.5))),
            child: Column(children: [Icon(i, color: c, size: 26), const SizedBox(height: 6), Text(t, style: TextStyle(color: cText, fontSize: 12.5))]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final text = inviteText();
    return Scaffold(
      appBar: AppBar(title: Text(trn('دعوت دوستان'))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Center(
          child: Container(
            width: 96,
            height: 96,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [primary, accent]),
              boxShadow: [BoxShadow(color: (cy.enabled ? cy.c1 : primary).withOpacity(0.4), blurRadius: 24, spreadRadius: -4)],
            ),
            child: Icon(Icons.person_add_alt_1_rounded, size: 46, color: cOnPrimary),
          ),
        ),
        const SizedBox(height: 18),
        Text(trn('تیا با دوستانت بهتر است'), textAlign: TextAlign.center, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: cText)),
        const SizedBox(height: 8),
        Text(trn('این پیام آماده را از هر راهی که می‌خواهی برای دوستانت بفرست.'), textAlign: TextAlign.center, style: TextStyle(color: cTextDim, height: 1.6)),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: cLine)),
          child: SelectableText(text, style: TextStyle(color: cText, height: 1.8)),
        ),
        const SizedBox(height: 14),
        Row(children: [
          _btn(context, Icons.copy_rounded, trn('کپی'), accent, () {
            Clipboard.setData(ClipboardData(text: text));
            snack(context, trn('کپی شد'));
          }),
          const SizedBox(width: 8),
          _btn(context, Icons.sms_outlined, trn('پیامک'), Colors.greenAccent, () => _open(context, Uri(scheme: 'sms', queryParameters: {'body': text}))),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          _btn(context, Icons.send_rounded, trn('تلگرام'), Colors.lightBlueAccent, () => _open(context, Uri(scheme: 'tg', host: 'msg', queryParameters: {'text': text}))),
          const SizedBox(width: 8),
          _btn(context, Icons.chat_rounded, trn('واتساپ'), Colors.teal, () => _open(context, Uri.https('wa.me', '/', {'text': text}))),
        ]),
      ]),
    );
  }
}

// ===========================================================================
// ابزارهای منوی پیام: لینک، انتخاب متن، اطلاعات، یادآوری
// ===========================================================================
Future<void> openLink(BuildContext context, String u) async {
  var ok = false;
  try {
    ok = await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
  } catch (_) {}
  if (!ok && context.mounted) snack(context, trn('باز نشد'));
}

Future<void> showSelectTextSheet(BuildContext context, String text) => showTiaSheet<void>(
      context,
      (c) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(trn('انتخاب متن'), style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: cText)),
        const SizedBox(height: 4),
        Text(trn('هر بخش را نگه دارید و بکشید تا انتخاب شود.'), style: TextStyle(color: cTextDim, fontSize: 12)),
        const SizedBox(height: 12),
        SelectableText(text, style: TextStyle(color: cText, fontSize: 17, height: 1.8)),
      ]),
    );

String _when(String? iso) {
  final t = DateTime.tryParse(iso ?? '')?.toLocal();
  if (t == null) return '';
  return '${dayLabel(t)} - ${hm(iso!)}';
}

void showMsgInfo(BuildContext context, Map<String, dynamic> m) {
  final rows = <MapEntry<String, String>>[
    MapEntry(trn('ارسال'), _when(m['created_at'] as String?)),
    if (m['read_at'] != null) MapEntry(trn('خوانده شد'), _when(m['read_at'] as String?)),
    if (m['edited_at'] != null) MapEntry(trn('ویرایش'), _when(m['edited_at'] as String?)),
  ];
  showDialog<void>(
    context: context,
    builder: (c) => Directionality(
      textDirection: appDir,
      child: AlertDialog(
        title: Text(trn('اطلاعات پیام')),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          for (final r in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Row(children: [Text('${r.key}: ', style: TextStyle(color: cTextDim)), Expanded(child: Text(r.value, style: TextStyle(color: cText, fontWeight: FontWeight.w600)))]),
            ),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: Text(trn('باشه')))],
      ),
    ),
  );
}

Future<void> _setReminder(BuildContext context, Map<String, dynamic> m, String scope, String target, DateTime at) async {
  try {
    final p = preview(m);
    await sb.from('message_reminders').insert({
      'scope': scope,
      'target': target,
      'msg_id': m['id'],
      'preview': p.length > 120 ? p.substring(0, 120) : p,
      'remind_at': at.toUtc().toIso8601String(),
    });
    if (context.mounted) snack(context, trf('یادآوری برای {0} تنظیم شد', [_when(at.toUtc().toIso8601String())]));
  } catch (_) {
    if (context.mounted) snack(context, trn('یادآوری تنظیم نشد. کد SQL شماره ۳ در Supabase اجرا شده است؟'));
  }
}

Future<void> showReminderSheet(BuildContext context, Map<String, dynamic> m, String scope, String target) {
  final now = DateTime.now();
  var tonight = DateTime(now.year, now.month, now.day, 20);
  if (!tonight.isAfter(now)) tonight = tonight.add(const Duration(days: 1));
  final tomorrow = DateTime(now.year, now.month, now.day, 9).add(const Duration(days: 1));
  final opts = <MapEntry<String, DateTime>>[
    MapEntry(trn('یک ساعت دیگر'), now.add(const Duration(hours: 1))),
    MapEntry(trn('امشب'), tonight),
    MapEntry(trn('فردا صبح'), tomorrow),
    MapEntry(trn('یک هفته دیگر'), now.add(const Duration(days: 7))),
  ];
  return showTiaSheet<void>(
    context,
    (c) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(trn('یادآوری این پیام'), style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: cText)),
      const SizedBox(height: 8),
      for (final o in opts)
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(Icons.alarm_rounded, color: accent),
          title: Text(o.key),
          subtitle: Text(_when(o.value.toUtc().toIso8601String()), style: TextStyle(color: cTextFaint, fontSize: 12)),
          onTap: () {
            Navigator.pop(c);
            _setReminder(context, m, scope, target, o.value);
          },
        ),
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Icon(Icons.edit_calendar_rounded, color: accent),
        title: Text(trn('زمان دلخواه')),
        onTap: () async {
          Navigator.pop(c);
          final d = await showDatePicker(context: context, initialDate: now, firstDate: now, lastDate: now.add(const Duration(days: 365)));
          if (d == null || !context.mounted) return;
          final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(now.add(const Duration(hours: 1))));
          if (t == null || !context.mounted) return;
          final at = DateTime(d.year, d.month, d.day, t.hour, t.minute);
          if (!at.isAfter(DateTime.now())) {
            snack(context, trn('زمان باید در آینده باشد'));
            return;
          }
          _setReminder(context, m, scope, target, at);
        },
      ),
    ]),
  );
}

/// نگه‌داشتن دکمه‌ی ارسال: ارسال بی‌صدا یا زمان‌بندی
Future<void> showSendOptions(BuildContext context, {required VoidCallback onSilent, required VoidCallback onSchedule}) => showTiaSheet<void>(
      context,
      (c) => Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(
          leading: Icon(Icons.notifications_off_outlined, color: accent),
          title: Text(trn('ارسال بی‌صدا')),
          subtitle: Text(trn('گیرنده اعلان نمی‌گیرد'), style: TextStyle(color: cTextFaint, fontSize: 12)),
          onTap: () {
            Navigator.pop(c);
            onSilent();
          },
        ),
        ListTile(
          leading: Icon(Icons.schedule_send_rounded, color: accent),
          title: Text(trn('زمان‌بندی ارسال')),
          onTap: () {
            Navigator.pop(c);
            onSchedule();
          },
        ),
      ]),
    );
