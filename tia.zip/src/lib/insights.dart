import 'package:flutter/material.dart';
import 'main.dart';
import 'social.dart';

final Set<int> _viewedPosts = {};

// ثبت بازدید یک پست (هر نفر فقط یک بار برای هر پست حساب می‌شود)
Future<void> recordPostView(int postId) async {
  if (me == null || _viewedPosts.contains(postId)) return;
  _viewedPosts.add(postId);
  try {
    await sb.from('post_views').upsert({'post_id': postId, 'viewer_id': me}, onConflict: 'post_id,viewer_id', ignoreDuplicates: true);
  } catch (_) {}
}

class MyHubPage extends StatefulWidget {
  const MyHubPage({super.key});
  @override
  State<MyHubPage> createState() => _MyHubPageState();
}

class _MyHubPageState extends State<MyHubPage> {
  bool loading = true;
  String? err;
  List<Map<String, dynamic>> posts = [];
  Map<int, int> views = {};
  List<String> followers = [], following = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final all = await postsOf(me!);
      final fl = await sb.from('follows').select('follower_id').eq('followee_id', me!).eq('status', 'accepted');
      final fg = await sb.from('follows').select('followee_id').eq('follower_id', me!).eq('status', 'accepted');
      final fIds = [for (final r in fl) r['follower_id'] as String];
      final gIds = [for (final r in fg) r['followee_id'] as String];
      await store.loadPeople([...fIds, ...gIds, me!]);
      final v = <int, int>{};
      try {
        final rows = await sb.from('post_views').select('post_id').limit(10000);
        for (final r in rows) {
          final id = r['post_id'] as int;
          v[id] = (v[id] ?? 0) + 1;
        }
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        posts = [for (final p in all) if (p['repost_of'] == null) p];
        views = v;
        followers = fIds;
        following = gIds;
        loading = false;
        err = null;
      });
    } catch (e) {
      if (mounted) setState(() {
        err = '$e';
        loading = false;
      });
    }
  }

  Widget stat(String label, String v, {VoidCallback? onTap}) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          child: Column(children: [Text(v, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text(label, style: TextStyle(color: cTextFaint, fontSize: 12))]),
        ),
      );

  Widget sumCard(IconData i, String label, int v) => Expanded(
        child: Container(
          margin: const EdgeInsets.all(4),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(settings.cardRadius), border: Border.all(color: cLine)),
          child: Column(children: [Icon(i, color: accent), const SizedBox(height: 4), Text('$v', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text(label, style: TextStyle(color: cTextFaint, fontSize: 11))]),
        ),
      );

  Widget people(List<String> ids, String empty) => ids.isEmpty
      ? Center(child: Text(empty, style: TextStyle(color: cTextFaint)))
      : ListView(children: [
          for (final id in ids)
            ListTile(
              leading: avatarFor(id),
              title: nameWithBadge(id),
              subtitle: Text((store.people[id]?['username'] as String?) == null ? '' : '@${store.people[id]!['username']}', style: TextStyle(color: accent)),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(id))),
            ),
        ]);

  Widget stats() {
    final totalViews = posts.fold<int>(0, (a, p) => a + (views[p['id'] as int] ?? 0));
    final totalLikes = posts.fold<int>(0, (a, p) => a + cnt(p, 'likes'));
    final totalComments = posts.fold<int>(0, (a, p) => a + cnt(p, 'comments'));
    return ListView(padding: const EdgeInsets.all(8), children: [
      Row(children: [sumCard(Icons.visibility_outlined, 'بازدید', totalViews), sumCard(Icons.favorite_border, 'لایک', totalLikes), sumCard(Icons.mode_comment_outlined, 'نظر', totalComments)]),
      const SizedBox(height: 8),
      if (posts.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Center(child: Text('هنوز پستی نگذاشته‌ای', style: TextStyle(color: cTextFaint)))),
      for (final p in posts)
        Container(
          margin: const EdgeInsets.fromLTRB(4, 4, 4, 4),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(settings.cardRadius), border: Border.all(color: cLine)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(((p['body'] as String).isEmpty ? '🖼 پست تصویری' : p['body'] as String), maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 8),
            Row(children: [
              Icon(Icons.visibility_outlined, size: 16, color: accent),
              Text(' ${views[p['id'] as int] ?? 0}'),
              const SizedBox(width: 16),
              const Icon(Icons.favorite, size: 16, color: Colors.redAccent),
              Text(' ${cnt(p, 'likes')}'),
              const SizedBox(width: 16),
              Icon(Icons.mode_comment_outlined, size: 16, color: cTextDim),
              Text(' ${cnt(p, 'comments')}'),
              const Spacer(),
              Text(ago(p['created_at'] as String), style: TextStyle(color: cTextFaint, fontSize: 11)),
            ]),
          ]),
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final uname = store.people[me]?['username'] as String?;
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(title: const Text('پروفایل و آمار من')),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : err != null
                ? Center(child: Padding(padding: const EdgeInsets.all(16), child: Text('بارگذاری نشد\n$err')))
                : Column(children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      child: Row(children: [
                        avatarFor(me!, r: 34),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            nameWithBadge(me!, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            if (uname != null) Text('@$uname', style: TextStyle(color: accent)),
                          ]),
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit_outlined),
                          tooltip: 'ویرایش پروفایل',
                          onPressed: () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => const EditProfilePage()));
                            if (mounted) setState(() {});
                          },
                        ),
                        IconButton(icon: const Icon(Icons.open_in_new), tooltip: 'نمای عمومی پروفایل', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(me!)))),
                      ]),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                      child: Row(children: [
                        StatBox('پست', '${posts.length}'),
                        StatBox('دنبال‌کننده', '${followers.length}', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FollowListPage(me!, true)))),
                        StatBox('دنبال‌شونده', '${following.length}', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FollowListPage(me!, false)))),
                      ]),
                    ),
                    const TabBar(tabs: [Tab(text: 'آمار پست‌ها'), Tab(text: 'دنبال‌کنندگان'), Tab(text: 'دنبال‌شده‌ها')]),
                    Expanded(child: TabBarView(children: [stats(), people(followers, 'هنوز کسی تو را دنبال نکرده'), people(following, 'هنوز کسی را دنبال نکرده‌ای')])),
                  ]),
      ),
    );
  }
}
