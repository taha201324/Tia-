import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter_contacts/flutter_contacts.dart' as fc;
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'chat.dart';
import 'main.dart';

const postSel = '*, likes(count), comments(count)';

String extOf(String name) => RegExp(r'\.[A-Za-z0-9]{1,8}$').stringMatch(name)?.toLowerCase() ?? '';
int cnt(Map<String, dynamic> p, String k) => (((p[k] as List?)?.firstOrNull as Map?)?['count'] as int?) ?? 0;

String ago(String iso) {
  final d = DateTime.now().difference(DateTime.parse(iso));
  if (d.inMinutes < 1) return 'الان';
  if (d.inMinutes < 60) return '${d.inMinutes} دقیقه پیش';
  if (d.inHours < 24) return '${d.inHours} ساعت پیش';
  return '${d.inDays} روز پیش';
}

Future<String> uploadFile(String bucket, String localPath, String name) async {
  final path = '${me!}/${DateTime.now().millisecondsSinceEpoch}${extOf(name)}';
  await sb.storage.from(bucket).upload(path, File(localPath), fileOptions: FileOptions(contentType: mimeOf(name)));
  return path;
}

Future<PlatformFile?> pickImage() async {
  final r = await FilePicker.platform.pickFiles(type: FileType.image);
  final f = r?.files.single;
  return (f == null || f.path == null) ? null : f;
}

Widget avatarFor(String id, {double r = 20}) {
  final p = store.people[id];
  final ap = p?['avatar_path'] as String?;
  final nm = (p?['name'] as String?) ?? '';
  if (ap != null && ap.isNotEmpty) {
    return CircleAvatar(radius: r, backgroundImage: NetworkImage(sb.storage.from('avatars').getPublicUrl(ap)));
  }
  return CircleAvatar(radius: r, backgroundColor: primary, foregroundColor: Colors.white, child: Text(nm.isEmpty ? '?' : nm[0]));
}

Widget nameWithBadge(String id, {TextStyle? style}) {
  final p = store.people[id];
  return Row(mainAxisSize: MainAxisSize.min, children: [
    Flexible(child: Text(store.name(id), style: style, overflow: TextOverflow.ellipsis)),
    if (p?['verified'] == true) Padding(padding: const EdgeInsets.only(right: 4), child: Icon(Icons.verified, size: 16, color: accent)),
  ]);
}

BoxDecoration? wallDecoration() {
  final img = settings.wallImage;
  if (img != null && File(img).existsSync()) {
    return BoxDecoration(image: DecorationImage(image: FileImage(File(img)), fit: BoxFit.cover));
  }
  final w = walls[settings.wallIdx];
  if (w == null) return null;
  return BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(w[0]), Color(w[1])]));
}

// ---------- data ----------
Future<List<Map<String, dynamic>>> enrich(List<Map<String, dynamic>> rows) async {
  final posts = rows.map((r) => Map<String, dynamic>.from(r)).toList();
  final origIds = posts.where((p) => p['repost_of'] != null).map((p) => p['repost_of'] as int).toSet().toList();
  final origs = <int, Map<String, dynamic>>{};
  if (origIds.isNotEmpty) {
    final o = await sb.from('posts').select(postSel).inFilter('id', origIds);
    for (final r in o) {
      origs[r['id'] as int] = Map<String, dynamic>.from(r);
    }
  }
  final all = [...posts, ...origs.values];
  await store.loadPeople(all.map((p) => p['author_id'] as String));
  final ids = all.map((p) => p['id'] as int).toList();
  var liked = <int>{}, saved = <int>{};
  if (ids.isNotEmpty) {
    final l = await sb.from('likes').select('post_id').eq('user_id', me!).inFilter('post_id', ids);
    liked = l.map((r) => r['post_id'] as int).toSet();
    final s = await sb.from('saves').select('post_id').eq('user_id', me!).inFilter('post_id', ids);
    saved = s.map((r) => r['post_id'] as int).toSet();
  }
  for (final p in all) {
    p['_liked'] = liked.contains(p['id']);
    p['_saved'] = saved.contains(p['id']);
  }
  for (final p in posts) {
    if (p['repost_of'] != null) p['_orig'] = origs[p['repost_of']];
  }
  return posts;
}

Future<List<Map<String, dynamic>>> feedFollowing() async {
  final f = await sb.from('follows').select('followee_id').eq('follower_id', me!).eq('status', 'accepted');
  final ids = [me!, ...f.map((r) => r['followee_id'] as String)];
  return enrich(await sb.from('posts').select(postSel).inFilter('author_id', ids).order('created_at', ascending: false).limit(50));
}

Future<List<Map<String, dynamic>>> feedExplore() async =>
    enrich(await sb.from('posts').select(postSel).order('created_at', ascending: false).limit(50));

Future<List<Map<String, dynamic>>> postsOf(String id) async =>
    enrich(await sb.from('posts').select(postSel).eq('author_id', id).order('created_at', ascending: false).limit(50));

Future<List<Map<String, dynamic>>> postsByTag(String tag) async =>
    enrich(await sb.from('posts').select(postSel).ilike('body', '%#$tag%').order('created_at', ascending: false).limit(50));

Future<List<Map<String, dynamic>>> savedPosts() async {
  final s = await sb.from('saves').select('post_id').eq('user_id', me!);
  final ids = s.map((r) => r['post_id'] as int).toList();
  if (ids.isEmpty) return [];
  return enrich(await sb.from('posts').select(postSel).inFilter('id', ids).order('created_at', ascending: false));
}

Future<void> setLike(int id, bool on) =>
    on ? sb.from('likes').insert({'post_id': id, 'user_id': me}) : sb.from('likes').delete().eq('post_id', id).eq('user_id', me!);

Future<void> setSave(int id, bool on) =>
    on ? sb.from('saves').insert({'post_id': id, 'user_id': me}) : sb.from('saves').delete().eq('post_id', id).eq('user_id', me!);

Future<String> followStatus(String id) async {
  final r = await sb.from('follows').select('status').eq('follower_id', me!).eq('followee_id', id).maybeSingle();
  return (r?['status'] as String?) ?? 'none';
}

Future<void> follow(String id, bool priv) =>
    sb.from('follows').insert({'follower_id': me, 'followee_id': id, 'status': priv ? 'pending' : 'accepted'});

Future<void> unfollow(String id) => sb.from('follows').delete().eq('follower_id', me!).eq('followee_id', id);

final _purls = <String, Future<String>>{};
Future<String> postUrl(String path) => _purls.putIfAbsent(path, () => sb.storage.from('post-images').createSignedUrl(path, 3600));

// ---------- text with #hashtags and @mentions ----------
Future<void> openTag(BuildContext c, String t) async {
  if (t.startsWith('#')) {
    Navigator.push(c, MaterialPageRoute(builder: (_) => PostListPage('#${t.substring(1)}', () => postsByTag(t.substring(1)))));
    return;
  }
  final r = await sb.from('profiles').select(profCols).eq('username', t.substring(1).toLowerCase()).maybeSingle();
  if (r != null && c.mounted) {
    store.people[r['id'] as String] = r;
    Navigator.push(c, MaterialPageRoute(builder: (_) => ProfilePage(r['id'] as String)));
  }
}

Widget richBody(BuildContext c, String text) {
  final spans = <InlineSpan>[];
  var last = 0;
  for (final m in RegExp(r'[#@][\p{L}\p{N}_]+', unicode: true).allMatches(text)) {
    if (m.start > last) spans.add(TextSpan(text: text.substring(last, m.start)));
    final t = m.group(0)!;
    spans.add(TextSpan(text: t, style: TextStyle(color: accent), recognizer: TapGestureRecognizer()..onTap = () => openTag(c, t)));
    last = m.end;
  }
  if (last < text.length) spans.add(TextSpan(text: text.substring(last)));
  return Text.rich(TextSpan(children: spans, style: const TextStyle(color: Colors.white, height: 1.5)));
}

// ---------- post widgets ----------
class PostImage extends StatelessWidget {
  final String path;
  const PostImage(this.path, {super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
        future: postUrl(path),
        builder: (c, s) {
          if (s.hasError) return const Icon(Icons.broken_image);
          if (!s.hasData) return const SizedBox(height: 160, child: Center(child: CircularProgressIndicator()));
          final url = s.data!;
          return GestureDetector(
            onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(), body: Center(child: InteractiveViewer(child: Image.network(url)))))),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(url, width: double.infinity, height: 260, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
            ),
          );
        },
      );
}

class PostCard extends StatefulWidget {
  final Map<String, dynamic> post;
  final VoidCallback onChanged;
  const PostCard(this.post, this.onChanged, {super.key});
  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  late bool liked, saved;
  late int likes, comments;
  Map<String, dynamic>? get p => widget.post['repost_of'] != null ? widget.post['_orig'] as Map<String, dynamic>? : widget.post;

  @override
  void initState() {
    super.initState();
    final x = p;
    liked = x?['_liked'] == true;
    saved = x?['_saved'] == true;
    likes = x == null ? 0 : cnt(x, 'likes');
    comments = x == null ? 0 : cnt(x, 'comments');
  }

  Future<void> like() async {
    final id = p!['id'] as int;
    setState(() {
      liked = !liked;
      likes += liked ? 1 : -1;
    });
    try {
      await setLike(id, liked);
    } catch (_) {
      if (mounted) {
        setState(() {
          liked = !liked;
          likes += liked ? 1 : -1;
        });
      }
    }
  }

  Future<void> save() async {
    final id = p!['id'] as int;
    setState(() => saved = !saved);
    try {
      await setSave(id, saved);
    } catch (_) {
      if (mounted) setState(() => saved = !saved);
    }
  }

  Widget act(IconData i, String label, VoidCallback f, {Color? color}) => InkWell(
        onTap: f,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(children: [Icon(i, size: 20, color: color ?? Colors.white70), if (label.isNotEmpty) Text(' $label', style: const TextStyle(color: Colors.white70))]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final x = p;
    final isRepost = widget.post['repost_of'] != null;
    final mineCard = widget.post['author_id'] == me;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (isRepost)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(children: [
              Icon(Icons.repeat, size: 14, color: accent),
              const SizedBox(width: 4),
              Text('${store.name(widget.post['author_id'] as String)} بازنشر کرد', style: TextStyle(color: accent, fontSize: 12)),
            ]),
          ),
        if (x == null)
          const Text('این پست در دسترس نیست', style: TextStyle(color: Colors.white54))
        else ...[
          Row(children: [
            GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(x['author_id'] as String))),
              child: avatarFor(x['author_id'] as String),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                nameWithBadge(x['author_id'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(ago(x['created_at'] as String), style: const TextStyle(color: Colors.white54, fontSize: 11)),
              ]),
            ),
            if (mineCard)
              PopupMenuButton<String>(
                onSelected: (_) async {
                  if (await confirm(context, 'این پست حذف شود؟')) {
                    await sb.from('posts').delete().eq('id', widget.post['id'] as int);
                    widget.onChanged();
                  }
                },
                itemBuilder: (_) => const [PopupMenuItem(value: 'del', child: Text('حذف'))],
              ),
          ]),
          if ((x['body'] as String).isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: richBody(context, x['body'] as String)),
          if (x['image_path'] != null) Padding(padding: const EdgeInsets.only(top: 10), child: PostImage(x['image_path'] as String)),
          const SizedBox(height: 6),
          Row(children: [
            act(liked ? Icons.favorite : Icons.favorite_border, '$likes', like, color: liked ? Colors.redAccent : null),
            act(Icons.mode_comment_outlined, '$comments', () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => CommentsPage(x['id'] as int)));
              widget.onChanged();
            }),
            act(Icons.repeat, '', () async {
              try {
                await sb.from('posts').insert({'author_id': me, 'repost_of': x['id']});
                if (context.mounted) snack(context, 'بازنشر شد');
              } catch (_) {
                if (context.mounted) snack(context, 'بازنشر نشد');
              }
            }),
            const Spacer(),
            act(saved ? Icons.bookmark : Icons.bookmark_border, '', save, color: saved ? accent : null),
          ]),
        ],
      ]),
    );
  }
}

class PostList extends StatefulWidget {
  final Future<List<Map<String, dynamic>>> Function() loader;
  final String empty;
  const PostList({super.key, required this.loader, required this.empty});
  @override
  State<PostList> createState() => _PostListState();
}

class _PostListState extends State<PostList> {
  List<Map<String, dynamic>>? posts;
  String? err;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await widget.loader();
      if (mounted) setState(() { posts = r; err = null; });
    } catch (e) {
      if (mounted) setState(() => err = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (err != null) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('بارگذاری نشد'),
        Padding(padding: const EdgeInsets.all(12), child: Text(err!, style: const TextStyle(fontSize: 11, color: Colors.white54))),
        TextButton(onPressed: load, child: const Text('تلاش دوباره')),
      ]));
    }
    if (posts == null) return const Center(child: CircularProgressIndicator());
    if (posts!.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(widget.empty, textAlign: TextAlign.center)));
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(children: [for (final p in posts!) PostCard(p, load, key: ValueKey('${p['id']}'))]),
    );
  }
}

class PostListPage extends StatelessWidget {
  final String title;
  final Future<List<Map<String, dynamic>>> Function() loader;
  const PostListPage(this.title, this.loader, {super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title)), body: PostList(loader: loader, empty: 'پستی نیست'));
}

class FeedTab extends StatefulWidget {
  const FeedTab({super.key});
  @override
  State<FeedTab> createState() => _FeedTabState();
}

class _FeedTabState extends State<FeedTab> {
  int v = 0;
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Row(children: [
              ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/icon.png', width: 32, height: 32)),
              const SizedBox(width: 10),
              const Text('Tia'),
            ]),
            actions: [IconButton(icon: const Icon(Icons.search), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage())))],
            bottom: const TabBar(tabs: [Tab(text: 'دنبال‌شوندگان'), Tab(text: 'پیشنهادی')]),
          ),
          body: TabBarView(children: [
            PostList(key: ValueKey('f$v'), loader: feedFollowing, empty: 'هنوز پستی نیست.\nچند نفر را دنبال کنید یا اولین پست را بنویسید.'),
            PostList(key: ValueKey('e$v'), loader: feedExplore, empty: 'پستی نیست'),
          ]),
          floatingActionButton: FloatingActionButton(
            backgroundColor: primary,
            foregroundColor: Colors.white,
            child: const Icon(Icons.edit),
            onPressed: () async {
              final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const ComposePage()));
              if (ok == true) setState(() => v++);
            },
          ),
        ),
      );
}

class ComposePage extends StatefulWidget {
  const ComposePage({super.key});
  @override
  State<ComposePage> createState() => _ComposePageState();
}

class _ComposePageState extends State<ComposePage> {
  final ctrl = TextEditingController();
  PlatformFile? img;
  bool busy = false;

  Future<void> post() async {
    final t = ctrl.text.trim();
    if (t.isEmpty && img == null) return;
    setState(() => busy = true);
    try {
      String? up;
      if (img != null) up = await uploadFile('post-images', img!.path!, img!.name);
      await sb.from('posts').insert({'author_id': me, 'body': t, 'image_path': up});
      if (mounted) Navigator.pop(context, true);
    } catch (_) {
      if (mounted) {
        snack(context, 'ارسال نشد. اینترنت را بررسی کنید.');
        setState(() => busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('پست جدید'), actions: [TextButton(onPressed: busy ? null : post, child: const Text('انتشار'))]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          TextField(controller: ctrl, maxLines: 6, decoration: const InputDecoration(hintText: 'چه خبر؟ از #هشتگ و @نام_کاربری استفاده کنید', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          if (img != null) ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(img!.path!), height: 180, fit: BoxFit.cover)),
          Row(children: [
            TextButton.icon(
              onPressed: () async {
                final f = await pickImage();
                if (f != null) setState(() => img = f);
              },
              icon: const Icon(Icons.image),
              label: Text(img == null ? 'افزودن عکس' : 'تغییر عکس'),
            ),
            if (img != null) TextButton(onPressed: () => setState(() => img = null), child: const Text('حذف عکس')),
          ]),
          if (busy) const LinearProgressIndicator(),
        ]),
      );
}

class CommentsPage extends StatefulWidget {
  final int postId;
  const CommentsPage(this.postId, {super.key});
  @override
  State<CommentsPage> createState() => _CommentsPageState();
}

class _CommentsPageState extends State<CommentsPage> {
  final ctrl = TextEditingController();
  List<Map<String, dynamic>> items = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final rows = await sb.from('comments').select().eq('post_id', widget.postId).order('created_at');
      await store.loadPeople(rows.map((r) => r['user_id'] as String));
      if (mounted) setState(() => items = rows);
    } catch (_) {}
  }

  Future<void> send() async {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    ctrl.clear();
    try {
      await sb.from('comments').insert({'post_id': widget.postId, 'user_id': me, 'body': t});
      await load();
    } catch (_) {
      if (mounted) snack(context, 'ارسال نشد');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('نظرات')),
        body: Column(children: [
          Expanded(
            child: items.isEmpty
                ? const Center(child: Text('هنوز نظری نیست'))
                : ListView(children: [
                    for (final c in items)
                      ListTile(
                        leading: avatarFor(c['user_id'] as String),
                        title: nameWithBadge(c['user_id'] as String),
                        subtitle: richBody(context, c['body'] as String),
                      ),
                  ]),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                Expanded(child: TextField(controller: ctrl, onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'نظر بنویسید...', border: OutlineInputBorder()))),
                IconButton(icon: Icon(Icons.send, color: primary), onPressed: send),
              ]),
            ),
          ),
        ]),
      );
}

// ---------- profile ----------
class ProfilePage extends StatefulWidget {
  final String id;
  const ProfilePage(this.id, {super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool loading = true;
  String? err;
  String status = 'none';
  int followers = 0, following = 0;
  List<Map<String, dynamic>>? posts;
  Map<String, dynamic> get prof => store.people[widget.id] ?? {};

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await sb.from('profiles').select(profCols).eq('id', widget.id).single();
      store.people[widget.id] = r;
      final fl = await sb.from('follows').select('follower_id').eq('followee_id', widget.id).eq('status', 'accepted');
      final fg = await sb.from('follows').select('followee_id').eq('follower_id', widget.id).eq('status', 'accepted');
      final st = widget.id == me ? 'me' : await followStatus(widget.id);
      final see = st == 'me' || r['is_private'] != true || st == 'accepted';
      final ps = see ? await postsOf(widget.id) : null;
      if (!mounted) return;
      setState(() {
        followers = fl.length;
        following = fg.length;
        status = st;
        posts = ps;
        loading = false;
        err = null;
      });
    } catch (e) {
      if (mounted) setState(() { err = '$e'; loading = false; });
    }
  }

  Future<void> toggleFollow() async {
    try {
      if (status == 'none') {
        await follow(widget.id, prof['is_private'] == true);
      } else {
        await unfollow(widget.id);
      }
      await load();
    } catch (_) {
      if (mounted) snack(context, 'انجام نشد');
    }
  }

  Widget stat(String label, String v) => Column(children: [Text(v, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white54))]);

  @override
  Widget build(BuildContext context) {
    if (loading) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    if (err != null) return Scaffold(appBar: AppBar(), body: Center(child: Padding(padding: const EdgeInsets.all(16), child: Text('بارگذاری نشد\n$err'))));
    final uname = prof['username'] as String?;
    final bio = prof['bio'] as String?;
    final isMe = status == 'me';
    return Scaffold(
      appBar: AppBar(title: Text(store.name(widget.id))),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              avatarFor(widget.id, r: 44),
              const SizedBox(height: 8),
              nameWithBadge(widget.id, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              if (uname != null && uname.isNotEmpty) Text('@$uname', style: TextStyle(color: accent)),
              if (prof['is_private'] == true) const Padding(padding: EdgeInsets.only(top: 4), child: Text('🔒 حساب خصوصی', style: TextStyle(color: Colors.white54, fontSize: 12))),
              if (bio != null && bio.isNotEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(bio, textAlign: TextAlign.center)),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [stat('پست', posts == null ? '-' : '${posts!.length}'), stat('دنبال‌کننده', '$followers'), stat('دنبال‌شونده', '$following')]),
              const SizedBox(height: 12),
              if (isMe)
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => const EditProfilePage()));
                      load();
                    },
                    child: const Text('ویرایش پروفایل'),
                  ),
                )
              else
                Row(children: [
                  Expanded(
                    child: FilledButton(
                      onPressed: toggleFollow,
                      child: Text(status == 'none' ? 'دنبال کردن' : status == 'pending' ? 'درخواست ارسال شد' : 'دنبال می‌کنید'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton(onPressed: () => openChat(context, widget.id), child: const Text('پیام')),
                ]),
            ]),
          ),
          const Divider(),
          if (posts == null)
            const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('🔒 برای دیدن پست‌ها باید این حساب را دنبال کنید')))
          else if (posts!.isEmpty)
            const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('هنوز پستی نیست')))
          else
            for (final p in posts!) PostCard(p, load, key: ValueKey('${p['id']}')),
        ]),
      ),
    );
  }
}

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});
  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late final name = TextEditingController(text: store.name(me!));
  late final uname = TextEditingController(text: (store.people[me!]?['username'] as String?) ?? '');
  late final bio = TextEditingController(text: (store.people[me!]?['bio'] as String?) ?? '');
  late bool priv = store.people[me!]?['is_private'] == true;
  bool busy = false;

  Future<void> changeAvatar() async {
    final f = await pickImage();
    if (f == null) return;
    setState(() => busy = true);
    try {
      final path = await uploadFile('avatars', f.path!, f.name);
      await sb.from('profiles').update({'avatar_path': path}).eq('id', me!);
      store.refreshPerson(me!, {...store.people[me!]!, 'avatar_path': path});
    } catch (_) {
      if (mounted) snack(context, 'تغییر عکس انجام نشد');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> save() async {
    final u = uname.text.trim().toLowerCase();
    if (name.text.trim().isEmpty) return;
    if (u.isNotEmpty && !RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(u)) {
      snack(context, 'نام کاربری: حروف انگلیسی، عدد و _ (۳ تا ۲۰ کاراکتر)');
      return;
    }
    setState(() => busy = true);
    try {
      final data = {'name': name.text.trim(), 'username': u.isEmpty ? null : u, 'bio': bio.text.trim(), 'is_private': priv};
      await sb.from('profiles').update(data).eq('id', me!);
      store.refreshPerson(me!, {...store.people[me!]!, ...data});
      if (mounted) Navigator.pop(context);
    } on PostgrestException catch (e) {
      if (mounted) {
        snack(context, e.code == '23505' ? 'این نام کاربری قبلاً گرفته شده' : 'ذخیره نشد');
        setState(() => busy = false);
      }
    } catch (_) {
      if (mounted) {
        snack(context, 'ذخیره نشد');
        setState(() => busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ویرایش پروفایل'), actions: [TextButton(onPressed: busy ? null : save, child: const Text('ذخیره'))]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Center(child: GestureDetector(onTap: changeAvatar, child: Stack(children: [avatarFor(me!, r: 50), const Positioned(bottom: 0, left: 0, child: CircleAvatar(radius: 14, child: Icon(Icons.camera_alt, size: 16)))]))),
          const SizedBox(height: 16),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'نام', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: uname, decoration: const InputDecoration(labelText: 'نام کاربری (انگلیسی)', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: bio, maxLines: 3, decoration: const InputDecoration(labelText: 'بیوگرافی', border: OutlineInputBorder())),
          SwitchListTile(title: const Text('حساب خصوصی'), subtitle: const Text('فقط دنبال‌کنندگان تاییدشده پست‌های شما را می‌بینند'), value: priv, onChanged: (v) => setState(() => priv = v)),
          if (busy) const LinearProgressIndicator(),
        ]),
      );
}

class RequestsPage extends StatefulWidget {
  const RequestsPage({super.key});
  @override
  State<RequestsPage> createState() => _RequestsPageState();
}

class _RequestsPageState extends State<RequestsPage> {
  List<String> ids = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await sb.from('follows').select('follower_id').eq('followee_id', me!).eq('status', 'pending');
      final l = r.map((x) => x['follower_id'] as String).toList();
      await store.loadPeople(l);
      if (mounted) setState(() => ids = l);
    } catch (_) {}
  }

  Future<void> answer(String id, bool ok) async {
    try {
      final q = sb.from('follows');
      if (ok) {
        await q.update({'status': 'accepted'}).eq('follower_id', id).eq('followee_id', me!);
      } else {
        await q.delete().eq('follower_id', id).eq('followee_id', me!);
      }
      await load();
    } catch (_) {
      if (mounted) snack(context, 'انجام نشد');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('درخواست‌های دنبال‌کردن')),
        body: ids.isEmpty
            ? const Center(child: Text('درخواستی نیست'))
            : ListView(children: [
                for (final id in ids)
                  ListTile(
                    leading: avatarFor(id),
                    title: nameWithBadge(id),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.check, color: Colors.greenAccent), onPressed: () => answer(id, true)),
                      IconButton(icon: const Icon(Icons.close, color: Colors.redAccent), onPressed: () => answer(id, false)),
                    ]),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(id))),
                  ),
              ]),
      );
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  List<Map<String, dynamic>> res = [];

  Future<void> search(String q) async {
    final s = q.trim().replaceAll(RegExp(r'[,()%*]'), '');
    if (s.length < 2) {
      setState(() => res = []);
      return;
    }
    try {
      final r = await sb.from('profiles').select(profCols).or('username.ilike.%$s%,name.ilike.%$s%').limit(20);
      for (final p in r) {
        store.people[p['id'] as String] = p;
      }
      if (mounted) setState(() => res = r);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: TextField(autofocus: true, onChanged: search, decoration: const InputDecoration(hintText: 'جستجوی نام یا نام کاربری...', border: InputBorder.none))),
        body: ListView(children: [
          for (final p in res)
            ListTile(
              leading: avatarFor(p['id'] as String),
              title: nameWithBadge(p['id'] as String),
              subtitle: Text(p['username'] == null ? '' : '@${p['username']}', style: TextStyle(color: accent)),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(p['id'] as String))),
            ),
        ]),
      );
}

// ---------- appearance ----------
class AppearancePage extends StatelessWidget {
  const AppearancePage({super.key});

  Widget dot(Widget inner, bool selected, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: selected ? Colors.white : Colors.white24, width: selected ? 3 : 1)),
          child: ClipOval(child: inner),
        ),
      );

  Future<void> pickWall() async {
    final f = await pickImage();
    if (f == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final dest = '${dir.path}/wall_${DateTime.now().millisecondsSinceEpoch}${extOf(f.name)}';
    await File(f.path!).copy(dest);
    settings.wallImage = dest;
    settings.save();
  }

  Widget head(String t) => Padding(padding: const EdgeInsets.only(top: 20, bottom: 10), child: Text(t, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ظاهر برنامه')),
        body: ListenableBuilder(
          listenable: settings,
          builder: (c, _) => ListView(padding: const EdgeInsets.all(16), children: [
            head('رنگ اصلی'),
            Wrap(spacing: 12, runSpacing: 12, children: [
              for (var i = 0; i < accents.length; i++)
                dot(ColoredBox(color: Color(accents[i])), settings.accentIdx == i, () {
                  settings.accentIdx = i;
                  settings.save();
                }),
            ]),
            head('پس‌زمینه‌ی برنامه'),
            Wrap(spacing: 12, runSpacing: 12, children: [
              for (var i = 0; i < bgTones.length; i++)
                dot(
                  DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(bgTones[i][0]), Color(bgTones[i][1])]))),
                  settings.bgIdx == i,
                  () {
                    settings.bgIdx = i;
                    settings.save();
                  },
                ),
            ]),
            head('والپیپر چت'),
            Wrap(spacing: 12, runSpacing: 12, children: [
              for (var i = 0; i < walls.length; i++)
                dot(
                  walls[i] == null
                      ? const Center(child: Icon(Icons.block, size: 22))
                      : DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(walls[i]![0]), Color(walls[i]![1])]))),
                  settings.wallImage == null && settings.wallIdx == i,
                  () {
                    settings.wallIdx = i;
                    settings.wallImage = null;
                    settings.save();
                  },
                ),
            ]),
            const SizedBox(height: 12),
            ListTile(leading: const Icon(Icons.photo_library), title: const Text('انتخاب عکس از گالری'), onTap: pickWall),
            if (settings.wallImage != null)
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('حذف عکس والپیپر'),
                onTap: () {
                  settings.wallImage = null;
                  settings.save();
                },
              ),
            const SizedBox(height: 12),
            const Text('این تنظیمات روی همین گوشی ذخیره می‌شوند.', style: TextStyle(color: Colors.white54, fontSize: 12)),
          ]),
        ),
      );
}

// ---------- contacts sync ----------
String? last10(String raw) {
  const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
  final b = StringBuffer();
  for (final ch in raw.split('')) {
    final i = fa.indexOf(ch), j = ar.indexOf(ch);
    if (i >= 0) {
      b.write(i);
    } else if (j >= 0) {
      b.write(j);
    } else if (RegExp(r'[0-9]').hasMatch(ch)) {
      b.write(ch);
    }
  }
  final d = b.toString();
  return d.length >= 10 ? d.substring(d.length - 10) : null;
}

Future<void> syncContacts(BuildContext c) async {
  void msg(String t) {
    if (c.mounted) snack(c, t);
  }

  if (!await confirm(c, 'شماره‌ی مخاطبین گوشی برای پیدا کردن کاربران Tia به سرور فرستاده می‌شود (ذخیره نمی‌شود). ادامه می‌دهید؟')) return;
  try {
    if (!await fc.FlutterContacts.requestPermission(readonly: true)) {
      msg('اجازه‌ی دسترسی به مخاطبین داده نشد');
      return;
    }
    final list = await fc.FlutterContacts.getContacts(withProperties: true);
    final nums = <String>{};
    for (final x in list) {
      for (final ph in x.phones) {
        final d = last10(ph.number);
        if (d != null) nums.add(d);
      }
    }
    final all = nums.toList();
    final found = <String, Map<String, dynamic>>{};
    for (var i = 0; i < all.length; i += 500) {
      final end = i + 500 > all.length ? all.length : i + 500;
      final r = await sb.rpc('match_contacts', params: {'p_phones': all.sublist(i, end)}) as List;
      for (final e in r) {
        final m = Map<String, dynamic>.from(e as Map);
        found[m['id'] as String] = m;
      }
    }
    if (found.isEmpty) {
      msg('هیچ‌کدام از مخاطبین گوشی شما هنوز در Tia نیستند');
      return;
    }
    store.people.addAll(found);
    await sb.from('contacts').upsert([for (final id in found.keys) {'owner_id': me, 'contact_id': id}]);
    await store.loadContacts();
    msg('${found.length} مخاطب از گوشی شما در Tia پیدا و اضافه شد');
  } catch (_) {
    msg('همگام‌سازی انجام نشد');
  }
}

// ---------- chat info ----------
class ChatInfoPage extends StatefulWidget {
  final String id;
  const ChatInfoPage(this.id, {super.key});
  @override
  State<ChatInfoPage> createState() => _ChatInfoPageState();
}

class _ChatInfoPageState extends State<ChatInfoPage> {
  String status = 'none';
  bool loading = true;
  Map<String, dynamic> get p => store.people[widget.id] ?? {};

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await sb.from('profiles').select(profCols).eq('id', widget.id).single();
      store.people[widget.id] = r;
      status = await followStatus(widget.id);
      await store.loadPhones([widget.id]);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  Future<void> toggleFollow() async {
    try {
      if (status == 'none') {
        await follow(widget.id, p['is_private'] == true);
      } else {
        await unfollow(widget.id);
      }
      await load();
    } catch (_) {
      if (mounted) snack(context, 'انجام نشد');
    }
  }

  @override
  Widget build(BuildContext context) {
    final phone = store.phones[widget.id] ?? '';
    final uname = (p['username'] as String?) ?? '';
    final bio = (p['bio'] as String?) ?? '';
    return Scaffold(
      appBar: AppBar(title: const Text('اطلاعات مخاطب')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Center(child: avatarFor(widget.id, r: 48)),
        const SizedBox(height: 12),
        Center(child: nameWithBadge(widget.id, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        const SizedBox(height: 16),
        ListTile(leading: const Icon(Icons.phone), title: Text(phone.isEmpty ? 'مخفی (فقط برای مخاطبین)' : phone, textDirection: TextDirection.ltr, textAlign: TextAlign.right), subtitle: const Text('شماره موبایل')),
        ListTile(leading: const Icon(Icons.alternate_email), title: Text(uname.isEmpty ? 'ندارد' : uname, textDirection: TextDirection.ltr, textAlign: TextAlign.right), subtitle: const Text('نام کاربری')),
        if (bio.isNotEmpty) ListTile(leading: const Icon(Icons.info_outline), title: Text(bio), subtitle: const Text('بیوگرافی')),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: loading ? null : toggleFollow,
          child: Text(status == 'none' ? 'دنبال کردن' : status == 'pending' ? 'درخواست ارسال شد (لغو)' : 'دنبال می‌کنید (لغو)'),
        ),
        const SizedBox(height: 8),
        OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(widget.id))), child: const Text('مشاهده‌ی پروفایل و پست‌ها')),
      ]),
    );
  }
}
