import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/gestures.dart';
import 'package:flutter_contacts/flutter_contacts.dart' as fc;
import 'package:flutter/material.dart';
import 'package:image/image.dart' as imglib;
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'chat.dart';
import 'cyber.dart';
import 'insights.dart';
import 'media.dart';
import 'safety.dart';
import 'stories.dart';
import 'main.dart';
import 'l10n.dart';

const postSel = '*, likes(count), comments(count)';

String extOf(String name) => RegExp(r'\.[A-Za-z0-9]{1,8}$').stringMatch(name)?.toLowerCase() ?? '';
int cnt(Map<String, dynamic> p, String k) => (((p[k] as List?)?.firstOrNull as Map?)?['count'] as int?) ?? 0;

String ago(String iso) {
  final d = DateTime.now().difference(DateTime.parse(iso));
  if (d.inMinutes < 1) return trn('الان');
  if (d.inMinutes < 60) return trf('{0} دقیقه پیش', [d.inMinutes]);
  if (d.inHours < 24) return trf('{0} ساعت پیش', [d.inHours]);
  return trf('{0} روز پیش', [d.inDays]);
}

Uint8List? _shrink(Uint8List bytes) {
  final im = imglib.decodeImage(bytes);
  if (im == null) return null;
  var r = imglib.bakeOrientation(im);
  if (r.width > 1600 || r.height > 1600) {
    r = r.width >= r.height ? imglib.copyResize(r, width: 1600) : imglib.copyResize(r, height: 1600);
  }
  return Uint8List.fromList(imglib.encodeJpg(r, quality: 82));
}

// عکس را کوچک می‌کند تا فضای ذخیره‌سازی و اینترنت کمتری مصرف شود
Future<String> compressImagePath(String path) async {
  try {
    if (extOf(path) == '.gif') return path;
    final bytes = await File(path).readAsBytes();
    final out = await compute(_shrink, bytes);
    if (out == null || out.length >= bytes.length) return path;
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/img_${DateTime.now().millisecondsSinceEpoch}.jpg');
    await f.writeAsBytes(out);
    return f.path;
  } catch (_) {
    return path;
  }
}

Future<String> uploadFile(String bucket, String localPath, String name) async {
  final lp = await compressImagePath(localPath);
  final nm = lp != localPath ? 'photo.jpg' : name;
  final path = '${me!}/${DateTime.now().millisecondsSinceEpoch}${extOf(nm)}';
  await sb.storage.from(bucket).upload(path, File(lp), fileOptions: FileOptions(contentType: mimeOf(nm)));
  return path;
}

Future<PlatformFile?> pickImage() async {
  final r = await FilePicker.platform.pickFiles(type: FileType.image);
  final f = r?.files.single;
  return (f == null || f.path == null) ? null : f;
}

Widget avatarFor(String id, {double r = 20}) {
  final p = store.people[id];
  final ap = p?['avatar_path'] as String?;
  final nm = (p?['name'] as String?) ?? '';
  if (ap != null && ap.isNotEmpty) {
    return CircleAvatar(radius: r, backgroundImage: NetworkImage(sb.storage.from('avatars').getPublicUrl(ap)));
  }
  return CircleAvatar(radius: r, backgroundColor: primary, foregroundColor: cOnPrimary, child: Text(nm.isEmpty ? '?' : nm[0]));
}

Widget nameWithBadge(String id, {TextStyle? style}) {
  final p = store.people[id];
  return Row(mainAxisSize: MainAxisSize.min, children: [
    Flexible(child: Text(store.name(id), style: style, overflow: TextOverflow.ellipsis)),
    if (p?['verified'] == true) Padding(padding: EdgeInsets.only(right: 4), child: Icon(Icons.verified, size: 16, color: accent)),
  ]);
}

BoxDecoration? wallDecoration() {
  final dim = settings.wallDim;
  final img = settings.wallImage;
  if (img != null && File(img).existsSync()) {
    return BoxDecoration(image: DecorationImage(image: FileImage(File(img)), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Color.fromRGBO(0, 0, 0, dim), BlendMode.darken)));
  }
  final w = walls[settings.wallIdx];
  if (w == null) return null;
  return BoxDecoration(
    gradient: LinearGradient(
      begin: Alignment.topRight,
      end: Alignment.bottomLeft,
      colors: [Color.lerp(Color(w[0]), Colors.black, dim)!, Color.lerp(Color(w[1]), Colors.black, dim)!],
    ),
  );
}

String? seenText(String id) {
  final iso = store.lastSeen[id];
  if (iso == null) return null;
  final d = DateTime.now().difference(DateTime.parse(iso));
  return d.inMinutes < 2 ? trn('آنلاین') : trf('آخرین بازدید {0}', [ago(iso)]);
}

// ---------- data ----------
Future<List<Map<String, dynamic>>> enrich(List<Map<String, dynamic>> rows) async {
  final posts = rows.map((r) => Map<String, dynamic>.from(r)).toList();
  final origIds = posts.where((p) => p['repost_of'] != null).map((p) => p['repost_of'] as int).toSet().toList();
  final origs = <int, Map<String, dynamic>>{};
  if (origIds.isNotEmpty) {
    final o = await sb.from('posts').select(postSel).inFilter('id', origIds);
    for (final r in o) {
      origs[r['id'] as int] = Map<String, dynamic>.from(r);
    }
  }
  final all = [...posts, ...origs.values];
  await store.loadPeople(all.map((p) => p['author_id'] as String));
  final ids = all.map((p) => p['id'] as int).toList();
  var liked = <int>{}, saved = <int>{};
  if (ids.isNotEmpty) {
    final l = await sb.from('likes').select('post_id').eq('user_id', me!).inFilter('post_id', ids);
    liked = l.map((r) => r['post_id'] as int).toSet();
    final s = await sb.from('saves').select('post_id').eq('user_id', me!).inFilter('post_id', ids);
    saved = s.map((r) => r['post_id'] as int).toSet();
  }
  for (final p in all) {
    p['_liked'] = liked.contains(p['id']);
    p['_saved'] = saved.contains(p['id']);
  }
  for (final p in posts) {
    if (p['repost_of'] != null) p['_orig'] = origs[p['repost_of']];
  }
  return posts.where((p) => !safety.isBlocked(p['author_id'] as String)).toList();
}

Future<List<Map<String, dynamic>>> feedFollowing() async {
  final f = await sb.from('follows').select('followee_id').eq('follower_id', me!).eq('status', 'accepted');
  final ids = [me!, ...f.map((r) => r['followee_id'] as String)];
  return enrich(await sb.from('posts').select(postSel).inFilter('author_id', ids).order('created_at', ascending: false).limit(50));
}

Future<List<Map<String, dynamic>>> feedExplore() async =>
    enrich(await sb.from('posts').select(postSel).order('created_at', ascending: false).limit(50));

Future<List<Map<String, dynamic>>> postsOf(String id) async =>
    enrich(await sb.from('posts').select(postSel).eq('author_id', id).order('created_at', ascending: false).limit(50));

Future<List<Map<String, dynamic>>> postsByTag(String tag) async =>
    enrich(await sb.from('posts').select(postSel).ilike('body', '%#$tag%').order('created_at', ascending: false).limit(50));

Future<List<Map<String, dynamic>>> savedPosts() async {
  final s = await sb.from('saves').select('post_id').eq('user_id', me!);
  final ids = s.map((r) => r['post_id'] as int).toList();
  if (ids.isEmpty) return [];
  return enrich(await sb.from('posts').select(postSel).inFilter('id', ids).order('created_at', ascending: false));
}

Future<void> setLike(int id, bool on) =>
    on ? sb.from('likes').insert({'post_id': id, 'user_id': me}) : sb.from('likes').delete().eq('post_id', id).eq('user_id', me!);

Future<void> setSave(int id, bool on) =>
    on ? sb.from('saves').insert({'post_id': id, 'user_id': me}) : sb.from('saves').delete().eq('post_id', id).eq('user_id', me!);

Future<String> followStatus(String id) async {
  final r = await sb.from('follows').select('status').eq('follower_id', me!).eq('followee_id', id).maybeSingle();
  return (r?['status'] as String?) ?? 'none';
}

Future<void> follow(String id, bool priv) =>
    sb.from('follows').insert({'follower_id': me, 'followee_id': id, 'status': priv ? 'pending' : 'accepted'});

Future<void> unfollow(String id) => sb.from('follows').delete().eq('follower_id', me!).eq('followee_id', id);

final _purls = <String, Future<String>>{};
Future<String> postUrl(String path) => _purls.putIfAbsent(path, () => sb.storage.from('post-images').createSignedUrl(path, 3600));

// ---------- text with #hashtags and @mentions ----------
Future<void> openTag(BuildContext c, String t) async {
  if (t.startsWith('http')) {
    try {
      await launchUrl(Uri.parse(t), mode: LaunchMode.externalApplication);
    } catch (_) {}
    return;
  }
  if (t.startsWith('#')) {
    Navigator.push(c, MaterialPageRoute(builder: (_) => PostListPage('#${t.substring(1)}', () => postsByTag(t.substring(1)))));
    return;
  }
  final r = await sb.from('profiles').select(profCols).eq('username', t.substring(1).toLowerCase()).maybeSingle();
  if (r != null && c.mounted) {
    store.people[r['id'] as String] = r;
    Navigator.push(c, MaterialPageRoute(builder: (_) => ProfilePage(r['id'] as String)));
  }
}

Widget richBody(BuildContext c, String text, {Color? link}) {
  final spans = <InlineSpan>[];
  var last = 0;
  final re = RegExp(
    r'(https?://[^\s]+|[#@][\p{L}\p{N}_]+|`[^`\n]+`|\*[^*\n]+\*|(?<![\p{L}\p{N}_])_[^_\n]+_(?![\p{L}\p{N}_]))',
    unicode: true,
  );
  for (final m in re.allMatches(text)) {
    if (m.start > last) spans.add(TextSpan(text: text.substring(last, m.start)));
    final t = m.group(0)!;
    final f = t[0];
    if (f == '`') {
      spans.add(TextSpan(text: t.substring(1, t.length - 1), style: const TextStyle(fontFamily: 'monospace', backgroundColor: Color(0x22000000))));
    } else if (f == '*') {
      spans.add(TextSpan(text: t.substring(1, t.length - 1), style: const TextStyle(fontWeight: FontWeight.w800)));
    } else if (f == '_') {
      spans.add(TextSpan(text: t.substring(1, t.length - 1), style: const TextStyle(fontStyle: FontStyle.italic)));
    } else {
      spans.add(TextSpan(
        text: t,
        style: TextStyle(color: link ?? accent, fontWeight: FontWeight.w600, decoration: link != null ? TextDecoration.underline : null),
        recognizer: TapGestureRecognizer()..onTap = () => openTag(c, t),
      ));
    }
    last = m.end;
  }
  if (last < text.length) spans.add(TextSpan(text: text.substring(last)));
  return Text.rich(TextSpan(children: spans, style: const TextStyle(height: 1.5)));
}

// ---------- post widgets ----------
class PostImage extends StatelessWidget {
  final String path;
  const PostImage(this.path, {super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
        future: postUrl(path),
        builder: (c, s) {
          if (s.hasError) return const Icon(Icons.broken_image);
          if (!s.hasData) return const SizedBox(height: 160, child: Center(child: CircularProgressIndicator()));
          final url = s.data!;
          return GestureDetector(
            onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(), body: Center(child: InteractiveViewer(child: Image.network(url)))))),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(url, width: double.infinity, height: 260, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
            ),
          );
        },
      );
}

class PostCard extends StatefulWidget {
  final Map<String, dynamic> post;
  final VoidCallback onChanged;
  const PostCard(this.post, this.onChanged, {super.key});
  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  late bool liked, saved;
  late int likes, comments;
  Map<String, dynamic>? get p => widget.post['repost_of'] != null ? widget.post['_orig'] as Map<String, dynamic>? : widget.post;

  @override
  void initState() {
    super.initState();
    final x = p;
    liked = x?['_liked'] == true;
    saved = x?['_saved'] == true;
    likes = x == null ? 0 : cnt(x, 'likes');
    comments = x == null ? 0 : cnt(x, 'comments');
    if (x != null && x['author_id'] != me) recordPostView(x['id'] as int);
  }

  Future<void> like() async {
    final id = p!['id'] as int;
    setState(() {
      liked = !liked;
      likes += liked ? 1 : -1;
    });
    try {
      await setLike(id, liked);
    } catch (_) {
      if (mounted) {
        setState(() {
          liked = !liked;
          likes += liked ? 1 : -1;
        });
      }
    }
  }

  Future<void> save() async {
    final id = p!['id'] as int;
    setState(() => saved = !saved);
    try {
      await setSave(id, saved);
    } catch (_) {
      if (mounted) setState(() => saved = !saved);
    }
  }

  Widget act(IconData i, String label, VoidCallback f, {Color? color}) => InkWell(
        onTap: f,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(children: [Icon(i, size: 20, color: color ?? cTextDim), if (label.isNotEmpty) Text(' $label', style: TextStyle(color: cTextDim))]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final x = p;
    final isRepost = widget.post['repost_of'] != null;
    final mineCard = widget.post['author_id'] == me;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(settings.cardRadius), boxShadow: softShadow(), border: isDark ? null : Border.all(color: cLine)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (isRepost)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(children: [
              Icon(Icons.repeat, size: 14, color: accent),
              const SizedBox(width: 4),
              Text(trf('{0} بازنشر کرد', [store.name(widget.post['author_id'] as String)]), style: TextStyle(color: accent, fontSize: 12)),
            ]),
          ),
        if (x == null)
          Text(trn('این پست در دسترس نیست'), style: TextStyle(color: cTextFaint))
        else ...[
          Row(children: [
            GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(x['author_id'] as String))),
              child: avatarFor(x['author_id'] as String),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                nameWithBadge(x['author_id'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(ago(x['created_at'] as String), style: TextStyle(color: cTextFaint, fontSize: 11)),
              ]),
            ),
            PopupMenuButton<String>(
              onSelected: (v) async {
                if (v == 'del') {
                  if (await confirm(context, trn('این پست حذف شود؟'))) {
                    await sb.from('posts').delete().eq('id', widget.post['id'] as int);
                    widget.onChanged();
                  }
                } else if (v == 'report') {
                  reportDialog(context, 'post', '${x['id']}');
                } else if (v == 'block') {
                  await blockDialog(context, x['author_id'] as String);
                  widget.onChanged();
                }
              },
              itemBuilder: (_) => mineCard
                  ? [PopupMenuItem(value: 'del', child: Text(trn('حذف')))]
                  : [PopupMenuItem(value: 'report', child: Text(trn('گزارش پست'))), PopupMenuItem(value: 'block', child: Text(trn('مسدود کردن نویسنده')))],
            ),
          ]),
          if ((x['body'] as String).isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: richBody(context, x['body'] as String)),
          if (x['image_path'] != null) Padding(padding: const EdgeInsets.only(top: 10), child: PostImage(x['image_path'] as String)),
          const SizedBox(height: 6),
          Row(children: [
            act(liked ? Icons.favorite : Icons.favorite_border, '$likes', like, color: liked ? Colors.redAccent : null),
            act(Icons.mode_comment_outlined, '$comments', () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => CommentsPage(x['id'] as int)));
              widget.onChanged();
            }),
            act(Icons.repeat, '', () async {
              try {
                await sb.from('posts').insert({'author_id': me, 'repost_of': x['id']});
                if (context.mounted) snack(context, trn('بازنشر شد'));
              } catch (_) {
                if (context.mounted) snack(context, trn('بازنشر نشد'));
              }
            }),
            const Spacer(),
            act(saved ? Icons.bookmark : Icons.bookmark_border, '', save, color: saved ? accent : null),
          ]),
        ],
      ]),
    );
  }
}

class PostList extends StatefulWidget {
  final Future<List<Map<String, dynamic>>> Function() loader;
  final String empty;
  const PostList({super.key, required this.loader, required this.empty});
  @override
  State<PostList> createState() => _PostListState();
}

class _PostListState extends State<PostList> {
  List<Map<String, dynamic>>? posts;
  String? err;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await widget.loader();
      if (mounted) setState(() { posts = r; err = null; });
    } catch (e) {
      if (mounted) setState(() => err = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (err != null) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(trn('بارگذاری نشد')),
        Padding(padding: EdgeInsets.all(12), child: Text(err!, style: TextStyle(fontSize: 11, color: cTextFaint))),
        TextButton(onPressed: load, child: Text(trn('تلاش دوباره'))),
      ]));
    }
    if (posts == null) return const Center(child: CircularProgressIndicator());
    if (posts!.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(widget.empty, textAlign: TextAlign.center)));
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(children: [for (final p in posts!) PostCard(p, load, key: ValueKey('${p['id']}'))]),
    );
  }
}

class PostListPage extends StatelessWidget {
  final String title;
  final Future<List<Map<String, dynamic>>> Function() loader;
  const PostListPage(this.title, this.loader, {super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title)), body: PostList(loader: loader, empty: trn('پستی نیست')));
}

class FeedTab extends StatefulWidget {
  const FeedTab({super.key});
  @override
  State<FeedTab> createState() => _FeedTabState();
}

class _FeedTabState extends State<FeedTab> {
  int v = 0;
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Row(children: [
              ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/icon.png', width: 32, height: 32)),
              const SizedBox(width: 10),
              const Text('Tia'),
            ]),
            actions: [
              IconButton(icon: const Icon(Icons.insights_outlined), tooltip: trn('پروفایل و آمار من'), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MyHubPage()))),
              IconButton(icon: const Icon(Icons.search), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage()))),
            ],
            bottom: TabBar(tabs: [Tab(text: trn('دنبال‌شوندگان')), Tab(text: trn('پیشنهادی'))]),
          ),
          body: Column(children: [
            StoriesBar(key: ValueKey('s$v')),
            Expanded(
              child: TabBarView(children: [
            PostList(key: ValueKey('f$v'), loader: feedFollowing, empty: trn('هنوز پستی نیست.\nچند نفر را دنبال کنید یا اولین پست را بنویسید.')),
            PostList(key: ValueKey('e$v'), loader: feedExplore, empty: trn('پستی نیست')),
              ]),
            ),
          ]),
          floatingActionButton: FloatingActionButton(
            backgroundColor: primary,
            foregroundColor: cOnPrimary,
            child: const Icon(Icons.edit),
            onPressed: () async {
              final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const ComposePage()));
              if (ok == true) setState(() => v++);
            },
          ),
        ),
      );
}

class ComposePage extends StatefulWidget {
  const ComposePage({super.key});
  @override
  State<ComposePage> createState() => _ComposePageState();
}

class _ComposePageState extends State<ComposePage> {
  final ctrl = TextEditingController();
  PlatformFile? img;
  bool busy = false;

  Future<void> post() async {
    final t = ctrl.text.trim();
    if (t.isEmpty && img == null) return;
    setState(() => busy = true);
    try {
      String? up;
      if (img != null) up = await uploadFile('post-images', img!.path!, img!.name);
      await sb.from('posts').insert({'author_id': me, 'body': t, 'image_path': up});
      if (mounted) Navigator.pop(context, true);
    } catch (_) {
      if (mounted) {
        snack(context, trn('ارسال نشد. اینترنت را بررسی کنید.'));
        setState(() => busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('پست جدید')), actions: [TextButton(onPressed: busy ? null : post, child: Text(trn('انتشار')))]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          TextField(controller: ctrl, maxLines: 6, decoration: fieldDeco(hintText: trn('چه خبر؟ از #هشتگ و @نام_کاربری استفاده کنید'))),
          const SizedBox(height: 12),
          if (img != null) ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(img!.path!), height: 180, fit: BoxFit.cover)),
          Row(children: [
            TextButton.icon(
              onPressed: () async {
                final f = await pickImage();
                if (f != null) setState(() => img = f);
              },
              icon: const Icon(Icons.image),
              label: Text(img == null ? trn('افزودن عکس') : trn('تغییر عکس')),
            ),
            if (img != null) TextButton(onPressed: () => setState(() => img = null), child: Text(trn('حذف عکس'))),
          ]),
          if (busy) const LinearProgressIndicator(),
        ]),
      );
}

class CommentsPage extends StatefulWidget {
  final int postId;
  const CommentsPage(this.postId, {super.key});
  @override
  State<CommentsPage> createState() => _CommentsPageState();
}

class _CommentsPageState extends State<CommentsPage> {
  final ctrl = TextEditingController();
  List<Map<String, dynamic>> items = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final rows = await sb.from('comments').select().eq('post_id', widget.postId).order('created_at');
      await store.loadPeople(rows.map((r) => r['user_id'] as String));
      if (mounted) setState(() => items = rows);
    } catch (_) {}
  }

  Future<void> send() async {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    ctrl.clear();
    try {
      await sb.from('comments').insert({'post_id': widget.postId, 'user_id': me, 'body': t});
      await load();
    } catch (_) {
      if (mounted) snack(context, trn('ارسال نشد'));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('نظرات'))),
        body: Column(children: [
          Expanded(
            child: items.isEmpty
                ? Center(child: Text(trn('هنوز نظری نیست')))
                : ListView(children: [
                    for (final c in items)
                      ListTile(
                        leading: avatarFor(c['user_id'] as String),
                        title: nameWithBadge(c['user_id'] as String),
                        subtitle: richBody(context, c['body'] as String),
                      ),
                  ]),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                Expanded(child: TextField(controller: ctrl, onSubmitted: (_) => send(), decoration: fieldDeco(hintText: trn('نظر بنویسید...')))),
                IconButton(icon: Icon(Icons.send, color: primary), onPressed: send),
              ]),
            ),
          ),
        ]),
      );
}

// ---------- profile ----------
class ProfilePage extends StatefulWidget {
  final String id;
  const ProfilePage(this.id, {super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool loading = true;
  String? err;
  String status = 'none';
  int followers = 0, following = 0;
  List<Map<String, dynamic>>? posts;
  Map<String, dynamic> get prof => store.people[widget.id] ?? {};
  bool get canSeeLists => status == 'me' || prof['is_private'] != true || status == 'accepted';

  void openList(bool followersList) {
    if (!canSeeLists) {
      snack(context, trn('🔒 حساب خصوصی است؛ برای دیدن فهرست باید دنبالش کنید'));
      return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => FollowListPage(widget.id, followersList)));
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await sb.from('profiles').select(profCols).eq('id', widget.id).single();
      store.people[widget.id] = r;
      final fl = await sb.from('follows').select('follower_id').eq('followee_id', widget.id).eq('status', 'accepted');
      final fg = await sb.from('follows').select('followee_id').eq('follower_id', widget.id).eq('status', 'accepted');
      final st = widget.id == me ? 'me' : await followStatus(widget.id);
      if (widget.id != me) {
        try {
          await store.loadLastSeen([widget.id]);
        } catch (_) {}
      }
      final see = st == 'me' || r['is_private'] != true || st == 'accepted';
      final ps = see ? await postsOf(widget.id) : null;
      if (!mounted) return;
      setState(() {
        followers = fl.length;
        following = fg.length;
        status = st;
        posts = ps;
        loading = false;
        err = null;
      });
    } catch (e) {
      if (mounted) setState(() { err = '$e'; loading = false; });
    }
  }

  Future<void> toggleFollow() async {
    try {
      if (status == 'none') {
        await follow(widget.id, prof['is_private'] == true);
      } else {
        await unfollow(widget.id);
      }
      await load();
    } catch (_) {
      if (mounted) snack(context, trn('انجام نشد'));
    }
  }

  Widget stat(String label, String v) => Column(children: [Text(v, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text(label, style: TextStyle(color: cTextFaint))]);

  @override
  Widget build(BuildContext context) {
    if (loading) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    if (err != null) return Scaffold(appBar: AppBar(), body: Center(child: Padding(padding: const EdgeInsets.all(16), child: Text(trf('بارگذاری نشد\n{0}', [err])))));
    final uname = prof['username'] as String?;
    final bio = prof['bio'] as String?;
    final isMe = status == 'me';
    return Scaffold(
      appBar: AppBar(
        title: Text(store.name(widget.id)),
        actions: [
          if (!isMe)
            PopupMenuButton<String>(
              onSelected: (v) async {
                if (v == 'report') {
                  reportDialog(context, 'user', widget.id);
                } else if (v == 'unblock') {
                  await safety.unblock(widget.id);
                  if (mounted) setState(() {});
                } else {
                  await blockDialog(context, widget.id);
                  if (mounted) setState(() {});
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: safety.isBlocked(widget.id) ? 'unblock' : 'block', child: Text(safety.isBlocked(widget.id) ? trn('رفع مسدودی') : trn('مسدود کردن'))),
                PopupMenuItem(value: 'report', child: Text(trn('گزارش تخلف'))),
              ],
            ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(children: [
          Container(
            decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color.lerp(bg, primary, isDark ? 0.35 : 0.16)!, bg])),
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              avatarFor(widget.id, r: 44),
              const SizedBox(height: 8),
              nameWithBadge(widget.id, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              if (uname != null && uname.isNotEmpty) Text('@$uname', style: TextStyle(color: accent)),
              if (seenText(widget.id) != null) Text(seenText(widget.id)!, style: TextStyle(color: cTextFaint, fontSize: 12)),
              if (prof['is_private'] == true) Padding(padding: EdgeInsets.only(top: 4), child: Text(trn('🔒 حساب خصوصی'), style: TextStyle(color: cTextFaint, fontSize: 12))),
              if (bio != null && bio.isNotEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(bio, textAlign: TextAlign.center)),
              const SizedBox(height: 8),
              Row(children: [
                StatBox(trn('پست'), posts == null ? '-' : '${posts!.length}'),
                StatBox(trn('دنبال‌کننده'), '$followers', onTap: () => openList(true)),
                StatBox(trn('دنبال‌شونده'), '$following', onTap: () => openList(false)),
              ]),
              const SizedBox(height: 12),
              if (isMe)
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => const EditProfilePage()));
                      load();
                    },
                    child: Text(trn('ویرایش پروفایل')),
                  ),
                )
              else
                Row(children: [
                  Expanded(
                    child: FilledButton(
                      onPressed: toggleFollow,
                      child: Text(status == 'none' ? trn('دنبال کردن') : status == 'pending' ? trn('درخواست ارسال شد') : trn('دنبال می‌کنید')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton(onPressed: () => openChat(context, widget.id), child: Text(trn('پیام'))),
                ]),
            ]),
          ),
          const Divider(),
          if (posts == null)
            Padding(padding: EdgeInsets.all(32), child: Center(child: Text(trn('🔒 برای دیدن پست‌ها باید این حساب را دنبال کنید'))))
          else if (posts!.isEmpty)
            Padding(padding: EdgeInsets.all(32), child: Center(child: Text(trn('هنوز پستی نیست'))))
          else
            for (final p in posts!) PostCard(p, load, key: ValueKey('${p['id']}')),
        ]),
      ),
    );
  }
}

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});
  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late final name = TextEditingController(text: store.name(me!));
  late final uname = TextEditingController(text: (store.people[me!]?['username'] as String?) ?? '');
  late final bio = TextEditingController(text: (store.people[me!]?['bio'] as String?) ?? '');
  late bool priv = store.people[me!]?['is_private'] == true;
  bool busy = false;

  Future<void> changeAvatar() async {
    final f = await pickImage();
    if (f == null) return;
    setState(() => busy = true);
    try {
      final path = await uploadFile('avatars', f.path!, f.name);
      await sb.from('profiles').update({'avatar_path': path}).eq('id', me!);
      store.refreshPerson(me!, {...store.people[me!]!, 'avatar_path': path});
    } catch (_) {
      if (mounted) snack(context, trn('تغییر عکس انجام نشد'));
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> save() async {
    final u = uname.text.trim().toLowerCase();
    if (name.text.trim().isEmpty) return;
    if (u.isNotEmpty && !RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(u)) {
      snack(context, trn('نام کاربری: حروف انگلیسی، عدد و _ (۳ تا ۲۰ کاراکتر)'));
      return;
    }
    setState(() => busy = true);
    try {
      final data = {'name': name.text.trim(), 'username': u.isEmpty ? null : u, 'bio': bio.text.trim(), 'is_private': priv};
      await sb.from('profiles').update(data).eq('id', me!);
      store.refreshPerson(me!, {...store.people[me!]!, ...data});
      if (mounted) Navigator.pop(context);
    } on PostgrestException catch (e) {
      if (mounted) {
        snack(context, e.code == '23505' ? trn('این نام کاربری قبلاً گرفته شده') : trn('ذخیره نشد'));
        setState(() => busy = false);
      }
    } catch (_) {
      if (mounted) {
        snack(context, trn('ذخیره نشد'));
        setState(() => busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('ویرایش پروفایل')), actions: [TextButton(onPressed: busy ? null : save, child: Text(trn('ذخیره')))]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Center(child: GestureDetector(onTap: changeAvatar, child: Stack(children: [avatarFor(me!, r: 50), const Positioned(bottom: 0, left: 0, child: CircleAvatar(radius: 14, child: Icon(Icons.camera_alt, size: 16)))]))),
          const SizedBox(height: 16),
          TextField(controller: name, decoration: fieldDeco(labelText: trn('نام'))),
          const SizedBox(height: 12),
          TextField(controller: uname, decoration: fieldDeco(labelText: trn('نام کاربری (انگلیسی)'))),
          const SizedBox(height: 12),
          TextField(controller: bio, maxLines: 3, decoration: fieldDeco(labelText: trn('بیوگرافی'))),
          SwitchListTile(title: Text(trn('حساب خصوصی')), subtitle: Text(trn('فقط دنبال‌کنندگان تاییدشده پست‌های شما را می‌بینند')), value: priv, onChanged: (v) => setState(() => priv = v)),
          if (busy) const LinearProgressIndicator(),
        ]),
      );
}

class RequestsPage extends StatefulWidget {
  const RequestsPage({super.key});
  @override
  State<RequestsPage> createState() => _RequestsPageState();
}

class _RequestsPageState extends State<RequestsPage> {
  List<String> ids = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await sb.from('follows').select('follower_id').eq('followee_id', me!).eq('status', 'pending');
      final l = r.map((x) => x['follower_id'] as String).toList();
      await store.loadPeople(l);
      if (mounted) setState(() => ids = l);
    } catch (_) {}
  }

  Future<void> answer(String id, bool ok) async {
    try {
      final q = sb.from('follows');
      if (ok) {
        await q.update({'status': 'accepted'}).eq('follower_id', id).eq('followee_id', me!);
      } else {
        await q.delete().eq('follower_id', id).eq('followee_id', me!);
      }
      await load();
    } catch (_) {
      if (mounted) snack(context, trn('انجام نشد'));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('درخواست‌های دنبال‌کردن'))),
        body: ids.isEmpty
            ? Center(child: Text(trn('درخواستی نیست')))
            : ListView(children: [
                for (final id in ids)
                  ListTile(
                    leading: avatarFor(id),
                    title: nameWithBadge(id),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.check, color: Colors.greenAccent), onPressed: () => answer(id, true)),
                      IconButton(icon: const Icon(Icons.close, color: Colors.redAccent), onPressed: () => answer(id, false)),
                    ]),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(id))),
                  ),
              ]),
      );
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  List<Map<String, dynamic>> res = [];

  Future<void> search(String q) async {
    final s = q.trim().replaceAll(RegExp(r'[,()%*]'), '');
    if (s.length < 2) {
      setState(() => res = []);
      return;
    }
    try {
      final r = await sb.from('profiles').select(profCols).or('username.ilike.%$s%,name.ilike.%$s%').limit(20);
      for (final p in r) {
        store.people[p['id'] as String] = p;
      }
      if (mounted) setState(() => res = r);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: TextField(autofocus: true, onChanged: search, decoration: fieldDeco(hintText: trn('جستجوی نام یا نام کاربری...'), plain: true))),
        body: ListView(children: [
          for (final p in res)
            ListTile(
              leading: avatarFor(p['id'] as String),
              title: nameWithBadge(p['id'] as String),
              subtitle: Text(p['username'] == null ? '' : '@${p['username']}', style: TextStyle(color: accent)),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(p['id'] as String))),
            ),
        ]),
      );
}

// ---------- appearance ----------
Future<void> pickCustomColor(BuildContext c) async {
  final cur = HSVColor.fromColor(primary);
  var hsv = HSVColor.fromAHSV(1, cur.hue, cur.saturation.clamp(0.2, 1.0).toDouble(), cur.value.clamp(0.3, 1.0).toDouble());
  final ok = await showDialog<bool>(
    context: c,
    builder: (_) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: Text(trn('رنگ دلخواه')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(height: 52, decoration: BoxDecoration(color: hsv.toColor(), borderRadius: BorderRadius.circular(14))),
          const SizedBox(height: 8),
          Slider(value: hsv.hue, min: 0, max: 360, onChanged: (v) => set(() => hsv = hsv.withHue(v))),
          Slider(value: hsv.saturation, min: 0.2, max: 1, onChanged: (v) => set(() => hsv = hsv.withSaturation(v))),
          Slider(value: hsv.value, min: 0.3, max: 1, onChanged: (v) => set(() => hsv = hsv.withValue(v))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(trn('انصراف'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(trn('اعمال'))),
        ],
      ),
    ),
  );
  if (ok == true) {
    settings.customHsv = [hsv.hue, hsv.saturation, hsv.value];
    settings.save();
  }
}

class AppearancePage extends StatelessWidget {
  const AppearancePage({super.key});

  Widget dot(Widget inner, bool selected, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: selected ? cText : cLine, width: selected ? 3 : 1)),
          child: ClipOval(child: inner),
        ),
      );

  Future<void> pickWall() async {
    final f = await pickImage();
    if (f == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final dest = '${dir.path}/wall_${DateTime.now().millisecondsSinceEpoch}${extOf(f.name)}';
    await File(f.path!).copy(dest);
    settings.wallImage = dest;
    settings.save();
  }

  Widget head(String t) => Padding(padding: EdgeInsets.only(top: 22, bottom: 10), child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: cText)));

  Widget slider(String label, double v, double min, double max, int? div, void Function(double) f) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: EdgeInsets.only(top: 6), child: Text(label, style: TextStyle(color: cTextDim))),
        Slider(value: v, min: min, max: max, divisions: div, onChanged: (x) {
          f(x);
          settings.save();
        }),
      ]);

  Widget previewBubble(bool mine, String text) => Align(
        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 3),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: bubbleDeco(mine),
          child: Text(text, style: TextStyle(color: bubbleFg(mine), fontSize: 15 * settings.chatTextScale)),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('ظاهر برنامه'))),
        body: ListenableBuilder(
          listenable: settings,
          builder: (c, _) {
            final tones = isDark ? darkTones : lightTones;
            final toneIdx = isDark ? settings.bgDark : settings.bgLight;
            return ListView(padding: const EdgeInsets.all(16), children: [
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.blur_on, color: accent),
                title: Text(trn('استودیوی سایبر'), style: TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(trn('تم سایبربانکی، رنگ نئون، شکل حباب، پس‌زمینه متحرک و پروفایل‌های ظاهری')),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const CyberStudioPage())),
              ),
              Container(
                height: 170,
                padding: const EdgeInsets.all(12),
                decoration: (wallDecoration() ?? BoxDecoration(color: bg)).copyWith(borderRadius: BorderRadius.circular(settings.cardRadius), border: Border.all(color: cLine)),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  previewBubble(false, trn('سلام! حالت شما چطوره؟')),
                  previewBubble(true, trn('عالی، ممنون از شما 🌟')),
                ]),
              ),
              head(trn('حالت نمایش')),
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<int>(
                  showSelectedIcon: false,
                  segments: [
                    ButtonSegment(value: 0, label: Text(trn('خودکار')), icon: Icon(Icons.brightness_auto)),
                    ButtonSegment(value: 1, label: Text(trn('روز')), icon: Icon(Icons.light_mode)),
                    ButtonSegment(value: 2, label: Text(trn('شب')), icon: Icon(Icons.dark_mode)),
                  ],
                  selected: {settings.themeMode},
                  onSelectionChanged: (s) {
                    settings.themeMode = s.first;
                    settings.save();
                  },
                ),
              ),
              if (isDark)
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(trn('پس‌زمینه‌ی کاملاً سیاه (AMOLED)')),
                  value: settings.amoled,
                  onChanged: (v) {
                    settings.amoled = v;
                    settings.save();
                  },
                ),
              head(trn('رنگ اصلی')),
              Wrap(spacing: 12, runSpacing: 12, children: [
                for (var i = 0; i < accents.length; i++)
                  dot(ColoredBox(color: Color(accents[i])), settings.customHsv == null && settings.accentIdx == i, () {
                    settings.accentIdx = i;
                    settings.customHsv = null;
                    settings.save();
                  }),
                dot(
                  Container(
                    decoration: const BoxDecoration(gradient: SweepGradient(colors: [Colors.red, Colors.yellow, Colors.green, Colors.cyan, Colors.blue, Colors.purple, Colors.red])),
                    child: const Icon(Icons.colorize, size: 22, color: Colors.white),
                  ),
                  settings.customHsv != null,
                  () => pickCustomColor(c),
                ),
              ]),
              head(isDark ? trn('پس‌زمینه‌ی شب') : trn('پس‌زمینه‌ی روز')),
              Wrap(spacing: 12, runSpacing: 12, children: [
                for (var i = 0; i < tones.length; i++)
                  dot(
                    tones[i] == null
                        ? Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, Color.lerp(primary, isDark ? Colors.black : Colors.white, 0.7)!])), child: Icon(Icons.auto_awesome, size: 20, color: Colors.white))
                        : DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(tones[i]![0]), Color(tones[i]![1])]))),
                    toneIdx == i,
                    () {
                      if (isDark) {
                        settings.bgDark = i;
                      } else {
                        settings.bgLight = i;
                      }
                      settings.save();
                    },
                  ),
              ]),
              Padding(padding: EdgeInsets.only(top: 6), child: Text(trn('گزینه‌ی ستاره‌دار، پس‌زمینه را با رنگ اصلی هماهنگ می‌کند.'), style: TextStyle(color: cTextFaint, fontSize: 12))),
              head(trn('والپیپر چت')),
              Wrap(spacing: 12, runSpacing: 12, children: [
                for (var i = 0; i < walls.length; i++)
                  dot(
                    walls[i] == null
                        ? Center(child: Icon(Icons.block, size: 22, color: cText))
                        : DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(walls[i]![0]), Color(walls[i]![1])]))),
                    settings.wallImage == null && settings.wallIdx == i,
                    () {
                      settings.wallIdx = i;
                      settings.wallImage = null;
                      settings.save();
                    },
                  ),
              ]),
              ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.photo_library), title: Text(trn('انتخاب عکس از گالری')), onTap: pickWall),
              if (settings.wallImage != null)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.delete_outline),
                  title: Text(trn('حذف عکس والپیپر')),
                  onTap: () {
                    settings.wallImage = null;
                    settings.save();
                  },
                ),
              slider(trn('تیره‌کردن والپیپر (برای خوانایی بهتر)'), settings.wallDim, 0, 0.7, null, (v) => settings.wallDim = v),
              head(trn('حباب پیام‌ها')),
              slider(trn('گردی گوشه‌ها'), settings.bubbleRadius, 6, 28, 11, (v) => settings.bubbleRadius = v),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(trn('حباب گرادیانی برای پیام‌های من')),
                value: settings.bubbleGradient,
                onChanged: (v) {
                  settings.bubbleGradient = v;
                  settings.save();
                },
              ),
              slider(trn('اندازه‌ی متن پیام‌ها'), settings.chatTextScale, 0.8, 1.4, 6, (v) => settings.chatTextScale = v),
              head(trn('کارت‌ها و لیست‌ها')),
              slider(trn('گردی گوشه‌ی کارت‌ها'), settings.cardRadius, 6, 28, 11, (v) => settings.cardRadius = v),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(trn('لیست فشرده')),
                value: settings.dense,
                onChanged: (v) {
                  settings.dense = v;
                  settings.save();
                },
              ),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                icon: const Icon(Icons.restart_alt),
                label: Text(trn('بازگشت به تنظیمات پیش‌فرض')),
                onPressed: () async {
                  if (await confirm(c, trn('همه‌ی تنظیمات ظاهری به حالت پیش‌فرض برگردد؟'))) settings.resetAppearance();
                },
              ),
              const SizedBox(height: 8),
              Text(trn('این تنظیمات روی همین گوشی ذخیره می‌شوند.'), style: TextStyle(color: cTextFaint, fontSize: 12)),
            ]);
          },
        ),
      );
}

// ---------- contacts sync ----------
String? last10(String raw) {
  const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
  final b = StringBuffer();
  for (final ch in raw.split('')) {
    final i = fa.indexOf(ch), j = ar.indexOf(ch);
    if (i >= 0) {
      b.write(i);
    } else if (j >= 0) {
      b.write(j);
    } else if (RegExp(r'[0-9]').hasMatch(ch)) {
      b.write(ch);
    }
  }
  final d = b.toString();
  return d.length >= 10 ? d.substring(d.length - 10) : null;
}

Future<void> syncContacts(BuildContext c) async {
  void msg(String t) {
    if (c.mounted) snack(c, t);
  }

  if (!await confirm(c, trn('شماره‌ی مخاطبین گوشی برای پیدا کردن کاربران Tia به سرور فرستاده می‌شود (ذخیره نمی‌شود). ادامه می‌دهید؟'))) return;
  try {
    if (!await fc.FlutterContacts.requestPermission(readonly: true)) {
      msg(trn('اجازه‌ی دسترسی به مخاطبین داده نشد'));
      return;
    }
    final list = await fc.FlutterContacts.getContacts(withProperties: true);
    final nums = <String>{};
    for (final x in list) {
      for (final ph in x.phones) {
        final d = last10(ph.number);
        if (d != null) nums.add(d);
      }
    }
    final all = nums.toList();
    final found = <String, Map<String, dynamic>>{};
    for (var i = 0; i < all.length; i += 500) {
      final end = i + 500 > all.length ? all.length : i + 500;
      final r = await sb.rpc('match_contacts', params: {'p_phones': all.sublist(i, end)}) as List;
      for (final e in r) {
        final m = Map<String, dynamic>.from(e as Map);
        found[m['id'] as String] = m;
      }
    }
    if (found.isEmpty) {
      msg(trn('هیچ‌کدام از مخاطبین گوشی شما هنوز در Tia نیستند'));
      return;
    }
    store.people.addAll(found);
    await sb.from('contacts').upsert([for (final id in found.keys) {'owner_id': me, 'contact_id': id}]);
    await store.loadContacts();
    msg(trf('{0} مخاطب از گوشی شما در Tia پیدا و اضافه شد', [found.length]));
  } catch (_) {
    msg(trn('همگام‌سازی انجام نشد'));
  }
}

// ---------- chat info ----------
class ChatInfoPage extends StatefulWidget {
  final String id;
  const ChatInfoPage(this.id, {super.key});
  @override
  State<ChatInfoPage> createState() => _ChatInfoPageState();
}

class _ChatInfoPageState extends State<ChatInfoPage> {
  String status = 'none';
  bool loading = true;
  Map<String, dynamic> get p => store.people[widget.id] ?? {};

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await sb.from('profiles').select(profCols).eq('id', widget.id).single();
      store.people[widget.id] = r;
      status = await followStatus(widget.id);
      await store.loadPhones([widget.id]);
      await store.loadLastSeen([widget.id]);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  Future<void> toggleFollow() async {
    try {
      if (status == 'none') {
        await follow(widget.id, p['is_private'] == true);
      } else {
        await unfollow(widget.id);
      }
      await load();
    } catch (_) {
      if (mounted) snack(context, trn('انجام نشد'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final phone = store.phones[widget.id] ?? '';
    final uname = (p['username'] as String?) ?? '';
    final bio = (p['bio'] as String?) ?? '';
    final blockedNow = safety.isBlocked(widget.id);
    return Scaffold(
      appBar: AppBar(title: Text(trn('اطلاعات مخاطب'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Center(child: avatarFor(widget.id, r: 48)),
        const SizedBox(height: 12),
        Center(child: nameWithBadge(widget.id, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        const SizedBox(height: 16),
        ListTile(leading: const Icon(Icons.phone), title: Text(phone.isEmpty ? trn('مخفی (فقط برای مخاطبین)') : phone, textDirection: TextDirection.ltr, textAlign: TextAlign.right), subtitle: Text(trn('شماره موبایل'))),
        ListTile(leading: const Icon(Icons.alternate_email), title: Text(uname.isEmpty ? trn('ندارد') : uname, textDirection: TextDirection.ltr, textAlign: TextAlign.right), subtitle: Text(trn('نام کاربری'))),
        if (seenText(widget.id) != null) ListTile(leading: const Icon(Icons.access_time), title: Text(seenText(widget.id)!), subtitle: Text(trn('وضعیت حضور'))),
        if (bio.isNotEmpty) ListTile(leading: const Icon(Icons.info_outline), title: Text(bio), subtitle: Text(trn('بیوگرافی'))),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: loading ? null : toggleFollow,
          child: Text(status == 'none' ? trn('دنبال کردن') : status == 'pending' ? trn('درخواست ارسال شد (لغو)') : trn('دنبال می‌کنید (لغو)')),
        ),
        const SizedBox(height: 8),
        OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(widget.id))), child: Text(trn('مشاهده‌ی پروفایل و پست‌ها'))),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          icon: const Icon(Icons.perm_media_outlined),
          label: Text(trn('رسانه‌ها، فایل‌ها و لینک‌ها')),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SharedMediaPage(store.name(widget.id), store.msgsWith(widget.id)))),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          icon: Icon(blockedNow ? Icons.lock_open : Icons.block),
          label: Text(blockedNow ? trn('رفع مسدودی') : trn('مسدود کردن')),
          onPressed: () async {
            if (blockedNow) {
              await safety.unblock(widget.id);
            } else {
              await blockDialog(context, widget.id);
            }
            if (mounted) setState(() {});
          },
        ),
        TextButton.icon(icon: const Icon(Icons.flag_outlined), label: Text(trn('گزارش تخلف')), onPressed: () => reportDialog(context, 'user', widget.id)),
      ]),
    );
  }
}


/// کارت بزرگ آمار (پست / دنبال‌کننده / دنبال‌شونده)؛ با onTap قابل لمس است
class StatBox extends StatelessWidget {
  final String label, value;
  final VoidCallback? onTap;
  const StatBox(this.label, this.value, {super.key, this.onTap});

  @override
  Widget build(BuildContext context) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Material(
            color: card,
            elevation: isDark ? 0 : 1.5,
            shadowColor: Colors.black26,
            borderRadius: BorderRadius.circular(settings.cardRadius),
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(label, style: TextStyle(fontSize: 13, color: cTextDim)),
                ]),
              ),
            ),
          ),
        ),
      );
}

/// فهرست دنبال‌کنندگان یا دنبال‌شوندگان یک کاربر؛ لمس هر نفر پروفایلش را باز می‌کند
class FollowListPage extends StatefulWidget {
  final String id;
  final bool followers;
  const FollowListPage(this.id, this.followers, {super.key});
  @override
  State<FollowListPage> createState() => _FollowListPageState();
}

class _FollowListPageState extends State<FollowListPage> {
  List<String> ids = [];
  bool loading = true, failed = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      failed = false;
    });
    try {
      final col = widget.followers ? 'follower_id' : 'followee_id';
      final other = widget.followers ? 'followee_id' : 'follower_id';
      final r = await sb.from('follows').select(col).eq(other, widget.id).eq('status', 'accepted');
      final l = [for (final x in r) x[col] as String];
      await store.loadPeople(l);
      if (!mounted) return;
      setState(() {
        ids = l;
        loading = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          failed = true;
          loading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('${widget.followers ? trn('دنبال‌کنندگان') : trn('دنبال‌شوندگان')} ${store.name(widget.id)}')),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : failed
                ? Center(child: FilledButton(onPressed: load, child: Text(trn('بارگذاری نشد؛ تلاش دوباره'))))
                : ids.isEmpty
                    ? Center(child: Text(widget.followers ? trn('هنوز دنبال‌کننده‌ای ندارد') : trn('هنوز کسی را دنبال نکرده'), style: TextStyle(color: cTextFaint)))
                    : RefreshIndicator(
                        onRefresh: load,
                        child: ListView(children: [
                          for (final id in ids)
                            ListTile(
                              leading: avatarFor(id),
                              title: nameWithBadge(id),
                              subtitle: (store.people[id]?['username'] as String?) == null ? null : Text('@${store.people[id]!['username']}', style: TextStyle(color: accent)),
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(id))),
                            ),
                        ]),
                      ),
      );
}
