import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_translation/google_mlkit_translation.dart';
import 'ai.dart';
import 'cyber.dart';
import 'l10n.dart';
import 'main.dart';
import 'ui_kit.dart';

// ===========================================================================
// تشخیص زبان
// ===========================================================================
String detectLang(String t) {
  var fa = 0, la = 0;
  for (final r in t.runes) {
    if ((r >= 0x0600 && r <= 0x06FF) || (r >= 0x0750 && r <= 0x077F)) {
      fa++;
    } else if ((r >= 0x41 && r <= 0x5A) || (r >= 0x61 && r <= 0x7A)) {
      la++;
    }
  }
  if (fa == 0 && la == 0) return 'other';
  return fa >= la ? 'fa' : 'en';
}

String faDigits(String s) {
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  final b = StringBuffer();
  for (final r in s.runes) {
    final c = String.fromCharCode(r);
    final i = '0123456789'.indexOf(c);
    b.write(i >= 0 ? fa[i] : c);
  }
  return b.toString();
}

// ===========================================================================
// ترجمه (سرویس آنلاین: MyMemory و در صورت خرابی، سرویس گوگل)
// ===========================================================================
const Map<String, String> trLangs = {
  'fa': 'فارسی',
  'en': 'انگلیسی',
  'ar': 'عربی',
  'tr': 'ترکی',
  'de': 'آلمانی',
  'fr': 'فرانسوی',
  'es': 'اسپانیایی',
  'ru': 'روسی',
};

final Map<String, String> _trCache = {};

// ---- ترجمه‌ی روی گوشی (ML Kit) فقط برای فارسی و انگلیسی ----
TranslateLanguage? _mlLang(String l) => l == 'fa' ? TranslateLanguage.persian : (l == 'en' ? TranslateLanguage.english : null);

Future<bool> mlReady(String l) async {
  final t = _mlLang(l);
  if (t == null) return false;
  try {
    return await OnDeviceTranslatorModelManager().isModelDownloaded(t.bcpCode);
  } catch (_) {
    return false;
  }
}

Future<bool> mlDownload(String l) async {
  final t = _mlLang(l);
  if (t == null) return false;
  try {
    return await OnDeviceTranslatorModelManager().downloadModel(t.bcpCode, isWifiRequired: false);
  } catch (_) {
    return false;
  }
}

Future<String?> _mlTranslate(String text, String from, String to) async {
  final a = _mlLang(from), b = _mlLang(to);
  if (a == null || b == null) return null;
  if (!await mlReady(from) || !await mlReady(to)) return null;
  final tr = OnDeviceTranslator(sourceLanguage: a, targetLanguage: b);
  try {
    final r = (await tr.translateText(text)).trim();
    return r.isEmpty ? null : r;
  } catch (_) {
    return null;
  } finally {
    tr.close();
  }
}

Future<String> _httpGet(Uri u) async {
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 10);
  try {
    final req = await c.getUrl(u);
    req.headers.set('User-Agent', 'Mozilla/5.0 (Linux; Android 13) Tia');
    final res = await req.close().timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) throw 'http ${res.statusCode}';
    return await utf8.decoder.bind(res).join();
  } finally {
    c.close(force: true);
  }
}

Future<String?> _myMemory(String q, String from, String to) async {
  try {
    final src = from == 'other' ? 'en' : from;
    if (src == to) return q;
    final body = await _httpGet(Uri.https('api.mymemory.translated.net', '/get', {'q': q, 'langpair': '$src|$to'}));
    final j = jsonDecode(body) as Map<String, dynamic>;
    final st = '${j['responseStatus']}';
    final t = ((j['responseData'] as Map?)?['translatedText'] as String?)?.trim();
    if (st != '200' || t == null || t.isEmpty) return null;
    final up = t.toUpperCase();
    if (up.contains('MYMEMORY WARNING') || up.contains('PLEASE SELECT TWO DISTINCT') || up.contains('INVALID')) return null;
    if (t == q.trim()) return null; // ترجمه نشده؛ به سرویس بعدی برو
    return t;
  } catch (_) {
    return null;
  }
}

Future<String?> _google(String q, String to) async {
  try {
    final body = await _httpGet(Uri.https('translate.googleapis.com', '/translate_a/single', {'client': 'gtx', 'sl': 'auto', 'tl': to, 'dt': 't', 'q': q}));
    final j = jsonDecode(body) as List;
    final parts = j[0] as List;
    final b = StringBuffer();
    for (final p in parts) {
      final s = (p as List)[0];
      if (s is String) b.write(s);
    }
    final t = b.toString().trim();
    return t.isEmpty ? null : t;
  } catch (_) {
    return null;
  }
}

List<String> _chunks(String t, int max) {
  final units = <String>[];
  for (final line in t.split('\n')) {
    if (line.length <= max) {
      units.add(line);
      continue;
    }
    final sents = RegExp(r'[^.!?؟!؛]+[.!?؟!؛]*').allMatches(line).map((m) => m.group(0)!).toList();
    var cur = '';
    for (final s in sents) {
      if (cur.length + s.length > max && cur.isNotEmpty) {
        units.add(cur);
        cur = '';
      }
      var x = s;
      while (x.length > max) {
        units.add(x.substring(0, max));
        x = x.substring(max);
      }
      cur += x;
    }
    if (cur.isNotEmpty) units.add(cur);
  }
  final out = <String>[];
  var cur = '';
  for (final u in units) {
    if (cur.isNotEmpty && cur.length + u.length + 1 > max) {
      out.add(cur);
      cur = u;
    } else {
      cur = cur.isEmpty ? u : '$cur\n$u';
    }
  }
  if (cur.isNotEmpty) out.add(cur);
  return out;
}

/// ترجمه‌ی متن به زبان [to]. در صورت خطا استثنا پرتاب می‌شود.
Future<String> translateText(String text, String to) async {
  final t = text.trim();
  if (t.isEmpty) return t;
  final key = '$to|$t';
  final hit = _trCache[key];
  if (hit != null) return hit;
  final from = detectLang(t);
  if (from == 'other' || from == to) return t;
  final local = await _mlTranslate(t, from, to);
  if (local != null) {
    _trCache[key] = local;
    return local;
  }
  final out = <String>[];
  for (final part in _chunks(t, 450)) {
    if (part.trim().isEmpty) {
      out.add(part);
      continue;
    }
    var r = await _myMemory(part, from, to);
    r ??= await _google(part, to);
    if (r == null) throw 'translate';
    out.add(r);
  }
  final res = out.join('\n');
  _trCache[key] = res;
  if (_trCache.length > 300) _trCache.remove(_trCache.keys.first);
  return res;
}

// ===========================================================================
// خلاصه‌سازی (روی گوشی، بدون اینترنت)
// ===========================================================================
final Set<String> _stop = {
  // فارسی
  'و', 'در', 'به', 'از', 'که', 'این', 'آن', 'را', 'با', 'برای', 'است', 'هست', 'بود', 'شد', 'می', 'هم', 'یا', 'اما', 'ولی', 'تا', 'بر', 'هر', 'یک', 'من', 'تو', 'او',
  'ما', 'شما', 'اونها', 'اون', 'اینها', 'نه', 'هیچ', 'خیلی', 'باید', 'دیگه', 'دیگر', 'چون', 'پس', 'بعد', 'قبل', 'اگر', 'اگه', 'کرد', 'کنم', 'کنی', 'کنیم', 'کنید',
  'دارم', 'داری', 'داره', 'داریم', 'دارید', 'دارن', 'میشه', 'شده', 'بشه', 'باشه', 'بوده', 'رو', 'ها', 'های', 'فقط', 'حالا', 'الان', 'اینجا', 'اونجا', 'چی', 'چه',
  'کی', 'کجا', 'چرا', 'چطور', 'نیست', 'نیستم', 'بی', 'مگه', 'آره', 'ببین', 'بابا', 'سلام', 'هستم', 'هستی', 'هستند', 'بود', 'بودم', 'کنه', 'کرده', 'داد', 'میکنم',
  'میکنه', 'میکنی', 'میخوام', 'میخوای', 'میشم', 'نمیشه', 'نمیدونم', 'اینو', 'اونو', 'همه', 'همین', 'همون', 'خب', 'خوب', 'ببخشید', 'لطفا', 'ممنون', 'مرسی', 'باشه',
  // انگلیسی
  'the', 'a', 'an', 'and', 'or', 'but', 'if', 'in', 'on', 'at', 'to', 'of', 'for', 'with', 'is', 'are', 'was', 'were', 'be', 'been', 'am', 'i', 'you', 'he', 'she', 'it',
  'we', 'they', 'my', 'your', 'his', 'her', 'its', 'our', 'their', 'this', 'that', 'these', 'those', 'do', 'does', 'did', 'have', 'has', 'had', 'not', 'no', 'yes', 'so',
  'just', 'can', 'will', 'would', 'should', 'could', 'what', 'when', 'where', 'who', 'why', 'how', 'me', 'him', 'them', 'us', 'there', 'here', 'then', 'than', 'too',
  'very', 'ok', 'okay', 'hi', 'hello', 'thanks', 'thank', 'please',
}.map(normFa).toSet();

List<String> _words(String t) => RegExp(r'[\u0600-\u06FFa-z0-9]+').allMatches(normFa(t)).map((m) => m.group(0)!).toList();

Map<String, int> _freq(Iterable<String> texts) {
  final f = <String, int>{};
  for (final t in texts) {
    for (final w in _words(t)) {
      if (w.length < 3 || _stop.contains(w) || RegExp(r'^[0-9]+$').hasMatch(w)) continue;
      f[w] = (f[w] ?? 0) + 1;
    }
  }
  return f;
}

List<String> keywordsOf(Iterable<String> texts, int n) {
  final f = _freq(texts);
  final es = f.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
  return [for (final e in es.take(n)) e.key];
}

class MsgSummary {
  final String text; // خالی یعنی متن برای خلاصه‌کردن کوتاه است
  final List<String> keywords;
  const MsgSummary(this.text, this.keywords);
}

MsgSummary summarizeText(String t) {
  final sents = RegExp(r'[^.!?؟!؛\n]+[.!?؟!؛]*').allMatches(t).map((m) => m.group(0)!.trim()).where((s) => s.length > 1).toList();
  final kw = keywordsOf([t], 6);
  if (sents.length < 3 && t.length < 220) return MsgSummary('', kw);
  if (sents.length < 2) {
    final cut = t.length > 180 ? '${t.substring(0, 180).trim()}…' : t;
    return MsgSummary(cut, kw);
  }
  final f = _freq([t]);
  final scores = <double>[];
  for (var i = 0; i < sents.length; i++) {
    final ws = _words(sents[i]).where((w) => f.containsKey(w)).toList();
    var s = 0.0;
    for (final w in ws) {
      s += f[w]!;
    }
    s = ws.isEmpty ? 0 : s / math.sqrt(ws.length);
    if (i == 0) s *= 1.3;
    scores.add(s);
  }
  final k = sents.length <= 3 ? 1 : (sents.length <= 6 ? 2 : 3);
  final idx = List<int>.generate(sents.length, (i) => i)..sort((a, b) => scores[b].compareTo(scores[a]));
  final pick = idx.take(k).toList()..sort();
  return MsgSummary(pick.map((i) => sents[i]).join(' '), kw);
}

class ChatSummary {
  final int total;
  final Map<String, int> bySender;
  final List<String> topics;
  final List<Map<String, dynamic>> questions, plans, important;
  const ChatSummary(this.total, this.bySender, this.topics, this.questions, this.plans, this.important);
}

final RegExp _planRe = RegExp(
  r'ساعت|فردا|امشب|امروز|پس ?فردا|شنبه|یکشنبه|دوشنبه|سه ?شنبه|چهارشنبه|پنج ?شنبه|جمعه|آخر هفته|قرار|جلسه|ملاقات|ظهر|عصر|صبح|[0-9]{1,2}:[0-9]{2}|tomorrow|tonight|today|monday|tuesday|wednesday|thursday|friday|saturday|sunday|meeting|appointment|at [0-9]',
);
final RegExp _impRe = RegExp(r'مهم|حتما|فوری|ضروری|آدرس|رمز|کد |شماره|قیمت|مهلت|ددلاین|لطفا|urgent|important|deadline|address|password|code|price|asap|please');

ChatSummary? summarizeChat(List<Map<String, dynamic>> all) {
  final ms = [
    for (final m in all)
      if (m['pending'] != true && kindOf(m) == 'text' && ((m['text'] as String?) ?? '').trim().isNotEmpty) m
  ];
  if (ms.length < 3) return null;
  final last = ms.length > 120 ? ms.sublist(ms.length - 120) : ms;
  final by = <String, int>{};
  for (final m in last) {
    final s = m['sender_id'] as String;
    by[s] = (by[s] ?? 0) + 1;
  }
  final topics = keywordsOf(last.map((m) => m['text'] as String), 6);
  final qs = <Map<String, dynamic>>[];
  final pl = <Map<String, dynamic>>[];
  for (final m in last.reversed) {
    final t = m['text'] as String;
    final n = normFa(t);
    if ((t.contains('؟') || t.contains('?')) && qs.length < 4) qs.add(m);
    if (_planRe.hasMatch(n) && pl.length < 4) pl.add(m);
  }
  final scored = <MapEntry<Map<String, dynamic>, int>>[];
  for (final m in last) {
    final t = m['text'] as String;
    final n = normFa(t);
    var s = 0;
    if (t.length > 40) s += 1;
    if (t.length > 120) s += 1;
    if (_impRe.hasMatch(n)) s += 3;
    if (RegExp(r'[0-9]{3,}').hasMatch(n)) s += 1;
    if (RegExp(r'https?://|www\.').hasMatch(n)) s += 1;
    scored.add(MapEntry(m, s));
  }
  scored.sort((a, b) => b.value.compareTo(a.value));
  final imp = [for (final e in scored.take(4)) if (e.value >= 2) e.key];
  return ChatSummary(last.length, by, topics, qs.reversed.toList(), pl.reversed.toList(), imp);
}

// ===========================================================================
// پیشنهاد پاسخ (روی گوشی)
// ===========================================================================
const _wb = r'[^\u0600-\u06FFa-z0-9]';
RegExp _rw(String alt) => RegExp('(?:^|$_wb)(?:$alt)(?:\$|$_wb)');

class _Cat {
  final String title;
  final RegExp? re;
  final List<String> replies;
  _Cat(this.title, String? pat, this.replies, {bool whole = false}) : re = pat == null ? null : (whole ? _rw(pat) : RegExp(pat));
  _Cat.en(this.title, String pat, this.replies) : re = _rw(pat);
}

final List<_Cat> _fa = [
  _Cat('صبح بخیر', 'صبح بخیر|صبحت بخیر|صبح شما بخیر', [
    'صبح تو هم بخیر ☀️', 'صبحت بخیر عزیز', 'صبح بخیر، روز خوبی داشته باشی', 'صبح شما هم بخیر', 'سلام، صبحت پر از انرژی ☕', 'صبح بخیر، چه خبر؟', 'صبح عالی‌ای داشته باشی 🌞',
    'صبح بخیر، صبحانه خوردی؟', 'سلام صبح بخیر، امروز چه برنامه‌ای داری؟',
  ]),
  _Cat('شب بخیر', 'شب بخیر|شبت بخیر|شب شما بخیر|شب خوش', [
    'شب تو هم بخیر 🌙', 'شبت بخیر، خوب بخوابی', 'شب بخیر، خوابای خوب ببینی', 'شبت آروم 😴', 'شب خوش، فردا حرف می‌زنیم', 'شب بخیر عزیزم', 'شب بخیر، به امید فردا ✨',
    'شب‌خوش، مراقب خودت باش',
  ]),
  _Cat('سلام و احوال‌پرسی', 'سلام|درود|وقت بخیر|عصر بخیر|salam|hello|hi|hey|های', [
    'سلام 👋', 'سلام، خوبی؟', 'سلام عزیزم', 'سلام، وقتت بخیر', 'درود', 'سلام! چه خبر؟', 'سلام، ممنون که پیام دادی', 'سلام، عصر بخیر', 'سلام، خوش اومدی', 'های 😊', 'سلام داداش',
    'سلام رفیق', 'سلام، چطوری؟', 'سلام، حالت چطوره؟', 'سلام و عرض ادب 🌹', 'به به، سلام!',
  ], whole: true),
  _Cat('حال و احوال', 'حالت|احوال|خوبی|چطوری|چطور هستی|چه خبر|چخبر|خوبین|خوبید|khobi|chetori|چه میکنی|چه می کنی', [
    'خوبم، ممنون! تو چطوری؟', 'مرسی خوبم، شما چطورید؟', 'عالیم، تو چه خبر؟', 'بد نیستم، تو چی؟', 'خدا رو شکر خوبم 🙏', 'سلامتی، تو خوبی؟', 'خوبم، فقط یکم خسته‌ام', 'عالی! تو چطوری؟',
    'همون روال همیشگی، تو چه خبر؟', 'دارم می‌گذرونم 😅', 'خوبم، از احوال‌پرسیت ممنون', 'هیچ خبری نیست، تو؟', 'کمی سرم شلوغه ولی خوبم', 'شکر خدا، تو خوبی؟', 'می‌گذره، تو چطوری؟',
  ]),
  _Cat('تشکر', 'ممنون|مرسی|تشکر|دمت گرم|دستت درد|سپاس|متشکر|mersi|mamnun|thanks|thank you|thx', [
    'خواهش می‌کنم 🌹', 'قابلی نداشت', 'وظیفه بود', 'خواهش می‌کنم، خوشحالم کمک کردم', 'کاری نکردم', 'سلامت باشی', 'هر وقت خواستی در خدمتم', 'قربانت', 'لطف داری', 'نه بابا، چه حرفیه',
    'خواهش، این حرفا چیه', 'نوش جان', 'خدمتگزارم 🙏', 'دشمنت شرمنده 😄', 'چاکریم', 'تو هم لطف داری',
  ]),
  _Cat('عذرخواهی', 'ببخشید|معذرت|شرمنده|عذر|پوزش|ببخشین|sorry', [
    'اشکالی نداره', 'مشکلی نیست', 'چیزی نشده، خیالت راحت', 'فراموشش کن', 'ناراحت نیستم', 'عیبی نداره عزیزم', 'بیخیال، پیش میاد', 'مهم نیست', 'باشه، من هم ببخشید', 'ایرادی نداره',
    'همه‌چی درسته', 'خواهش می‌کنم، فکرش رو نکن', 'بزرگواری، اصلاً مهم نیست',
  ]),
  _Cat('تبریک و شادباش', 'تبریک|مبارک|تولد|عیدت|عید شما|سالگرد|برنده|congrat|happy birthday', [
    'ممنونم 🙏', 'مرسی عزیزم، لطف داری', 'خیلی ممنون، همچنین 🌹', 'سپاس از لطفت', 'مبارکت باشه 🎉', 'تبریک می‌گم، خیلی خوشحالم 🎊', 'چه عالی! تبریک 👏', 'خدا رو شکر، مبارکت باشه',
    'به سلامتی، جشن می‌گیریم؟', 'ان‌شاءالله همیشه شاد باشی', 'همچنین برای شما', 'دمت گرم، آفرین 👏', 'ایشالا قسمت همه', 'هزار سال به این سال‌ها 🎂',
  ]),
  _Cat('خداحافظی', 'خداحافظ|فعلا|بعدا میبینمت|میبینمت|بدرود|خدانگهدار|خدافظ|bye|see you', [
    'خداحافظ 👋', 'فعلاً، بعداً حرف می‌زنیم', 'به امید دیدار', 'مراقب خودت باش', 'خدانگهدار', 'موفق باشی', 'بعداً می‌بینمت', 'تا بعد!', 'قربانت، فعلاً', 'روز خوبی داشته باشی', 'خوش بگذره',
    'خدافظ، سلام برسون', 'فعلاً، خبرم کن',
  ]),
  _Cat('سؤال بله/خیر', 'آیا|میشه|میتونی|میخوای|میخواید|میتونید|بلدی|هستی؟|داری؟|داری\\?|میای|میایی|میری|میدونی|یادته', [
    'آره حتماً', 'بله، مشکلی نیست', 'نه، نمی‌تونم', 'متأسفانه نه', 'فکر کنم آره', 'باشه، انجام می‌دم', 'الان نه، بعداً', 'بذار ببینم می‌شه یا نه', 'حتماً، چرا که نه', 'آره ولی کمی زمان می‌بره',
    'نه، وقت ندارم', 'آره، دقیقاً', 'نه، فکر نکنم', 'بله، خیالت راحت', 'اگه بتونم حتماً', 'ببینم چی می‌شه، خبرت می‌کنم',
  ]),
  _Cat('زمان', 'کی|چه ساعتی|ساعت چند|چه زمانی|چه موقع|چه وقت|تا کی|از کی', [
    'ساعت ۸', 'فردا صبح', 'امشب', 'تا یک ساعت دیگه', 'بعد از ظهر', 'هر وقت تو بخوای', 'هنوز مشخص نیست', 'چند دقیقه دیگه', 'آخر هفته', 'همین امروز', 'اواخر هفته', 'ساعتش رو بعداً هماهنگ می‌کنیم',
    'تا شب', 'ظهر', 'عصر', 'فردا شب',
  ], whole: true),
  _Cat('مکان', 'کجایی|کجاست|کجا|کجاییم|کدوم|کجاس|کجا هستی', [
    'خونه‌ام', 'تو راهم', 'سر کارم', 'رسیدم', 'دم در', 'الان می‌رسم', 'بیرونم، چند دقیقه دیگه میام', 'دانشگاهم', 'تو مسیرم', 'نزدیکم، لوکیشنم رو می‌فرستم', 'هنوز نرسیدم', 'تو ماشینم',
    'محل کارم', 'پیش دوستم', 'همین نزدیکی‌ام',
  ], whole: true),
  _Cat('چه می‌کنی؟', 'چکار میکنی|چیکار|چه کار|مشغولی|بیکاری|داری چیکار|مشغول چی|سرگرمی', [
    'هیچی، بیکارم', 'دارم کار می‌کنم', 'دارم استراحت می‌کنم 😌', 'تازه اومدم خونه', 'دارم فیلم می‌بینم 🎬', 'سرم شلوغه، بعداً حرف بزنیم؟', 'دارم درس می‌خونم 📚', 'هیچی، تو چیکار می‌کنی؟',
    'دارم غذا درست می‌کنم 🍳', 'تو راهم', 'بیکار نیستم ولی بگو', 'دارم گوشی بازی می‌کنم 😅', 'تازه از خواب بیدار شدم', 'مشغول کارهای روزمره‌ام',
  ]),
  _Cat('قرار و برنامه', 'قرار|بریم|میریم|برنامه|فردا|امشب|آخر هفته|جمعه|پنج شنبه|پنجشنبه|بیرون|دورهمی|دور همی|پیشنهاد', [
    'باشه، بریم 👍', 'قرار شد', 'ساعت چند؟', 'کجا بریم؟', 'من هستم', 'متأسفانه نمی‌تونم بیام', 'بذار هماهنگ کنم و بهت بگم', 'عالیه، پیشنهاد خوبیه', 'کی؟', 'فردا خوبه', 'من بعد از ظهر آزادم',
    'هر جا تو بگی', 'چه ایده‌ی خوبی! 😍', 'نمی‌دونم، بعداً قطعی می‌گم', 'امشب نه، یه شب دیگه', 'پایه‌ام 😎',
  ]),
  _Cat('تماس', 'زنگ|تماس|تلفن|صدات|بزنگ|phone|call', [
    'الان زنگ می‌زنم', 'الان نمی‌تونم صحبت کنم، بعداً زنگ می‌زنم', 'می‌تونی زنگ بزنی؟', 'پیام بده بهتره', 'چند دقیقه دیگه تماس می‌گیرم', 'گوشیم در دسترس نبود، ببخش', 'الان توی جلسه‌ام',
    'بزن، آزادم', 'تماس بگیر', 'تلفنم کم‌باتریه، پیام بده', 'بعد از ظهر زنگ می‌زنم',
  ]),
  _Cat('درخواست کمک', 'کمک|لطفا|ممکنه|خواهشی|خواهش|کمکم کن|راهنمایی|زحمت', [
    'حتماً، چه کمکی؟', 'بگو چی لازم داری', 'باشه، انجام می‌دم', 'چشم', 'الان نمی‌تونم، بعداً حتماً', 'بفرمایید، در خدمتم', 'بگو ببینم چی شده', 'من هستم، بگو', 'آره حتماً کمکت می‌کنم',
    'می‌تونی بیشتر توضیح بدی؟', 'بذار ببینم می‌تونم یا نه', 'چشم، انجامش می‌دم', 'زحمتی نیست',
  ]),
  _Cat('همدردی', 'ناراحت|غمگین|حالم بد|افسرده|گریه|خسته ام|خستم|خسته‌ام|دلتنگ|بیحوصله|اعصابم|داغون|حوصله ندارم|استرس', [
    'ناراحت شدم، چی شده؟', 'متأسفم، من هستم 🤍', 'قوی باش، درست می‌شه', 'می‌خوای حرف بزنیم؟', 'بغلت می‌کنم 🫂', 'همه‌چی درست می‌شه، مطمئن باش', 'هر کمکی خواستی بگو', 'سخته می‌دونم، کنارتم',
    'کاش می‌تونستم کاری کنم', 'استراحت کن، زیاد فکر نکن', 'بهتر می‌شی ان‌شاءالله', 'می‌خوای زنگ بزنم؟',
  ]),
  _Cat('سلامتی', 'مریض|سرما|دکتر|بیمارستان|تب |درد|سرماخورد|کسالت|قرص', [
    'زودتر خوب شی 🙏', 'سلامتی، ان‌شاءالله زود خوب می‌شی', 'دکتر رفتی؟', 'استراحت کن و آب زیاد بخور', 'مراقب خودت باش', 'کاری از من برمیاد؟', 'الهی بهتر شی', 'شفا بگیری',
    'داروهات رو سر وقت بخور', 'خدا رو شکر که بهتری',
  ]),
  _Cat('خبر خوب', 'خوشحال|عالیه|عالی|خوب شد|خبر خوب|قبول شدم|پیروز|موفق شدم|هورا|ایول|بردم|استخدام', [
    'چه عالی! 🎉', 'خیلی خوشحال شدم برات', 'آفرین، حقته 👏', 'ایول! تبریک', 'دمت گرم، افتخار می‌کنم', 'خدا رو شکر، چه خبر خوبی', 'باورم نمی‌شه، عالیه 😍', 'خیلی خوب شد',
    'بریم جشن بگیریم؟', 'می‌دونستم از پسش برمیای 💪', 'کلی ذوق کردم', 'مبارک باشه!',
  ]),
  _Cat('خنده', 'ههه|خخخ|😂|🤣|خنده|هاها|لول|lol|😆|😹', [
    '😂😂', 'هههه خیلی خوب بود', 'مردم از خنده 🤣', '😅', 'نکن دیگه 😂', 'خیلی باحال بود', 'الان داشتم می‌خندیدم', '😆', 'خندم گرفت', 'عالی بود هه', 'بهتر از این نمی‌شد 😄',
  ]),
  _Cat('موافقت', 'باشه|اوکی|اکی|حله|قبوله|okay|ok|مشکلی نیست|موافقم|فهمیدم|چشم|حتما|تایید|قبول', [
    'عالیه 👌', 'ممنون', 'باشه، قرار شد', 'پس هماهنگ', 'خوبه، پس همینه', '👍', 'دمت گرم', 'باشه، خبر می‌دم', 'مرسی که هماهنگ کردی', 'توافق شد', 'باشه پس', 'حله 👌', 'عالی، پس منتظرم',
  ], whole: true),
  _Cat('فایل و ارسال', 'بفرست|فایل|مدارک|ارسال کن|بفرستی|بفرستید|سند|لینک|عکسش|ایمیل', [
    'الان می‌فرستم', 'چند دقیقه دیگه می‌فرستم', 'فرستادم، ببین', 'دریافت کردم، ممنون', 'کدوم فایل رو می‌خوای؟', 'الان دم دستم نیست، بعداً می‌فرستم', 'لینکش رو می‌فرستم', 'پیدا کردم، یه لحظه',
    'ایمیل می‌کنم', 'به‌زودی برات می‌فرستم',
  ]),
  _Cat('تأخیر و انتظار', 'دیر|منتظر|تاخیر|زود باش|عجله|رسیدی|نرسیدی|کی میرسی', [
    'ببخشید دیر شد، دارم میام', 'پنج دقیقه دیگه می‌رسم', 'تو ترافیکم، شرمنده', 'الان راه افتادم', 'رسیدم، بیا دم در', 'یه کم دیرتر می‌رسم', 'دارم میام، چند دقیقه صبر کن', 'تقریباً رسیدم',
    'نگران نباش، می‌رسم', 'بیست دقیقه دیگه اونجام', 'از راه رسیدم 🏃',
  ]),
  _Cat('صبر کن', 'یه لحظه|چند دقیقه|صبر کن|الان میام|لحظه|بعدا|بعداً', [
    'باشه، منتظرم', 'عجله‌ای نیست', 'هر وقت تونستی', 'باشه، صبر می‌کنم', 'مشکلی نیست، بگو', 'باشه، هر وقت آماده بودی', 'منتظرتم', 'خیالت راحت، وقت داریم',
  ]),
  _Cat('غذا', 'ناهار|شام|صبحانه|گرسنه|غذا|رستوران|پیتزا|کباب|چایی|قهوه|بخوریم|ناهارخوری', [
    'بریم یه چیزی بخوریم 🍕', 'من هم گرسنه‌ام', 'چی بخوریم؟', 'ناهار خوردم، ممنون', 'تازه شام خوردم', 'پیتزا بگیریم؟', 'من پایه‌ام 😋', 'آره بریم، کجا؟', 'نوش جان 😋', 'دستپختت عالیه!',
    'یه قهوه بخوریم؟ ☕', 'هرچی تو بگی', 'من یه چیز سبک می‌خورم',
  ]),
  _Cat('کار و درس', 'کار|جلسه|پروژه|دفتر|شرکت|مدیر|گزارش|ددلاین|مهلت|تحویل|امتحان|درس|کلاس|تمرین|استاد|دانشگاه|مدرسه|تکلیف', [
    'الان سرم شلوغه، بعداً جواب می‌دم', 'روی کارش هستم', 'تا فردا تحویل می‌دم', 'جلسه دارم، بعداً زنگ می‌زنم', 'تموم شد، الان می‌فرستم', 'هماهنگ می‌کنم', 'باشه، بررسی می‌کنم',
    'نزدیکه تموم شه', 'بذار نگاهی بندازم و بگم', 'موفق باشی 💪', 'ان‌شاءالله خوب می‌شه', 'یه کم زمان می‌خواد', 'خسته نباشی',
  ]),
  _Cat('پول و پرداخت', 'پول|کارت|واریز|قیمت|حساب|تومن|تومان|هزینه|بدهی|قسط|حقوق|پرداخت', [
    'الان واریز می‌کنم', 'شماره کارتت رو بفرست', 'واریز شد، چک کن', 'قیمتش چنده؟', 'بذار حسابش رو بکنم', 'فردا حساب می‌کنیم', 'دریافت شد، ممنون', 'هزینه‌اش چقدر می‌شه؟', 'قابلی نداره',
    'پس‌فردا کارت‌به‌کارت می‌کنم', 'می‌تونم تا آخر هفته بدم',
  ]),
  _Cat('محبت', 'دوستت دارم|دلم تنگ|عاشق|عزیزم|جانم|قربانت|بوس|ماچ|عشقم|فدات', [
    'منم دوستت دارم ❤️', 'دلم برات تنگ شده 🥺', 'قربونت برم', 'عزیزمی 🌹', 'جونم 😍', 'خیلی دوستت دارم', 'تو هم عزیزی', 'منم دلتنگتم', 'فدات بشم', 'تو بهترینی 💖', 'ماچ 😘',
  ]),
  _Cat('تعجب', 'وای|جدی|واقعا|باورم نمیشه|نه بابا|چی؟|شوخی|عجیبه|دروغ|وایسا', [
    'جدی؟ 😮', 'باورم نمی‌شه!', 'واقعاً؟', 'نه بابا!', 'وای، چه عجیب', 'شوخی می‌کنی؟', 'چی شد پس؟', 'تعریف کن ببینم', 'خدایا 😳', 'فکرش رو نمی‌کردم', 'این که خیلی عالیه',
    'یعنی چی شد؟', 'دروغ نگو 😲',
  ]),
  _Cat('سفر', 'رسیدم|راه افتادم|سفر|پرواز|فرودگاه|ترمینال|بلیط|جاده|مقصد|رسیدین', [
    'سلامت برسی 🚗', 'به سلامت! خبر بده', 'رسیدی؟ خوبه', 'سفر خوبی داشته باشی ✈️', 'مراقب خودت باش تو جاده', 'رسیدی خبر بده', 'خوش بگذره 🌴', 'ان‌شاءالله به سلامتی', 'عکس بفرست از اونجا 📷',
  ]),
  _Cat('خواب', 'خوابیدی|بیداری|خوابم میاد|بخوابم|بیدار|دیروقته|بخواب', [
    'نه، هنوز بیدارم', 'تازه بیدار شدم ☀️', 'دارم می‌خوابم، شب بخیر 🌙', 'خوابم میاد 😴', 'تو چرا هنوز بیداری؟', 'بخواب که فردا کار داری', 'شب بخیر، خوب بخوابی', 'به‌زودی می‌خوابم',
    'بعداً حرف می‌زنیم، خوابم میاد',
  ]),
  _Cat('عید و مناسبت', 'نوروز|عید|سال نو|یلدا|رمضان|محرم|اربعین', [
    'عیدت مبارک 🌷', 'سال نو مبارک! 🎉', 'شب یلدات مبارک 🍉', 'ان‌شاءالله سالی پر از شادی داشته باشی', 'همچنین، عید شما هم مبارک', 'التماس دعا 🤲', 'قبول باشه 🤲', 'مبارکت باشه، دیدنی‌ها بیشتر 🌹',
  ]),
  _Cat('ورزش و بازی', 'فوتبال|بازی|استقلال|پرسپولیس|باشگاه|ورزش|دویدن|والیبال|مسابقه', [
    'دیدی چه بازی‌ای بود؟ 😍', 'من هم نگاه کردم', 'فردا بریم باشگاه؟', 'پایه‌ام، کی؟', 'بریم یه دور بازی کنیم؟', 'نتیجه چی شد؟', 'عالی بود! 👏', 'ایشالا دفعه‌ی بعد',
  ]),
  _Cat('فیلم و موسیقی', 'فیلم|سریال|آهنگ|موزیک|کنسرت|سینما|پادکست', [
    'پیشنهادت چیه؟', 'دیدم، عالی بود 🎬', 'نه ندیدم، تعریف کن', 'بریم سینما؟', 'اسمش چیه؟', 'آهنگ خوبیه 🎶', 'بفرست گوش بدم', 'من هم خیلی دوستش دارم',
  ]),
  _Cat('دعوت و مهمانی', 'مهمان|دعوت|بیا خونه|مهمونی|دورهمی خونه', [
    'ممنون از دعوتت، حتماً میام', 'کی هستین؟', 'چیزی بیارم؟', 'قربانت، متأسفانه نمی‌تونم', 'عالیه، منتظرم 😍', 'هماهنگ می‌کنم و خبر می‌دم', 'آدرس رو بفرست',
  ]),
  _Cat('هر سؤالی', r'\?|؟', [
    'آره', 'نه', 'شاید', 'نمی‌دونم، بذار چک کنم', 'بذار فکر کنم', 'الان نمی‌تونم جواب بدم، بعداً می‌گم', 'بله، دقیقاً', 'نه، فکر نکنم', 'آره، حتماً', 'نه متأسفانه', 'تا ساعتی دیگه خبرت می‌کنم',
    'باید بپرسم و بهت بگم', 'سؤال خوبیه!', 'چرا می‌پرسی؟',
  ]),
];

final List<String> _faGeneric = [
  'باشه', 'آره', 'نه', '🙏', '👍', 'ممنون', 'چشم', 'حتماً', 'متوجه شدم', 'بعداً صحبت می‌کنیم', 'چرا که نه؟', 'موافقم', 'نمی‌دونم', 'آفرین', '😊', '❤️', 'بعداً بهت خبر می‌دم', 'دقیقاً', 'درسته',
  'فهمیدم', 'عالیه', 'جالبه', 'ادامه بده', 'بیشتر بگو', 'واقعاً؟', 'شاید', 'ببینم چی می‌شه', 'همین‌طوره', 'نظرم همینه', 'قبول دارم', 'خیلی خوبه', 'الان مشغولم، بعداً جواب می‌دم', 'ببینم چی می‌شه',
];

final List<_Cat> _en = [
  _Cat.en('Greeting', 'hello|hi|hey|good morning|good evening|good afternoon|good night', [
    'Hi! 👋', 'Hello, how are you?', 'Hey! What\'s up?', 'Good morning ☀️', 'Hi there 😊', 'Hey, long time!', 'Hello! Nice to hear from you', 'Good evening!', 'Good night 🌙', 'Hey you!',
  ]),
  _Cat.en('How are you', 'how are you|how r u|how\'s it going|what\'s up|whats up|sup\\b|how have you been', [
    "I'm good, thanks! You?", 'Doing great, how about you?', 'Not bad, you?', 'All good here 🙏', "Can't complain, you?", 'Pretty busy but good', 'Great! What about you?', 'Same as always, you?', "I'm fine, thanks for asking",
  ]),
  _Cat.en('Thanks', 'thank[a-z]*|thx|appreciate|cheers', [
    "You're welcome! 🌹", 'No problem!', 'Anytime!', 'Happy to help', 'Glad I could help', 'Of course!', "Don't mention it", 'My pleasure 😊', 'Sure thing',
  ]),
  _Cat.en('Apology', 'sorry|apolog[a-z]*|my bad|forgive[a-z]*', [
    "No worries", "It's okay", "Don't worry about it", 'No problem at all', 'All good', "It's fine, really", 'Forget it, it happens', "Nothing to apologize for",
  ]),
  _Cat.en('Congrats', 'congrat[a-z]*|happy birthday|well done|great job', [
    'Thank you so much! 🙏', 'Thanks, that means a lot', 'Thank you, same to you!', 'Congratulations! 🎉', "That's amazing, well done 👏", "So happy for you!", 'You deserve it!', 'Awesome news!',
  ]),
  _Cat.en('Goodbye', 'bye|goodbye|see you|talk later|ttyl|good night|gotta go|cya', [
    'Bye! 👋', 'See you later', 'Talk to you soon', 'Take care!', 'Good night 🌙', 'Catch you later', 'Have a great day!', 'See you tomorrow', 'Bye, stay safe',
  ]),
  _Cat.en('Yes/No question', 'can you|could you|would you|will you|do you|did you|are you|is it|have you|should we|shall we|want to|wanna', [
    'Yes, sure!', 'Of course', 'Sorry, I can\'t', 'Not right now', 'Maybe, let me check', "I think so", "I don't think so", 'Absolutely 👍', 'Let me think about it', 'Probably', 'Yes, no problem',
  ]),
  _Cat.en('When', 'when|what time|how long|until when', [
    'In an hour', 'Tomorrow morning', 'Tonight', 'This evening', 'Not sure yet', 'Whenever you want', 'In a few minutes', 'This weekend', 'Right now', "I'll let you know",
  ]),
  _Cat.en('Where', 'where are you|where is|where r u|where', [
    "I'm at home", "On my way", 'At work', "I've arrived", 'Almost there', 'Outside, come out', 'In the car', 'Around the corner', "Not there yet", "I'll send my location",
  ]),
  _Cat.en('What are you doing', 'what are you doing|what r u doing|what are you up to|busy|are you free', [
    'Nothing much, you?', 'Working', 'Just relaxing 😌', 'Watching a movie 🎬', 'Studying 📚', "Cooking something 🍳", "A bit busy, can I reply later?", 'Just got home', "I'm free, what's up?",
  ]),
  _Cat.en('Plans', 'lets|let\'s|plans?|tomorrow|tonight|weekend|meet|hang out|dinner|lunch|coffee', [
    "Sounds good, let's do it! 👍", 'What time?', 'Where should we go?', "I'm in!", "Sorry, I can't make it", 'Let me check and get back to you', 'Great idea 😍', 'Tomorrow works for me', "I'm free in the afternoon", 'Not tonight, maybe another time',
  ]),
  _Cat.en('Call', 'call me|phone|ring|can we talk|give me a call', [
    "I'll call you now", "Can't talk right now, I'll call later", 'Call me anytime', 'Text me instead', 'In a meeting, call you back', "I'll call in a few minutes", 'Sure, go ahead and call',
  ]),
  _Cat.en('Help', 'help|please|could you help|favor|need your', [
    'Sure, what do you need?', 'Of course, tell me', "I'll do it", 'On it!', "Can't right now, but later for sure", 'Tell me more', "Let me see what I can do", 'Happy to help!',
  ]),
  _Cat.en('Sympathy', 'sad|upset|tired|stressed|depress[a-z]*|not feeling|bad day|sick|hurts|cry', [
    "I'm sorry to hear that 🤍", "I'm here for you", "It'll get better, I promise", 'Want to talk about it?', 'Take care of yourself', 'Hang in there 💪', 'Let me know if I can help', 'Sending you a hug 🫂',
  ]),
  _Cat.en('Good news', 'great news|good news|i passed|i got the job|we won|so happy|excited|awesome', [
    "That's amazing! 🎉", 'So happy for you!', 'Congrats, you deserve it 👏', "Wow, that's great news!", 'I knew you could do it 💪', 'Yay!', "Let's celebrate!", 'Fantastic!',
  ]),
  _Cat.en('Laugh', 'lol|haha|😂|🤣|funny|lmao|joke', ['😂😂', 'Haha that\'s so good', 'I can\'t stop laughing 🤣', '😅', 'Stop it 😂', 'LOL', 'That\'s hilarious', '😆']),
  _Cat.en('Agreement', 'ok|okay|sure|alright|fine|deal|got it|sounds good|agreed', [
    'Great 👌', 'Perfect', 'Cool, see you then', '👍', "Deal!", 'Thanks for letting me know', 'Alright then', 'Awesome', 'Got it, thanks',
  ]),
  _Cat.en('Love', 'love you|miss you|my dear|sweetheart|darling', [
    'Love you too ❤️', 'Miss you too 🥺', 'You mean the world to me', 'Aww 😍', 'You\'re the best 💖', 'Sending love 😘',
  ]),
  _Cat.en('Surprise', 'really|seriously|no way|wow|omg|unbelievable|what\\?', [
    'Really? 😮', "I can't believe it!", 'No way!', 'Wow!', 'Are you serious?', 'Tell me more', 'That\'s crazy 😳', 'Seriously?', 'What happened?',
  ]),
  _Cat.en('Food', 'lunch|dinner|breakfast|hungry|eat|food|pizza|restaurant|coffee', [
    "Let's grab something to eat 🍕", "I'm hungry too", 'What do you feel like?', 'I already ate, thanks', 'Pizza sounds great 😋', 'Coffee? ☕', 'Anywhere you like', 'Sounds delicious',
  ]),
  _Cat.en('Work', 'work|meeting|project|deadline|report|email|exam|class|homework|boss', [
    "I'm a bit busy, will reply later", "I'm on it", "I'll send it by tomorrow", 'In a meeting, will call back', 'Almost done', 'Let me take a look and get back to you', 'Good luck 💪', 'Will do',
  ]),
  _Cat.en('Late', 'late|waiting|where are you|hurry|are you coming|on your way', [
    "Sorry I'm late, on my way", '5 more minutes', 'Stuck in traffic, sorry', 'Just left', "I'm here, come outside", 'Almost there', "Don't worry, I'll be there soon", 'Running a bit late',
  ]),
  _Cat('Any question', r'\?', [
    'Yes', 'No', 'Maybe', "I'm not sure, let me check", 'Let me think', "I'll answer later", 'Exactly', "I don't think so", 'Definitely', 'Good question!', "I'll let you know shortly",
  ]),
];

final List<String> _enGeneric = [
  'Okay', 'Yes', 'No', '🙏', '👍', 'Thanks', 'Sure', 'Got it', "I'll talk to you later", 'Why not?', 'Agreed', "I don't know", 'Nice!', '😊', '❤️', "I'll let you know", 'Exactly', "That's right",
  'Interesting', 'Tell me more', 'Really?', 'Maybe', 'Let me see', 'I think so too', 'Sounds good', "I'm busy right now, will reply later",
];

const Map<String, List<String>> _kindFa = {
  'image': ['عکس قشنگیه 😍', 'چه عکس خوبی!', 'عالیه 👌', 'کجا گرفتیش؟', 'خیلی باحاله', 'دمت گرم، قشنگ بود', 'به‌به 😍', 'چه صحنه‌ای!', '👍', 'ممنون که فرستادی', 'بقیه‌اش رو هم بفرست'],
  'video': ['دیدم، عالی بود', 'چه ویدیوی باحالی 😂', 'بعداً می‌بینم و نظرم رو می‌گم', 'کی گرفتیش؟', 'قشنگ بود 👏', 'ممنون که فرستادی', 'الان نگاه می‌کنم'],
  'audio': ['شنیدم 👍', 'الان گوش می‌دم', 'ویست رو گوش دادم، باشه', 'بعداً گوش می‌دم و جواب می‌دم', 'متوجه شدم، ممنون', 'الان نمی‌تونم گوش بدم، متنی بگو', 'چشم، انجام می‌دم'],
  'file': ['گرفتم، ممنون', 'دریافت شد 👍', 'بررسی می‌کنم و خبر می‌دم', 'ممنون که فرستادی', 'می‌بینم و جواب می‌دم', 'الان نگاه می‌کنم'],
  'location': ['دارم میام', 'ممنون، می‌رسم', 'الان راه می‌افتم', 'نزدیکش رسیدم', 'نقشه رو دیدم، اومدم', 'باشه، دقیقاً همونجا؟', 'تا چند دقیقه دیگه اونجام'],
  'contact': ['ممنون، ذخیره کردم', 'باشه، بهش پیام می‌دم', 'این شماره رو می‌شناسی؟', 'ممنون از مخاطب', 'الان تماس می‌گیرم'],
  'poll': ['رأی دادم', 'نظرسنجی خوبیه', 'الان رأی می‌دم', 'جالبه، منتظر نتیجه‌ام'],
  'sticker': ['😂', '😍', '👌', 'خیلی باحال بود 😄', 'عالیه', 'هههه', '🤣', '❤️'],
  'gif': ['😂', '😍', '👌', 'خیلی باحال بود 😄', 'عالیه', 'هههه', '🤣', '❤️'],
};

const Map<String, List<String>> _kindEn = {
  'image': ['Nice photo! 😍', 'Great picture!', 'Love it 👌', 'Where was this taken?', 'So cool', 'Thanks for sharing', 'Beautiful 😍', '👍'],
  'video': ['Watched it, great!', 'That\'s hilarious 😂', "I'll watch it later and tell you", 'When was this?', 'Nice one 👏', 'Thanks for sharing'],
  'audio': ['Heard it 👍', "Listening now", "Got your voice message, okay", "I'll listen later and reply", "Understood, thanks", "Can't listen now, can you text me?"],
  'file': ['Got it, thanks', 'Received 👍', "I'll check it and get back to you", 'Thanks for sending', "Looking at it now"],
  'location': ["I'm on my way", 'Thanks, heading there', 'Leaving now', 'Almost there', 'See you there'],
  'contact': ['Thanks, saved it', "I'll message them", 'Thanks for the contact'],
  'poll': ['Voted', 'Good poll', "I'll vote now", 'Curious about the result'],
  'sticker': ['😂', '😍', '👌', 'Love it', '🤣', '❤️'],
  'gif': ['😂', '😍', '👌', 'Love it', '🤣', '❤️'],
};

final RegExp _finglish = RegExp(r'salam|khobi|chetori|mersi|mamnun|khoda|merci|chakeram|dooset|doost|man ham|nemidonam|bashe');

class ReplyGroup {
  final String title;
  final List<String> replies;
  const ReplyGroup(this.title, this.replies);
}

/// فهرست دسته‌بندی‌شده‌ی همه‌ی پیشنهادها؛ دسته‌های مناسب پیام اول می‌آیند
class ReplyPack {
  final List<String> top; // برای نوار پیشنهاد
  final List<ReplyGroup> matched; // مناسب این پیام
  final List<ReplyGroup> others; // بقیه
  const ReplyPack(this.top, this.matched, this.others);
}

List<String> _timeReplies(String n, bool fa) {
  final m = RegExp(r'([0-9]{1,2}:[0-9]{2})').firstMatch(n) ?? RegExp(r'ساعت\s*([0-9]{1,2})').firstMatch(n) ?? RegExp(r'at ([0-9]{1,2}(?::[0-9]{2})?)').firstMatch(n);
  if (m == null) return const [];
  final t = m.group(1)!;
  if (fa) {
    final x = faDigits(t);
    return ['باشه، ساعت $x خوبه ✅', 'ساعت $x می‌رسم', 'ساعت $x نمی‌رسم، یه کم دیرتر؟', 'ساعت $x هماهنگه'];
  }
  return ['Works for me at $t ✅', "I'll be there at $t", "I can't make $t, can we do it later?"];
}

ReplyPack buildReplies(Map<String, dynamic> msg, {int limit = 48}) {
  final kind = kindOf(msg);
  final text = kind == 'text' ? ((msg['text'] as String?) ?? '') : '';
  final n = normFa(text);
  var lang = kind == 'text' ? detectLang(text) : (appLang == 'en' ? 'en' : 'fa');
  if (lang == 'other') lang = appLang == 'en' ? 'en' : 'fa';
  if (lang == 'en' && _finglish.hasMatch(n)) lang = 'fa';
  final fa = lang == 'fa';
  final cats = fa ? _fa : _en;
  final generic = fa ? _faGeneric : _enGeneric;
  final matched = <ReplyGroup>[];
  final used = <_Cat>{};
  if (kind != 'text') {
    final k = (fa ? _kindFa : _kindEn)[kind];
    if (k != null) matched.add(ReplyGroup(fa ? 'مناسب این پیام' : 'For this message', k));
  } else {
    final tr = _timeReplies(n, fa);
    if (tr.isNotEmpty) matched.add(ReplyGroup(fa ? 'زمان' : 'Time', tr));
    for (final c in cats) {
      if (c.re != null && c.re!.hasMatch(n)) {
        used.add(c);
        matched.add(ReplyGroup(c.title, c.replies));
      }
    }
  }
  final others = <ReplyGroup>[
    for (final c in cats)
      if (!used.contains(c)) ReplyGroup(c.title, c.replies),
    ReplyGroup(fa ? 'عمومی' : 'General', generic),
  ];
  // نوار پیشنهاد: از هر دسته‌ی مرتبط به‌نوبت می‌آید تا متنوع باشد
  final top = <String>[];
  final seen = <String>{};
  void add(String s) {
    if (seen.add(s)) top.add(s);
  }
  final lists = [for (final g in matched) g.replies];
  var i = 0;
  while (top.length < limit && lists.any((l) => i < l.length)) {
    for (final l in lists) {
      if (i < l.length) add(l[i]);
    }
    i++;
  }
  for (final s in generic) {
    if (top.length >= limit) break;
    add(s);
  }
  return ReplyPack(top.take(limit).toList(), matched, others);
}

/// تکمیل متن در حال نوشتن از روی کتابخانه‌ی پاسخ‌ها
List<String> completions(String typed, {int max = 8}) {
  final q = normFa(typed.trim());
  if (q.length < 2) return const [];
  final lang = detectLang(typed);
  final cats = lang == 'en' ? _en : _fa;
  final out = <String>[];
  for (final c in cats) {
    for (final r in c.replies) {
      final nr = normFa(r);
      if (nr.startsWith(q) && nr.length > q.length && !out.contains(r)) out.add(r);
      if (out.length >= max) return out;
    }
  }
  return out;
}

// ===========================================================================
// رابط: نوار پیشنهاد بالای کادر پیام
// ===========================================================================
const _startersFa = ['سلام 👋', 'خوبی؟', 'چه خبر؟', 'وقت داری؟', 'یه سوال داشتم', 'می‌تونی کمکم کنی؟', 'فردا می‌بینمت', 'ممنون که هستی 🌹', 'صبح بخیر ☀️', 'شب بخیر 🌙'];
const _startersEn = ['Hi 👋', 'How are you?', "What's up?", 'Are you free?', 'Quick question', 'Can you help me?', 'See you tomorrow', 'Thanks for being there 🌹'];

class SmartBar extends StatelessWidget {
  final Map<String, dynamic>? last; // آخرین پیام گفتگو (اگر از طرف مقابل باشد)
  final String typed;
  final void Function(String text) onPick;
  final void Function(String lang) onTranslateTyped;
  final VoidCallback onMore, onSummary;
  final List<String> history; // پیام‌های قبلیِ خود کاربر برای تکمیل شخصی
  final List<String> Function(String typed)? emojiFor;
  final List<String> Function(String typed, List<String> history)? personal;
  const SmartBar({super.key, required this.last, required this.typed, required this.onPick, required this.onTranslateTyped, required this.onMore, required this.onSummary, this.history = const [], this.emojiFor, this.personal});

  Widget _chip(BuildContext context, String t, VoidCallback f, {IconData? icon, bool strong = false}) {
    final glow = cy.enabled;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: f,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: strong ? Color.lerp(card, primary, 0.35) : card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: strong ? accent : (glow ? cy.c1.withOpacity(0.45) : cLine)),
            boxShadow: glow ? [BoxShadow(color: cy.c1.withOpacity(0.10 + 0.2 * cy.glow), blurRadius: 8)] : null,
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (icon != null) ...[Icon(icon, size: 15, color: accent), const SizedBox(width: 5)],
            Text(t, style: TextStyle(color: cText, fontSize: 13)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = <Widget>[];
    final hasTyped = typed.trim().isNotEmpty;
    if (hasTyped) {
      final lang = detectLang(typed);
      if (lang == 'fa') {
        items.add(_chip(context, trn('ترجمه به انگلیسی'), () => onTranslateTyped('en'), icon: Icons.translate_rounded, strong: true));
      } else if (lang == 'en') {
        items.add(_chip(context, trn('ترجمه به فارسی'), () => onTranslateTyped('fa'), icon: Icons.translate_rounded, strong: true));
      }
      if (personal != null) {
        for (final c in personal!(typed, history)) {
          items.add(_chip(context, c, () => onPick(c), icon: Icons.history_rounded));
        }
      }
      if (emojiFor != null) {
        for (final e in emojiFor!(typed)) {
          items.add(_chip(context, e, () => onPick('${typed.trimRight()} $e')));
        }
      }
      for (final c in completions(typed)) {
        items.add(_chip(context, c, () => onPick(c)));
      }
    } else if (last != null) {
      final pack = buildReplies(last!);
      for (final s in pack.top) {
        items.add(_chip(context, s, () => onPick(s)));
      }
    } else {
      for (final s in (appLang == 'en' ? _startersEn : _startersFa)) {
        items.add(_chip(context, s, () => onPick(s)));
      }
    }
    if (items.isEmpty && last == null) {
      items.add(_chip(context, trn('✨ خلاصه'), onSummary));
    }
    return SizedBox(
      height: 42,
      child: Row(children: [
        const SizedBox(width: 8),
        InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onMore,
          child: Container(
            width: 36,
            height: 32,
            decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [primary, accent2.withOpacity(0.85)])),
            child: Icon(Icons.auto_awesome_rounded, size: 18, color: cOnPrimary),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(vertical: 5), children: items)),
        IconButton(visualDensity: VisualDensity.compact, tooltip: trn('خلاصه‌ی گفتگو'), icon: Icon(Icons.summarize_outlined, color: accent, size: 22), onPressed: onSummary),
      ]),
    );
  }
}

// ===========================================================================
// ترجمه‌ی زنده زیر پیام‌های دریافتی
// ===========================================================================
class LiveTranslation extends StatefulWidget {
  final String text;
  final Color color;
  final String? to;
  const LiveTranslation(this.text, {super.key, required this.color, this.to});
  @override
  State<LiveTranslation> createState() => _LiveTranslationState();
}

class _LiveTranslationState extends State<LiveTranslation> {
  Future<String?>? _f;

  @override
  void initState() {
    super.initState();
    final lang = detectLang(widget.text);
    final target = widget.to ?? ai.liveTo;
    if (lang != 'other' && lang != target && widget.text.trim().length > 1) {
      _f = translateText(widget.text, target).then<String?>((v) => v, onError: (_) => null);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_f == null) return const SizedBox.shrink();
    return FutureBuilder<String?>(
      future: _f,
      builder: (c, s) {
        final t = s.data;
        if (t == null || t.trim().isEmpty || t.trim() == widget.text.trim()) return const SizedBox.shrink();
        return Container(
          margin: const EdgeInsets.only(top: 6),
          padding: const EdgeInsets.fromLTRB(8, 5, 8, 5),
          decoration: BoxDecoration(color: Color.lerp(Colors.transparent, widget.color, 0.12), borderRadius: BorderRadius.circular(10)),
          child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.translate_rounded, size: 13, color: widget.color.withOpacity(0.7)),
            const SizedBox(width: 6),
            Flexible(child: Text(t, style: TextStyle(color: widget.color.withOpacity(0.92), fontSize: 13, height: 1.5))),
          ]),
        );
      },
    );
  }
}

// ===========================================================================
// برگه‌ها
// ===========================================================================
Widget _sheetTitle(String t, {IconData? icon}) => Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 10),
      child: Row(children: [
        if (icon != null) ...[Icon(icon, color: accent, size: 22), const SizedBox(width: 8)],
        Expanded(child: Text(t, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: cText))),
      ]),
    );

/// ترجمه‌ی یک پیام یا متن؛ [onUse] متن ترجمه‌شده را در کادر پیام می‌گذارد
Future<void> showTranslateSheet(BuildContext context, String text, {void Function(String)? onUse}) {
  final src = detectLang(text);
  var to = src == 'fa' ? 'en' : 'fa';
  Future<String>? job;
  return showTiaSheet<void>(context, (c) => StatefulBuilder(builder: (c, setS) {
        job ??= translateText(text, to);
        return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          _sheetTitle(trn('ترجمه'), icon: Icons.translate_rounded),
          SizedBox(
            height: 38,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              for (final e in trLangs.entries)
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 6),
                  child: ChoiceChip(
                    label: Text(trn(e.value)),
                    selected: to == e.key,
                    onSelected: (_) => setS(() {
                      to = e.key;
                      job = translateText(text, to);
                    }),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Color.lerp(card, Colors.white, 0.04), borderRadius: BorderRadius.circular(14), border: Border.all(color: cLine)),
            child: Text(text, style: TextStyle(color: cTextDim, height: 1.6)),
          ),
          const SizedBox(height: 10),
          FutureBuilder<String>(
            future: job,
            builder: (c, s) {
              if (s.connectionState != ConnectionState.done) {
                return const Padding(padding: EdgeInsets.all(18), child: Center(child: CircularProgressIndicator(strokeWidth: 3)));
              }
              if (s.hasError || s.data == null) {
                return Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(trn('ترجمه انجام نشد. اینترنت را بررسی کنید؛ ممکن است سرویس ترجمه در شبکه‌ی شما در دسترس نباشد.'), style: const TextStyle(color: Colors.redAccent, height: 1.6)),
                );
              }
              final r = s.data!;
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Color.lerp(card, primary, 0.22), borderRadius: BorderRadius.circular(14), border: Border.all(color: accent.withOpacity(0.5))),
                  child: SelectableText(r, style: TextStyle(color: cText, fontSize: 16, height: 1.7)),
                ),
                const SizedBox(height: 10),
                Row(children: [
                  OutlinedButton.icon(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: r));
                      snack(context, trn('کپی شد'));
                    },
                    icon: const Icon(Icons.copy, size: 18),
                    label: Text(trn('کپی')),
                  ),
                  const SizedBox(width: 8),
                  if (onUse != null)
                    FilledButton.icon(
                      onPressed: () {
                        Navigator.pop(c);
                        onUse(r);
                      },
                      icon: const Icon(Icons.edit_note_rounded, size: 20),
                      label: Text(trn('استفاده در پیام')),
                    ),
                ]),
              ]);
            },
          ),
        ]);
      }));
}

Future<void> showSummarySheet(BuildContext context, String text) {
  final s = summarizeText(text);
  return showTiaSheet<void>(context, (c) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        _sheetTitle(trn('✨ خلاصه'), icon: Icons.auto_awesome_rounded),
        if (s.text.isEmpty)
          Padding(padding: const EdgeInsets.all(8), child: Text(trn('این پیام آن‌قدر کوتاه است که خلاصه‌کردن لازم نیست.'), style: TextStyle(color: cTextDim, height: 1.6)))
        else
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Color.lerp(card, primary, 0.22), borderRadius: BorderRadius.circular(14), border: Border.all(color: accent.withOpacity(0.5))),
            child: SelectableText(s.text, style: TextStyle(color: cText, fontSize: 16, height: 1.8)),
          ),
        if (s.keywords.isNotEmpty) ...[
          const SizedBox(height: 14),
          Text(trn('کلیدواژه‌ها'), style: TextStyle(color: cTextDim, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Wrap(spacing: 6, runSpacing: 6, children: [for (final k in s.keywords) Chip(label: Text(k), visualDensity: VisualDensity.compact)]),
        ],
        if (s.text.isNotEmpty) ...[
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: s.text));
              snack(context, trn('کپی شد'));
            },
            icon: const Icon(Icons.copy, size: 18),
            label: Text(trn('کپی')),
          ),
        ],
      ]));
}

Future<void> showChatSummarySheet(BuildContext context, List<Map<String, dynamic>> all, void Function(int id) jump) {
  final s = summarizeChat(all);
  Widget section(String title, IconData ic, List<Map<String, dynamic>> ms, BuildContext c) {
    if (ms.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(ic, size: 18, color: accent), const SizedBox(width: 6), Text(title, style: TextStyle(color: cText, fontWeight: FontWeight.w800))]),
        const SizedBox(height: 6),
        for (final m in ms)
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              Navigator.pop(c);
              jump(m['id'] as int);
            },
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: Color.lerp(card, Colors.white, 0.05), borderRadius: BorderRadius.circular(12), border: Border.all(color: cLine)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(store.name(m['sender_id'] as String), style: TextStyle(color: accent, fontSize: 11, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(m['text'] as String, maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: cText, height: 1.5)),
              ]),
            ),
          ),
      ]),
    );
  }

  return showTiaSheet<void>(context, (c) {
    if (s == null) {
      return Column(mainAxisSize: MainAxisSize.min, children: [
        _sheetTitle(trn('خلاصه‌ی گفتگو'), icon: Icons.summarize_outlined),
        Padding(padding: const EdgeInsets.all(12), child: Text(trn('پیام متنی کافی برای خلاصه‌کردن نیست.'), style: TextStyle(color: cTextDim))),
      ]);
    }
    final by = s.bySender.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      _sheetTitle(trn('خلاصه‌ی گفتگو'), icon: Icons.summarize_outlined),
      Text(trf('{0} پیام متنی اخیر بررسی شد', [s.total]), style: TextStyle(color: cTextDim, fontSize: 12)),
      const SizedBox(height: 8),
      Wrap(spacing: 6, runSpacing: 6, children: [
        for (final e in by.take(6)) Chip(avatar: const Icon(Icons.chat_bubble_outline, size: 14), label: Text('${e.key == me ? trn('من') : store.name(e.key)}  ${e.value}'), visualDensity: VisualDensity.compact),
      ]),
      if (s.topics.isNotEmpty) ...[
        const SizedBox(height: 14),
        Row(children: [Icon(Icons.tag, size: 18, color: accent), const SizedBox(width: 6), Text(trn('موضوعات'), style: TextStyle(color: cText, fontWeight: FontWeight.w800))]),
        const SizedBox(height: 6),
        Wrap(spacing: 6, runSpacing: 6, children: [for (final k in s.topics) Chip(label: Text(k), visualDensity: VisualDensity.compact)]),
      ],
      section(trn('پرسش‌ها'), Icons.help_outline_rounded, s.questions, c),
      section(trn('قرارها و زمان‌ها'), Icons.event_outlined, s.plans, c),
      section(trn('مهم‌ترین پیام‌ها'), Icons.star_outline_rounded, s.important, c),
    ]);
  });
}

/// همه‌ی پیشنهادهای پاسخ برای یک پیام (دسته‌بندی‌شده)
Future<void> showRepliesSheet(BuildContext context, Map<String, dynamic> msg, void Function(String) onPick) {
  final pack = buildReplies(msg);
  Widget group(BuildContext c, ReplyGroup g, {bool hot = false}) => Padding(
        padding: const EdgeInsets.only(top: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(trn(g.title), style: TextStyle(color: hot ? accent : cTextDim, fontWeight: FontWeight.w800, fontSize: 13)),
          const SizedBox(height: 6),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (final r in g.replies)
              ActionChip(
                label: Text(r),
                backgroundColor: hot ? Color.lerp(card, primary, 0.3) : null,
                onPressed: () {
                  Navigator.pop(c);
                  onPick(r);
                },
              ),
          ]),
        ]),
      );
  return showTiaSheet<void>(context, (c) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        _sheetTitle(trn('✨ پیشنهاد پاسخ'), icon: Icons.auto_awesome_rounded),
        for (final g in pack.matched) group(c, g, hot: true),
        for (final g in pack.others) group(c, g),
      ]));
}
