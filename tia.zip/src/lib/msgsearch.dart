import 'package:flutter/material.dart';
import 'chat.dart';
import 'groups.dart';
import 'main.dart';
import 'safety.dart';

class MessageSearchPage extends StatefulWidget {
  const MessageSearchPage({super.key});
  @override
  State<MessageSearchPage> createState() => _MessageSearchPageState();
}

class _MessageSearchPageState extends State<MessageSearchPage> {
  String q = '';

  List<Map<String, dynamic>> results() {
    if (q.length < 2) return [];
    final out = <Map<String, dynamic>>[];
    for (final m in store.msgs) {
      final peer = store.peerOf(m);
      if (!safety.visible('d', peer, m)) continue;
      if (snippet(m).toLowerCase().contains(q)) {
        out.add({'m': m, 'title': peer == me ? 'پیام‌های ذخیره‌شده' : store.name(peer), 'peer': peer});
      }
    }
    for (final m in gs.msgs) {
      final gid = m['group_id'] as int;
      if (!gs.groups.containsKey(gid) || !safety.visible('g', '$gid', m)) continue;
      if (snippet(m).toLowerCase().contains(q)) {
        out.add({'m': m, 'title': '${gs.groups[gid]!['title']}', 'gid': gid});
      }
    }
    out.sort((a, b) => ((b['m'] as Map)['created_at'] as String).compareTo((a['m'] as Map)['created_at'] as String));
    return out.take(100).toList();
  }

  @override
  Widget build(BuildContext context) {
    final res = results();
    return Scaffold(
      appBar: AppBar(
        title: TextField(autofocus: true, onChanged: (v) => setState(() => q = v.trim().toLowerCase()), decoration: fieldDeco(hintText: 'جستجو در همه‌ی پیام‌ها...', plain: true)),
      ),
      body: q.length < 2
          ? const Center(child: Text('حداقل دو حرف بنویسید'))
          : res.isEmpty
              ? const Center(child: Text('نتیجه‌ای پیدا نشد'))
              : ListView(children: [
                  for (final r in res)
                    ListTile(
                      title: Text(r['title'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${store.name((r['m'] as Map)['sender_id'] as String)}: ${snippet(r['m'] as Map<String, dynamic>)}', maxLines: 2, overflow: TextOverflow.ellipsis),
                      trailing: Text(hm((r['m'] as Map)['created_at'] as String), style: const TextStyle(fontSize: 12)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => r['gid'] != null ? ChatPage(gid: r['gid'] as int, jumpTo: (r['m'] as Map)['id'] as int) : ChatPage(peer: r['peer'] as String, jumpTo: (r['m'] as Map)['id'] as int))),
                    ),
                ]),
    );
  }
}
