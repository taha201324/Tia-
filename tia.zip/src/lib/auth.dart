import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'cyber.dart';
import 'main.dart';
import 'l10n.dart';

// ---------------------------------------------------------------------------
// ابزارها
// ---------------------------------------------------------------------------
String normPhone(String s) {
  const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
  var o = s;
  for (var i = 0; i < 10; i++) {
    o = o.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
  }
  return o.replaceAll(RegExp(r'[\s\-()]'), '');
}

String phoneEmail(String p) => '$p@tia.chat';

const _codeAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

String generateRecoveryCode() {
  final r = Random.secure();
  return List.generate(16, (_) => _codeAlphabet[r.nextInt(_codeAlphabet.length)]).join();
}

String prettyCode(String c) => [for (var i = 0; i < c.length; i += 4) c.substring(i, min(i + 4, c.length))].join('-');
String cleanCode(String c) => c.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');

BuildContext? get _rootCtx => navKey.currentState?.overlay?.context;

// ---------------------------------------------------------------------------
// ظاهر صفحه‌های ورود: بالای رنگی + ورقه‌ی تخت
// ---------------------------------------------------------------------------
Color get heroText => isDark ? cText : cOnPrimary;

class _HeroPainter extends CustomPainter {
  final Color c;
  const _HeroPainter(this.c);
  @override
  void paint(Canvas canvas, Size size) {
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..color = c.withOpacity(0.14);
    for (final r in [80.0, 140.0, 200.0, 260.0]) {
      canvas.drawCircle(Offset(size.width * 0.92, size.height * 0.06), r, ring);
    }
    final fill = Paint()..color = c.withOpacity(0.07);
    canvas.save();
    canvas.translate(size.width * 0.05, size.height * 0.88);
    canvas.rotate(0.5);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(-90, -90, 180, 180), const Radius.circular(44)), fill);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// تم مستقل صفحه‌های ورود/ثبت‌نام: صرف‌نظر از تم سایبر و رنگ‌هایی که کاربر برای خانه و چت انتخاب کرده،
/// ورود همیشه ظاهر ثابت و روشن خودش را دارد. با ورود کاربر، تم عادی برنامه برمی‌گردد.
class AuthTheme {
  static bool _on = false;
  static bool _cyWas = true;

  static void enter() {
    if (_on) return;
    _on = true;
    _cyWas = cy.enabled;
    cy.enabled = false;
    isDark = false;
    primary = const Color(0xFF4C5FEF);
    accent = Color.lerp(primary, Colors.black, 0.15)!;
    accent2 = const Color(0xFFF59E0B);
    bg = const Color(0xFFF4F6FB);
    card = Colors.white;
    cText = const Color(0xFF16161D);
    cTextDim = const Color(0xB316161D);
    cTextFaint = const Color(0x8016161D);
    cLine = const Color(0x1F000000);
    cOnPrimary = Colors.white;
  }

  static void leave() {
    if (!_on) return;
    _on = false;
    cy.enabled = _cyWas;
    applyTheme();
    WidgetsBinding.instance.addPostFrameCallback((_) => settings.refresh());
  }

  static ThemeData data() => buildTheme();
}

class AuthBackdrop extends StatelessWidget {
  final Widget child;
  const AuthBackdrop({super.key, required this.child});

  Widget _blob(double size, Color c) => Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: c));

  @override
  Widget build(BuildContext context) {
    if (cy.enabled) {
      return Scaffold(backgroundColor: Colors.transparent, body: Stack(children: [SafeArea(child: child)]));
    }
    // ظاهر مخصوص ورود: گرادیان عمیق + حباب‌های نرم رنگی
    return Scaffold(
      backgroundColor: const Color(0xFF1E1B4B),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF1E1B4B), Color(0xFF3B5BDB), Color(0xFF7C3AED)]),
        ),
        child: Stack(children: [
          Positioned(top: -90, right: -70, child: _blob(260, Colors.white.withOpacity(0.07))),
          Positioned(top: 170, left: -60, child: _blob(150, const Color(0xFFEC4899).withOpacity(0.16))),
          Positioned(bottom: -110, left: -80, child: _blob(320, const Color(0xFFF59E0B).withOpacity(0.14))),
          Positioned(bottom: 120, right: -50, child: _blob(120, const Color(0xFF22D3EE).withOpacity(0.14))),
          SafeArea(child: child),
        ]),
      ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  const GlassCard({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: cy.enabled ? card.withOpacity(0.82) : card,
          borderRadius: BorderRadius.circular(cy.enabled ? 22 : 32),
          border: cy.enabled ? Border.all(color: cy.c1.withOpacity(0.55)) : null,
          boxShadow: cy.enabled ? [BoxShadow(color: cy.c1.withOpacity(0.15 + 0.3 * cy.glow), blurRadius: 24 + 20 * cy.glow)] : const [BoxShadow(color: Color(0x33000000), blurRadius: 36, offset: Offset(0, 14))],
        ),
        child: child,
      );
}

InputDecoration glassField(String label, IconData icon, {Widget? suffix, String? hint}) {
  OutlineInputBorder b(Color c, double w) => OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: c, width: w));
  return InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: Icon(icon, size: 20),
    suffixIcon: suffix,
    filled: true,
    fillColor: (isDark ? Colors.white : Colors.black).withOpacity(0.055),
    border: b(Colors.transparent, 0),
    enabledBorder: b(Colors.transparent, 0),
    focusedBorder: b(primary, 1.8),
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
  );
}

Widget fadeUp(Widget child, {int delayMs = 0}) => TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 650 + delayMs),
      curve: Curves.easeOutCubic,
      builder: (c, v, ch) => Opacity(opacity: v.clamp(0.0, 1.0), child: Transform.translate(offset: Offset(0, (1 - v) * 26), child: ch)),
      child: child,
    );

class GradientButton extends StatelessWidget {
  final String text;
  final bool busy;
  final VoidCallback? onTap;
  const GradientButton(this.text, {super.key, this.busy = false, this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: busy ? null : onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          height: 56,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: cy.enabled
                ? LinearGradient(colors: [cy.c1, Color.lerp(cy.c1, cy.c2, 0.7)!])
                : LinearGradient(colors: [primary.withOpacity(busy ? 0.6 : 1), const Color(0xFF7C3AED).withOpacity(busy ? 0.6 : 1)]),
            borderRadius: BorderRadius.circular(cy.enabled ? 14 : 20),
            boxShadow: cy.enabled ? [BoxShadow(color: cy.c1.withOpacity(0.2 + 0.45 * cy.glow), blurRadius: 14 + 18 * cy.glow)] : [BoxShadow(color: primary.withOpacity(0.35), blurRadius: 16, offset: const Offset(0, 6))],
          ),
          child: busy
              ? SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.5, color: cOnPrimary))
              : Text(text, style: TextStyle(color: cOnPrimary, fontSize: 16.5, fontWeight: FontWeight.w900)),
        ),
      );
}

class StrengthBar extends StatelessWidget {
  final String pass;
  const StrengthBar(this.pass, {super.key});
  @override
  Widget build(BuildContext context) {
    var s = 0;
    if (pass.length >= 6) s++;
    if (pass.length >= 9) s++;
    if (RegExp(r'[A-Za-z]').hasMatch(pass) && RegExp(r'[0-9]').hasMatch(pass)) s++;
    if (RegExp(r'[^A-Za-z0-9]').hasMatch(pass)) s++;
    final cols = [Colors.redAccent, Colors.orangeAccent, Colors.amber, Colors.lightGreen, Colors.greenAccent];
    final labels = [trn('خیلی ضعیف'), trn('ضعیف'), trn('متوسط'), trn('خوب'), trn('عالی')];
    final idx = pass.isEmpty ? 0 : s.clamp(0, 4);
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(children: [
        for (var i = 0; i < 4; i++)
          Expanded(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              height: 4,
              margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(color: pass.isNotEmpty && i < s ? cols[idx] : cLine, borderRadius: BorderRadius.circular(3)),
            ),
          ),
        const SizedBox(width: 8),
        Text(pass.isEmpty ? '' : labels[idx], style: TextStyle(fontSize: 11, color: cTextDim)),
      ]),
    );
  }
}

Widget logoBlock(bool signup) => cy.enabled ? CyberLogoBlock(signup: signup) : Column(children: [
      TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.6, end: 1),
        duration: const Duration(milliseconds: 900),
        curve: Curves.elasticOut,
        builder: (c, v, ch) => Transform.scale(scale: v, child: ch),
        child: Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(30), boxShadow: [BoxShadow(color: Colors.white.withOpacity(0.35), blurRadius: 36, spreadRadius: 2)]),
          child: ClipRRect(borderRadius: BorderRadius.circular(28), child: Image.asset('assets/icon.png', width: 84)),
        ),
      ),
      const SizedBox(height: 14),
      Text('Tia', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: heroText, letterSpacing: 1)),
      const SizedBox(height: 2),
      AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: Text(signup ? trn('یک حساب بساز و شروع کن') : trn('پیام‌رسان و شبکه‌ی اجتماعی تو'), key: ValueKey(signup), style: TextStyle(color: heroText.withOpacity(0.85), fontSize: 14)),
      ),
    ]);

// ---------------------------------------------------------------------------
// صفحه‌ی ورود / ساخت حساب
// ---------------------------------------------------------------------------
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool signup = false, busy = false, showPass = false;
  String? err, note;
  final phone = TextEditingController(), name = TextEditingController(), uname = TextEditingController(), pass = TextEditingController();

  String netErr(Object e) => e is SocketException || e is TimeoutException ? trn('اتصال برقرار نشد. اینترنت یا فیلترشکن را بررسی کنید.') : trn('مشکلی پیش آمد. دوباره تلاش کنید.');

  Future<void> submit() async {
    final p = normPhone(phone.text);
    if (p.length < 10) return setState(() => err = trn('شماره موبایل را کامل وارد کنید'));
    if (pass.text.length < 6) return setState(() => err = trn('رمز عبور باید حداقل ۶ کاراکتر باشد'));
    if (signup) {
      if (name.text.trim().isEmpty) return setState(() => err = trn('نام خود را وارد کنید'));
      if (!RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(uname.text.trim().toLowerCase())) return setState(() => err = trn('نام کاربری: حروف انگلیسی، عدد و _ (۳ تا ۲۰ کاراکتر)'));
    }
    setState(() {
      busy = true;
      err = null;
    });
    final email = phoneEmail(p);
    try {
      if (!signup) {
        bool? exists;
        try {
          exists = (await sb.rpc('account_exists', params: {'p_email': email})) == true;
        } catch (_) {
          exists = null; // تابع هنوز در سرور ساخته نشده
        }
        if (exists == false) {
          setState(() {
            signup = true;
            busy = false;
            note = trn('با این شماره حسابی پیدا نشد؛ نام و نام کاربری را بنویس تا همین حالا برایت بسازیم ✨');
          });
          return;
        }
        try {
          await sb.auth.signInWithPassword(email: email, password: pass.text);
        } on AuthException {
          err = exists == true ? trn('رمز عبور درست نیست') : trn('شماره یا رمز عبور درست نیست');
        }
      } else {
        final free = await sb.rpc('signup_available', params: {'p_phone': p, 'p_username': uname.text.trim().toLowerCase()});
        if (free != true) throw 'taken';
        final r = await sb.auth.signUp(email: email, password: pass.text);
        if (r.session == null) throw 'confirm';
        await sb.from('profiles').insert({'id': r.user!.id, 'phone': p, 'name': name.text.trim(), 'username': uname.text.trim().toLowerCase()});
        unawaited(createRecoveryCode(null, firstTime: true));
        try {
          (await SharedPreferences.getInstance()).setBool('onboard_${r.user!.id}', true);
        } catch (_) {}
      }
    } on AuthException {
      err = trn('ثبت‌نام انجام نشد. شاید این شماره قبلاً ثبت شده باشد.');
    } catch (e) {
      err = e == 'taken' ? trn('این شماره یا نام کاربری قبلاً ثبت شده است') : e == 'confirm' ? trn('در Supabase گزینه‌ی Confirm email را خاموش کنید') : netErr(e);
    }
    if (mounted) setState(() => busy = false);
  }

  Widget seg() {
    Widget tab(String t, bool on, VoidCallback f) => Expanded(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: f,
            child: Container(
              height: 44,
              alignment: Alignment.center,
              child: AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5, color: on ? cOnPrimary : cTextDim),
                child: Text(t),
              ),
            ),
          ),
        );
    return Container(
      height: 44,
      decoration: BoxDecoration(color: (isDark ? Colors.white : Colors.black).withOpacity(0.07), borderRadius: BorderRadius.circular(16)),
      child: Stack(children: [
        AnimatedAlign(
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOutCubic,
          alignment: signup ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
          child: FractionallySizedBox(
            widthFactor: 0.5,
            child: Container(
              margin: const EdgeInsets.all(3),
              decoration: BoxDecoration(color: primary, borderRadius: BorderRadius.circular(13)),
            ),
          ),
        ),
        Row(children: [
          tab(trn('ورود'), !signup, () => setState(() {
                signup = false;
                err = null;
                note = null;
              })),
          tab(trn('ساخت حساب'), signup, () => setState(() {
                signup = true;
                err = null;
                note = null;
              })),
        ]),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => AuthBackdrop(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(22, 18, 22, 30),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(children: [
                fadeUp(logoBlock(signup)),
                const SizedBox(height: 26),
                fadeUp(
                  GlassCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      seg(),
                      const SizedBox(height: 18),
                      AnimatedSize(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        alignment: Alignment.topCenter,
                        child: note == null
                            ? const SizedBox(width: double.infinity)
                            : Container(
                                margin: const EdgeInsets.only(bottom: 14),
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(color: primary.withOpacity(0.16), borderRadius: BorderRadius.circular(14), border: Border.all(color: primary.withOpacity(0.4))),
                                child: Text(note!, style: TextStyle(color: cText, fontSize: 13, height: 1.6)),
                              ),
                      ),
                      TextField(controller: phone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: glassField(trn('شماره موبایل'), Icons.phone_iphone_rounded, hint: '09123456789')),
                      AnimatedSize(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOutCubic,
                        alignment: Alignment.topCenter,
                        child: signup
                            ? Column(children: [
                                const SizedBox(height: 12),
                                TextField(controller: name, decoration: glassField(trn('نام'), Icons.person_outline_rounded)),
                                const SizedBox(height: 12),
                                TextField(controller: uname, textDirection: TextDirection.ltr, decoration: glassField(trn('نام کاربری (انگلیسی)'), Icons.alternate_email_rounded)),
                              ])
                            : const SizedBox(width: double.infinity),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: pass,
                        obscureText: !showPass,
                        onChanged: (_) => setState(() {}),
                        onSubmitted: (_) => submit(),
                        decoration: glassField(trn('رمز عبور'), Icons.lock_outline_rounded, suffix: IconButton(icon: Icon(showPass ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20), onPressed: () => setState(() => showPass = !showPass))),
                      ),
                      if (signup) StrengthBar(pass.text),
                      AnimatedSize(
                        duration: const Duration(milliseconds: 250),
                        child: err == null
                            ? const SizedBox(width: double.infinity)
                            : Padding(
                                padding: const EdgeInsets.only(top: 12),
                                child: Row(children: [
                                  const Icon(Icons.error_outline, color: Colors.redAccent, size: 18),
                                  const SizedBox(width: 6),
                                  Expanded(child: Text(err!, style: const TextStyle(color: Colors.redAccent, fontSize: 13))),
                                ]),
                              ),
                      ),
                      if (!signup)
                        Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: TextButton(
                            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Theme(data: AuthTheme.data(), child: ForgotPasswordPage(initialPhone: phone.text)))),
                            child: Text(trn('فراموشی رمز عبور؟'), style: TextStyle(color: accent, fontWeight: FontWeight.w700)),
                          ),
                        )
                      else
                        const SizedBox(height: 8),
                      GradientButton(signup ? trn('ساخت حساب') : trn('ورود'), busy: busy, onTap: submit),
                    ]),
                  ),
                  delayMs: 150,
                ),
                const SizedBox(height: 18),
                fadeUp(Text(trn('با ورود، شرایط استفاده از تیا را می‌پذیرید'), style: TextStyle(color: heroText.withOpacity(0.7), fontSize: 12)), delayMs: 300),
              ]),
            ),
          ),
        ),
      );
}

// ---------------------------------------------------------------------------
// فراموشی رمز عبور
// ---------------------------------------------------------------------------
class ForgotPasswordPage extends StatefulWidget {
  final String initialPhone;
  const ForgotPasswordPage({super.key, this.initialPhone = ''});
  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  late final phone = TextEditingController(text: widget.initialPhone);
  final code = TextEditingController(), p1 = TextEditingController(), p2 = TextEditingController();
  bool busy = false, show = false;
  String? err;

  Future<void> submit() async {
    final p = normPhone(phone.text);
    final c = cleanCode(code.text);
    if (p.length < 10) return setState(() => err = trn('شماره موبایل را کامل وارد کنید'));
    if (c.length != 16) return setState(() => err = trn('کد بازیابی ۱۶ حرفی است (مثل ABCD-EFGH-JKLM-NPQR)'));
    if (p1.text.length < 6) return setState(() => err = trn('رمز جدید باید حداقل ۶ کاراکتر باشد'));
    if (p1.text != p2.text) return setState(() => err = trn('تکرار رمز با رمز جدید یکی نیست'));
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final ok = await sb.rpc('reset_password_with_code', params: {'p_email': phoneEmail(p), 'p_code': c, 'p_new': p1.text});
      if (ok == true) {
        await sb.auth.signInWithPassword(email: phoneEmail(p), password: p1.text);
        if (mounted) {
          Navigator.of(context).popUntil((r) => r.isFirst);
          snack(context, trn('رمز عبور عوض شد و وارد شدی ✅'));
        }
        return;
      }
      err = trn('شماره یا کد بازیابی درست نیست (بعد از ۵ بار اشتباه، ۳۰ دقیقه قفل می‌شود)');
    } on PostgrestException {
      err = trn('سرویس بازیابی در سرور فعال نیست. فایل supabase_recovery.sql را اجرا کنید.');
    } catch (_) {
      err = trn('اتصال برقرار نشد. اینترنت یا فیلترشکن را بررسی کنید.');
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => AuthBackdrop(
        child: Column(children: [
          Align(alignment: AlignmentDirectional.centerStart, child: Padding(padding: const EdgeInsets.all(8), child: BackButton(color: heroText))),
          Expanded(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(22, 0, 22, 30),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 440),
                  child: Column(children: [
                    fadeUp(Column(children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(shape: BoxShape.circle, color: heroText.withOpacity(0.16)),
                        child: Icon(Icons.lock_reset_rounded, size: 46, color: heroText),
                      ),
                      const SizedBox(height: 16),
                      Text(trn('بازیابی رمز عبور'), style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: heroText)),
                      const SizedBox(height: 6),
                      Text(trn('شماره‌ات و کد بازیابی‌ای که موقع ساخت حساب گرفتی را بنویس'), textAlign: TextAlign.center, style: TextStyle(color: heroText.withOpacity(0.85), height: 1.6)),
                    ])),
                    const SizedBox(height: 22),
                    fadeUp(
                      GlassCard(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          TextField(controller: phone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: glassField(trn('شماره موبایل'), Icons.phone_iphone_rounded)),
                          const SizedBox(height: 12),
                          TextField(
                            controller: code,
                            textDirection: TextDirection.ltr,
                            textCapitalization: TextCapitalization.characters,
                            style: const TextStyle(letterSpacing: 2, fontWeight: FontWeight.w700),
                            decoration: glassField(trn('کد بازیابی'), Icons.key_rounded, hint: 'XXXX-XXXX-XXXX-XXXX'),
                          ),
                          const SizedBox(height: 12),
                          TextField(controller: p1, obscureText: !show, onChanged: (_) => setState(() {}), decoration: glassField(trn('رمز جدید'), Icons.lock_outline_rounded, suffix: IconButton(icon: Icon(show ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20), onPressed: () => setState(() => show = !show)))),
                          StrengthBar(p1.text),
                          const SizedBox(height: 12),
                          TextField(controller: p2, obscureText: !show, decoration: glassField(trn('تکرار رمز جدید'), Icons.lock_outline_rounded)),
                          if (err != null)
                            Padding(
                              padding: const EdgeInsets.only(top: 12),
                              child: Row(children: [
                                const Icon(Icons.error_outline, color: Colors.redAccent, size: 18),
                                const SizedBox(width: 6),
                                Expanded(child: Text(err!, style: const TextStyle(color: Colors.redAccent, fontSize: 13))),
                              ]),
                            ),
                          const SizedBox(height: 18),
                          GradientButton(trn('تعویض رمز عبور'), busy: busy, onTap: submit),
                          const SizedBox(height: 12),
                          Text(trn('کد بازیابی را نداری؟ اگر هنوز روی گوشی دیگری وارد هستی، از تنظیمات یک کد جدید بساز. بدون کد، امکان بازیابی وجود ندارد.'), textAlign: TextAlign.center, style: TextStyle(color: cTextFaint, fontSize: 12, height: 1.7)),
                        ]),
                      ),
                      delayMs: 150,
                    ),
                  ]),
                ),
              ),
            ),
          ),
        ]),
      );
}

// ---------------------------------------------------------------------------
// کد بازیابی: ساخت، نمایش و یادآوری
// ---------------------------------------------------------------------------
Future<void> showRecoveryCodeDialog(BuildContext ctx, String code) => showDialog<void>(
      context: ctx,
      barrierDismissible: false,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: _RecoveryDialog(code),
      ),
    );

class _RecoveryDialog extends StatefulWidget {
  final String code;
  const _RecoveryDialog(this.code);
  @override
  State<_RecoveryDialog> createState() => _RecoveryDialogState();
}

class _RecoveryDialogState extends State<_RecoveryDialog> {
  bool saved = false;
  @override
  Widget build(BuildContext context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
        title: Row(children: [Icon(Icons.shield_moon_rounded, color: accent), const SizedBox(width: 8), Text(trn('کد بازیابی تو'))]),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(trn('اگر رمزت را فراموش کنی، فقط با این کد می‌توانی حسابت را پس بگیری. آن را یک جای امن بنویس یا ذخیره کن؛ دوباره نشان داده نمی‌شود.'), style: TextStyle(height: 1.7)),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(color: primary.withOpacity(0.14), borderRadius: BorderRadius.circular(16), border: Border.all(color: primary.withOpacity(0.5))),
            child: SelectableText(prettyCode(widget.code), textAlign: TextAlign.center, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 2.5, fontFamily: 'monospace')),
          ),
          TextButton.icon(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: prettyCode(widget.code)));
              snack(context, trn('کپی شد'));
            },
            icon: const Icon(Icons.copy_rounded, size: 18),
            label: Text(trn('کپی کد')),
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            value: saved,
            onChanged: (v) => setState(() => saved = v ?? false),
            title: Text(trn('کد را در جای امن ذخیره کردم'), style: TextStyle(fontSize: 13)),
          ),
        ]),
        actions: [FilledButton(onPressed: saved ? () => Navigator.pop(context) : null, child: Text(trn('ادامه')))],
      );
}

Future<void> createRecoveryCode(BuildContext? ctx, {bool firstTime = false}) async {
  try {
    final code = generateRecoveryCode();
    await sb.rpc('set_recovery_code', params: {'p_code': code});
    await Future.delayed(const Duration(milliseconds: 400));
    final c = ctx != null && ctx.mounted ? ctx : _rootCtx;
    if (c != null && c.mounted) await showRecoveryCodeDialog(c, code);
  } catch (_) {
    final c = ctx != null && ctx.mounted ? ctx : _rootCtx;
    if (c != null && c.mounted && !firstTime) snack(c, trn('ساخت کد بازیابی انجام نشد. فایل supabase_recovery.sql را در سرور اجرا کنید.'));
  }
}

// برای حساب‌های قدیمی که هنوز کد بازیابی ندارند؛ حداکثر روزی یک بار
Future<void> recoveryReminder() async {
  try {
    final has = await sb.rpc('has_recovery_code');
    if (has == true) return;
    final p = await SharedPreferences.getInstance();
    final today = DateTime.now().toIso8601String().substring(0, 10);
    if (p.getString('rc_prompt_day') == today) return;
    await p.setString('rc_prompt_day', today);
    await Future.delayed(const Duration(seconds: 2));
    final c = _rootCtx;
    if (c == null || !c.mounted) return;
    final go = await showDialog<bool>(
      context: c,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
          title: Text(trn('حسابت را امن کن')),
          content: Text(trn('هنوز کد بازیابی نداری. با آن می‌توانی اگر رمزت را فراموش کردی، حسابت را پس بگیری.'), style: TextStyle(height: 1.7)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: Text(trn('بعداً'))),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(trn('ساخت کد'))),
          ],
        ),
      ),
    );
    if (go == true) await createRecoveryCode(null);
  } catch (_) {}
}
