import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'main.dart';
import 'safety.dart';

String? currentSessionId() {
  try {
    final t = sb.auth.currentSession?.accessToken;
    if (t == null) return null;
    final part = t.split('.')[1];
    final json = utf8.decode(base64Url.decode(base64Url.normalize(part)));
    return (jsonDecode(json) as Map<String, dynamic>)['session_id'] as String?;
  } catch (_) {
    return null;
  }
}

class DeviceInfo {
  final IconData icon;
  final String name;
  const DeviceInfo(this.icon, this.name);
}

DeviceInfo parseDevice(String? ua) {
  final u = (ua ?? '').toLowerCase();
  if (u.contains('android')) return const DeviceInfo(Icons.phone_android_rounded, 'گوشی اندروید');
  if (u.contains('iphone') || u.contains('ipad') || u.contains('ios')) return const DeviceInfo(Icons.phone_iphone_rounded, 'آیفون / آیپد');
  if (u.contains('windows')) return const DeviceInfo(Icons.desktop_windows_rounded, 'ویندوز');
  if (u.contains('mac')) return const DeviceInfo(Icons.laptop_mac_rounded, 'مک');
  if (u.contains('linux')) return const DeviceInfo(Icons.computer_rounded, 'لینوکس');
  if (u.contains('dart') || u.contains('okhttp')) return const DeviceInfo(Icons.phone_android_rounded, 'برنامه‌ی تیا');
  if (u.contains('mozilla') || u.contains('chrome') || u.contains('safari')) return const DeviceInfo(Icons.language_rounded, 'مرورگر');
  return const DeviceInfo(Icons.devices_rounded, 'دستگاه ناشناس');
}

String ago(String? iso) {
  final d = DateTime.tryParse(iso ?? '')?.toLocal();
  if (d == null) return '';
  final diff = DateTime.now().difference(d);
  if (diff.inMinutes < 2) return 'همین حالا';
  if (diff.inMinutes < 60) return '${diff.inMinutes} دقیقه پیش';
  if (diff.inHours < 24) return '${diff.inHours} ساعت پیش';
  return '${diff.inDays} روز پیش';
}

class SessionsPage extends StatefulWidget {
  const SessionsPage({super.key});
  @override
  State<SessionsPage> createState() => _SessionsPageState();
}

class _SessionsPageState extends State<SessionsPage> {
  List<Map<String, dynamic>> list = [];
  bool loading = true, failed = false;
  final cur = currentSessionId();

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      failed = false;
    });
    try {
      final r = await sb.rpc('my_sessions');
      list = [for (final e in (r as List)) Map<String, dynamic>.from(e as Map)];
    } catch (_) {
      failed = true;
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> revoke(Map<String, dynamic> s) async {
    if (!await confirm(context, 'این دستگاه از حساب خارج شود؟')) return;
    try {
      await sb.rpc('revoke_session', params: {'p_id': s['id']});
      if (mounted) snack(context, 'دستگاه خارج شد (تا چند دقیقه ممکن است هنوز باز بماند)');
      await load();
    } on PostgrestException catch (e) {
      if (mounted) snack(context, e.message);
    } catch (_) {
      if (mounted) snack(context, 'انجام نشد. اینترنت را بررسی کنید.');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('دستگاه‌های متصل')),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : failed
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Text('فهرست دستگاه‌ها دریافت نشد.\nاگر تازه به‌روز کرده‌اید، فایل supabase_sessions.sql را در سرور اجرا کنید.', textAlign: TextAlign.center, style: TextStyle(height: 1.7)),
                        const SizedBox(height: 12),
                        FilledButton(onPressed: load, child: const Text('تلاش دوباره')),
                      ]),
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: load,
                    child: ListView(padding: const EdgeInsets.only(top: 8, bottom: 24), children: [
                      for (final s in list)
                        cardTile(
                          ListTile(
                            leading: Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(color: primary.withOpacity(0.16), shape: BoxShape.circle),
                              child: Icon(parseDevice(s['user_agent'] as String?).icon, color: accent),
                            ),
                            title: Row(children: [
                              Text(parseDevice(s['user_agent'] as String?).name, style: const TextStyle(fontWeight: FontWeight.w700)),
                              if (s['id'] == cur) ...[
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(color: Colors.green.withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
                                  child: const Text('این دستگاه', style: TextStyle(fontSize: 11, color: Colors.green, fontWeight: FontWeight.bold)),
                                ),
                              ],
                            ]),
                            subtitle: Text('آخرین فعالیت: ${ago((s['updated_at'] ?? s['created_at']) as String?)}${(s['ip'] ?? '').toString().isEmpty ? '' : '\nIP: ${s['ip']}'}', style: const TextStyle(height: 1.6)),
                            isThreeLine: (s['ip'] ?? '').toString().isNotEmpty,
                            trailing: s['id'] == cur ? null : IconButton(icon: const Icon(Icons.logout_rounded, color: Colors.redAccent), tooltip: 'خروج این دستگاه', onPressed: () => revoke(s)),
                          ),
                        ),
                      if (list.length > 1)
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: OutlinedButton.icon(
                            onPressed: () async {
                              await logoutOthersFlow(context);
                              await load();
                            },
                            icon: const Icon(Icons.devices_other),
                            label: const Text('خروج از همه‌ی دستگاه‌های دیگر'),
                          ),
                        ),
                    ]),
                  ),
      );
}
