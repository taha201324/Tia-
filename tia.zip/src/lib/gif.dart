import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'main.dart';
import 'l10n.dart';

// اختیاری: اگر کلید گیفی داشتید از طریق --dart-define=GIPHY_KEY=... داده می‌شود.
// بدون کلید، فقط «کتابخانه» و «ذخیره‌شده‌ها» (روی سرور خودتان) کار می‌کنند.
const giphyKey = String.fromEnvironment('GIPHY_KEY');

String _err(Object e) => e is PostgrestException ? e.message : (e is StorageException ? e.message : trn('انجام نشد. اینترنت را بررسی کنید.'));

class GifEntry {
  final int? id;
  final String? path; // مسیر فایل در chat-files (گیف‌های خودم)
  final String? url; // آدرس مستقیم (کتابخانه یا آنلاین)
  final String? preview;
  final String title, tags;
  const GifEntry({this.id, this.path, this.url, this.preview, this.title = '', this.tags = ''});
}

Future<Uint8List> _download(String url) async {
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 10);
  try {
    final req = await c.getUrl(Uri.parse(url));
    final res = await req.close().timeout(const Duration(seconds: 30));
    final b = BytesBuilder();
    await for (final chunk in res) {
      b.add(chunk);
      if (b.length > 10 * 1024 * 1024) throw 'big';
    }
    return b.takeBytes();
  } finally {
    c.close(force: true);
  }
}

Future<Map<String, dynamic>> _getJson(String url) async => jsonDecode(utf8.decode(await _download(url))) as Map<String, dynamic>;

Future<List<GifEntry>> searchOnline(String q) async {
  if (giphyKey.isEmpty) return [];
  final base = q.trim().isEmpty ? 'https://api.giphy.com/v1/gifs/trending?' : 'https://api.giphy.com/v1/gifs/search?q=${Uri.encodeQueryComponent(q.trim())}&';
  final j = await _getJson('${base}api_key=$giphyKey&limit=30&rating=pg-13');
  final out = <GifEntry>[];
  for (final d in (j['data'] as List? ?? [])) {
    final im = (d as Map)['images'] as Map?;
    final full = (im?['downsized'] as Map?)?['url'] as String?;
    final small = (im?['fixed_width_small'] as Map?)?['url'] as String? ?? (im?['fixed_width'] as Map?)?['url'] as String?;
    if (full != null) out.add(GifEntry(url: full, preview: small ?? full));
  }
  return out;
}

String libraryUrl(String path) => sb.storage.from('gif-library').getPublicUrl(path);

Future<List<GifEntry>> loadSaved() async {
  final rows = await sb.from('saved_gifs').select().eq('owner_id', me!).order('id', ascending: false).limit(300);
  return [for (final r in rows) GifEntry(id: r['id'] as int, path: r['path'] as String?, url: r['url'] as String?, title: (r['name'] as String?) ?? '')];
}

Future<List<GifEntry>> loadLibrary() async {
  final rows = await sb.from('gif_library').select().order('id', ascending: false).limit(500);
  return [for (final r in rows) GifEntry(id: r['id'] as int, url: libraryUrl(r['path'] as String), title: (r['title'] as String?) ?? '', tags: (r['tags'] as String?) ?? '')];
}

Future<bool> loadIsAdmin() async {
  try {
    final r = await sb.from('app_admins').select('user_id').eq('user_id', me!).maybeSingle();
    return r != null;
  } catch (_) {
    return false;
  }
}

Future<void> saveEntry({String? path, String? url, String name = 'gif.gif'}) async {
  final dup = path != null ? await sb.from('saved_gifs').select('id').eq('owner_id', me!).eq('path', path) : await sb.from('saved_gifs').select('id').eq('owner_id', me!).eq('url', url!);
  if ((dup as List).isNotEmpty) return;
  await sb.from('saved_gifs').insert({'path': path, 'url': url, 'name': name});
}

// ذخیره‌ی گیفی که در چت آمده در «گیف‌های من»
Future<void> saveMessageGif(BuildContext c, Map<String, dynamic> m) async {
  try {
    final p = m['file_path'] as String?;
    if (p == null) {
      await saveEntry(url: m['text'] as String);
    } else if (p.startsWith('${me!}/')) {
      await saveEntry(path: p, name: (m['file_name'] as String?) ?? 'gif.gif');
    } else {
      final bytes = await sb.storage.from('chat-files').download(p);
      final np = '${me!}/gif_${DateTime.now().millisecondsSinceEpoch}.gif';
      await sb.storage.from('chat-files').uploadBinary(np, bytes, fileOptions: const FileOptions(contentType: 'image/gif'));
      await saveEntry(path: np, name: (m['file_name'] as String?) ?? 'gif.gif');
    }
    if (c.mounted) snack(c, trn('در گیف‌های من ذخیره شد'));
  } catch (e) {
    if (c.mounted) snack(c, _err(e));
  }
}

class GifPanel extends StatefulWidget {
  final void Function(GifEntry) onGif;
  final VoidCallback onPickFile;
  const GifPanel({super.key, required this.onGif, required this.onPickFile});
  @override
  State<GifPanel> createState() => _GifPanelState();
}

class _GifPanelState extends State<GifPanel> {
  final qc = TextEditingController();
  int tab = 0; // 0 کتابخانه، 1 ذخیره‌شده‌ها، 2 آنلاین
  List<GifEntry> lib = [], saved = [], online = [];
  bool loading = true, failed = false, isAdmin = false;
  Timer? deb;

  @override
  void initState() {
    super.initState();
    loadIsAdmin().then((v) {
      if (mounted) setState(() => isAdmin = v);
    });
    reload();
  }

  @override
  void dispose() {
    deb?.cancel();
    qc.dispose();
    super.dispose();
  }

  Future<void> reload() async {
    setState(() {
      loading = true;
      failed = false;
    });
    try {
      if (tab == 0) lib = await loadLibrary();
      if (tab == 1) saved = await loadSaved();
      if (tab == 2) online = await searchOnline(qc.text);
    } catch (_) {
      failed = true;
    }
    if (mounted) setState(() => loading = false);
  }

  List<GifEntry> get shown {
    final q = qc.text.trim().toLowerCase();
    if (tab == 2) return online;
    final src = tab == 0 ? lib : saved;
    if (q.isEmpty) return src;
    return src.where((g) => '${g.title} ${g.tags}'.toLowerCase().contains(q)).toList();
  }

  Future<List<String>?> askMeta(String title) async {
    final t = TextEditingController(text: title), g = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(trn('افزودن به کتابخانه')),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: t, decoration: InputDecoration(labelText: trn('عنوان'))),
            TextField(controller: g, decoration: InputDecoration(labelText: trn('برچسب‌ها (با فاصله)، مثل: خنده شاد'))),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: Text(trn('انصراف'))),
            TextButton(onPressed: () => Navigator.pop(context, true), child: Text(trn('افزودن'))),
          ],
        ),
      ),
    );
    if (ok != true) return null;
    return [t.text.trim(), g.text.trim()];
  }

  Future<void> addToLibrary(Uint8List bytes, String defTitle) async {
    final meta = await askMeta(defTitle);
    if (meta == null) return;
    try {
      final path = 'lib_${DateTime.now().millisecondsSinceEpoch}.gif';
      await sb.storage.from('gif-library').uploadBinary(path, bytes, fileOptions: const FileOptions(contentType: 'image/gif'));
      await sb.from('gif_library').insert({'title': meta[0], 'tags': meta[1], 'path': path});
      if (mounted) snack(context, trn('به کتابخانه اضافه شد'));
      if (tab == 0) reload();
    } catch (e) {
      if (mounted) snack(context, _err(e));
    }
  }

  Future<void> adminPickFile() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['gif'], withData: true);
    final f = r?.files.single;
    if (f == null) return;
    final bytes = f.bytes ?? await File(f.path!).readAsBytes();
    if (bytes.length > 10 * 1024 * 1024) {
      if (mounted) snack(context, trn('حجم گیف بیشتر از ۱۰ مگابایت است'));
      return;
    }
    await addToLibrary(bytes, f.name.replaceAll(RegExp(r'\.gif$', caseSensitive: false), ''));
  }

  Future<void> promote(GifEntry g) async {
    try {
      final bytes = g.path != null ? await sb.storage.from('chat-files').download(g.path!) : await _download(g.url!);
      await addToLibrary(bytes, g.title.replaceAll(RegExp(r'\.gif$', caseSensitive: false), ''));
    } catch (e) {
      if (mounted) snack(context, _err(e));
    }
  }

  Future<void> longPress(GifEntry g) async {
    final acts = <(IconData, String, Future<void> Function())>[];
    if (tab == 0) {
      acts.add((Icons.star_border, trn('ذخیره در گیف‌های من'), () async {
        if (g.url != null) await saveEntry(url: g.url, name: g.title);
        if (mounted) snack(context, trn('ذخیره شد'));
      }));
      if (isAdmin && g.id != null) {
        acts.add((Icons.delete_outline, trn('حذف از کتابخانه'), () async {
          await sb.from('gif_library').delete().eq('id', g.id!);
          await reload();
        }));
      }
    } else if (tab == 1) {
      acts.add((Icons.delete_outline, trn('حذف از گیف‌های من'), () async {
        await sb.from('saved_gifs').delete().eq('id', g.id!);
        await reload();
      }));
      if (isAdmin) acts.add((Icons.library_add_outlined, trn('افزودن به کتابخانه‌ی عمومی'), () => promote(g)));
    } else {
      acts.add((Icons.star_border, trn('ذخیره در گیف‌های من'), () async {
        await saveEntry(url: g.url);
        if (mounted) snack(context, trn('ذخیره شد'));
      }));
    }
    await showModalBottomSheet(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final a in acts)
              ListTile(
                leading: Icon(a.$1),
                title: Text(a.$2),
                onTap: () async {
                  Navigator.pop(ctx);
                  try {
                    await a.$3();
                  } catch (e) {
                    if (mounted) snack(context, _err(e));
                  }
                },
              ),
          ]),
        ),
      ),
    );
  }

  Widget chip(int i, String label) => Padding(
        padding: const EdgeInsets.only(left: 6),
        child: ChoiceChip(
          label: Text(label),
          selected: tab == i,
          onSelected: (_) {
            setState(() => tab = i);
            reload();
          },
        ),
      );

  @override
  Widget build(BuildContext context) {
    final list = shown;
    Widget body;
    if (loading) {
      body = const Center(child: CircularProgressIndicator());
    } else if (failed) {
      body = Center(child: TextButton(onPressed: reload, child: Text(tab == 0 ? trn('کتابخانه در دسترس نیست؛ دوباره تلاش کنید') : trn('خطا در دریافت؛ دوباره تلاش کنید'))));
    } else if (list.isEmpty) {
      body = Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            tab == 0 ? trn('کتابخانه هنوز خالی است') : tab == 1 ? trn('گیفی ذخیره نکرده‌اید.\nروی هر گیف در چت انگشت را نگه دارید.') : trn('نتیجه‌ای پیدا نشد'),
            textAlign: TextAlign.center,
          ),
        ),
      );
    } else {
      body = GridView.builder(
        padding: const EdgeInsets.all(6),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 4, crossAxisSpacing: 4),
        itemCount: list.length,
        itemBuilder: (c, i) => GestureDetector(
          onTap: () => widget.onGif(list[i]),
          onLongPress: () => longPress(list[i]),
          child: ClipRRect(borderRadius: BorderRadius.circular(8), child: _Thumb(list[i])),
        ),
      );
    }
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
        child: Row(children: [
          chip(0, trn('کتابخانه')),
          chip(1, trn('گیف‌های من')),
          if (giphyKey.isNotEmpty) chip(2, trn('آنلاین')),
          const Spacer(),
          if (isAdmin && tab == 0) IconButton(tooltip: trn('افزودن گیف به کتابخانه'), icon: const Icon(Icons.add_circle_outline), onPressed: adminPickFile),
          IconButton(tooltip: trn('فرستادن گیف از گوشی'), icon: const Icon(Icons.folder_open), onPressed: widget.onPickFile),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
        child: SizedBox(
          height: 38,
          child: TextField(
            controller: qc,
            decoration: InputDecoration(
              hintText: trn('جستجو...'),
              prefixIcon: const Icon(Icons.search, size: 20),
              contentPadding: EdgeInsets.zero,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
            ),
            onChanged: (v) {
              if (tab == 2) {
                deb?.cancel();
                deb = Timer(const Duration(milliseconds: 500), reload);
              } else {
                setState(() {});
              }
            },
          ),
        ),
      ),
      Expanded(child: body),
    ]);
  }
}

class _Thumb extends StatelessWidget {
  final GifEntry g;
  const _Thumb(this.g);
  @override
  Widget build(BuildContext context) {
    Widget img(String u) => Image.network(u, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: card, child: const Icon(Icons.broken_image, size: 18)));
    final direct = g.preview ?? g.url;
    if (direct != null) return img(direct);
    return FutureBuilder<String>(
      future: store.urlFor(g.path!),
      builder: (c, s) => s.hasData ? img(s.data!) : Container(color: card),
    );
  }
}

class GifBubble extends StatelessWidget {
  final String? url, path;
  const GifBubble({super.key, this.url, this.path});

  Widget img(String u, {double? w, BoxFit fit = BoxFit.cover}) => Image.network(u, width: w, fit: fit, errorBuilder: (_, __, ___) => const Padding(padding: EdgeInsets.all(20), child: Icon(Icons.broken_image)));

  void open(BuildContext c, String u) => Navigator.push(c, MaterialPageRoute(builder: (_) => Scaffold(backgroundColor: Colors.black, appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white), body: Center(child: InteractiveViewer(child: img(u, fit: BoxFit.contain))))));

  @override
  Widget build(BuildContext context) {
    Widget tile(String u) => GestureDetector(
          onTap: () => open(context, u),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Stack(children: [
              img(u, w: 220),
              Positioned(
                left: 6,
                top: 6,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                  decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(6)),
                  child: const Text('GIF', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                ),
              ),
            ]),
          ),
        );
    if (path != null && path!.isNotEmpty) {
      return FutureBuilder<String>(
        future: store.urlFor(path!),
        builder: (c, s) => s.hasData ? tile(s.data!) : const SizedBox(width: 200, height: 140, child: Center(child: CircularProgressIndicator())),
      );
    }
    return tile(url ?? '');
  }
}
