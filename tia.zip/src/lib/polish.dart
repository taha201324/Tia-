import 'package:flutter/material.dart';
import 'main.dart';

class Skeleton extends StatefulWidget {
  final double height;
  final double? width;
  final double radius;
  const Skeleton({super.key, required this.height, this.width, this.radius = 8});
  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 1300))..repeat();

  @override
  void dispose() {
    ac.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: ac,
        builder: (_, __) => Container(
          height: widget.height,
          width: widget.width,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(widget.radius),
            gradient: LinearGradient(
              begin: Alignment(-1.5 + ac.value * 3, 0),
              end: Alignment(-0.5 + ac.value * 3, 0),
              colors: [Color.lerp(bg, cText, 0.06)!, Color.lerp(bg, cText, 0.14)!, Color.lerp(bg, cText, 0.06)!],
            ),
          ),
        ),
      );
}

Widget postSkeleton() => Container(
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(settings.cardRadius)),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Skeleton(height: 40, width: 40, radius: 20),
          SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Skeleton(height: 12, width: 120), SizedBox(height: 8), Skeleton(height: 10, width: 70)]),
        ]),
        SizedBox(height: 14),
        Skeleton(height: 14),
        SizedBox(height: 8),
        Skeleton(height: 14, width: 220),
        SizedBox(height: 14),
        Skeleton(height: 150, radius: 12),
      ]),
    );
