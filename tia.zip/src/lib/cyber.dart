import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';
import 'l10n.dart';

// ---------------------------------------------------------------------------
// تنظیمات تم سایبربانکی (رنگ نئون، حباب، پس‌زمینه، انیمیشن، پروفایل‌ها)
// ---------------------------------------------------------------------------
const neonPalette = <int>[
  0xFF00F5FF, 0xFFFF2BD6, 0xFFB6FF00, 0xFFFFE600, 0xFF7C4DFF,
  0xFFFF3B3B, 0xFF00FF9C, 0xFF3D7BFF, 0xFFFF8A00, 0xFFFFFFFF,
];

const bubbleShapeNames = ['سایبری', 'گرد', 'تیز', 'قرصی'];
const bgStyleNames = ['شبکه‌ی سینت‌ویو', 'شفق نئونی', 'باران ماتریکس', 'کندوی شش‌ضلعی', 'ساده'];
const entryNames = ['گلیچ و زوم', 'سر خوردن', 'محو شدن', 'بدون جلوه'];

final Map<String, Map<String, dynamic>> cyberPresets = {
  'سایبر بانکی': {'n1': 0xFF00F5FF, 'n2': 0xFFFF2BD6, 'n3': 0xFFB6FF00, 'glow': 0.65, 'speed': 1.0, 'bubble': 0, 'bg': 0, 'entry': 0, 'particles': true, 'shapes': true, 'scan': true, 'tunnel': true},
  'نئون توکیو': {'n1': 0xFFFF2BD6, 'n2': 0xFF7C4DFF, 'n3': 0xFF00F5FF, 'glow': 0.8, 'speed': 0.8, 'bubble': 3, 'bg': 1, 'entry': 1, 'particles': true, 'shapes': true, 'scan': false, 'tunnel': true},
  'ماتریکس': {'n1': 0xFF00FF9C, 'n2': 0xFFB6FF00, 'n3': 0xFF00F5FF, 'glow': 0.5, 'speed': 1.2, 'bubble': 2, 'bg': 2, 'entry': 0, 'particles': false, 'shapes': false, 'scan': true, 'tunnel': true},
  'غروب سینت‌ویو': {'n1': 0xFFFF8A00, 'n2': 0xFFFF2BD6, 'n3': 0xFFFFE600, 'glow': 0.7, 'speed': 0.9, 'bubble': 1, 'bg': 0, 'entry': 2, 'particles': true, 'shapes': true, 'scan': true, 'tunnel': true},
  'یخ قطبی': {'n1': 0xFF3D7BFF, 'n2': 0xFF00F5FF, 'n3': 0xFFFFFFFF, 'glow': 0.45, 'speed': 0.7, 'bubble': 0, 'bg': 3, 'entry': 1, 'particles': true, 'shapes': false, 'scan': false, 'tunnel': true},
};

class CyberCfg extends ChangeNotifier {
  bool enabled = true, particles = true, shapes = true, scanlines = true, tunnel = true;
  int neon1 = 0xFF00F5FF, neon2 = 0xFFFF2BD6, neon3 = 0xFFB6FF00;
  double glow = 0.65, speed = 1.0;
  int bubble = 0, bgStyle = 0, entry = 0;
  List<Map<String, dynamic>> profiles = [];
  String activeProfile = 'سایبر بانکی';
  SharedPreferences? _p;

  Color get c1 => Color(neon1);
  Color get c2 => Color(neon2);
  Color get c3 => Color(neon3);

  Map<String, dynamic> toMap() => {
        'n1': neon1, 'n2': neon2, 'n3': neon3, 'glow': glow, 'speed': speed,
        'bubble': bubble, 'bg': bgStyle, 'entry': entry,
        'particles': particles, 'shapes': shapes, 'scan': scanlines, 'tunnel': tunnel,
      };

  void fromMap(Map<String, dynamic> m) {
    neon1 = (m['n1'] as num?)?.toInt() ?? neon1;
    neon2 = (m['n2'] as num?)?.toInt() ?? neon2;
    neon3 = (m['n3'] as num?)?.toInt() ?? neon3;
    glow = ((m['glow'] as num?)?.toDouble() ?? glow).clamp(0.0, 1.0).toDouble();
    speed = ((m['speed'] as num?)?.toDouble() ?? speed).clamp(0.2, 2.5).toDouble();
    bubble = ((m['bubble'] as num?)?.toInt() ?? bubble).clamp(0, 3).toInt();
    bgStyle = ((m['bg'] as num?)?.toInt() ?? bgStyle).clamp(0, 4).toInt();
    entry = ((m['entry'] as num?)?.toInt() ?? entry).clamp(0, 3).toInt();
    particles = (m['particles'] as bool?) ?? particles;
    shapes = (m['shapes'] as bool?) ?? shapes;
    scanlines = (m['scan'] as bool?) ?? scanlines;
    tunnel = (m['tunnel'] as bool?) ?? tunnel;
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _p = p;
    enabled = p.getBool('cy_on') ?? true;
    activeProfile = p.getString('cy_active') ?? trn('سایبر بانکی');
    try {
      final raw = p.getString('cy_cfg');
      if (raw != null) fromMap(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {}
    try {
      final raw = p.getString('cy_profiles');
      if (raw != null) {
        profiles = [for (final e in (jsonDecode(raw) as List)) Map<String, dynamic>.from(e as Map)];
      }
    } catch (_) {}
  }

  void _persist() {
    final p = _p;
    if (p == null) return;
    p.setBool('cy_on', enabled);
    p.setString('cy_active', activeProfile);
    p.setString('cy_cfg', jsonEncode(toMap()));
    p.setString('cy_profiles', jsonEncode(profiles));
  }

  void save() {
    _persist();
    notifyListeners();
    settings.refresh();
  }

  void applyMap(String name, Map<String, dynamic> m) {
    fromMap(m);
    activeProfile = name;
    save();
  }

  void saveProfile(String name) {
    final n = name.trim();
    if (n.isEmpty) return;
    final map = Map<String, dynamic>.from(toMap())..['name'] = n;
    profiles.removeWhere((e) => e['name'] == n);
    profiles.add(map);
    activeProfile = n;
    save();
  }

  void deleteProfile(String name) {
    profiles.removeWhere((e) => e['name'] == name);
    save();
  }
}

final cy = CyberCfg();

// رنگ‌های برنامه را به حالت سایبر می‌برد (بعد از applyTheme صدا زده می‌شود)
void applyCyberTheme() {
  if (!cy.enabled) return;
  isDark = true;
  primary = cy.c1;
  accent = Color.lerp(cy.c1, Colors.white, 0.35)!;
  accent2 = cy.c2;
  bg = const Color(0xFF05060F);
  card = const Color(0xFF0C0F20);
  cText = const Color(0xFFEAF6FF);
  cTextDim = const Color(0xB3EAF6FF);
  cTextFaint = const Color(0x80EAF6FF);
  cLine = cy.c1.withOpacity(0.22);
  cOnPrimary = const Color(0xFF03050C);
}

BoxDecoration cyberBubble(bool mine) {
  final r = settings.bubbleRadius;
  double tl, tr, bl, br;
  switch (cy.bubble) {
    case 1:
      tl = r;
      tr = r;
      bl = mine ? r : r * 0.22;
      br = mine ? r * 0.22 : r;
      break;
    case 2:
      tl = tr = bl = br = 3;
      break;
    case 3:
      tl = tr = bl = br = 28;
      break;
    default:
      if (mine) {
        tr = r;
        bl = r;
        tl = 3;
        br = 3;
      } else {
        tl = r;
        br = r;
        tr = 3;
        bl = 3;
      }
  }
  final g = cy.glow;
  final col = mine ? cy.c1 : cy.c2;
  return BoxDecoration(
    gradient: mine ? LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [cy.c1, Color.lerp(cy.c1, cy.c2, 0.6)!]) : null,
    color: mine ? null : const Color(0xFF0E1226),
    borderRadius: BorderRadius.only(topLeft: Radius.circular(tl), topRight: Radius.circular(tr), bottomLeft: Radius.circular(bl), bottomRight: Radius.circular(br)),
    border: Border.all(color: col.withOpacity(mine ? 0.9 : 0.55), width: 1.1),
    boxShadow: g <= 0.02 ? <BoxShadow>[] : [BoxShadow(color: col.withOpacity(0.16 + 0.4 * g), blurRadius: 4 + 22 * g, spreadRadius: -1)],
  );
}

// ---------------------------------------------------------------------------
// ابزار انیمیشن
// ---------------------------------------------------------------------------
class CyberTicker extends StatefulWidget {
  final Widget Function(BuildContext c, double t) builder;
  const CyberTicker({super.key, required this.builder});
  @override
  State<CyberTicker> createState() => _CyberTickerState();
}

class _CyberTickerState extends State<CyberTicker> with SingleTickerProviderStateMixin {
  late final Ticker _tk;
  double t = 0;
  Duration _last = Duration.zero;

  @override
  void initState() {
    super.initState();
    _tk = createTicker((e) {
      final dt = (e - _last).inMicroseconds / 1e6;
      _last = e;
      t += dt.clamp(0.0, 0.1).toDouble() * cy.speed;
      if (mounted) setState(() {});
    })..start();
  }

  @override
  void dispose() {
    _tk.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.builder(context, t);
}

double _fr(double x) => x - x.floorToDouble();

// ---------------------------------------------------------------------------
// پس‌زمینه‌ی متحرک
// ---------------------------------------------------------------------------
class CyberBackground extends StatefulWidget {
  final int? style;
  final double dim;
  const CyberBackground({super.key, this.style, this.dim = 0.22});
  @override
  State<CyberBackground> createState() => _CyberBackgroundState();
}

class _CyberBackgroundState extends State<CyberBackground> with SingleTickerProviderStateMixin {
  late final Ticker _tk;
  final ValueNotifier<double> _t = ValueNotifier<double>(0);
  Duration _last = Duration.zero;

  @override
  void initState() {
    super.initState();
    _tk = createTicker((e) {
      final dt = (e - _last).inMicroseconds / 1e6;
      _last = e;
      _t.value += dt.clamp(0.0, 0.1).toDouble() * cy.speed;
    })..start();
  }

  @override
  void dispose() {
    _tk.dispose();
    _t.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => RepaintBoundary(
        child: CustomPaint(
          painter: _CyberPainter(_t, widget.style ?? cy.bgStyle, widget.dim),
          size: Size.infinite,
          isComplex: true,
          willChange: true,
        ),
      );
}

class _CyberPainter extends CustomPainter {
  final ValueNotifier<double> tn;
  final int style;
  final double dim;
  _CyberPainter(this.tn, this.style, this.dim) : super(repaint: tn);

  @override
  bool shouldRepaint(covariant _CyberPainter old) => true;

  @override
  void paint(Canvas canvas, Size s) {
    if (s.isEmpty) return;
    final t = tn.value;
    final rect = Offset.zero & s;
    canvas.drawRect(
      rect,
      Paint()..shader = ui.Gradient.linear(Offset.zero, Offset(0, s.height), const [Color(0xFF04050D), Color(0xFF0B0822), Color(0xFF04050D)], const [0.0, 0.55, 1.0]),
    );
    switch (style) {
      case 0:
        _grid(canvas, s, t);
        break;
      case 1:
        _aurora(canvas, s, t);
        break;
      case 2:
        _rain(canvas, s, t);
        break;
      case 3:
        _hex(canvas, s, t);
        break;
      default:
        break;
    }
    if (cy.shapes) _shapes(canvas, s, t);
    if (cy.particles) _particles(canvas, s, t);
    if (cy.scanlines) _scan(canvas, s, t);
    if (dim > 0) canvas.drawRect(rect, Paint()..color = Color.fromRGBO(0, 0, 0, dim));
  }

  void _grid(Canvas canvas, Size s, double t) {
    final w = s.width, h = s.height;
    final y0 = h * 0.58;
    final cx = w / 2;
    // خورشید
    final sunR = math.min(w, h) * 0.2;
    final sunC = Offset(cx, y0 - sunR * 0.55);
    canvas.drawCircle(
      sunC,
      sunR,
      Paint()..shader = ui.Gradient.linear(Offset(cx, sunC.dy - sunR), Offset(cx, sunC.dy + sunR), [cy.c3.withOpacity(0.55), cy.c2.withOpacity(0.55)]),
    );
    for (var i = 0; i < 6; i++) {
      final yy = sunC.dy + sunR * (0.05 + i * 0.16);
      canvas.drawRect(Rect.fromLTWH(cx - sunR, yy, sunR * 2, 1.5 + i * 1.2), Paint()..color = const Color(0xFF05060F));
    }
    // درخشش افق
    canvas.drawRect(
      Rect.fromLTWH(0, y0 - 40, w, 80),
      Paint()..shader = ui.Gradient.linear(Offset(0, y0 - 40), Offset(0, y0 + 40), [Colors.transparent, cy.c1.withOpacity(0.25 * (0.4 + cy.glow)), Colors.transparent], const [0.0, 0.5, 1.0]),
    );
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..color = cy.c2.withOpacity(0.5);
    // خطوط عمودی با پرسپکتیو
    for (var i = -14; i <= 14; i++) {
      canvas.drawLine(Offset(cx + i * w * 0.035, y0), Offset(cx + i * w * 0.30, h), line);
    }
    // خطوط افقی که به سمت بیننده می‌آیند
    const n = 14;
    for (var k = 0; k < n; k++) {
      final p = ((k + t * 0.45) % n) / n;
      final y = y0 + (h - y0) * math.pow(p, 2.2).toDouble();
      canvas.drawLine(Offset(0, y), Offset(w, y), line..color = cy.c2.withOpacity(0.08 + 0.5 * p));
    }
    canvas.drawLine(Offset(0, y0), Offset(w, y0), Paint()..color = cy.c1.withOpacity(0.9)..strokeWidth = 1.6);
  }

  void _aurora(Canvas canvas, Size s, double t) {
    final cols = [cy.c1, cy.c2, cy.c3];
    for (var k = 0; k < 3; k++) {
      final c = Offset(s.width * (0.5 + 0.38 * math.sin(t * 0.30 + k * 2.1)), s.height * (0.45 + 0.32 * math.cos(t * 0.23 + k * 1.7)));
      final r = math.max(s.width, s.height) * 0.55;
      canvas.drawCircle(c, r, Paint()..shader = ui.Gradient.radial(c, r, [cols[k].withOpacity(0.30 + 0.2 * cy.glow), Colors.transparent]));
    }
  }

  void _rain(Canvas canvas, Size s, double t) {
    final n = (s.width / 22).floor();
    final p = Paint();
    for (var i = 0; i < n; i++) {
      final sp = 0.4 + ((i * 37) % 100) / 100 * 0.9;
      final off = ((i * 53) % 100) / 100;
      final head = ((t * sp * 0.22 + off) % 1.4) - 0.2;
      final y = head * s.height;
      final len = s.height * 0.26;
      final x = i * 22.0 + 9;
      for (var j = 0; j < 8; j++) {
        final yy = y - j * (len / 8);
        if (yy < -10 || yy > s.height) continue;
        final a = (1 - j / 8) * 0.75;
        p.color = (j == 0 ? Colors.white : cy.c1).withOpacity(a);
        canvas.drawRect(Rect.fromLTWH(x, yy, 2.2, 10), p);
      }
    }
  }

  void _hex(Canvas canvas, Size s, double t) {
    const size = 38.0;
    final dx = math.sqrt(3) * size;
    final dy = size * 1.5;
    final c0 = Offset(s.width * (0.5 + 0.4 * math.sin(t * 0.4)), s.height * (0.5 + 0.4 * math.cos(t * 0.33)));
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    var row = 0;
    for (double y = -size; y < s.height + size; y += dy, row++) {
      for (double x = (row.isOdd ? dx / 2 : 0) - dx; x < s.width + dx; x += dx) {
        final d = (Offset(x, y) - c0).distance;
        final a = (0.05 + 0.4 * math.max(0.0, 1 - d / (s.width * 0.65)) + 0.12 * ((math.sin(d * 0.02 - t * 2) + 1) / 2)).clamp(0.0, 0.7).toDouble();
        p.color = (d % 300 < 150 ? cy.c1 : cy.c2).withOpacity(a);
        final path = Path();
        for (var k = 0; k < 6; k++) {
          final ang = math.pi / 6 + k * math.pi / 3;
          final pt = Offset(x + size * math.cos(ang), y + size * math.sin(ang));
          if (k == 0) {
            path.moveTo(pt.dx, pt.dy);
          } else {
            path.lineTo(pt.dx, pt.dy);
          }
        }
        path.close();
        canvas.drawPath(path, p);
      }
    }
  }

  Offset _proj(double x, double y, double z, double ax, double ay, double sz, Offset c) {
    final cx = math.cos(ax), sx = math.sin(ax), cyy = math.cos(ay), sy = math.sin(ay);
    final y1 = y * cx - z * sx;
    final z1 = y * sx + z * cx;
    final x2 = x * cyy + z1 * sy;
    final z2 = -x * sy + z1 * cyy;
    final k = 3.2 / (3.2 - z2);
    return Offset(c.dx + x2 * sz * k, c.dy + y1 * sz * k);
  }

  void _wireCube(Canvas canvas, Offset c, double sz, double ax, double ay, Paint p) {
    final v = <Offset>[];
    for (var i = 0; i < 8; i++) {
      v.add(_proj((i & 1) == 0 ? -1 : 1, (i & 2) == 0 ? -1 : 1, (i & 4) == 0 ? -1 : 1, ax, ay, sz, c));
    }
    const e = [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]];
    for (final a in e) {
      canvas.drawLine(v[a[0]], v[a[1]], p);
    }
  }

  void _poly(Canvas canvas, Offset c, double r, int sides, double rot, Paint p) {
    final path = Path();
    for (var k = 0; k < sides; k++) {
      final a = rot + k * 2 * math.pi / sides;
      final pt = Offset(c.dx + r * math.cos(a), c.dy + r * math.sin(a));
      if (k == 0) {
        path.moveTo(pt.dx, pt.dy);
      } else {
        path.lineTo(pt.dx, pt.dy);
      }
    }
    path.close();
    canvas.drawPath(path, p);
  }

  void _shapes(Canvas canvas, Size s, double t) {
    final cols = [cy.c1, cy.c2, cy.c3];
    for (var k = 0; k < 8; k++) {
      final z = 0.3 + _fr(k * 0.53 + 0.17) * 0.9;
      final bx = _fr(k * 0.37 + 0.11);
      final by = _fr(k * 0.61 + 0.23);
      final x = s.width * bx + math.sin(t * 0.2 * z + k) * 34 * z;
      final y = (by * s.height - t * 10 * z) % (s.height + 120) - 60;
      final sz = 18 + 40 * z;
      final rot = t * (0.2 + 0.3 * z) * (k.isEven ? 1 : -1);
      final col = cols[k % 3];
      final c = Offset(x, y);
      final alpha = 0.25 + 0.45 * z;
      final core = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1 + 1.1 * z
        ..color = col.withOpacity(alpha);
      final glowP = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..color = col.withOpacity(0.22 * cy.glow)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 2 + 4 * z);
      void draw(Paint p) {
        switch (k % 6) {
          case 0:
          case 3:
            _wireCube(canvas, c, sz * 0.5, rot * 1.3, rot, p);
            break;
          case 1:
            _poly(canvas, c, sz * 0.7, 3, rot, p);
            break;
          case 2:
            _poly(canvas, c, sz * 0.7, 6, rot, p);
            break;
          case 4:
            canvas.drawOval(Rect.fromCenter(center: c, width: sz * 1.4, height: sz * 1.4 * (0.25 + 0.75 * math.cos(rot).abs())), p);
            break;
          default:
            _poly(canvas, c, sz * 0.6, 4, rot + math.pi / 4, p);
        }
      }

      if (cy.glow > 0.05) draw(glowP);
      draw(core);
    }
  }

  void _particles(Canvas canvas, Size s, double t) {
    final cols = [cy.c1, cy.c2, cy.c3, Colors.white];
    final p = Paint();
    for (var k = 0; k < 46; k++) {
      final z = 0.2 + _fr(k * 0.4142) * 0.8;
      final px = _fr(k * 0.6180339 + 0.1);
      final py = _fr(k * 0.7548776 + 0.3);
      final x = (px * s.width + math.sin(t * 0.4 * z + k) * 18 * z + t * 3 * z) % s.width;
      final y = ((py * s.height - t * (8 + 22 * z)) % s.height + s.height) % s.height;
      final tw = 0.5 + 0.5 * math.sin(t * 2 + k);
      final col = cols[k % 4];
      if (z > 0.7) {
        p.color = col.withOpacity(0.10 * tw);
        canvas.drawCircle(Offset(x, y), 6 * z, p);
      }
      p.color = col.withOpacity((0.25 + 0.6 * tw * z).clamp(0.0, 1.0).toDouble());
      canvas.drawCircle(Offset(x, y), 0.6 + 1.8 * z, p);
    }
  }

  void _scan(Canvas canvas, Size s, double t) {
    final y = (t * 60) % (s.height + 200) - 100;
    canvas.drawRect(
      Rect.fromLTWH(0, y, s.width, 90),
      Paint()..shader = ui.Gradient.linear(Offset(0, y), Offset(0, y + 90), [Colors.transparent, cy.c1.withOpacity(0.07), Colors.transparent], const [0.0, 0.5, 1.0]),
    );
  }
}

// پس‌زمینه‌ی سراسری برنامه
class CyberStage extends StatelessWidget {
  final Widget child;
  const CyberStage({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    if (!cy.enabled) return child;
    return Stack(fit: StackFit.expand, children: [const Positioned.fill(child: CyberBackground()), child]);
  }
}

// ---------------------------------------------------------------------------
// تونل خطای دید (حلقه‌های شش‌ضلعی در حال زوم بی‌پایان، با چرخش مخالف)
// ---------------------------------------------------------------------------
class _TunnelPainter extends CustomPainter {
  final double t;
  _TunnelPainter(this.t);
  @override
  bool shouldRepaint(covariant _TunnelPainter old) => old.t != t;

  @override
  void paint(Canvas canvas, Size s) {
    final c = s.center(Offset.zero);
    final maxR = math.min(s.width, s.height) * 0.62;
    const n = 14;
    for (var i = 0; i < n; i++) {
      final f = ((i + t * 0.6) % n) / n;
      final r = math.pow(f, 2.2).toDouble() * maxR;
      if (r < 2) continue;
      final rot = t * 0.25 + i * 0.12 + f * 1.2;
      final col = i.isEven ? cy.c1 : cy.c2;
      final a = math.sin(f * math.pi).clamp(0.0, 1.0).toDouble();
      final path = Path();
      for (var k = 0; k < 6; k++) {
        final ang = rot + k * math.pi / 3;
        final pt = Offset(c.dx + r * math.cos(ang), c.dy + r * math.sin(ang));
        if (k == 0) {
          path.moveTo(pt.dx, pt.dy);
        } else {
          path.lineTo(pt.dx, pt.dy);
        }
      }
      path.close();
      if (i.isEven) canvas.drawPath(path, Paint()..color = col.withOpacity(0.05 * a));
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.8 + 3 * f
          ..color = col.withOpacity(0.75 * a),
      );
    }
    // پره‌هایی که خلاف جهت می‌چرخند
    final sp = Paint()
      ..strokeWidth = 1
      ..color = cy.c3.withOpacity(0.35);
    for (var k = 0; k < 12; k++) {
      final ang = -t * 0.35 + k * math.pi / 6;
      canvas.drawLine(Offset(c.dx + maxR * 0.08 * math.cos(ang), c.dy + maxR * 0.08 * math.sin(ang)), Offset(c.dx + maxR * math.cos(ang), c.dy + maxR * math.sin(ang)), sp);
    }
  }
}

class _CubePainter extends CustomPainter {
  final double t;
  _CubePainter(this.t);
  @override
  bool shouldRepaint(covariant _CubePainter old) => old.t != t;

  Offset _p(double x, double y, double z, double ax, double ay, double sz, Offset c) {
    final y1 = y * math.cos(ax) - z * math.sin(ax);
    final z1 = y * math.sin(ax) + z * math.cos(ax);
    final x2 = x * math.cos(ay) + z1 * math.sin(ay);
    final z2 = -x * math.sin(ay) + z1 * math.cos(ay);
    final k = 3.4 / (3.4 - z2);
    return Offset(c.dx + x2 * sz * k, c.dy + y1 * sz * k);
  }

  @override
  void paint(Canvas canvas, Size s) {
    final c = s.center(Offset.zero);
    final sz = s.width * 0.34;
    void cube(double scale, double ax, double ay, Color col, double sw) {
      final v = <Offset>[];
      for (var i = 0; i < 8; i++) {
        v.add(_p((i & 1) == 0 ? -1 : 1, (i & 2) == 0 ? -1 : 1, (i & 4) == 0 ? -1 : 1, ax, ay, sz * scale, c));
      }
      const e = [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7], [0, 4], [1, 5], [2, 6], [3, 7]];
      final glowP = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = sw + 4
        ..color = col.withOpacity(0.25 * cy.glow)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
      final core = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = sw
        ..color = col.withOpacity(0.9);
      for (final a in e) {
        canvas.drawLine(v[a[0]], v[a[1]], glowP);
        canvas.drawLine(v[a[0]], v[a[1]], core);
      }
    }

    cube(1.0, t * 0.7, t * 0.9, cy.c1, 1.4);
    cube(0.62, -t * 0.9, t * 0.6 + 1, cy.c2, 1.2);
  }
}

class _FlashPainter extends CustomPainter {
  final double v;
  _FlashPainter(this.v);
  @override
  bool shouldRepaint(covariant _FlashPainter old) => old.v != v;
  @override
  void paint(Canvas canvas, Size s) {
    final y = s.height * v;
    canvas.drawRect(Rect.fromLTWH(0, math.max(0, y - 120), s.width, 120), Paint()..shader = ui.Gradient.linear(Offset(0, y - 120), Offset(0, y), [Colors.transparent, cy.c1.withOpacity(0.22 * (1 - v))]));
    canvas.drawRect(Rect.fromLTWH(0, y - 1, s.width, 2), Paint()..color = cy.c1.withOpacity(0.9 * (1 - v)));
  }
}

Widget _logoImage(double size) => ClipRRect(borderRadius: BorderRadius.circular(size * 0.27), child: Image.asset('assets/icon.png', width: size, height: size, fit: BoxFit.cover));

Widget cyberLogo3D(double t, {double size = 84}) {
  final ang = math.sin(t * 0.8) * 0.55;
  final tilt = math.sin(t * 0.5) * 0.18;
  Matrix4 mat(double z) => Matrix4.identity()
    ..setEntry(3, 2, 0.0014)
    ..rotateX(tilt)
    ..rotateY(ang)
    ..multiply(Matrix4.translationValues(0, 0, z));
  final layers = <Widget>[];
  for (var i = 7; i >= 1; i--) {
    layers.add(Transform(
      alignment: Alignment.center,
      transform: mat(-i * 3.0),
      child: ColorFiltered(
        colorFilter: ColorFilter.mode(Color.lerp(cy.c1, cy.c2, i / 7)!.withOpacity((0.75 - i * 0.07).clamp(0.1, 0.8).toDouble()), BlendMode.srcATop),
        child: _logoImage(size),
      ),
    ));
  }
  layers.add(Transform(alignment: Alignment.center, transform: mat(0), child: _logoImage(size)));
  return Container(
    width: size,
    height: size,
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(size * 0.27), boxShadow: [BoxShadow(color: cy.c1.withOpacity(0.25 + 0.4 * cy.glow), blurRadius: 30 + 30 * cy.glow, spreadRadius: 1)]),
    child: Stack(alignment: Alignment.center, clipBehavior: Clip.none, children: layers),
  );
}

Widget glitchText(String s, double t, {double size = 40}) {
  final burst = (t % 3.2) < 0.2;
  final dx = burst ? math.sin(t * 90) * 5 : 0.8;
  TextStyle st(Color c, {List<Shadow>? sh}) => TextStyle(fontSize: size, fontWeight: FontWeight.w900, letterSpacing: 6, color: c, shadows: sh);
  return Stack(alignment: Alignment.center, children: [
    Transform.translate(offset: Offset(-dx - 1, burst ? 2 : 0), child: Text(s, style: st(cy.c2.withOpacity(0.85)))),
    Transform.translate(offset: Offset(dx + 1, burst ? -2 : 0), child: Text(s, style: st(cy.c1.withOpacity(0.85)))),
    Text(s, style: st(Colors.white, sh: [Shadow(color: cy.c1.withOpacity(0.9 * cy.glow), blurRadius: 18)])),
  ]);
}

// لوگوی سه‌بعدی صفحه‌ی ورود: تونل خطای دید + مکعب سیمی + آیکن لایه‌لایه
class CyberLogoBlock extends StatelessWidget {
  final bool signup;
  const CyberLogoBlock({super.key, required this.signup});
  @override
  Widget build(BuildContext context) => CyberTicker(
        builder: (c, t) => Column(children: [
          SizedBox(
            height: 250,
            width: 280,
            child: Stack(alignment: Alignment.center, clipBehavior: Clip.none, children: [
              if (cy.tunnel) Positioned.fill(child: CustomPaint(painter: _TunnelPainter(t))),
              SizedBox(width: 170, height: 170, child: CustomPaint(painter: _CubePainter(t))),
              cyberLogo3D(t, size: 84),
            ]),
          ),
          glitchText('TIA', t),
          const SizedBox(height: 6),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: Text(signup ? trn('یک حساب بساز و وارد شبکه شو') : trn('پیام‌رسان و شبکه‌ی اجتماعی تو'), key: ValueKey(signup), style: TextStyle(color: cy.c1.withOpacity(0.9), fontSize: 14, letterSpacing: 0.4)),
          ),
        ]),
      );
}

// ---------------------------------------------------------------------------
// جلوه‌ی ورود به صفحه‌ی چت
// ---------------------------------------------------------------------------
class CyberEntry extends StatefulWidget {
  final Widget child;
  const CyberEntry({super.key, required this.child});
  @override
  State<CyberEntry> createState() => _CyberEntryState();
}

class _CyberEntryState extends State<CyberEntry> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..forward();
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!cy.enabled || cy.entry == 3) return widget.child;
    return AnimatedBuilder(
      animation: c,
      child: widget.child,
      builder: (ctx, ch) {
        final raw = c.value;
        final v = Curves.easeOutCubic.transform(raw);
        var dx = 0.0, dy = 0.0, sc = 1.0;
        if (cy.entry == 0) {
          dx = (1 - raw) * math.sin(raw * 70) * 9;
          sc = 1.12 - 0.12 * v;
        } else if (cy.entry == 1) {
          dy = (1 - v) * 80;
        }
        return Stack(fit: StackFit.expand, children: [
          Opacity(
            opacity: v.clamp(0.0, 1.0).toDouble(),
            child: Transform(
              alignment: Alignment.center,
              transform: Matrix4.translationValues(dx, dy, 0)..multiply(Matrix4.diagonal3Values(sc, sc, 1)),
              child: ch,
            ),
          ),
          if (cy.entry == 0 && raw < 1) IgnorePointer(child: CustomPaint(painter: _FlashPainter(raw))),
        ]);
      },
    );
  }
}

// ---------------------------------------------------------------------------
// استودیوی سایبر: شخصی‌سازی کامل + پروفایل‌های ظاهری
// ---------------------------------------------------------------------------
class CyberStudioPage extends StatelessWidget {
  const CyberStudioPage({super.key});

  Widget head(String t) => Padding(padding: const EdgeInsets.only(top: 22, bottom: 10), child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: cText)));

  Widget swatches(int current, void Function(int) pick) => Wrap(spacing: 10, runSpacing: 10, children: [
        for (final v in neonPalette)
          GestureDetector(
            onTap: () => pick(v),
            child: Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: Color(v),
                shape: BoxShape.circle,
                border: Border.all(color: current == v ? Colors.white : Colors.white24, width: current == v ? 3 : 1),
                boxShadow: [BoxShadow(color: Color(v).withOpacity(0.5), blurRadius: 10)],
              ),
            ),
          ),
      ]);

  Widget chips(List<String> names, int sel, void Function(int) pick) => Wrap(spacing: 8, runSpacing: 8, children: [
        for (var i = 0; i < names.length; i++) ChoiceChip(label: Text(trn(names[i])), selected: sel == i, onSelected: (_) => pick(i)),
      ]);

  Widget slider(String label, double v, double min, double max, void Function(double) f) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.only(top: 6), child: Text(label, style: TextStyle(color: cTextDim))),
        Slider(value: v.clamp(min, max).toDouble(), min: min, max: max, onChanged: (x) {
          f(x);
          cy.save();
        }),
      ]);

  Widget bubblePreview(bool mine, String text) => Align(
        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: bubbleDeco(mine),
          child: Text(text, style: TextStyle(color: bubbleFg(mine), fontSize: 15)),
        ),
      );

  Future<void> saveDialog(BuildContext c) async {
    final ctrl = TextEditingController();
    final name = await showDialog<String>(
      context: c,
      builder: (d) => AlertDialog(
        title: Text(trn('ذخیره‌ی پروفایل ظاهری')),
        content: TextField(controller: ctrl, autofocus: true, decoration: InputDecoration(hintText: trn('نام تم، مثلاً «شب توکیو»'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: Text(trn('انصراف'))),
          FilledButton(onPressed: () => Navigator.pop(d, ctrl.text), child: Text(trn('ذخیره'))),
        ],
      ),
    );
    if (name != null && name.trim().isNotEmpty) cy.saveProfile(name);
  }

  Future<void> importDialog(BuildContext c) async {
    final data = await Clipboard.getData('text/plain');
    try {
      final m = jsonDecode(data?.text ?? '') as Map<String, dynamic>;
      final name = (m['name'] as String?) ?? trn('تم واردشده');
      cy.applyMap(name, m);
      cy.saveProfile(name);
      if (c.mounted) snack(c, trn('تم وارد شد'));
    } catch (_) {
      if (c.mounted) snack(c, trn('کدی از تم در کلیپ‌بورد پیدا نشد'));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('استودیوی سایبر'))),
        body: ListenableBuilder(
          listenable: cy,
          builder: (c, _) => ListView(padding: const EdgeInsets.all(16), children: [
            Container(
              height: 190,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(settings.cardRadius), border: Border.all(color: cLine)),
              child: Stack(children: [
                const Positioned.fill(child: CyberBackground(dim: 0.1)),
                Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    bubblePreview(false, trn('سلام! به شبکه خوش اومدی ⚡')),
                    bubblePreview(true, trn('اتصال برقرار شد، آماده‌ام 🌐')),
                  ]),
                ),
              ]),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('تم سایبربانکی')),
              subtitle: Text(trn('خاموش = ظاهر قبلی تیا (رنگ‌ها از «ظاهر برنامه»)')),
              value: cy.enabled,
              onChanged: (v) {
                cy.enabled = v;
                cy.save();
              },
            ),
            head(trn('رنگ نئون اصلی (حباب من، دکمه‌ها)')),
            swatches(cy.neon1, (v) {
              cy.neon1 = v;
              cy.activeProfile = 'سفارشی';
              cy.save();
            }),
            head(trn('رنگ نئون دوم (حباب طرف مقابل، جلوه‌ها)')),
            swatches(cy.neon2, (v) {
              cy.neon2 = v;
              cy.activeProfile = 'سفارشی';
              cy.save();
            }),
            head(trn('رنگ نئون سوم (ذرات و خورشید)')),
            swatches(cy.neon3, (v) {
              cy.neon3 = v;
              cy.activeProfile = 'سفارشی';
              cy.save();
            }),
            head(trn('شدت و سرعت')),
            slider(trn('شدت درخشش'), cy.glow, 0, 1, (x) => cy.glow = x),
            slider(trn('سرعت انیمیشن'), cy.speed, 0.2, 2.5, (x) => cy.speed = x),
            head(trn('شکل حباب پیام')),
            chips(bubbleShapeNames, cy.bubble, (i) {
              cy.bubble = i;
              cy.save();
            }),
            head(trn('پس‌زمینه')),
            chips(bgStyleNames, cy.bgStyle, (i) {
              cy.bgStyle = i;
              cy.save();
            }),
            head(trn('جلوه‌ی ورود به چت')),
            chips(entryNames, cy.entry, (i) {
              cy.entry = i;
              cy.save();
            }),
            head(trn('افکت‌ها')),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(trn('ذرات شناور')), value: cy.particles, onChanged: (v) {
              cy.particles = v;
              cy.save();
            }),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(trn('اشکال هندسی متحرک (عمق مصنوعی)')), value: cy.shapes, onChanged: (v) {
              cy.shapes = v;
              cy.save();
            }),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(trn('خط اسکن نئونی')), value: cy.scanlines, onChanged: (v) {
              cy.scanlines = v;
              cy.save();
            }),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(trn('تونل خطای دید در صفحه‌ی ورود')), value: cy.tunnel, onChanged: (v) {
              cy.tunnel = v;
              cy.save();
            }),
            head(trn('تم‌ها و پروفایل‌های ظاهری')),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final e in cyberPresets.entries)
                ActionChip(
                  avatar: Icon(Icons.bolt, size: 16, color: Color(e.value['n1'] as int)),
                  label: Text(trn(e.key)),
                  backgroundColor: cy.activeProfile == e.key ? primary.withOpacity(0.3) : null,
                  onPressed: () => cy.applyMap(e.key, e.value),
                ),
            ]),
            if (cy.profiles.isNotEmpty) ...[
              const SizedBox(height: 14),
              Text(trn('پروفایل‌های من'), style: TextStyle(color: cTextDim)),
              for (final p in cy.profiles)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.palette_outlined, color: Color((p['n1'] as num).toInt())),
                  title: Text('${p['name']}'),
                  selected: cy.activeProfile == p['name'],
                  onTap: () => cy.applyMap('${p['name']}', p),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(
                      icon: const Icon(Icons.copy),
                      tooltip: trn('کپی کد تم برای اشتراک'),
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: jsonEncode(p)));
                        snack(c, trn('کد تم کپی شد'));
                      },
                    ),
                    IconButton(icon: const Icon(Icons.delete_outline, color: Colors.redAccent), onPressed: () => cy.deleteProfile('${p['name']}')),
                  ]),
                ),
            ],
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: () => saveDialog(c), icon: const Icon(Icons.save_outlined), label: Text(trn('ذخیره‌ی تنظیمات فعلی')))),
              const SizedBox(width: 8),
              OutlinedButton.icon(onPressed: () => importDialog(c), icon: const Icon(Icons.download_outlined), label: Text(trn('واردکردن'))),
            ]),
          ]),
        ),
      );
}
