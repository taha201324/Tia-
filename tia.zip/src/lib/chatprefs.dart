import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'l10n.dart';
import 'main.dart';
import 'ui_kit.dart';

/// تنظیمات مخصوص هر گفتگو: پس‌زمینه و ترجمه‌ی خودکار
class ChatPrefs {
  static Future<Map<String, dynamic>> load(String key) async {
    try {
      final raw = (await SharedPreferences.getInstance()).getString('cp_$key');
      if (raw != null) return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {}
    return {};
  }

  static Future<void> save(String key, Map<String, dynamic> v) async {
    try {
      final p = await SharedPreferences.getInstance();
      if (v.isEmpty) {
        await p.remove('cp_$key');
      } else {
        await p.setString('cp_$key', jsonEncode(v));
      }
    } catch (_) {}
  }

  static const List<List<int>> walls = [
    [0xFF0F2027, 0xFF2C5364],
    [0xFF1A1A2E, 0xFF16213E],
    [0xFF2B1055, 0xFF7597DE],
    [0xFF134E5E, 0xFF71B280],
    [0xFF42275A, 0xFF734B6D],
    [0xFF000000, 0xFF434343],
    [0xFFFDC830, 0xFFF37335],
    [0xFFFF9A9E, 0xFFFAD0C4],
    [0xFFA8EDEA, 0xFFFED6E3],
    [0xFFE0EAFC, 0xFFCFDEF3],
  ];

  static BoxDecoration? wallOf(Map<String, dynamic> p) {
    final w = p['wall'];
    if (w is int && w >= 0 && w < walls.length) {
      return BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(walls[w][0]), Color(walls[w][1])]));
    }
    final f = p['wallFile'];
    if (f is String && File(f).existsSync()) {
      return BoxDecoration(image: DecorationImage(image: FileImage(File(f)), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.25), BlendMode.darken)));
    }
    return null;
  }

  /// انتخاب پس‌زمینه برای یک گفتگو؛ برمی‌گرداند true اگر چیزی عوض شد
  static Future<void> pickWall(BuildContext context, Map<String, dynamic> prefs, Future<void> Function() changed) {
    return showTiaSheet<void>(context, (c) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(trn('پس‌زمینه‌ی این گفتگو'), style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: cText)),
          const SizedBox(height: 14),
          Wrap(spacing: 10, runSpacing: 10, children: [
            for (var i = 0; i < walls.length; i++)
              InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () async {
                  prefs.remove('wallFile');
                  prefs['wall'] = i;
                  Navigator.pop(c);
                  await changed();
                },
                child: Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(walls[i][0]), Color(walls[i][1])]),
                    border: Border.all(color: prefs['wall'] == i ? accent : cLine, width: prefs['wall'] == i ? 3 : 1),
                  ),
                ),
              ),
          ]),
          const SizedBox(height: 14),
          Row(children: [
            OutlinedButton.icon(
              icon: const Icon(Icons.image_outlined, size: 18),
              label: Text(trn('عکس از گوشی')),
              onPressed: () async {
                final r = await FilePicker.platform.pickFiles(type: FileType.image);
                final src = r?.files.single.path;
                if (src == null) return;
                final dir = await getApplicationSupportDirectory();
                final dst = '${dir.path}/wall_${DateTime.now().millisecondsSinceEpoch}.jpg';
                await File(src).copy(dst);
                prefs.remove('wall');
                prefs['wallFile'] = dst;
                if (c.mounted) Navigator.pop(c);
                await changed();
              },
            ),
            const SizedBox(width: 8),
            TextButton(
              onPressed: () async {
                prefs.remove('wall');
                prefs.remove('wallFile');
                Navigator.pop(c);
                await changed();
              },
              child: Text(trn('پیش‌فرض')),
            ),
          ]),
        ]));
  }
}
