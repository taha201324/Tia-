import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'main.dart';
import 'push.dart';
import 'l10n.dart';

/// چند حسابی: نشست (refresh token) هر حساب روی همین گوشی نگه داشته می‌شود تا بدون ورود دوباره بشود بین حساب‌ها جابه‌جا شد.
class SavedAccount {
  final String id, label, refresh;
  const SavedAccount(this.id, this.label, this.refresh);
  Map<String, dynamic> toJson() => {'id': id, 'label': label, 'refresh': refresh};
  static SavedAccount fromJson(Map<String, dynamic> j) => SavedAccount(j['id'] as String, (j['label'] as String?) ?? '', j['refresh'] as String);
}

class Accounts {
  static const _k = 'accounts_v1';
  /// وقتی true است، صفحه‌ی اصلی موقتاً با یک لودینگ جایگزین می‌شود تا سرویس‌های حساب قبلی کامل بسته شوند.
  static final ValueNotifier<bool> switching = ValueNotifier(false);
  static final ValueNotifier<int> changes = ValueNotifier(0);
  static bool _inited = false;

  static Future<List<SavedAccount>> list() async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString(_k);
      if (raw == null) return [];
      return [for (final e in jsonDecode(raw) as List) SavedAccount.fromJson(Map<String, dynamic>.from(e as Map))];
    } catch (_) {
      return [];
    }
  }

  static Future<void> _persist(List<SavedAccount> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_k, jsonEncode([for (final a in l) a.toJson()]));
    changes.value++;
  }

  static String labelOf(User u) => (u.email ?? u.phone ?? u.id).replaceAll('@tia.chat', '');

  static Future<void> _save(Session s) async {
    final rt = s.refreshToken;
    if (rt == null || rt.isEmpty) return;
    final l = await list();
    final a = SavedAccount(s.user.id, labelOf(s.user), rt);
    final i = l.indexWhere((e) => e.id == a.id);
    if (i >= 0) {
      l[i] = a;
    } else {
      l.add(a);
    }
    await _persist(l);
  }

  /// از Home.initState صدا زده می‌شود (چندبار صدا زدن بی‌خطر است).
  static Future<void> init() async {
    if (_inited) return;
    _inited = true;
    final s = sb.auth.currentSession;
    if (s != null) await _save(s);
    sb.auth.onAuthStateChange.listen((st) {
      final s = st.session;
      if (s == null) return;
      if (st.event == AuthChangeEvent.signedIn || st.event == AuthChangeEvent.tokenRefreshed || st.event == AuthChangeEvent.userUpdated || st.event == AuthChangeEvent.initialSession) {
        _save(s);
      }
    });
  }

  static void _msg(String t) => messengerKey.currentState?.showSnackBar(SnackBar(content: Text(t)));

  /// جابه‌جایی به حساب دیگر
  static Future<bool> switchTo(String id) async {
    if (switching.value || id == me) return id == me;
    final l = await list();
    final i = l.indexWhere((e) => e.id == id);
    if (i < 0) return false;
    switching.value = true;
    try {
      await Future.delayed(const Duration(milliseconds: 400)); // صفحه‌ی حساب قبلی بسته و سرویس‌هایش متوقف شود
      final r = await sb.auth.setSession(l[i].refresh);
      final s = r.session;
      if (s == null) throw AuthException('no session');
      await _save(s);
      return true;
    } on AuthException {
      // نشست این حساب منقضی شده (مثلاً از جای دیگر خارج شده)
      final l2 = await list();
      l2.removeWhere((e) => e.id == id);
      await _persist(l2);
      _msg(trn('نشست این حساب منقضی شده؛ دوباره وارد شوید.'));
      return false;
    } catch (_) {
      _msg(trn('جابه‌جایی انجام نشد. اینترنت را بررسی کنید.'));
      return false;
    } finally {
      await Future.delayed(const Duration(milliseconds: 120));
      switching.value = false;
    }
  }

  /// افزودن حساب: فقط روی همین گوشی از حساب فعلی خارج می‌شویم (سرور نشست را نمی‌بندد) تا صفحه‌ی ورود باز شود.
  static Future<void> beginAdd() async {
    final s = sb.auth.currentSession;
    if (s != null) await _save(s);
    await TiaPush.instance.releaseLocal();
    switching.value = true;
    try {
      await Future.delayed(const Duration(milliseconds: 400));
      await sb.auth.signOut(scope: SignOutScope.local);
    } finally {
      switching.value = false;
    }
  }

  /// خروج کامل از حساب فعلی؛ اگر حساب دیگری ذخیره باشد به آن می‌رویم.
  static Future<void> logoutCurrent() async {
    final id = me;
    final l = await list();
    l.removeWhere((e) => e.id == id);
    await _persist(l);
    switching.value = true;
    try {
      await Future.delayed(const Duration(milliseconds: 400));
      await sb.auth.signOut();
    } finally {
      switching.value = false;
    }
    if (l.isNotEmpty) await switchTo(l.first.id);
  }
}

class AccountsPage extends StatelessWidget {
  const AccountsPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('حساب‌ها'))),
        body: ValueListenableBuilder<int>(
          valueListenable: Accounts.changes,
          builder: (c, _, __) => FutureBuilder<List<SavedAccount>>(
            future: Accounts.list(),
            builder: (c, snap) {
              final l = snap.data ?? const <SavedAccount>[];
              return ListView(children: [
                for (final a in l)
                  ListTile(
                    leading: Icon(a.id == me ? Icons.radio_button_checked : Icons.radio_button_off, color: a.id == me ? Theme.of(c).colorScheme.primary : null),
                    title: Text(a.id == me ? ((store.people[a.id]?['name'] as String?) ?? a.label) : a.label),
                    subtitle: Text(a.id == me ? trn('حساب فعال') : trn('برای جابه‌جایی لمس کنید')),
                    onTap: a.id == me
                        ? null
                        : () {
                            Navigator.of(c).popUntil((r) => r.isFirst);
                            Accounts.switchTo(a.id);
                          },
                  ),
                ListTile(
                  leading: const Icon(Icons.person_add_alt_1),
                  title: Text(trn('افزودن حساب')),
                  subtitle: Text(trn('حساب فعلی ذخیره می‌ماند و وارد حساب دیگری می‌شوید')),
                  onTap: () {
                    Navigator.of(c).popUntil((r) => r.isFirst);
                    Accounts.beginAdd();
                  },
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(16, 12, 16, 24),
                  child: Text(trn('اعلان آنی فقط برای حساب فعال می‌آید. «خروج از حساب» نشست همان حساب را کامل می‌بندد.'), style: TextStyle(fontSize: 12, height: 1.6)),
                ),
              ]);
            },
          ),
        ),
      );
}

/// تغییر زبان برنامه (فارسی ⇄ English)
Future<void> toggleAppLang() async {
  await saveAppLang(appLang == 'en' ? 'fa' : 'en');
  settings.refresh();
}

Future<void> showLanguageDialog(BuildContext c) => showDialog<void>(
      context: c,
      builder: (d) => AlertDialog(
        title: Text(trn('زبان برنامه')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final l in [['fa', trn('فارسی')], ['en', 'English']])
            ListTile(
              title: Text(l[1]),
              trailing: appLang == l[0] ? const Icon(Icons.check) : null,
              onTap: () async {
                Navigator.pop(d);
                if (appLang != l[0]) await toggleAppLang();
              },
            ),
        ]),
      ),
    );

/// صفحه‌ی ورود + دکمه‌ی زبان + میان‌بر حساب‌های ذخیره‌شده (وقتی از «افزودن حساب» آمده‌ایم و می‌خواهیم برگردیم)
class LoginWithSaved extends StatelessWidget {
  final Widget login;
  const LoginWithSaved({super.key, required this.login});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: Accounts.changes,
        builder: (c, _, __) => FutureBuilder<List<SavedAccount>>(
          future: Accounts.list(),
          builder: (c, snap) {
            final l = snap.data ?? const <SavedAccount>[];
            return Stack(children: [
              login,
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: SafeArea(
                  child: Material(
                    color: Colors.transparent,
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Row(children: [
                        TextButton.icon(
                          onPressed: toggleAppLang,
                          icon: const Icon(Icons.language, color: Colors.white, size: 18),
                          label: Text(appLang == 'en' ? trn('فارسی') : 'English', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                        ),
                        const Spacer(),
                        if (l.isNotEmpty)
                          Flexible(
                            child: Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
                              Text(trn('بازگشت به:'), style: const TextStyle(fontSize: 12, color: Colors.white)),
                              for (final a in l) ActionChip(label: Text(a.label), onPressed: () => Accounts.switchTo(a.id)),
                            ]),
                          ),
                      ]),
                    ),
                  ),
                ),
              ),
            ]);
          },
        ),
      );
}
