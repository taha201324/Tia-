import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';

class AccountStore extends ChangeNotifier {
  List<Map<String, dynamic>> list = [];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('accounts');
    if (raw == null) return;
    try {
      list = (jsonDecode(raw) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {}
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('accounts', jsonEncode(list));
    notifyListeners();
  }

  String? _old(String id, String key) {
    for (final a in list) {
      if (a['id'] == id) return a[key] as String?;
    }
    return null;
  }

  // نشست فعلی (و آخرین توکن آن) را در لیست حساب‌های ذخیره‌شده نگه می‌دارد
  Future<void> saveCurrent() async {
    final s = sb.auth.currentSession;
    final u = sb.auth.currentUser;
    if (s == null || u == null || s.refreshToken == null) return;
    final prof = store.people[u.id];
    final rec = <String, dynamic>{
      'id': u.id,
      'name': (prof?['name'] as String?) ?? _old(u.id, 'name') ?? 'حساب',
      'username': (prof?['username'] as String?) ?? _old(u.id, 'username') ?? '',
      'avatar': (prof?['avatar_path'] as String?) ?? _old(u.id, 'avatar') ?? '',
      'refresh': s.refreshToken,
    };
    final i = list.indexWhere((a) => a['id'] == u.id);
    if (i >= 0) {
      list[i] = rec;
    } else {
      list.add(rec);
    }
    await _save();
  }

  Future<void> remove(String id) async {
    list.removeWhere((a) => a['id'] == id);
    await _save();
  }

  Future<bool> switchTo(String id) async {
    final t = list.where((a) => a['id'] == id).toList();
    if (t.isEmpty) return false;
    await saveCurrent();
    navKey.currentState?.popUntil((r) => r.isFirst);
    try {
      await sb.auth.setSession(t.first['refresh'] as String);
      await saveCurrent();
      return true;
    } catch (_) {
      await remove(id);
      return false;
    }
  }

  // بدون خروج از حساب فعلی: فقط صفحه‌ی ورود حساب دوم باز می‌شود
  Future<void> addAccount() async {
    await saveCurrent();
    navKey.currentState?.push(MaterialPageRoute(builder: (_) => const LoginPage(addMode: true)));
  }

  Future<void> logoutCurrent() async {
    final id = me;
    try {
      await sb.auth.signOut();
    } catch (_) {}
    if (id != null) await remove(id);
    for (final a in List.of(list)) {
      if (await switchTo(a['id'] as String)) break;
    }
  }
}

final accounts = AccountStore();

Widget accountAvatar(Map<String, dynamic> a, {double r = 20}) {
  final ap = a['avatar'] as String?;
  final nm = (a['name'] as String?) ?? '';
  if (ap != null && ap.isNotEmpty) {
    return CircleAvatar(radius: r, backgroundImage: NetworkImage(sb.storage.from('avatars').getPublicUrl(ap)));
  }
  return CircleAvatar(radius: r, backgroundColor: primary, foregroundColor: cOnPrimary, child: Text(nm.isEmpty ? '?' : nm[0]));
}

Future<void> showAccountSheet(BuildContext c) => showModalBottomSheet(
      context: c,
      builder: (sc) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: ListenableBuilder(
            listenable: accounts,
            builder: (_, __) => SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const ListTile(title: Text('حساب‌ها', style: TextStyle(fontWeight: FontWeight.bold))),
                for (final a in accounts.list)
                  ListTile(
                    leading: accountAvatar(a),
                    title: Text('${a['name']}'),
                    subtitle: Text(((a['username'] as String?) ?? '').isEmpty ? '' : '@${a['username']}'),
                    trailing: a['id'] == me ? Icon(Icons.check_circle, color: primary) : null,
                    onTap: () async {
                      Navigator.pop(sc);
                      if (a['id'] != me) {
                        final ok = await accounts.switchTo(a['id'] as String);
                        if (!ok && c.mounted) snack(c, 'نشست این حساب منقضی شده است. دوباره وارد شوید.');
                      }
                    },
                  ),
                ListTile(
                  leading: const Icon(Icons.person_add_alt_1),
                  title: const Text('افزودن حساب'),
                  onTap: () {
                    Navigator.pop(sc);
                    accounts.addAccount();
                  },
                ),
              ]),
            ),
          ),
        ),
      ),
    );
