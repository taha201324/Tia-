import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'applock.dart';
import 'chat.dart';
import 'extras.dart';
import 'groups.dart';
import 'safety.dart';
import 'social.dart';

Color primary = const Color(0xFF7B5CFF);
Color accent = const Color(0xFFC8B4FF);
Color bg = const Color(0xFF0B0B14);
Color card = const Color(0xFF1C1C2E);
Color cText = const Color(0xFFF2F2F7);
Color cTextDim = const Color(0xB3FFFFFF);
Color cTextFaint = const Color(0x80FFFFFF);
Color cLine = const Color(0x1FFFFFFF);
Color cOnPrimary = Colors.white;
bool isDark = true;

const profCols = 'id,name,username,bio,avatar_path,is_private,verified,phone_visibility,last_seen_visibility';

const accents = [0xFF7B5CFF, 0xFF2196F3, 0xFF00BFA5, 0xFF4CAF50, 0xFFFF9800, 0xFFE91E63, 0xFFF44336, 0xFF9C27B0, 0xFF00BCD4, 0xFFFFC107, 0xFF3F51B5, 0xFF009688, 0xFFFF5722, 0xFF795548];

// null = رنگ پس‌زمینه هماهنگ با رنگ اصلی
const darkTones = <List<int>?>[
  null,
  [0xFF0B0B14, 0xFF1C1C2E],
  [0xFF000000, 0xFF161616],
  [0xFF0A0F1E, 0xFF16213A],
  [0xFF0A1410, 0xFF14281F],
  [0xFF140A10, 0xFF2A1420],
  [0xFF121212, 0xFF1E1E1E],
];
const lightTones = <List<int>?>[
  null,
  [0xFFF5F6FA, 0xFFFFFFFF],
  [0xFFFFFFFF, 0xFFF1F3F8],
  [0xFFF3F0FF, 0xFFFFFFFF],
  [0xFFEFF7F2, 0xFFFFFFFF],
  [0xFFFFF4EE, 0xFFFFFFFF],
  [0xFFEEF4FB, 0xFFFFFFFF],
];
const walls = <List<int>?>[
  null,
  [0xFF1B1B3A, 0xFF4A2C7A],
  [0xFF0F2027, 0xFF2C5364],
  [0xFF200122, 0xFF6F0000],
  [0xFF134E5E, 0xFF71B280],
  [0xFF232526, 0xFF414345],
  [0xFFFFE0F0, 0xFFE0E7FF],
  [0xFFE0F7F1, 0xFFE8F5E9],
  [0xFFFFF3E0, 0xFFFCE4EC],
];

Color currentPrimary() {
  final h = settings.customHsv;
  if (h != null) return HSVColor.fromAHSV(1, h[0], h[1], h[2]).toColor();
  return Color(accents[settings.accentIdx.clamp(0, accents.length - 1)]);
}

void applyTheme() {
  final sys = WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark;
  isDark = settings.themeMode == 2 || (settings.themeMode == 0 && sys);
  primary = currentPrimary();
  accent = isDark ? Color.lerp(primary, Colors.white, 0.45)! : Color.lerp(primary, Colors.black, 0.15)!;
  final tones = isDark ? darkTones : lightTones;
  final t = tones[(isDark ? settings.bgDark : settings.bgLight).clamp(0, tones.length - 1)];
  if (t == null) {
    final h = HSLColor.fromColor(primary);
    final s = (h.saturation * 0.4).clamp(0.08, 0.45).toDouble();
    bg = h.withSaturation(s).withLightness(isDark ? 0.07 : 0.96).toColor();
    card = h.withSaturation(s).withLightness(isDark ? 0.12 : 1.0).toColor();
  } else {
    bg = Color(t[0]);
    card = Color(t[1]);
  }
  if (isDark && settings.amoled) {
    bg = Colors.black;
    card = Color(0xFF131313);
  }
  cText = isDark ? Color(0xFFF2F2F7) : Color(0xFF16161D);
  cTextDim = isDark ? Color(0xB3FFFFFF) : Color(0xB316161D);
  cTextFaint = isDark ? Color(0x80FFFFFF) : Color(0x8016161D);
  cLine = isDark ? Color(0x1FFFFFFF) : Color(0x1F000000);
  cOnPrimary = primary.computeLuminance() > 0.55 ? Color(0xFF16161D) : Colors.white;
}

List<BoxShadow> softShadow() => isDark ? [] : [BoxShadow(color: Color(0x14000000), blurRadius: 14, offset: Offset(0, 5))];

BoxDecoration bubbleDeco(bool mine) {
  final r = settings.bubbleRadius, s = r * 0.3;
  final br = BorderRadius.only(
    topLeft: Radius.circular(r),
    topRight: Radius.circular(r),
    bottomLeft: Radius.circular(mine ? r : s),
    bottomRight: Radius.circular(mine ? s : r),
  );
  if (mine) {
    return BoxDecoration(
      color: settings.bubbleGradient ? null : primary,
      gradient: settings.bubbleGradient ? LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [primary, Color.lerp(primary, isDark ? Colors.black : Colors.white, 0.2)!]) : null,
      borderRadius: br,
    );
  }
  return BoxDecoration(color: card, borderRadius: br, border: isDark ? null : Border.all(color: cLine));
}

Color bubbleFg(bool mine) => mine ? cOnPrimary : cText;

Widget cardTile(Widget child) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: Material(color: card, elevation: isDark ? 0 : 1.5, shadowColor: Colors.black26, borderRadius: BorderRadius.circular(settings.cardRadius), clipBehavior: Clip.antiAlias, child: child),
    );

InputDecoration fieldDeco({String? hintText, String? labelText, Widget? prefixIcon, bool plain = false}) {
  OutlineInputBorder b(Color c, double w) => OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: c, width: w));
  return InputDecoration(
    hintText: hintText,
    labelText: labelText,
    prefixIcon: prefixIcon,
    filled: !plain,
    fillColor: card,
    border: plain ? InputBorder.none : OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
    enabledBorder: plain ? InputBorder.none : b(cLine, 1),
    focusedBorder: plain ? InputBorder.none : b(primary, 1.6),
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
  );
}

ThemeData buildTheme() {
  final br = isDark ? Brightness.dark : Brightness.light;
  final scheme = ColorScheme.fromSeed(seedColor: primary, brightness: br).copyWith(
    primary: primary,
    onPrimary: cOnPrimary,
    secondary: accent,
    surface: bg,
    onSurface: cText,
    surfaceContainerLowest: bg,
    surfaceContainerLow: card,
    surfaceContainer: card,
    surfaceContainerHigh: card,
    surfaceContainerHighest: card,
    outline: cTextFaint,
    outlineVariant: cLine,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: br,
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
    dividerColor: cLine,
    appBarTheme: AppBarTheme(
      backgroundColor: bg,
      foregroundColor: cText,
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
      titleTextStyle: TextStyle(color: cText, fontSize: 20, fontWeight: FontWeight.w700),
    ),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: card, indicatorColor: Color.lerp(card, primary, 0.3), surfaceTintColor: Colors.transparent, height: 68),
    floatingActionButtonTheme: FloatingActionButtonThemeData(backgroundColor: primary, foregroundColor: cOnPrimary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
  );
}

void rebuildAll(Element e) {
  e.markNeedsBuild();
  e.visitChildren(rebuildAll);
}

final navKey = GlobalKey<NavigatorState>();
final messengerKey = GlobalKey<ScaffoldMessengerState>();
SupabaseClient get sb => Supabase.instance.client;
String? get me => sb.auth.currentUser?.id;

String hm(String iso) {
  final t = DateTime.parse(iso).toLocal();
  return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
}

String kindOf(Map<String, dynamic> m) => (m['kind'] as String?) ?? 'text';

String preview(Map<String, dynamic> m) {
  switch (kindOf(m)) {
    case 'image':
      return '📷 عکس';
    case 'audio':
      return '🎤 پیام صوتی';
    case 'file':
      return '📎 ${m['file_name'] ?? 'فایل'}';
    case 'poll':
      return '📊 نظرسنجی';
    case 'video':
      return '🎬 ویدئو';
    default:
      return m['text'] as String;
  }
}

String mimeOf(String name) {
  final e = name.contains('.') ? name.split('.').last.toLowerCase() : '';
  const m = {
    'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'gif': 'image/gif', 'webp': 'image/webp',
    'm4a': 'audio/mp4', 'mp3': 'audio/mpeg', 'pdf': 'application/pdf', 'mp4': 'video/mp4', 'mov': 'video/quicktime', 'mkv': 'video/x-matroska', 'webm': 'video/webm', '3gp': 'video/3gpp', 'txt': 'text/plain',
  };
  return m[e] ?? 'application/octet-stream';
}

class Settings extends ChangeNotifier {
  bool notifications = true, sound = true, amoled = false, dense = false, bubbleGradient = true;
  String? lockHash, lockSalt;
  int lockTimeout = 30;
  double textScale = 1.0, chatTextScale = 1.0, bubbleRadius = 18, cardRadius = 16, wallDim = 0.0;
  int themeMode = 0, accentIdx = 0, bgDark = 1, bgLight = 1, wallIdx = 0;
  List<double>? customHsv;
  String? wallImage;
  late SharedPreferences _p;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    notifications = _p.getBool('notif') ?? true;
    sound = _p.getBool('sound') ?? true;
    amoled = _p.getBool('amoled') ?? false;
    dense = _p.getBool('dense') ?? false;
    lockHash = _p.getString('lockHash');
    lockSalt = _p.getString('lockSalt');
    lockTimeout = _p.getInt('lockTimeout') ?? 30;
    bubbleGradient = _p.getBool('bubbleGradient') ?? true;
    textScale = _p.getDouble('scale') ?? 1.0;
    chatTextScale = _p.getDouble('chatScale') ?? 1.0;
    bubbleRadius = _p.getDouble('bubbleRadius') ?? 18;
    cardRadius = _p.getDouble('cardRadius') ?? 16;
    wallDim = _p.getDouble('wallDim') ?? 0.0;
    themeMode = (_p.getInt('themeMode') ?? 0).clamp(0, 2);
    accentIdx = (_p.getInt('accent') ?? 0).clamp(0, accents.length - 1);
    bgDark = (_p.getInt('bgDark') ?? 1).clamp(0, darkTones.length - 1);
    bgLight = (_p.getInt('bgLight') ?? 1).clamp(0, lightTones.length - 1);
    wallIdx = (_p.getInt('wallIdx') ?? 0).clamp(0, walls.length - 1);
    wallImage = _p.getString('wallImage');
    final hs = _p.getString('customHsv');
    if (hs != null) {
      final parts = hs.split(',').map(double.tryParse).toList();
      if (parts.length == 3 && !parts.contains(null)) customHsv = parts.map((e) => e!).toList();
    }
    applyTheme();
  }

  void refresh() {
    applyTheme();
    notifyListeners();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final r = WidgetsBinding.instance.rootElement;
      if (r != null) rebuildAll(r);
    });
  }

  void save() {
    _p.setBool('notif', notifications);
    _p.setBool('sound', sound);
    _p.setBool('amoled', amoled);
    _p.setBool('dense', dense);
    if (lockHash == null) {
      _p.remove('lockHash');
      _p.remove('lockSalt');
    } else {
      _p.setString('lockHash', lockHash!);
      _p.setString('lockSalt', lockSalt ?? '');
    }
    _p.setInt('lockTimeout', lockTimeout);
    _p.setBool('bubbleGradient', bubbleGradient);
    _p.setDouble('scale', textScale);
    _p.setDouble('chatScale', chatTextScale);
    _p.setDouble('bubbleRadius', bubbleRadius);
    _p.setDouble('cardRadius', cardRadius);
    _p.setDouble('wallDim', wallDim);
    _p.setInt('themeMode', themeMode);
    _p.setInt('accent', accentIdx);
    _p.setInt('bgDark', bgDark);
    _p.setInt('bgLight', bgLight);
    _p.setInt('wallIdx', wallIdx);
    if (wallImage == null) {
      _p.remove('wallImage');
    } else {
      _p.setString('wallImage', wallImage!);
    }
    if (customHsv == null) {
      _p.remove('customHsv');
    } else {
      _p.setString('customHsv', customHsv!.join(','));
    }
    refresh();
  }

  void resetAppearance() {
    amoled = false;
    dense = false;
    bubbleGradient = true;
    chatTextScale = 1.0;
    bubbleRadius = 18;
    cardRadius = 16;
    wallDim = 0.0;
    themeMode = 0;
    accentIdx = 0;
    customHsv = null;
    bgDark = 1;
    bgLight = 1;
    wallIdx = 0;
    wallImage = null;
    save();
  }
}

final settings = Settings();

class Store extends ChangeNotifier {
  List<Map<String, dynamic>> msgs = [];
  final people = <String, Map<String, dynamic>>{};
  List<String> contactIds = [];
  StreamSubscription? _sub;
  int _lastId = -1;
  bool _first = true;

  String peerOf(Map<String, dynamic> m) => (m['sender_id'] == me ? m['receiver_id'] : m['sender_id']) as String;
  String name(String id) => (people[id]?['name'] as String?) ?? 'کاربر';
  List<Map<String, dynamic>> msgsWith(String peer) => msgs.where((m) => peerOf(m) == peer && safety.visible('d', peer, m)).toList();

  Future<void> start() async {
    stop();
    _first = true;
    _lastId = -1;
    await loadPeople([me!]);
    await loadContacts();
    _sub = sb.from('messages').stream(primaryKey: ['id']).order('created_at').listen((rows) async {
      final sorted = [...rows]..sort((a, b) => (a['id'] as int).compareTo(b['id'] as int));
      msgs = sorted;
      await loadPeople(sorted.map(peerOf));
      if (sorted.isNotEmpty) {
        final l = sorted.last;
        if (!_first && (l['id'] as int) > _lastId && l['receiver_id'] == me && settings.notifications && !safety.flag('d', l['sender_id'] as String, 'muted')) {
          messengerKey.currentState?.showSnackBar(SnackBar(content: Text('پیام جدید از ${name(l['sender_id'] as String)}')));
        }
        _lastId = l['id'] as int;
      }
      _first = false;
      notifyListeners();
    });
  }

  void stop() {
    _sub?.cancel();
    _sub = null;
    msgs = [];
    people.clear();
    contactIds = [];
    _urls.clear();
    phones.clear();
  }

  Future<void> loadPeople(Iterable<String> ids) async {
    final missing = ids.where((i) => !people.containsKey(i)).toSet().toList();
    if (missing.isEmpty) return;
    final rows = await sb.from('profiles').select(profCols).inFilter('id', missing);
    for (final r in rows) {
      people[r['id'] as String] = r;
    }
  }

  final lastSeen = <String, String?>{};
  Future<void> loadLastSeen(Iterable<String> ids) async {
    final l = ids.toSet().toList();
    if (l.isEmpty) return;
    for (final id in l) {
      lastSeen[id] = null;
    }
    final r = await sb.rpc('get_last_seen', params: {'ids': l}) as List;
    for (final e in r) {
      final x = e as Map;
      lastSeen[x['id'] as String] = x['last_seen'] as String?;
    }
  }

  final phones = <String, String?>{};
  Future<void> loadPhones(Iterable<String> ids) async {
    final l = ids.toSet().toList();
    if (l.isEmpty) return;
    for (final id in l) {
      phones[id] = null;
    }
    final r = await sb.rpc('get_phones', params: {'ids': l}) as List;
    for (final e in r) {
      final m = e as Map;
      phones[m['id'] as String] = m['phone'] as String?;
    }
  }

  Future<void> loadContacts() async {
    final rows = await sb.from('contacts').select('contact_id').eq('owner_id', me!);
    contactIds = rows.map((r) => r['contact_id'] as String).toList();
    await loadPeople(contactIds);
    try {
      await loadPhones([...contactIds, me!]);
    } catch (_) {}
    notifyListeners();
  }

  int unread(String peer) => peer == me ? 0 : msgs.where((m) => m['sender_id'] == peer && m['receiver_id'] == me && m['read_at'] == null && safety.visible('d', peer, m)).length;

  Future<void> sendRaw(String peer, Map<String, dynamic> d) => sb.from('messages').insert({'sender_id': me, 'receiver_id': peer, ...d});

  void dropMsg(int id) {
    msgs.removeWhere((m) => m['id'] == id);
    notifyListeners();
  }

  Future<String?> addContact(String q) async {
    final t = q.trim();
    Map<String, dynamic>? r;
    final digits = last10(t);
    if (digits != null && RegExp(r'^[+0-9۰-۹٠-٩ ]+$').hasMatch(t)) {
      final res = await sb.rpc('match_contacts', params: {'p_phones': [digits]}) as List;
      if (res.isNotEmpty) r = Map<String, dynamic>.from(res.first as Map);
    } else {
      r = await sb.from('profiles').select(profCols).eq('username', t.replaceFirst('@', '').toLowerCase()).maybeSingle();
    }
    if (r == null) return 'کاربری با این شماره یا نام کاربری پیدا نشد';
    if (r['id'] == me) return 'این خودِ شماست';
    people[r['id'] as String] = r;
    await sb.from('contacts').upsert({'owner_id': me, 'contact_id': r['id']});
    await loadContacts();
    return null;
  }

  Future<void> removeContact(String id) async {
    await sb.from('contacts').delete().eq('owner_id', me!).eq('contact_id', id);
    await loadContacts();
  }

  Future<void> send(String peer, String text) => sb.from('messages').insert({'sender_id': me, 'receiver_id': peer, 'text': text});

  final _urls = <String, Future<String>>{};
  Future<String> urlFor(String path) => _urls.putIfAbsent(path, () => sb.storage.from('chat-files').createSignedUrl(path, 3600));

  Future<void> sendFile(String peer, String localPath, String kind, String name) async {
    final f = File(localPath);
    if (await f.length() > 25 * 1024 * 1024) throw 'big';
    final ext = RegExp(r'\.[A-Za-z0-9]{1,8}$').stringMatch(name)?.toLowerCase() ?? '';
    final path = '${me!}/${DateTime.now().millisecondsSinceEpoch}$ext';
    await sb.storage.from('chat-files').upload(path, f, fileOptions: FileOptions(contentType: mimeOf(name)));
    await sb.from('messages').insert({'sender_id': me, 'receiver_id': peer, 'text': '', 'kind': kind, 'file_path': path, 'file_name': name});
  }

  void refreshPerson(String id, Map<String, dynamic> p) {
    people[id] = p;
    notifyListeners();
  }

  bool _marking = false;
  Future<void> markRead(String peer) async {
    if (_marking) return;
    _marking = true;
    try {
      await sb.from('messages').update({'read_at': DateTime.now().toUtc().toIso8601String()}).eq('sender_id', peer).eq('receiver_id', me!).isFilter('read_at', null);
    } catch (_) {}
    _marking = false;
  }

  Future<void> rename(String v) async {
    await sb.from('profiles').update({'name': v}).eq('id', me!);
    people[me!] = {...people[me!]!, 'name': v};
    notifyListeners();
  }
}

final store = Store();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await settings.load();
  await Supabase.initialize(
    url: const String.fromEnvironment('SUPABASE_URL'),
    anonKey: const String.fromEnvironment('SUPABASE_ANON_KEY'),
  );
  runApp(const App());
}

class App extends StatefulWidget {
  const App({super.key});
  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    if (settings.themeMode == 0) settings.refresh();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: settings,
        builder: (context, _) => MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Tia',
          scaffoldMessengerKey: messengerKey,
          navigatorKey: navKey,
          theme: buildTheme(),
          builder: (c, w) => MediaQuery(
            data: MediaQuery.of(c).copyWith(textScaler: TextScaler.linear(settings.textScale)),
            child: Directionality(textDirection: TextDirection.rtl, child: LockGate(child: w!)),
          ),
          home: StreamBuilder<AuthState>(
            stream: sb.auth.onAuthStateChange,
            builder: (c, _) => sb.auth.currentSession == null ? const LoginPage() : const Home(),
          ),
        ),
      );
}

Future<String?> inputDialog(BuildContext c, String title, String label, [String init = '', bool phone = false]) {
  final t = TextEditingController(text: init);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(controller: t, keyboardType: phone ? TextInputType.phone : null, decoration: fieldDeco(labelText: label)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('انصراف')),
        FilledButton(
          onPressed: () {
            if (t.text.trim().isNotEmpty) Navigator.pop(c, t.text.trim().replaceAll(' ', ''));
          },
          child: const Text('تایید'),
        ),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext c, String text) async =>
    await showDialog<bool>(
      context: c,
      builder: (_) => AlertDialog(
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('خیر')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('بله')),
        ],
      ),
    ) ??
    false;

Widget avatar(String name) =>
    CircleAvatar(backgroundColor: primary, foregroundColor: cOnPrimary, child: Text(name.isEmpty ? '?' : name[0]));

void snack(BuildContext c, String t) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t)));

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool signup = false, busy = false;
  String? err;
  final phone = TextEditingController(), name = TextEditingController(), uname = TextEditingController(), pass = TextEditingController();

  Future<void> submit() async {
    final p = phone.text.trim().replaceAll(' ', '');
    if (p.length < 10 || pass.text.length < 6 || (signup && name.text.trim().isEmpty) || (signup && !RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(uname.text.trim().toLowerCase()))) {
      setState(() => err = 'شماره (حداقل ۱۰ رقم)، رمز (حداقل ۶ کاراکتر) و نام را کامل وارد کنید. نام کاربری: حروف انگلیسی، عدد و _ (۳ تا ۲۰ کاراکتر)');
      return;
    }
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final email = '$p@tia.chat';
      if (signup) {
        final free = await sb.rpc('signup_available', params: {'p_phone': p, 'p_username': uname.text.trim().toLowerCase()});
        if (free != true) throw 'taken';
        final r = await sb.auth.signUp(email: email, password: pass.text);
        if (r.session == null) throw 'confirm';
        await sb.from('profiles').insert({'id': r.user!.id, 'phone': p, 'name': name.text.trim(), 'username': uname.text.trim().toLowerCase()});
      } else {
        await sb.auth.signInWithPassword(email: email, password: pass.text);
      }
    } catch (e) {
      err = e == 'taken' ? 'این شماره یا نام کاربری قبلاً ثبت شده است' : e == 'confirm' ? 'در Supabase گزینه‌ی Confirm email را خاموش کنید' : 'ناموفق بود. اطلاعات و اینترنت را بررسی کنید.\n$e';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color.lerp(bg, primary, isDark ? 0.35 : 0.2)!, bg])),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(children: [
                  Container(
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), boxShadow: [BoxShadow(color: Color.lerp(Colors.transparent, primary, 0.5)!, blurRadius: 30, spreadRadius: 2)]),
                    child: ClipRRect(borderRadius: BorderRadius.circular(28), child: Image.asset('assets/icon.png', width: 104)),
                  ),
                  const SizedBox(height: 16),
                  Text('Tia', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: cText)),
                  Text(signup ? 'ساخت حساب جدید' : 'خوش آمدید', style: TextStyle(color: cTextDim)),
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(24), boxShadow: softShadow(), border: isDark ? null : Border.all(color: cLine)),
                    child: Column(children: [
                      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: fieldDeco(labelText: 'شماره موبایل')),
                      const SizedBox(height: 12),
                      if (signup) ...[
                        TextField(controller: name, decoration: fieldDeco(labelText: 'نام')),
                        const SizedBox(height: 12),
                        TextField(controller: uname, decoration: fieldDeco(labelText: 'نام کاربری (انگلیسی)')),
                        const SizedBox(height: 12),
                      ],
                      TextField(controller: pass, obscureText: true, decoration: fieldDeco(labelText: 'رمز عبور')),
                      if (err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(err!, style: const TextStyle(color: Colors.redAccent))),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: FilledButton(
                          style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                          onPressed: busy ? null : submit,
                          child: Text(busy ? '...' : (signup ? 'ثبت‌نام' : 'ورود'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                        ),
                      ),
                      TextButton(
                        onPressed: () => setState(() => signup = !signup),
                        child: Text(signup ? 'حساب دارید؟ وارد شوید' : 'حساب ندارید؟ ثبت‌نام کنید'),
                      ),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
        ),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int i = 0;
  Timer? _beat;
  @override
  void initState() {
    super.initState();
    sb.rpc('touch_seen').catchError((_) {});
    _beat = Timer.periodic(const Duration(seconds: 60), (_) => sb.rpc('touch_seen').catchError((_) {}));
    store.start();
    gs.start();
    rx.start();
    safety.load().catchError((_) {});
  }

  @override
  void dispose() {
    _beat?.cancel();
    store.stop();
    gs.stop();
    rx.stop();
    safety.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: const [FeedTab(), ChatsTab(), ContactsTab(), SettingsTab()][i],
        bottomNavigationBar: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (v) => setState(() => i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'چت‌ها'),
            NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'مخاطبین'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'تنظیمات'),
          ],
        ),
      );
}

class ContactsTab extends StatefulWidget {
  const ContactsTab({super.key});
  @override
  State<ContactsTab> createState() => _ContactsTabState();
}

class _ContactsTabState extends State<ContactsTab> {
  String q = '';
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final ids = store.contactIds.where((id) => store.name(id).contains(q) || (store.phones[id] ?? '').contains(q) || ((store.people[id]?['username'] as String?) ?? '').contains(q)).toList();
          return Scaffold(
            appBar: AppBar(
              title: const Text('مخاطبین'),
              actions: [IconButton(icon: const Icon(Icons.sync), tooltip: 'همگام‌سازی با مخاطبین گوشی', onPressed: () => syncContacts(context))],
            ),
            body: Column(children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  onChanged: (v) => setState(() => q = v),
                  decoration: fieldDeco(prefixIcon: Icon(Icons.search), hintText: 'جستجو...'),
                ),
              ),
              Expanded(
                child: ids.isEmpty
                    ? const Center(child: Text('مخاطبی نیست. با دکمه‌ی پایین (شماره یا نام کاربری) اضافه کنید، یا با دکمه‌ی همگام‌سازی بالا از مخاطبین گوشی بیاورید.'))
                    : ListView.builder(
                        itemCount: ids.length,
                        itemBuilder: (c, n) {
                          final id = ids[n];
                          return ListTile(
                            leading: avatarFor(id),
                            title: Text(store.name(id)),
                            subtitle: Text(store.phones[id] ?? ((store.people[id]?['username'] as String?) == null ? '' : '@${store.people[id]!['username']}'), style: TextStyle(color: accent)),
                            onTap: () => openChat(c, id),
                            onLongPress: () async {
                              if (await confirm(c, 'مخاطب «${store.name(id)}» حذف شود؟')) store.removeContact(id);
                            },
                          );
                        },
                      ),
              ),
            ]),
            floatingActionButton: FloatingActionButton(
              backgroundColor: primary,
              foregroundColor: cOnPrimary,
              child: const Icon(Icons.person_add),
              onPressed: () async {
                final p = await inputDialog(context, 'مخاطب جدید', 'شماره موبایل یا نام کاربری');
                if (p == null) return;
                String? e;
                try {
                  e = await store.addContact(p);
                } catch (_) {
                  e = 'خطا در ارتباط با سرور';
                }
                if (e != null && context.mounted) snack(context, e);
              },
            ),
          );
        },
      );
}

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  Widget section(String title, List<Widget> kids) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(padding: EdgeInsets.only(bottom: 8, right: 4), child: Text(title, style: TextStyle(color: accent, fontWeight: FontWeight.w700))),
          Material(
            color: card,
            elevation: isDark ? 0 : 1.5,
            shadowColor: Colors.black26,
            borderRadius: BorderRadius.circular(settings.cardRadius),
            clipBehavior: Clip.antiAlias,
            child: Column(children: kids),
          ),
        ]),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('تنظیمات')),
        body: ListenableBuilder(
          listenable: Listenable.merge([settings, store]),
          builder: (c, _) {
            final mine = store.people[me ?? ''];
            final nm = (mine?['name'] as String?) ?? '';
            final un = (mine?['username'] as String?) ?? '';
            return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: Material(
                  borderRadius: BorderRadius.circular(settings.cardRadius + 4),
                  clipBehavior: Clip.antiAlias,
                  color: Colors.transparent,
                  child: Ink(
                    decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [primary, Color.lerp(primary, isDark ? Colors.black : Colors.white, 0.25)!])),
                    child: InkWell(
                      onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => ProfilePage(me!))),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(children: [
                          avatarFor(me ?? '', r: 30),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(nm, style: TextStyle(color: cOnPrimary, fontSize: 18, fontWeight: FontWeight.w800)),
                              if (un.isNotEmpty) Text('@$un', style: TextStyle(color: cOnPrimary)),
                              Text(store.phones[me ?? ''] ?? '', style: TextStyle(color: cOnPrimary), textDirection: TextDirection.ltr),
                            ]),
                          ),
                          Icon(Icons.chevron_left, color: cOnPrimary),
                        ]),
                      ),
                    ),
                  ),
                ),
              ),
              section('ظاهر', [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: SizedBox(
                    width: double.infinity,
                    child: SegmentedButton<int>(
                      showSelectedIcon: false,
                      segments: const [
                        ButtonSegment(value: 0, label: Text('خودکار'), icon: Icon(Icons.brightness_auto)),
                        ButtonSegment(value: 1, label: Text('روز'), icon: Icon(Icons.light_mode)),
                        ButtonSegment(value: 2, label: Text('شب'), icon: Icon(Icons.dark_mode)),
                      ],
                      selected: {settings.themeMode},
                      onSelectionChanged: (s) {
                        settings.themeMode = s.first;
                        settings.save();
                      },
                    ),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.palette_outlined),
                  title: const Text('شخصی‌سازی کامل ظاهر'),
                  subtitle: const Text('رنگ، پس‌زمینه، والپیپر چت، حباب پیام و بیشتر'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const AppearancePage())),
                ),
                ListTile(
                  title: const Text('اندازه‌ی متن برنامه'),
                  subtitle: Slider(
                    value: settings.textScale,
                    min: 0.8,
                    max: 1.3,
                    divisions: 5,
                    onChanged: (v) {
                      settings.textScale = v;
                      settings.save();
                    },
                  ),
                ),
              ]),
              section('اعلان‌ها', [
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_none),
                  title: const Text('اعلان پیام جدید'),
                  value: settings.notifications,
                  onChanged: (v) {
                    settings.notifications = v;
                    settings.save();
                  },
                ),
                SwitchListTile(
                  secondary: const Icon(Icons.volume_up_outlined),
                  title: const Text('صدای پیام'),
                  value: settings.sound,
                  onChanged: (v) {
                    settings.sound = v;
                    settings.save();
                  },
                ),
              ]),
              section('حریم خصوصی', [
                ListTile(
                  leading: const Icon(Icons.visibility_outlined),
                  title: const Text('چه کسانی شماره‌ی من را ببینند؟'),
                  subtitle: Text(phoneVisLabel(store.people[me ?? '']?['phone_visibility'] as String?)),
                  onTap: () => choosePhoneVisibility(c),
                ),
                ListTile(
                  leading: const Icon(Icons.person_add_alt),
                  title: const Text('درخواست‌های دنبال‌کردن'),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const RequestsPage())),
                ),
                ListTile(
                  leading: const Icon(Icons.block),
                  title: const Text('کاربران مسدودشده'),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const BlockedPage())),
                ),
                ListTile(
                  leading: const Icon(Icons.access_time),
                  title: const Text('چه کسانی آخرین بازدید من را ببینند؟'),
                  subtitle: Text(phoneVisLabel(store.people[me ?? '']?['last_seen_visibility'] as String?)),
                  onTap: () => chooseLastSeen(c),
                ),
                ListTile(
                  leading: const Icon(Icons.lock_outline),
                  title: const Text('قفل برنامه با رمز'),
                  subtitle: Text(lockEnabled() ? 'فعال' : 'غیرفعال'),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const AppLockPage())),
                ),
              ]),
              section('محتوا', [
                ListTile(
                  leading: const Icon(Icons.bookmark_border),
                  title: const Text('پست‌های ذخیره‌شده'),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => PostListPage('ذخیره‌شده‌ها', savedPosts))),
                ),
              ]),
              section('حساب', [
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: const Text('درباره‌ی Tia'),
                  onTap: () => showAboutDialog(context: c, applicationName: 'Tia', applicationVersion: '1.2.2', applicationLegalese: 'کلیه حقوق متعلق به Taha می‌باشد'),
                ),
                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.redAccent),
                  title: const Text('خروج از حساب'),
                  onTap: () async {
                    if (await confirm(c, 'از حساب خارج می‌شوید؟')) await sb.auth.signOut();
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.password),
                  title: const Text('تغییر رمز عبور'),
                  onTap: () => changePasswordFlow(c),
                ),
                ListTile(
                  leading: const Icon(Icons.devices_other),
                  title: const Text('خروج از سایر دستگاه‌ها'),
                  onTap: () => logoutOthersFlow(c),
                ),
                ListTile(
                  leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
                  title: const Text('حذف حساب کاربری', style: TextStyle(color: Colors.redAccent)),
                  onTap: () => deleteAccountFlow(c),
                ),
              ]),
            ]);
          },
        ),
      );
}

class ImageBubble extends StatelessWidget {
  final String path;
  const ImageBubble(this.path, {super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
        future: store.urlFor(path),
        builder: (c, s) {
          if (s.hasError) return const Icon(Icons.broken_image);
          if (!s.hasData) return const SizedBox(width: 200, height: 140, child: Center(child: CircularProgressIndicator()));
          final url = s.data!;
          return GestureDetector(
            onTap: () => Navigator.push(
              c,
              MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(), body: Center(child: InteractiveViewer(child: Image.network(url))))),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(url, width: 220, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
            ),
          );
        },
      );
}

class VoiceBubble extends StatefulWidget {
  final String path;
  const VoiceBubble(this.path, {super.key});
  @override
  State<VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<VoiceBubble> {
  final player = AudioPlayer();
  bool playing = false;
  Duration pos = Duration.zero, dur = Duration.zero;
  double rate = 1.0;
  final _subs = <StreamSubscription>[];

  @override
  void initState() {
    super.initState();
    _subs.add(player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => playing = s == PlayerState.playing);
    }));
    _subs.add(player.onPositionChanged.listen((p) {
      if (mounted) setState(() => pos = p);
    }));
    _subs.add(player.onDurationChanged.listen((d) {
      if (mounted) setState(() => dur = d);
    }));
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    player.dispose();
    super.dispose();
  }

  Future<void> toggle() async {
    if (playing) {
      await player.pause();
    } else if (player.state == PlayerState.paused) {
      await player.resume();
    } else {
      try {
        await player.play(UrlSource(await store.urlFor(widget.path)));
        await player.setPlaybackRate(rate);
      } catch (_) {
        if (mounted) snack(context, 'پخش نشد');
      }
    }
  }

  Future<void> cycleRate() async {
    final next = rate == 1.0 ? 1.5 : rate == 1.5 ? 2.0 : 1.0;
    setState(() => rate = next);
    try {
      await player.setPlaybackRate(next);
    } catch (_) {}
  }

  String fmt(Duration d) => '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final fg = IconTheme.of(context).color ?? cText;
    final max = dur.inMilliseconds <= 0 ? 1.0 : dur.inMilliseconds.toDouble();
    final v = pos.inMilliseconds.clamp(0, max.toInt()).toDouble();
    return SizedBox(
      width: 230,
      child: Row(children: [
        InkWell(onTap: toggle, child: Icon(playing ? Icons.pause_circle : Icons.play_circle, size: 38)),
        Expanded(
          child: SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 3,
              activeTrackColor: fg,
              thumbColor: fg,
              inactiveTrackColor: Color.lerp(Colors.transparent, fg, 0.3),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 10),
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
            ),
            child: Slider(value: v, min: 0, max: max, onChanged: (x) => player.seek(Duration(milliseconds: x.toInt()))),
          ),
        ),
        Column(mainAxisSize: MainAxisSize.min, children: [
          Text(fmt(playing || pos > Duration.zero ? pos : dur), style: const TextStyle(fontSize: 11)),
          InkWell(onTap: cycleRate, child: Text('${rate == rate.roundToDouble() ? rate.toInt() : rate}x', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))),
        ]),
      ]),
    );
  }
}

class FileBubble extends StatelessWidget {
  final String path, name;
  const FileBubble(this.path, this.name, {super.key});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: () async {
          try {
            await launchUrl(Uri.parse(await store.urlFor(path)), mode: LaunchMode.externalApplication);
          } catch (_) {
            if (context.mounted) snack(context, 'باز نشد');
          }
        },
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.insert_drive_file),
          const SizedBox(width: 8),
          Flexible(child: Text(name, style: const TextStyle(decoration: TextDecoration.underline))),
        ]),
      );
}
