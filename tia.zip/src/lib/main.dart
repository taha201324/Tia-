import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'social.dart';

Color primary = const Color(0xFF7B5CFF);
Color accent = const Color(0xFFC8B4FF);
Color bg = const Color(0xFF0B0B14);
Color card = const Color(0xFF1C1C2E);

const accents = [0xFF7B5CFF, 0xFF2196F3, 0xFF00BFA5, 0xFF4CAF50, 0xFFFF9800, 0xFFE91E63, 0xFFF44336, 0xFF9C27B0, 0xFF00BCD4, 0xFFFFC107];
const bgTones = [
  [0xFF0B0B14, 0xFF1C1C2E],
  [0xFF000000, 0xFF161616],
  [0xFF0A0F1E, 0xFF16213A],
  [0xFF0A1410, 0xFF14281F],
  [0xFF140A10, 0xFF2A1420],
  [0xFF120D1F, 0xFF231A3D],
];
const walls = <List<int>?>[
  null,
  [0xFF1B1B3A, 0xFF4A2C7A],
  [0xFF0F2027, 0xFF2C5364],
  [0xFF200122, 0xFF6F0000],
  [0xFF134E5E, 0xFF71B280],
  [0xFF232526, 0xFF414345],
];

void applyTheme() {
  primary = Color(accents[settings.accentIdx]);
  accent = Color.lerp(primary, Colors.white, 0.55)!;
  bg = Color(bgTones[settings.bgIdx][0]);
  card = Color(bgTones[settings.bgIdx][1]);
}

void rebuildAll(Element e) {
  e.markNeedsBuild();
  e.visitChildren(rebuildAll);
}

final messengerKey = GlobalKey<ScaffoldMessengerState>();
SupabaseClient get sb => Supabase.instance.client;
String? get me => sb.auth.currentUser?.id;

String hm(String iso) {
  final t = DateTime.parse(iso).toLocal();
  return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
}

String kindOf(Map<String, dynamic> m) => (m['kind'] as String?) ?? 'text';

String preview(Map<String, dynamic> m) {
  switch (kindOf(m)) {
    case 'image':
      return '📷 عکس';
    case 'audio':
      return '🎤 پیام صوتی';
    case 'file':
      return '📎 ${m['file_name'] ?? 'فایل'}';
    default:
      return m['text'] as String;
  }
}

String mimeOf(String name) {
  final e = name.contains('.') ? name.split('.').last.toLowerCase() : '';
  const m = {
    'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'gif': 'image/gif', 'webp': 'image/webp',
    'm4a': 'audio/mp4', 'mp3': 'audio/mpeg', 'pdf': 'application/pdf', 'mp4': 'video/mp4', 'txt': 'text/plain',
  };
  return m[e] ?? 'application/octet-stream';
}

class Settings extends ChangeNotifier {
  bool notifications = true, sound = true;
  double textScale = 1.0;
  int accentIdx = 0, bgIdx = 0, wallIdx = 0;
  String? wallImage;
  late SharedPreferences _p;
  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    notifications = _p.getBool('notif') ?? true;
    sound = _p.getBool('sound') ?? true;
    textScale = _p.getDouble('scale') ?? 1.0;
    accentIdx = (_p.getInt('accent') ?? 0).clamp(0, accents.length - 1);
    bgIdx = (_p.getInt('bgIdx') ?? 0).clamp(0, bgTones.length - 1);
    wallIdx = (_p.getInt('wallIdx') ?? 0).clamp(0, walls.length - 1);
    wallImage = _p.getString('wallImage');
    applyTheme();
  }

  void save() {
    _p.setBool('notif', notifications);
    _p.setBool('sound', sound);
    _p.setDouble('scale', textScale);
    _p.setInt('accent', accentIdx);
    _p.setInt('bgIdx', bgIdx);
    _p.setInt('wallIdx', wallIdx);
    if (wallImage == null) {
      _p.remove('wallImage');
    } else {
      _p.setString('wallImage', wallImage!);
    }
    applyTheme();
    notifyListeners();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final r = WidgetsBinding.instance.rootElement;
      if (r != null) rebuildAll(r);
    });
  }
}

final settings = Settings();

class Store extends ChangeNotifier {
  List<Map<String, dynamic>> msgs = [];
  final people = <String, Map<String, dynamic>>{};
  List<String> contactIds = [];
  StreamSubscription? _sub;
  int _lastId = -1;
  bool _first = true;

  String peerOf(Map<String, dynamic> m) => (m['sender_id'] == me ? m['receiver_id'] : m['sender_id']) as String;
  String name(String id) => (people[id]?['name'] as String?) ?? 'کاربر';
  List<Map<String, dynamic>> msgsWith(String peer) => msgs.where((m) => peerOf(m) == peer).toList();

  Future<void> start() async {
    stop();
    _first = true;
    _lastId = -1;
    await loadPeople([me!]);
    await loadContacts();
    _sub = sb.from('messages').stream(primaryKey: ['id']).order('created_at').listen((rows) async {
      final sorted = [...rows]..sort((a, b) => (a['id'] as int).compareTo(b['id'] as int));
      msgs = sorted;
      await loadPeople(sorted.map(peerOf));
      if (sorted.isNotEmpty) {
        final l = sorted.last;
        if (!_first && (l['id'] as int) > _lastId && l['receiver_id'] == me && settings.notifications) {
          messengerKey.currentState?.showSnackBar(SnackBar(content: Text('پیام جدید از ${name(l['sender_id'] as String)}')));
        }
        _lastId = l['id'] as int;
      }
      _first = false;
      notifyListeners();
    });
  }

  void stop() {
    _sub?.cancel();
    _sub = null;
    msgs = [];
    people.clear();
    contactIds = [];
    _urls.clear();
  }

  Future<void> loadPeople(Iterable<String> ids) async {
    final missing = ids.where((i) => !people.containsKey(i)).toSet().toList();
    if (missing.isEmpty) return;
    final rows = await sb.from('profiles').select().inFilter('id', missing);
    for (final r in rows) {
      people[r['id'] as String] = r;
    }
  }

  Future<void> loadContacts() async {
    final rows = await sb.from('contacts').select('contact_id').eq('owner_id', me!);
    contactIds = rows.map((r) => r['contact_id'] as String).toList();
    await loadPeople(contactIds);
    notifyListeners();
  }

  Future<String?> addContact(String phone) async {
    final r = await sb.from('profiles').select().eq('phone', phone).maybeSingle();
    if (r == null) return 'کاربری با این شماره ثبت‌نام نکرده است';
    if (r['id'] == me) return 'این شماره‌ی خودتان است';
    people[r['id'] as String] = r;
    await sb.from('contacts').upsert({'owner_id': me, 'contact_id': r['id']});
    await loadContacts();
    return null;
  }

  Future<void> removeContact(String id) async {
    await sb.from('contacts').delete().eq('owner_id', me!).eq('contact_id', id);
    await loadContacts();
  }

  Future<void> send(String peer, String text) => sb.from('messages').insert({'sender_id': me, 'receiver_id': peer, 'text': text});

  final _urls = <String, Future<String>>{};
  Future<String> urlFor(String path) => _urls.putIfAbsent(path, () => sb.storage.from('chat-files').createSignedUrl(path, 3600));

  Future<void> sendFile(String peer, String localPath, String kind, String name) async {
    final f = File(localPath);
    if (await f.length() > 25 * 1024 * 1024) throw 'big';
    final ext = RegExp(r'\.[A-Za-z0-9]{1,8}$').stringMatch(name)?.toLowerCase() ?? '';
    final path = '${me!}/${DateTime.now().millisecondsSinceEpoch}$ext';
    await sb.storage.from('chat-files').upload(path, f, fileOptions: FileOptions(contentType: mimeOf(name)));
    await sb.from('messages').insert({'sender_id': me, 'receiver_id': peer, 'text': '', 'kind': kind, 'file_path': path, 'file_name': name});
  }

  void refreshPerson(String id, Map<String, dynamic> p) {
    people[id] = p;
    notifyListeners();
  }

  bool _marking = false;
  Future<void> markRead(String peer) async {
    if (_marking) return;
    _marking = true;
    try {
      await sb.from('messages').update({'read_at': DateTime.now().toUtc().toIso8601String()}).eq('sender_id', peer).eq('receiver_id', me!).isFilter('read_at', null);
    } catch (_) {}
    _marking = false;
  }

  Future<void> rename(String v) async {
    await sb.from('profiles').update({'name': v}).eq('id', me!);
    people[me!] = {...people[me!]!, 'name': v};
    notifyListeners();
  }
}

final store = Store();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await settings.load();
  await Supabase.initialize(
    url: const String.fromEnvironment('SUPABASE_URL'),
    anonKey: const String.fromEnvironment('SUPABASE_ANON_KEY'),
  );
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: settings,
        builder: (context, _) => MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Tia',
          scaffoldMessengerKey: messengerKey,
          theme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.dark,
            scaffoldBackgroundColor: bg,
            colorScheme: ColorScheme.dark(primary: primary, secondary: accent, surface: bg, onSurface: Colors.white),
            appBarTheme: AppBarTheme(backgroundColor: bg, foregroundColor: Colors.white, surfaceTintColor: Colors.transparent),
            navigationBarTheme: NavigationBarThemeData(backgroundColor: card, indicatorColor: primary),
            dividerColor: card,
          ),
          builder: (c, w) => MediaQuery(
            data: MediaQuery.of(c).copyWith(textScaler: TextScaler.linear(settings.textScale)),
            child: Directionality(textDirection: TextDirection.rtl, child: w!),
          ),
          home: StreamBuilder<AuthState>(
            stream: sb.auth.onAuthStateChange,
            builder: (c, _) => sb.auth.currentSession == null ? const LoginPage() : const Home(),
          ),
        ),
      );
}

Future<String?> inputDialog(BuildContext c, String title, String label, [String init = '', bool phone = false]) {
  final t = TextEditingController(text: init);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(controller: t, keyboardType: phone ? TextInputType.phone : null, decoration: InputDecoration(labelText: label)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('انصراف')),
        FilledButton(
          onPressed: () {
            if (t.text.trim().isNotEmpty) Navigator.pop(c, t.text.trim().replaceAll(' ', ''));
          },
          child: const Text('تایید'),
        ),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext c, String text) async =>
    await showDialog<bool>(
      context: c,
      builder: (_) => AlertDialog(
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('خیر')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('بله')),
        ],
      ),
    ) ??
    false;

Widget avatar(String name) =>
    CircleAvatar(backgroundColor: primary, foregroundColor: Colors.white, child: Text(name.isEmpty ? '?' : name[0]));

void snack(BuildContext c, String t) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t)));

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool signup = false, busy = false;
  String? err;
  final phone = TextEditingController(), name = TextEditingController(), uname = TextEditingController(), pass = TextEditingController();

  Future<void> submit() async {
    final p = phone.text.trim().replaceAll(' ', '');
    if (p.length < 10 || pass.text.length < 6 || (signup && name.text.trim().isEmpty) || (signup && !RegExp(r'^[a-z0-9_]{3,20}$').hasMatch(uname.text.trim().toLowerCase()))) {
      setState(() => err = 'شماره (حداقل ۱۰ رقم)، رمز (حداقل ۶ کاراکتر) و نام را کامل وارد کنید. نام کاربری: حروف انگلیسی، عدد و _ (۳ تا ۲۰ کاراکتر)');
      return;
    }
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final email = '$p@tia.chat';
      if (signup) {
        final free = await sb.rpc('signup_available', params: {'p_phone': p, 'p_username': uname.text.trim().toLowerCase()});
        if (free != true) throw 'taken';
        final r = await sb.auth.signUp(email: email, password: pass.text);
        if (r.session == null) throw 'confirm';
        await sb.from('profiles').insert({'id': r.user!.id, 'phone': p, 'name': name.text.trim(), 'username': uname.text.trim().toLowerCase()});
      } else {
        await sb.auth.signInWithPassword(email: email, password: pass.text);
      }
    } catch (e) {
      err = e == 'taken' ? 'این شماره یا نام کاربری قبلاً ثبت شده است' : e == 'confirm' ? 'در Supabase گزینه‌ی Confirm email را خاموش کنید' : 'ناموفق بود. اطلاعات و اینترنت را بررسی کنید.\n$e';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/icon.png', width: 110)),
              const SizedBox(height: 24),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره موبایل', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              if (signup) ...[
                TextField(controller: name, decoration: const InputDecoration(labelText: 'نام', border: OutlineInputBorder())),
                const SizedBox(height: 12),
                TextField(controller: uname, decoration: const InputDecoration(labelText: 'نام کاربری (انگلیسی)', border: OutlineInputBorder())),
                const SizedBox(height: 12),
              ],
              TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'رمز عبور', border: OutlineInputBorder())),
              if (err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(err!, style: const TextStyle(color: Colors.redAccent))),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: busy ? null : submit, child: Text(busy ? '...' : (signup ? 'ثبت‌نام' : 'ورود'))),
              ),
              TextButton(
                onPressed: () => setState(() => signup = !signup),
                child: Text(signup ? 'حساب دارید؟ وارد شوید' : 'حساب ندارید؟ ثبت‌نام کنید'),
              ),
            ]),
          ),
        ),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int i = 0;
  @override
  void initState() {
    super.initState();
    store.start();
  }

  @override
  void dispose() {
    store.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: const [FeedTab(), ChatsTab(), ContactsTab(), SettingsTab()][i],
        bottomNavigationBar: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (v) => setState(() => i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'چت‌ها'),
            NavigationDestination(icon: Icon(Icons.people_outline), label: 'مخاطبین'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'تنظیمات'),
          ],
        ),
      );
}

Future<void> openChat(BuildContext c, String id) => Navigator.push(c, MaterialPageRoute(builder: (_) => ChatPage(id)));

class ChatsTab extends StatelessWidget {
  const ChatsTab({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final last = <String, Map<String, dynamic>>{};
          for (final m in store.msgs) {
            last[store.peerOf(m)] = m;
          }
          final ids = last.keys.toList()..sort((a, b) => (last[b]!['created_at'] as String).compareTo(last[a]!['created_at'] as String));
          return Scaffold(
            appBar: AppBar(
              title: Row(children: [
                ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/icon.png', width: 32, height: 32)),
                const SizedBox(width: 10),
                const Text('Tia'),
              ]),
            ),
            body: ids.isEmpty
                ? const Center(child: Text('هنوز گفتگویی ندارید.\nاز دکمه‌ی پایین پیام جدید بفرستید.', textAlign: TextAlign.center))
                : ListView.separated(
                    itemCount: ids.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (c, n) {
                      final id = ids[n], m = last[id]!;
                      return ListTile(
                        leading: avatarFor(id),
                        title: Text(store.name(id)),
                        subtitle: Text(preview(m), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: accent)),
                        trailing: Text(hm(m['created_at'] as String), style: const TextStyle(fontSize: 12)),
                        onTap: () => openChat(c, id),
                      );
                    },
                  ),
            floatingActionButton: FloatingActionButton(
              backgroundColor: primary,
              foregroundColor: Colors.white,
              child: const Icon(Icons.edit),
              onPressed: () async {
                final id = await showModalBottomSheet<String>(
                  context: context,
                  builder: (c) => Directionality(
                    textDirection: TextDirection.rtl,
                    child: ListView(children: [
                      const ListTile(title: Text('ارسال پیام به...')),
                      if (store.contactIds.isEmpty) const ListTile(title: Text('ابتدا از بخش مخاطبین، مخاطب اضافه کنید')),
                      for (final id in store.contactIds) ListTile(leading: avatarFor(id), title: Text(store.name(id)), onTap: () => Navigator.pop(c, id)),
                    ]),
                  ),
                );
                if (id != null && context.mounted) openChat(context, id);
              },
            ),
          );
        },
      );
}

class ContactsTab extends StatefulWidget {
  const ContactsTab({super.key});
  @override
  State<ContactsTab> createState() => _ContactsTabState();
}

class _ContactsTabState extends State<ContactsTab> {
  String q = '';
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final ids = store.contactIds.where((id) => store.name(id).contains(q) || ((store.people[id]?['phone'] as String?) ?? '').contains(q)).toList();
          return Scaffold(
            appBar: AppBar(title: const Text('مخاطبین')),
            body: Column(children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  onChanged: (v) => setState(() => q = v),
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'جستجو...', border: OutlineInputBorder()),
                ),
              ),
              Expanded(
                child: ids.isEmpty
                    ? const Center(child: Text('مخاطبی نیست. با دکمه‌ی پایین، با شماره اضافه کنید.'))
                    : ListView.builder(
                        itemCount: ids.length,
                        itemBuilder: (c, n) {
                          final id = ids[n];
                          return ListTile(
                            leading: avatarFor(id),
                            title: Text(store.name(id)),
                            subtitle: Text((store.people[id]?['phone'] as String?) ?? '', style: TextStyle(color: accent)),
                            onTap: () => openChat(c, id),
                            onLongPress: () async {
                              if (await confirm(c, 'مخاطب «${store.name(id)}» حذف شود؟')) store.removeContact(id);
                            },
                          );
                        },
                      ),
              ),
            ]),
            floatingActionButton: FloatingActionButton(
              backgroundColor: primary,
              foregroundColor: Colors.white,
              child: const Icon(Icons.person_add),
              onPressed: () async {
                final p = await inputDialog(context, 'مخاطب جدید', 'شماره موبایل', '', true);
                if (p == null) return;
                String? e;
                try {
                  e = await store.addContact(p);
                } catch (_) {
                  e = 'خطا در ارتباط با سرور';
                }
                if (e != null && context.mounted) snack(context, e);
              },
            ),
          );
        },
      );
}

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('تنظیمات')),
        body: ListenableBuilder(
          listenable: Listenable.merge([settings, store]),
          builder: (c, _) {
            final mine = store.people[me ?? ''];
            final nm = (mine?['name'] as String?) ?? '';
            return ListView(children: [
              ListTile(
                leading: avatarFor(me ?? ''),
                title: Text(nm),
                subtitle: Text((mine?['phone'] as String?) ?? ''),
                trailing: const Icon(Icons.edit),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => ProfilePage(me!))),
              ),
              const Divider(),
              SwitchListTile(
                title: const Text('اعلان پیام جدید'),
                value: settings.notifications,
                onChanged: (v) {
                  settings.notifications = v;
                  settings.save();
                },
              ),
              SwitchListTile(
                title: const Text('صدای پیام'),
                value: settings.sound,
                onChanged: (v) {
                  settings.sound = v;
                  settings.save();
                },
              ),
              ListTile(
                title: const Text('اندازه‌ی متن'),
                subtitle: Slider(
                  value: settings.textScale,
                  min: 0.8,
                  max: 1.3,
                  divisions: 5,
                  onChanged: (v) {
                    settings.textScale = v;
                    settings.save();
                  },
                ),
              ),
              ListTile(
                leading: const Icon(Icons.palette_outlined),
                title: const Text('ظاهر برنامه (رنگ و پس‌زمینه)'),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const AppearancePage())),
              ),
              ListTile(
                leading: const Icon(Icons.bookmark_border),
                title: const Text('ذخیره‌شده‌ها'),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => PostListPage('ذخیره‌شده‌ها', savedPosts))),
              ),
              ListTile(
                leading: const Icon(Icons.person_add_alt),
                title: const Text('درخواست‌های دنبال‌کردن'),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const RequestsPage())),
              ),
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('درباره‌ی Tia'),
                onTap: () => showAboutDialog(context: c, applicationName: 'Tia', applicationVersion: '1.0.0'),
              ),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.redAccent),
                title: const Text('خروج از حساب'),
                onTap: () async {
                  if (await confirm(c, 'از حساب خارج می‌شوید؟')) await sb.auth.signOut();
                },
              ),
            ]);
          },
        ),
      );
}

class ChatPage extends StatefulWidget {
  final String peer;
  const ChatPage(this.peer, {super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctrl = TextEditingController();
  final rec = AudioRecorder();
  bool recording = false, uploading = false;
  int secs = 0;
  Timer? timer;

  @override
  void dispose() {
    timer?.cancel();
    rec.dispose();
    ctrl.dispose();
    super.dispose();
  }

  Future<void> sendText() async {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    ctrl.clear();
    setState(() {});
    try {
      await store.send(widget.peer, t);
    } catch (_) {
      if (mounted) snack(context, 'ارسال نشد. اینترنت را بررسی کنید.');
    }
  }

  Future<void> upload(String path, String kind, String name) async {
    setState(() => uploading = true);
    try {
      await store.sendFile(widget.peer, path, kind, name);
    } catch (e) {
      if (mounted) snack(context, e == 'big' ? 'حجم فایل بیشتر از ۲۵ مگابایت است' : 'ارسال نشد. اینترنت را بررسی کنید.');
    }
    if (mounted) setState(() => uploading = false);
  }

  Future<void> pick(FileType t, String kind) async {
    final r = await FilePicker.platform.pickFiles(type: t);
    final f = r?.files.single;
    if (f == null || f.path == null) return;
    await upload(f.path!, kind, f.name);
  }

  void attachMenu() => showModalBottomSheet(
        context: context,
        builder: (c) => Directionality(
          textDirection: TextDirection.rtl,
          child: Wrap(children: [
            ListTile(
              leading: const Icon(Icons.image),
              title: const Text('عکس'),
              onTap: () {
                Navigator.pop(c);
                pick(FileType.image, 'image');
              },
            ),
            ListTile(
              leading: const Icon(Icons.insert_drive_file),
              title: const Text('فایل'),
              onTap: () {
                Navigator.pop(c);
                pick(FileType.any, 'file');
              },
            ),
          ]),
        ),
      );

  Future<void> startRec() async {
    if (!await rec.hasPermission()) {
      if (mounted) snack(context, 'اجازه‌ی میکروفون داده نشد');
      return;
    }
    final dir = await getTemporaryDirectory();
    await rec.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a');
    secs = 0;
    timer = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => secs++));
    setState(() => recording = true);
  }

  Future<void> stopRec(bool send) async {
    timer?.cancel();
    final p = await rec.stop();
    setState(() => recording = false);
    if (p == null) return;
    if (send && secs >= 1) await upload(p, 'audio', 'voice.m4a');
    try {
      File(p).deleteSync();
    } catch (_) {}
  }

  Widget body(Map<String, dynamic> m) {
    final path = m['file_path'] as String?;
    switch (kindOf(m)) {
      case 'image':
        return ImageBubble(path!);
      case 'audio':
        return VoiceBubble(path!);
      case 'file':
        return FileBubble(path!, (m['file_name'] as String?) ?? 'فایل');
      default:
        return Text(m['text'] as String, style: const TextStyle(color: Colors.white));
    }
  }

  Widget inputBar() {
    if (recording) {
      return Row(children: [
        IconButton(icon: const Icon(Icons.delete, color: Colors.redAccent), onPressed: () => stopRec(false)),
        const Icon(Icons.fiber_manual_record, color: Colors.redAccent, size: 14),
        const SizedBox(width: 6),
        Text('${secs ~/ 60}:${(secs % 60).toString().padLeft(2, '0')}'),
        const Spacer(),
        IconButton(icon: Icon(Icons.send, color: primary), onPressed: () => stopRec(true)),
      ]);
    }
    return Row(children: [
      IconButton(icon: const Icon(Icons.attach_file), onPressed: attachMenu),
      Expanded(
        child: TextField(
          controller: ctrl,
          onChanged: (_) => setState(() {}),
          onSubmitted: (_) => sendText(),
          decoration: const InputDecoration(hintText: 'پیام بنویسید...', border: OutlineInputBorder()),
        ),
      ),
      ctrl.text.trim().isEmpty
          ? IconButton(icon: Icon(Icons.mic, color: primary), onPressed: startRec)
          : IconButton(icon: Icon(Icons.send, color: primary), onPressed: sendText),
    ]);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final list = store.msgsWith(widget.peer).reversed.toList();
          if (store.msgs.any((m) => m['sender_id'] == widget.peer && m['receiver_id'] == me && m['read_at'] == null)) {
            WidgetsBinding.instance.addPostFrameCallback((_) => store.markRead(widget.peer));
          }
          return Scaffold(
            appBar: AppBar(title: Text(store.name(widget.peer))),
            body: Container(decoration: wallDecoration(), child: Column(children: [
              Expanded(
                child: ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(12),
                  itemCount: list.length,
                  itemBuilder: (c, n) {
                    final m = list[n];
                    final mine = m['sender_id'] == me;
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(c).size.width * 0.75),
                        decoration: BoxDecoration(color: mine ? primary : card, borderRadius: BorderRadius.circular(14)),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
                          body(m),
                          Row(mainAxisSize: MainAxisSize.min, children: [
                            Text(hm(m['created_at'] as String), style: TextStyle(color: accent, fontSize: 10)),
                            if (mine) ...[
                              const SizedBox(width: 4),
                              Icon(m['read_at'] != null ? Icons.done_all : Icons.done, size: 13, color: m['read_at'] != null ? accent : Colors.white54),
                            ],
                          ]),
                        ]),
                      ),
                    );
                  },
                ),
              ),
              if (uploading) const LinearProgressIndicator(),
              SafeArea(child: Padding(padding: const EdgeInsets.all(8), child: inputBar())),
            ])),
          );
        },
      );
}

class ImageBubble extends StatelessWidget {
  final String path;
  const ImageBubble(this.path, {super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
        future: store.urlFor(path),
        builder: (c, s) {
          if (s.hasError) return const Icon(Icons.broken_image);
          if (!s.hasData) return const SizedBox(width: 200, height: 140, child: Center(child: CircularProgressIndicator()));
          final url = s.data!;
          return GestureDetector(
            onTap: () => Navigator.push(
              c,
              MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(), body: Center(child: InteractiveViewer(child: Image.network(url))))),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(url, width: 220, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
            ),
          );
        },
      );
}

class VoiceBubble extends StatefulWidget {
  final String path;
  const VoiceBubble(this.path, {super.key});
  @override
  State<VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<VoiceBubble> {
  final player = AudioPlayer();
  bool playing = false;

  @override
  void initState() {
    super.initState();
    player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => playing = s == PlayerState.playing);
    });
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  Future<void> toggle() async {
    if (playing) {
      await player.pause();
    } else if (player.state == PlayerState.paused) {
      await player.resume();
    } else {
      try {
        await player.play(UrlSource(await store.urlFor(widget.path)));
      } catch (_) {
        if (mounted) snack(context, 'پخش نشد');
      }
    }
  }

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: toggle,
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(playing ? Icons.pause_circle : Icons.play_circle, size: 36, color: Colors.white),
          const SizedBox(width: 8),
          const Text('پیام صوتی', style: TextStyle(color: Colors.white)),
        ]),
      );
}

class FileBubble extends StatelessWidget {
  final String path, name;
  const FileBubble(this.path, this.name, {super.key});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: () async {
          try {
            await launchUrl(Uri.parse(await store.urlFor(path)), mode: LaunchMode.externalApplication);
          } catch (_) {
            if (context.mounted) snack(context, 'باز نشد');
          }
        },
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.insert_drive_file, color: Colors.white),
          const SizedBox(width: 8),
          Flexible(child: Text(name, style: const TextStyle(color: Colors.white, decoration: TextDecoration.underline))),
        ]),
      );
}
