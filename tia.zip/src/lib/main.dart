import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'accounts.dart';
import 'ai_chat.dart';
import 'ai.dart';
import 'applock.dart';
import 'auth.dart';
import 'cyber.dart';
import 'chat.dart';
import 'extras.dart';
import 'groups.dart';
import 'rich.dart';
import 'net.dart';
import 'push.dart';
import 'sessions.dart';
import 'safety.dart';
import 'social.dart';
import 'l10n.dart';
import 'e2ee.dart';
import 'onboarding.dart';

Color primary = const Color(0xFF7B5CFF);
Color accent = const Color(0xFFC8B4FF);
Color accent2 = const Color(0xFFFFB547);
Color bg = const Color(0xFF0B0B14);
Color card = const Color(0xFF1C1C2E);
Color cText = const Color(0xFFF2F2F7);
Color cTextDim = const Color(0xB3FFFFFF);
Color cTextFaint = const Color(0x80FFFFFF);
Color cLine = const Color(0x1FFFFFFF);
Color cOnPrimary = Colors.white;
bool isDark = true;

const profCols = 'id,name,username,bio,avatar_path,is_private,verified,phone_visibility,last_seen_visibility';

const accents = [0xFF18D6A0, 0xFFFFA62B, 0xFFFF5C7A, 0xFF3DDC84, 0xFF22B8F0, 0xFF8E7CFF, 0xFFE8E04A, 0xFFFF7A59, 0xFF14B8A6, 0xFFF06292, 0xFF4F7DF3, 0xFFB388FF, 0xFFA3E635, 0xFFD4A373];

// null = رنگ پس‌زمینه هماهنگ با رنگ اصلی
const darkTones = <List<int>?>[
  null,
  [0xFF0C1411, 0xFF16221C],
  [0xFF0B0B0D, 0xFF161619],
  [0xFF0B1118, 0xFF152130],
  [0xFF140F0B, 0xFF221A14],
  [0xFF110D18, 0xFF1D1726],
  [0xFF000000, 0xFF111111],
];
const lightTones = <List<int>?>[
  null,
  [0xFFF7F4EC, 0xFFFFFFFF],
  [0xFFFFFFFF, 0xFFF3F1EA],
  [0xFFEEF6F1, 0xFFFFFFFF],
  [0xFFFFF3E6, 0xFFFFFFFF],
  [0xFFEFF3F8, 0xFFFFFFFF],
  [0xFFF6EFF8, 0xFFFFFFFF],
];
const walls = <List<int>?>[
  null,
  [0xFF1B1B3A, 0xFF4A2C7A],
  [0xFF0F2027, 0xFF2C5364],
  [0xFF200122, 0xFF6F0000],
  [0xFF134E5E, 0xFF71B280],
  [0xFF232526, 0xFF414345],
  [0xFFFFE0F0, 0xFFE0E7FF],
  [0xFFE0F7F1, 0xFFE8F5E9],
  [0xFFFFF3E0, 0xFFFCE4EC],
];

Color currentPrimary() {
  final h = settings.customHsv;
  if (h != null) return HSVColor.fromAHSV(1, h[0], h[1], h[2]).toColor();
  return Color(accents[settings.accentIdx.clamp(0, accents.length - 1)]);
}

void applyTheme() {
  final sys = WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark;
  isDark = settings.themeMode == 2 || (settings.themeMode == 0 && sys);
  primary = currentPrimary();
  accent = isDark ? Color.lerp(primary, Colors.white, 0.45)! : Color.lerp(primary, Colors.black, 0.15)!;
  final tones = isDark ? darkTones : lightTones;
  final t = tones[(isDark ? settings.bgDark : settings.bgLight).clamp(0, tones.length - 1)];
  if (t == null) {
    final h = HSLColor.fromColor(primary);
    final s = (h.saturation * 0.4).clamp(0.08, 0.45).toDouble();
    bg = h.withSaturation(s).withLightness(isDark ? 0.07 : 0.96).toColor();
    card = h.withSaturation(s).withLightness(isDark ? 0.12 : 1.0).toColor();
  } else {
    bg = Color(t[0]);
    card = Color(t[1]);
  }
  if (isDark && settings.amoled) {
    bg = Colors.black;
    card = Color(0xFF131313);
  }
  cText = isDark ? Color(0xFFF2F2F7) : Color(0xFF16161D);
  cTextDim = isDark ? Color(0xB3FFFFFF) : Color(0xB316161D);
  cTextFaint = isDark ? Color(0x80FFFFFF) : Color(0x8016161D);
  cLine = isDark ? Color(0x1FFFFFFF) : Color(0x1F000000);
  cOnPrimary = primary.computeLuminance() > 0.4 ? Color(0xFF16161D) : Colors.white;
  final hue = HSVColor.fromColor(primary).hue;
  accent2 = (hue > 15 && hue < 80) ? (isDark ? Color(0xFF5CC8FF) : Color(0xFF0EA5E9)) : (isDark ? Color(0xFFFFC266) : Color(0xFFF59E0B));
  applyCyberTheme();
}

List<BoxShadow> softShadow() => isDark ? [] : [BoxShadow(color: Color(0x14000000), blurRadius: 14, offset: Offset(0, 5))];

BoxDecoration bubbleDeco(bool mine) {
  if (cy.enabled) return cyberBubble(mine);
  final r = settings.bubbleRadius, t = r * 0.22;
  final br = BorderRadius.only(
    topLeft: Radius.circular(r),
    topRight: Radius.circular(r),
    bottomLeft: Radius.circular(mine ? r : t),
    bottomRight: Radius.circular(mine ? t : r),
  );
  if (mine) {
    return BoxDecoration(
      color: settings.bubbleGradient ? null : primary,
      gradient: settings.bubbleGradient ? LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [primary, Color.lerp(primary, accent2, 0.45)!]) : null,
      borderRadius: br,
    );
  }
  return BoxDecoration(
    color: isDark ? Color.lerp(card, Colors.white, 0.05) : card,
    borderRadius: br,
    border: isDark ? null : Border.all(color: cLine),
  );
}

Color bubbleFg(bool mine) => mine ? cOnPrimary : cText;

Widget cardTile(Widget child) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(settings.cardRadius), border: cy.enabled ? Border.all(color: cy.c1.withOpacity(0.2)) : (isDark ? null : Border.all(color: cLine)), boxShadow: cy.enabled && cy.glow > 0.05 ? [BoxShadow(color: cy.c1.withOpacity(0.06 + 0.08 * cy.glow), blurRadius: 14)] : null),
        child: Material(color: card, borderRadius: BorderRadius.circular(settings.cardRadius), clipBehavior: Clip.antiAlias, child: child),
      ),
    );

InputDecoration fieldDeco({String? hintText, String? labelText, Widget? prefixIcon, bool plain = false, double radius = 16}) {
  OutlineInputBorder b(Color c, double w) => OutlineInputBorder(borderRadius: BorderRadius.circular(radius), borderSide: BorderSide(color: c, width: w));
  return InputDecoration(
    hintText: hintText,
    labelText: labelText,
    prefixIcon: prefixIcon,
    filled: !plain,
    fillColor: card,
    border: plain ? InputBorder.none : OutlineInputBorder(borderRadius: BorderRadius.circular(radius), borderSide: BorderSide.none),
    enabledBorder: plain ? InputBorder.none : b(cLine, 1),
    focusedBorder: plain ? InputBorder.none : b(primary, 1.6),
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
  );
}

ThemeData buildTheme() {
  final br = isDark ? Brightness.dark : Brightness.light;
  final scheme = ColorScheme.fromSeed(seedColor: primary, brightness: br).copyWith(
    primary: primary,
    onPrimary: cOnPrimary,
    secondary: accent,
    surface: bg,
    onSurface: cText,
    surfaceContainerLowest: bg,
    surfaceContainerLow: card,
    surfaceContainer: card,
    surfaceContainerHigh: card,
    surfaceContainerHighest: card,
    outline: cTextFaint,
    outlineVariant: cLine,
  );
  final r20 = RoundedRectangleBorder(borderRadius: BorderRadius.circular(22));
  return ThemeData(
    useMaterial3: true,
    brightness: br,
    colorScheme: scheme,
    scaffoldBackgroundColor: cy.enabled ? Colors.transparent : bg,
    dividerColor: cLine,
    splashFactory: InkSparkle.splashFactory,
    pageTransitionsTheme: const PageTransitionsTheme(builders: {
      TargetPlatform.android: ZoomPageTransitionsBuilder(),
    }),
    appBarTheme: AppBarTheme(
      backgroundColor: cy.enabled ? Colors.transparent : bg,
      shape: cy.enabled ? Border(bottom: BorderSide(color: cy.c1.withOpacity(0.45))) : null,
      foregroundColor: cText,
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      titleTextStyle: TextStyle(color: cText, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: -0.3, shadows: cy.enabled ? [Shadow(color: cy.c1.withOpacity(0.8 * cy.glow), blurRadius: 14)] : null),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: cy.enabled ? card.withOpacity(0.78) : Colors.transparent,
      indicatorColor: primary.withOpacity(isDark ? 0.32 : 0.20),
      indicatorShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      height: 70,
      labelTextStyle: WidgetStatePropertyAll(TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: cTextDim)),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(backgroundColor: primary, foregroundColor: cOnPrimary, elevation: 2, shape: const StadiumBorder()),
    dialogTheme: DialogThemeData(backgroundColor: card, surfaceTintColor: Colors.transparent, shape: r20),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: card,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
    ),
    snackBarTheme: SnackBarThemeData(behavior: SnackBarBehavior.floating, backgroundColor: isDark ? const Color(0xFF2A2A40) : const Color(0xFF26263A), contentTextStyle: const TextStyle(color: Colors.white), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
    chipTheme: ChipThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      side: BorderSide(color: cLine),
      selectedColor: primary.withOpacity(isDark ? 0.35 : 0.22),
      backgroundColor: card,
      labelStyle: TextStyle(color: cText, fontWeight: FontWeight.w600),
    ),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14))),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((st) => st.contains(WidgetState.selected) ? cOnPrimary : cTextDim),
      trackColor: WidgetStateProperty.resolveWith((st) => st.contains(WidgetState.selected) ? primary : cLine),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    ),
    listTileTheme: ListTileThemeData(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
    popupMenuTheme: PopupMenuThemeData(color: card, surfaceTintColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
  );
}

void rebuildAll(Element e) {
  e.markNeedsBuild();
  e.visitChildren(rebuildAll);
}

final navKey = GlobalKey<NavigatorState>();
final messengerKey = GlobalKey<ScaffoldMessengerState>();
SupabaseClient get sb => Supabase.instance.client;
String? get me => sb.auth.currentUser?.id;

String hm(String iso) {
  final t = DateTime.parse(iso).toLocal();
  return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
}

String kindOf(Map<String, dynamic> m) => (m['kind'] as String?) ?? 'text';

String preview(Map<String, dynamic> m) {
  switch (kindOf(m)) {
    case 'image':
      return trn('📷 عکس');
    case 'audio':
      return trn('🎤 پیام صوتی');
    case 'file':
      return '📎 ${m['file_name'] ?? trn('فایل')}';
    case 'poll':
      return trn('📊 نظرسنجی');
    case 'video':
      return trn('🎬 ویدئو');
    case 'location':
      return trn('📍 موقعیت مکانی');
    case 'contact':
      return trn('👤 مخاطب');
    case 'gif':
      return trn('🎞 گیف');
    case 'sticker':
      return m['text'] as String;
    default:
      return m['text'] as String;
  }
}

String mimeOf(String name) {
  final e = name.contains('.') ? name.split('.').last.toLowerCase() : '';
  const m = {
    'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'gif': 'image/gif', 'webp': 'image/webp',
    'm4a': 'audio/mp4', 'wav': 'audio/wav', 'mp3': 'audio/mpeg', 'pdf': 'application/pdf', 'mp4': 'video/mp4', 'mov': 'video/quicktime', 'mkv': 'video/x-matroska', 'webm': 'video/webm', '3gp': 'video/3gpp', 'txt': 'text/plain',
  };
  return m[e] ?? 'application/octet-stream';
}

class Settings extends ChangeNotifier {
  bool notifications = true, sound = true, amoled = false, dense = false, bubbleGradient = false;
  String? lockHash, lockSalt;
  int lockTimeout = 30;
  double textScale = 1.0, chatTextScale = 1.0, bubbleRadius = 20, cardRadius = 22, wallDim = 0.0;
  int themeMode = 0, accentIdx = 0, bgDark = 1, bgLight = 1, wallIdx = 0, startTab = 0;
  List<double>? customHsv;
  String? wallImage;
  late SharedPreferences _p;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    if ((_p.getInt('designV') ?? 0) < 2) {
      // ظاهر جدید تیا: یک بار تنظیمات رنگ و شکل به پیش‌فرض تازه برمی‌گردد
      for (final k in ['accent', 'bgDark', 'bgLight', 'customHsv', 'bubbleGradient', 'bubbleRadius', 'cardRadius']) {
        await _p.remove(k);
      }
      await _p.setInt('designV', 2);
    }
    notifications = _p.getBool('notif') ?? true;
    sound = _p.getBool('sound') ?? true;
    amoled = _p.getBool('amoled') ?? false;
    dense = _p.getBool('dense') ?? false;
    lockHash = _p.getString('lockHash');
    lockSalt = _p.getString('lockSalt');
    lockTimeout = _p.getInt('lockTimeout') ?? 30;
    final v2 = _p.getInt('startTab2');
    final old = (_p.getInt('startTab') ?? 0).clamp(0, 3);
    startTab = (v2 ?? (old >= 2 ? old + 1 : old)).clamp(0, 4); // نوار پایین ۵ تب شد؛ تب‌های بعد از «چت‌ها» یکی جابه‌جا شدند
    bubbleGradient = _p.getBool('bubbleGradient') ?? false;
    textScale = _p.getDouble('scale') ?? 1.0;
    chatTextScale = _p.getDouble('chatScale') ?? 1.0;
    bubbleRadius = _p.getDouble('bubbleRadius') ?? 20;
    cardRadius = _p.getDouble('cardRadius') ?? 22;
    wallDim = _p.getDouble('wallDim') ?? 0.0;
    themeMode = (_p.getInt('themeMode') ?? 0).clamp(0, 2);
    accentIdx = (_p.getInt('accent') ?? 0).clamp(0, accents.length - 1);
    bgDark = (_p.getInt('bgDark') ?? 1).clamp(0, darkTones.length - 1);
    bgLight = (_p.getInt('bgLight') ?? 1).clamp(0, lightTones.length - 1);
    wallIdx = (_p.getInt('wallIdx') ?? 0).clamp(0, walls.length - 1);
    wallImage = _p.getString('wallImage');
    final hs = _p.getString('customHsv');
    if (hs != null) {
      final parts = hs.split(',').map(double.tryParse).toList();
      if (parts.length == 3 && !parts.contains(null)) customHsv = parts.map((e) => e!).toList();
    }
    applyTheme();
  }

  void refresh() {
    applyTheme();
    notifyListeners();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final r = WidgetsBinding.instance.rootElement;
      if (r != null) rebuildAll(r);
    });
  }

  void save() {
    _p.setBool('notif', notifications);
    _p.setBool('sound', sound);
    _p.setBool('amoled', amoled);
    _p.setBool('dense', dense);
    if (lockHash == null) {
      _p.remove('lockHash');
      _p.remove('lockSalt');
    } else {
      _p.setString('lockHash', lockHash!);
      _p.setString('lockSalt', lockSalt ?? '');
    }
    _p.setInt('lockTimeout', lockTimeout);
    _p.setInt('startTab2', startTab);
    _p.setBool('bubbleGradient', bubbleGradient);
    _p.setDouble('scale', textScale);
    _p.setDouble('chatScale', chatTextScale);
    _p.setDouble('bubbleRadius', bubbleRadius);
    _p.setDouble('cardRadius', cardRadius);
    _p.setDouble('wallDim', wallDim);
    _p.setInt('themeMode', themeMode);
    _p.setInt('accent', accentIdx);
    _p.setInt('bgDark', bgDark);
    _p.setInt('bgLight', bgLight);
    _p.setInt('wallIdx', wallIdx);
    if (wallImage == null) {
      _p.remove('wallImage');
    } else {
      _p.setString('wallImage', wallImage!);
    }
    if (customHsv == null) {
      _p.remove('customHsv');
    } else {
      _p.setString('customHsv', customHsv!.join(','));
    }
    refresh();
  }

  void resetAppearance() {
    amoled = false;
    dense = false;
    bubbleGradient = true;
    chatTextScale = 1.0;
    bubbleRadius = 18;
    cardRadius = 16;
    wallDim = 0.0;
    themeMode = 0;
    accentIdx = 0;
    customHsv = null;
    bgDark = 1;
    bgLight = 1;
    wallIdx = 0;
    wallImage = null;
    save();
  }
}

final settings = Settings();

class Store extends ChangeNotifier {
  List<Map<String, dynamic>> msgs = [];
  final people = <String, Map<String, dynamic>>{};
  List<String> contactIds = [];
  StreamSubscription? _sub;
  int _lastId = -1;
  bool _first = true;

  String peerOf(Map<String, dynamic> m) => (m['sender_id'] == me ? m['receiver_id'] : m['sender_id']) as String;
  String name(String id) => (people[id]?['name'] as String?) ?? trn('کاربر');
  List<Map<String, dynamic>> msgsWith(String peer) => msgs.where((m) => peerOf(m) == peer && safety.visible('d', peer, m)).toList();

  Future<void> start() async {
    stop();
    _first = true;
    _lastId = -1;
    await loadPeople([me!]);
    await loadContacts();
    _listen();
  }

  void _listen() {
    _sub = sb.from('messages').stream(primaryKey: ['id']).order('created_at').listen((rows) async {
      net.noteStreamOk();
      final sorted = await e2ee.open([...rows]..sort((a, b) => (a['id'] as int).compareTo(b['id'] as int)));
      msgs = [...sorted, ...outbox.pendingDm()];
      await loadPeople(sorted.map(peerOf));
      if (sorted.isNotEmpty) {
        final l = sorted.last;
        if (!_first && (l['id'] as int) > _lastId && l['receiver_id'] == me && settings.notifications && !safety.flag('d', l['sender_id'] as String, 'muted')) {
          messengerKey.currentState?.showSnackBar(SnackBar(content: Text(trf('پیام جدید از {0}', [name(l['sender_id'] as String)]))));
        }
        _lastId = l['id'] as int;
      }
      _first = false;
      notifyListeners();
    }, onError: (_) => net.noteStreamError());
  }

  // اتصال دوباره‌ی Realtime (بدون پاک‌کردن پیام‌های فعلی)
  void resubscribe() {
    if (me == null || _sub == null) return;
    _sub?.cancel();
    _listen();
  }

  void refreshPending() {
    msgs = [...msgs.where((m) => m['pending'] != true), ...outbox.pendingDm()];
    notifyListeners();
  }

  // دریافت پیام‌هایی که در زمان قطعی از دست رفته‌اند (درخواست سبک)
  Future<void> catchUp() async {
    if (me == null || _first) return;
    var maxId = 0;
    for (final m in msgs) {
      if (m['pending'] == true) continue;
      final id = m['id'] as int;
      if (id > maxId) maxId = id;
    }
    final rows = await sb.from('messages').select().gt('id', maxId).order('id').limit(300);
    final have = msgs.map((m) => m['id']).toSet();
    final fresh = <Map<String, dynamic>>[
      for (final r in await e2ee.open([for (final r in rows) Map<String, dynamic>.from(r)]))
        if (!have.contains(r['id'])) r,
    ];
    if (fresh.isEmpty) return;
    final real = [...msgs.where((m) => m['pending'] != true), ...fresh]..sort((a, b) => (a['id'] as int).compareTo(b['id'] as int));
    msgs = [...real, ...outbox.pendingDm()];
    await loadPeople(fresh.map(peerOf));
    final l = fresh.last;
    if ((l['id'] as int) > _lastId) {
      if (l['receiver_id'] == me && settings.notifications && !safety.flag('d', l['sender_id'] as String, 'muted')) {
        messengerKey.currentState?.showSnackBar(SnackBar(content: Text(trf('پیام جدید از {0}', [name(l['sender_id'] as String)]))));
      }
      _lastId = l['id'] as int;
    }
    notifyListeners();
  }

  void stop() {
    _sub?.cancel();
    _sub = null;
    msgs = [];
    people.clear();
    contactIds = [];
    _urls.clear();
    phones.clear();
  }

  Future<void> loadPeople(Iterable<String> ids) async {
    final missing = ids.where((i) => !people.containsKey(i)).toSet().toList();
    if (missing.isEmpty) return;
    final rows = await sb.from('profiles').select(profCols).inFilter('id', missing);
    for (final r in rows) {
      people[r['id'] as String] = r;
    }
  }

  final lastSeen = <String, String?>{};
  Future<void> loadLastSeen(Iterable<String> ids) async {
    final l = ids.toSet().toList();
    if (l.isEmpty) return;
    for (final id in l) {
      lastSeen[id] = null;
    }
    final r = await sb.rpc('get_last_seen', params: {'ids': l}) as List;
    for (final e in r) {
      final x = e as Map;
      lastSeen[x['id'] as String] = x['last_seen'] as String?;
    }
  }

  final phones = <String, String?>{};
  Future<void> loadPhones(Iterable<String> ids) async {
    final l = ids.toSet().toList();
    if (l.isEmpty) return;
    for (final id in l) {
      phones[id] = null;
    }
    final r = await sb.rpc('get_phones', params: {'ids': l}) as List;
    for (final e in r) {
      final m = e as Map;
      phones[m['id'] as String] = m['phone'] as String?;
    }
  }

  Future<void> loadContacts() async {
    final rows = await sb.from('contacts').select('contact_id').eq('owner_id', me!);
    contactIds = rows.map((r) => r['contact_id'] as String).toList();
    await loadPeople(contactIds);
    try {
      await loadPhones([...contactIds, me!]);
    } catch (_) {}
    notifyListeners();
  }

  int unread(String peer) => peer == me ? 0 : msgs.where((m) => m['sender_id'] == peer && m['receiver_id'] == me && m['read_at'] == null && safety.visible('d', peer, m)).length;

  Future<void> sendRaw(String peer, Map<String, dynamic> d) => outbox.send('dm', peer: peer, body: d);

  void dropMsg(int id) {
    msgs.removeWhere((m) => m['id'] == id);
    notifyListeners();
  }

  Future<String?> addContact(String q) async {
    final t = q.trim();
    Map<String, dynamic>? r;
    final digits = last10(t);
    if (digits != null && RegExp(r'^[+0-9۰-۹٠-٩ ]+$').hasMatch(t)) {
      final res = await sb.rpc('match_contacts', params: {'p_phones': [digits]}) as List;
      if (res.isNotEmpty) r = Map<String, dynamic>.from(res.first as Map);
    } else {
      r = await sb.from('profiles').select(profCols).eq('username', t.replaceFirst('@', '').toLowerCase()).maybeSingle();
    }
    if (r == null) return trn('کاربری با این شماره یا نام کاربری پیدا نشد');
    if (r['id'] == me) return trn('این خودِ شماست');
    people[r['id'] as String] = r;
    await sb.from('contacts').upsert({'owner_id': me, 'contact_id': r['id']});
    await loadContacts();
    return null;
  }

  Future<void> removeContact(String id) async {
    await sb.from('contacts').delete().eq('owner_id', me!).eq('contact_id', id);
    await loadContacts();
  }

  Future<void> send(String peer, String text) async => sb.from('messages').insert({'sender_id': me, 'receiver_id': peer, 'text': await e2ee.encrypt(text, peer) ?? text});

  final _urls = <String, Future<String>>{};
  Future<String> urlFor(String path) => _urls.putIfAbsent(path, () => sb.storage.from('chat-files').createSignedUrl(path, 3600));

  Future<void> sendFile(String peer, String localPath, String kind, String name) async {
    final f = File(localPath);
    if (await f.length() > 25 * 1024 * 1024) throw 'big';
    final ext = RegExp(r'\.[A-Za-z0-9]{1,8}$').stringMatch(name)?.toLowerCase() ?? '';
    final path = '${me!}/${DateTime.now().millisecondsSinceEpoch}$ext';
    await sb.storage.from('chat-files').upload(path, f, fileOptions: FileOptions(contentType: mimeOf(name)));
    await sb.from('messages').insert({'sender_id': me, 'receiver_id': peer, 'text': '', 'kind': kind, 'file_path': path, 'file_name': name});
  }

  void refreshPerson(String id, Map<String, dynamic> p) {
    people[id] = p;
    notifyListeners();
  }

  bool _marking = false;
  Future<void> markRead(String peer) async {
    if (_marking) return;
    _marking = true;
    try {
      await sb.from('messages').update({'read_at': DateTime.now().toUtc().toIso8601String()}).eq('sender_id', peer).eq('receiver_id', me!).isFilter('read_at', null);
    } catch (_) {}
    _marking = false;
  }

  Future<void> rename(String v) async {
    await sb.from('profiles').update({'name': v}).eq('id', me!);
    people[me!] = {...people[me!]!, 'name': v};
    notifyListeners();
  }
}

final store = Store();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  ErrorWidget.builder = (d) => Material(
        color: Colors.white,
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text('خطا در نمایش:\n${d.exceptionAsString()}', textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.red, fontSize: 12)),
          ),
        ),
      );
  try {
    await cy.load();
    await ai.load();
    await settings.load();
    await loadAppLang();
  } catch (_) {}
  runApp(const Boot());
}

// برنامه بلافاصله باز می‌شود و اتصال به سرور در پس‌زمینه انجام می‌شود (به‌جای صفحه‌ی سفید)
class Boot extends StatefulWidget {
  const Boot({super.key});
  @override
  State<Boot> createState() => _BootState();
}

class _BootState extends State<Boot> {
  bool ready = false, slow = false;
  String? err;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    init();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> init() async {
    setState(() {
      err = null;
      slow = false;
    });
    _t?.cancel();
    _t = Timer(const Duration(seconds: 8), () {
      if (mounted) setState(() => slow = true);
    });
    const url = String.fromEnvironment('SUPABASE_URL');
    const key = String.fromEnvironment('SUPABASE_ANON_KEY');
    if (url.isEmpty || key.isEmpty) {
      setState(() => err = trn('آدرس یا کلید سرور هنگام ساخت برنامه وارد نشده است.'));
      return;
    }
    try {
      await Supabase.initialize(url: url, anonKey: key);
      if (mounted) setState(() => ready = true);
    } catch (e) {
      if (mounted) setState(() => err = trf('اتصال به سرور برقرار نشد.\n{0}', [e]));
    }
    _t?.cancel();
  }

  @override
  Widget build(BuildContext context) {
    if (ready) return const App();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Tia',
      theme: buildTheme(),
      builder: (c, w) => Directionality(textDirection: appDir, child: CyberStage(child: w!)),
      home: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              cy.enabled ? const CyberLogoBlock(signup: false) : ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/icon.png', width: 96)),
              const SizedBox(height: 20),
              if (err == null) const CircularProgressIndicator(),
              if (err == null && slow)
                Padding(
                  padding: const EdgeInsets.only(top: 16),
                  child: Text(trn('اتصال به سرور کند است…\nاینترنت یا VPN را بررسی کنید.'), textAlign: TextAlign.center, style: TextStyle(color: cTextDim)),
                ),
              if (err != null) ...[
                Text(err!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent)),
                const SizedBox(height: 16),
                FilledButton(onPressed: init, child: Text(trn('تلاش دوباره'))),
              ],
            ]),
          ),
        ),
      ),
    );
  }
}

class App extends StatefulWidget {
  const App({super.key});
  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    if (settings.themeMode == 0) settings.refresh();
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: settings,
        builder: (context, _) => MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Tia',
          scaffoldMessengerKey: messengerKey,
          navigatorKey: navKey,
          theme: buildTheme(),
          builder: (c, w) => MediaQuery(
            data: MediaQuery.of(c).copyWith(textScaler: TextScaler.linear(settings.textScale)),
            child: Directionality(textDirection: appDir, child: CyberStage(child: LockGate(child: NetShell(child: w!)))),
          ),
          home: ValueListenableBuilder<bool>(
            valueListenable: Accounts.switching,
            builder: (c, sw, _) => sw
                ? const Scaffold(body: Center(child: CircularProgressIndicator()))
                : StreamBuilder<AuthState>(
                    stream: sb.auth.onAuthStateChange,
                    builder: (c, _) {
                      if (sb.auth.currentSession == null) {
                        AuthTheme.enter();
                        return Theme(data: AuthTheme.data(), child: const LoginWithSaved(login: LoginPage()));
                      }
                      AuthTheme.leave();
                      return Home(key: ValueKey(sb.auth.currentUser?.id));
                    },
                  ),
          ),
        ),
      );
}

void aboutTia(BuildContext c) => showDialog(
      context: c,
      builder: (d) => AlertDialog(
        title: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.asset('assets/icon.png', width: 40)),
          const SizedBox(width: 12),
          const Text('Tia'),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(trn('نسخه‌ی 1.4.0')),
          SizedBox(height: 8),
          Text(trn('تمامی حقوق این برنامه برای Taha در گلاید محفوظ است.')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(d), child: Text(trn('بستن')))],
      ),
    );

Future<String?> inputDialog(BuildContext c, String title, String label, [String init = '', bool phone = false]) {
  final t = TextEditingController(text: init);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(controller: t, keyboardType: phone ? TextInputType.phone : null, decoration: fieldDeco(labelText: label)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: Text(trn('انصراف'))),
        FilledButton(
          onPressed: () {
            if (t.text.trim().isNotEmpty) Navigator.pop(c, t.text.trim().replaceAll(' ', ''));
          },
          child: Text(trn('تایید')),
        ),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext c, String text) async =>
    await showDialog<bool>(
      context: c,
      builder: (_) => AlertDialog(
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(trn('خیر'))),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(trn('بله'))),
        ],
      ),
    ) ??
    false;

Widget avatar(String name) =>
    CircleAvatar(backgroundColor: primary, foregroundColor: cOnPrimary, child: Text(name.isEmpty ? '?' : name[0]));

void snack(BuildContext c, String t) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t)));

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int i = settings.startTab.clamp(0, 4);
  Timer? _beat;
  @override
  void initState() {
    super.initState();
    sb.rpc('touch_seen').catchError((_) {});
    _beat = Timer.periodic(const Duration(seconds: 60), (_) => sb.rpc('touch_seen').catchError((_) {}));
    store.start();
    gs.start();
    rx.start();
    safety.load().catchError((_) {});
    recoveryReminder();
    outbox.load().whenComplete(net.start);
    TiaPush.instance.start();
    Accounts.init();
    e2ee.init().then((_) {
      if (e2ee.ready) store.resubscribe();
    });
    onboardTick.addListener(_onboard);
    WidgetsBinding.instance.addPostFrameCallback((_) => _onboard());
  }

  void _onboard() {
    if (mounted) maybeShowOnboarding(context);
  }

  @override
  void dispose() {
    onboardTick.removeListener(_onboard);
    _beat?.cancel();
    net.stop();
    store.stop();
    gs.stop();
    rx.stop();
    safety.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: AnimatedSwitcher(
          duration: const Duration(milliseconds: 260),
          switchInCurve: Curves.easeOutCubic,
          transitionBuilder: (w, a) => FadeTransition(opacity: a, child: SlideTransition(position: Tween<Offset>(begin: const Offset(0, 0.02), end: Offset.zero).animate(a), child: w)),
          child: KeyedSubtree(key: ValueKey(i), child: const [FeedTab(), ChatsTab(), AiTab(), ContactsTab(), SettingsTab()][i]),
        ),
        bottomNavigationBar: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
            child: Container(
              decoration: BoxDecoration(
                color: card,
                borderRadius: BorderRadius.circular(34),
                border: Border.all(color: cLine),
                boxShadow: isDark ? [] : const [BoxShadow(color: Color(0x1A000000), blurRadius: 22, offset: Offset(0, 8))],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(34),
                child: MediaQuery.removePadding(
                  context: context,
                  removeBottom: true,
                  child: NavigationBar(
                    height: 64,
                    labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
                    selectedIndex: i,
                    onDestinationSelected: (v) => setState(() => i = v),
                    destinations: [
                      NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: trn('خانه')),
                      NavigationDestination(icon: Icon(Icons.chat_bubble_outline_rounded), selectedIcon: Icon(Icons.chat_bubble_rounded), label: trn('چت‌ها')),
                      NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: trn('هوش')),
                      NavigationDestination(icon: Icon(Icons.people_outline_rounded), selectedIcon: Icon(Icons.people_rounded), label: trn('مخاطبین')),
                      NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: trn('تنظیمات')),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}

class ContactsTab extends StatefulWidget {
  const ContactsTab({super.key});
  @override
  State<ContactsTab> createState() => _ContactsTabState();
}

class _ContactsTabState extends State<ContactsTab> {
  String q = '';
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final ids = store.contactIds.where((id) => store.name(id).contains(q) || (store.phones[id] ?? '').contains(q) || ((store.people[id]?['username'] as String?) ?? '').contains(q)).toList();
          return Scaffold(
            appBar: AppBar(
              title: Text(trn('مخاطبین')),
              actions: [IconButton(icon: const Icon(Icons.sync), tooltip: trn('همگام‌سازی با مخاطبین گوشی'), onPressed: () => syncContacts(context))],
            ),
            body: Column(children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  onChanged: (v) => setState(() => q = v),
                  decoration: fieldDeco(prefixIcon: Icon(Icons.search), hintText: trn('جستجو...')),
                ),
              ),
              Expanded(
                child: ids.isEmpty
                    ? Center(child: Text(trn('مخاطبی نیست. با دکمه‌ی پایین (شماره یا نام کاربری) اضافه کنید، یا با دکمه‌ی همگام‌سازی بالا از مخاطبین گوشی بیاورید.')))
                    : ListView.builder(
                        itemCount: ids.length,
                        itemBuilder: (c, n) {
                          final id = ids[n];
                          return ListTile(
                            leading: avatarFor(id),
                            title: Text(store.name(id)),
                            subtitle: Text(store.phones[id] ?? ((store.people[id]?['username'] as String?) == null ? '' : '@${store.people[id]!['username']}'), style: TextStyle(color: accent)),
                            onTap: () => openChat(c, id),
                            onLongPress: () async {
                              if (await confirm(c, trf('مخاطب «{0}» حذف شود؟', [store.name(id)]))) store.removeContact(id);
                            },
                          );
                        },
                      ),
              ),
            ]),
            floatingActionButton: FloatingActionButton(
              backgroundColor: primary,
              foregroundColor: cOnPrimary,
              child: const Icon(Icons.person_add),
              onPressed: () async {
                final p = await inputDialog(context, trn('مخاطب جدید'), trn('شماره موبایل یا نام کاربری'));
                if (p == null) return;
                String? e;
                try {
                  e = await store.addContact(p);
                } catch (_) {
                  e = trn('خطا در ارتباط با سرور');
                }
                if (e != null && context.mounted) snack(context, e);
              },
            ),
          );
        },
      );
}

Widget settingsSection(String title, List<Widget> kids) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (title.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8, right: 4), child: Text(title, style: TextStyle(color: accent, fontWeight: FontWeight.w700))),
        Material(
          color: card,
          elevation: isDark ? 0 : 1.5,
          shadowColor: Colors.black26,
          borderRadius: BorderRadius.circular(settings.cardRadius),
          clipBehavior: Clip.antiAlias,
          child: Column(children: kids),
        ),
      ]),
    );

/// صفحه‌ی زیرمجموعه‌ی تنظیمات (برای دسته‌بندی مثل تلگرام/بله)
class SettingsSubPage extends StatelessWidget {
  final String title;
  final List<Widget> Function(BuildContext c) kids;
  const SettingsSubPage(this.title, this.kids, {super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: ListenableBuilder(
          listenable: Listenable.merge([settings, store]),
          builder: (c, _) => ListView(padding: const EdgeInsets.only(bottom: 24), children: kids(c)),
        ),
      );
}

List<Widget> _notifKids(BuildContext c) => [
      settingsSection(trn('اعلان‌ها'), [
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_none),
                  title: Text(trn('اعلان پیام جدید')),
                  value: settings.notifications,
                  onChanged: (v) {
                    settings.notifications = v;
                    settings.save();
                    TiaPush.instance.sync();
                  },
                ),
                const PushSettingsTile(),
                const PushInstantSwitch(),
                SwitchListTile(
                  secondary: const Icon(Icons.volume_up_outlined),
                  title: Text(trn('صدای پیام')),
                  value: settings.sound,
                  onChanged: (v) {
                    settings.sound = v;
                    settings.save();
                  },
                ),
                    ]),
    ];

List<Widget> _privacyKids(BuildContext c) => [
      settingsSection(trn('حریم خصوصی'), [
                ListTile(
                  leading: const Icon(Icons.visibility_outlined),
                  title: Text(trn('چه کسانی شماره‌ی من را ببینند؟')),
                  subtitle: Text(phoneVisLabel(store.people[me ?? '']?['phone_visibility'] as String?)),
                  onTap: () => choosePhoneVisibility(c),
                ),
                ListTile(
                  leading: const Icon(Icons.person_add_alt),
                  title: Text(trn('درخواست‌های دنبال‌کردن')),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const RequestsPage())),
                ),
                ListTile(
                  leading: const Icon(Icons.block),
                  title: Text(trn('کاربران مسدودشده')),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const BlockedPage())),
                ),
                ListTile(
                  leading: const Icon(Icons.access_time),
                  title: Text(trn('چه کسانی آخرین بازدید من را ببینند؟')),
                  subtitle: Text(phoneVisLabel(store.people[me ?? '']?['last_seen_visibility'] as String?)),
                  onTap: () => chooseLastSeen(c),
                ),
                ListTile(
                  leading: const Icon(Icons.lock_outline),
                  title: Text(trn('قفل برنامه با رمز')),
                  subtitle: Text(lockEnabled() ? trn('فعال') : trn('غیرفعال')),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const AppLockPage())),
                ),
                    ]),
      settingsSection(trn('امنیت حساب'), [
                ListTile(
                  leading: const Icon(Icons.password),
                  title: Text(trn('تغییر رمز عبور')),
                  onTap: () => changePasswordFlow(c),
                ),
                ListTile(
                  leading: const Icon(Icons.key_rounded),
                  title: Text(trn('کد بازیابی رمز عبور')),
                  subtitle: Text(trn('ساخت کد جدید (کد قبلی باطل می‌شود)')),
                  onTap: () async {
                    if (await confirm(c, trn('کد بازیابی جدید ساخته شود؟ کد قبلی دیگر کار نمی‌کند.'))) {
                      if (c.mounted) await createRecoveryCode(c);
                    }
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.devices_rounded),
                  title: Text(trn('دستگاه‌های متصل')),
                  subtitle: Text(trn('مشاهده و خروج دستگاه‌ها')),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const SessionsPage())),
                ),
                ListTile(
                  leading: const Icon(Icons.devices_other),
                  title: Text(trn('خروج از سایر دستگاه‌ها')),
                  onTap: () => logoutOthersFlow(c),
                ),
                ListTile(
                  leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
                  title: Text(trn('حذف حساب کاربری'), style: TextStyle(color: Colors.redAccent)),
                  onTap: () => deleteAccountFlow(c),
                ),
                    ]),
    ];

List<Widget> _appearanceKids(BuildContext c) => [
      settingsSection(trn('ظاهر'), [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: SizedBox(
                    width: double.infinity,
                    child: SegmentedButton<int>(
                      showSelectedIcon: false,
                      segments: [
                        ButtonSegment(value: 0, label: Text(trn('خودکار')), icon: Icon(Icons.brightness_auto)),
                        ButtonSegment(value: 1, label: Text(trn('روز')), icon: Icon(Icons.light_mode)),
                        ButtonSegment(value: 2, label: Text(trn('شب')), icon: Icon(Icons.dark_mode)),
                      ],
                      selected: {settings.themeMode},
                      onSelectionChanged: (s) {
                        settings.themeMode = s.first;
                        settings.save();
                      },
                    ),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.blur_on),
                  title: Text(trn('استودیوی سایبر')),
                  subtitle: Text(trn('رنگ نئون، حباب، پس‌زمینه متحرک، جلوه‌ی ورود و تم‌های ذخیره‌شده')),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const CyberStudioPage())),
                ),
                ListTile(
                  leading: const Icon(Icons.palette_outlined),
                  title: Text(trn('شخصی‌سازی کامل ظاهر')),
                  subtitle: Text(trn('رنگ، پس‌زمینه، والپیپر چت، حباب پیام و بیشتر')),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const AppearancePage())),
                ),
                ListTile(
                  title: Text(trn('اندازه‌ی متن برنامه')),
                  subtitle: Slider(
                    value: settings.textScale,
                    min: 0.8,
                    max: 1.3,
                    divisions: 5,
                    onChanged: (v) {
                      settings.textScale = v;
                      settings.save();
                    },
                  ),
                ),
                    ]),
      settingsSection(trn('شروع برنامه'), [
                ListTile(
                  leading: const Icon(Icons.flag_rounded),
                  title: Text(trn('صفحه‌ی شروع')),
                  subtitle: Text([trn('خانه'), trn('چت‌ها'), trn('هوش'), trn('مخاطبین'), trn('تنظیمات')][settings.startTab.clamp(0, 4)]),
                  onTap: () async {
                    final v = await showDialog<int>(
                      context: c,
                      builder: (dc) => SimpleDialog(
                        title: Text(trn('برنامه از کدام بخش باز شود؟')),
                        children: [
                          for (var k = 0; k < 5; k++)
                            SimpleDialogOption(
                              onPressed: () => Navigator.pop(dc, k),
                              child: Row(children: [
                                Icon(settings.startTab == k ? Icons.radio_button_checked : Icons.radio_button_off, color: primary),
                                const SizedBox(width: 12),
                                Text([trn('خانه'), trn('چت‌ها'), trn('هوش'), trn('مخاطبین'), trn('تنظیمات')][k], style: const TextStyle(fontSize: 16)),
                              ]),
                            ),
                        ],
                      ),
                    );
                    if (v != null) {
                      settings.startTab = v;
                      settings.save();
                    }
                  },
                ),
                    ]),
    ];

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  Widget _row(BuildContext c, IconData i, String title, String? sub, Widget Function() page) => ListTile(
        leading: Icon(i, color: accent),
        title: Text(title),
        subtitle: sub == null ? null : Text(sub, style: const TextStyle(fontSize: 12)),
        trailing: const Icon(Icons.chevron_left),
        onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => page())),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('تنظیمات'))),
        body: ListenableBuilder(
          listenable: Listenable.merge([settings, store]),
          builder: (c, _) {
            final mine = store.people[me ?? ''];
            final nm = (mine?['name'] as String?) ?? '';
            final un = (mine?['username'] as String?) ?? '';
            return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: Material(
                  borderRadius: BorderRadius.circular(settings.cardRadius + 4),
                  clipBehavior: Clip.antiAlias,
                  color: Colors.transparent,
                  child: Ink(
                    decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [primary, Color.lerp(primary, isDark ? Colors.black : Colors.white, 0.25)!])),
                    child: InkWell(
                      onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => ProfilePage(me!))),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(children: [
                          avatarFor(me ?? '', r: 30),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(nm, style: TextStyle(color: cOnPrimary, fontSize: 18, fontWeight: FontWeight.w800)),
                              if (un.isNotEmpty) Text('@$un', style: TextStyle(color: cOnPrimary)),
                              Text(store.phones[me ?? ''] ?? '', style: TextStyle(color: cOnPrimary), textDirection: TextDirection.ltr),
                            ]),
                          ),
                          Icon(Icons.chevron_left, color: cOnPrimary),
                        ]),
                      ),
                    ),
                  ),
                ),
              ),
              settingsSection('', [
                _row(c, Icons.switch_account_outlined, trn('حساب‌ها'), trn('جابه‌جایی بین چند حساب و افزودن حساب'), () => const AccountsPage()),
                ListTile(
                  leading: Icon(Icons.language, color: accent),
                  title: Text(trn('زبان برنامه')),
                  subtitle: Text(appLang == 'en' ? 'English' : trn('فارسی'), style: const TextStyle(fontSize: 12)),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => showLanguageDialog(c),
                ),
                _row(c, Icons.smart_toy_outlined, trn('دستیار هوشمند'), trn('خلاصه، ترجمه، پاسخ به هر سوال'), () => const AiTab()),
                _row(c, Icons.notifications_none, trn('اعلان‌ها و صدا'), null, () => SettingsSubPage(trn('اعلان‌ها و صدا'), _notifKids)),
                _row(c, Icons.lock_outline, trn('حریم خصوصی و امنیت'), trn('شماره، آخرین بازدید، قفل برنامه، دستگاه‌ها'), () => SettingsSubPage(trn('حریم خصوصی و امنیت'), _privacyKids)),
                _row(c, Icons.palette_outlined, trn('ظاهر و شخصی‌سازی'), trn('تم، رنگ، اندازه‌ی متن، صفحه‌ی شروع'), () => SettingsSubPage(trn('ظاهر و شخصی‌سازی'), _appearanceKids)),
                _row(c, Icons.lock_outline_rounded, trn('رمزنگاری سرتاسری'), trn('امنیت پیام‌های خصوصی'), () => const E2eeInfoPage()),
                _row(c, Icons.subtitles_outlined, trn('هوش روی گوشی'), trn('ترجمه، خلاصه، پیشنهاد پاسخ و ویس به متن'), () => const AiSettingsPage()),
                _row(c, Icons.bookmark_border, trn('پست‌های ذخیره‌شده'), null, () => PostListPage(trn('ذخیره‌شده‌ها'), savedPosts)),
              ]),
              settingsSection('', [
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: Text(trn('درباره‌ی Tia')),
                  onTap: () => aboutTia(c),
                ),
                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.redAccent),
                  title: Text(trn('خروج از حساب')),
                  onTap: () async {
                    if (await confirm(c, trn('از حساب خارج می‌شوید؟'))) {
                      await TiaPush.instance.unregister();
                      await Accounts.logoutCurrent();
                    }
                  },
                ),
              ]),
            ]);
          },
        ),
      );
}

class ImageBubble extends StatelessWidget {
  final String path;
  const ImageBubble(this.path, {super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
        future: store.urlFor(path),
        builder: (c, s) {
          if (s.hasError) return const Icon(Icons.broken_image);
          if (!s.hasData) return const SizedBox(width: 200, height: 140, child: Center(child: CircularProgressIndicator()));
          final url = s.data!;
          return GestureDetector(
            onTap: () => Navigator.push(
              c,
              MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(), body: Center(child: InteractiveViewer(child: Image.network(url))))),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(url, width: 220, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
            ),
          );
        },
      );
}

class VoiceBubble extends StatefulWidget {
  final String path;
  final String? wave;
  const VoiceBubble(this.path, {this.wave, super.key});
  @override
  State<VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<VoiceBubble> {
  final player = AudioPlayer();
  bool playing = false;
  Duration pos = Duration.zero, dur = Duration.zero;
  double rate = 1.0;
  final _subs = <StreamSubscription>[];

  @override
  void initState() {
    super.initState();
    _subs.add(player.onPlayerStateChanged.listen((s) {
      if (mounted) setState(() => playing = s == PlayerState.playing);
    }));
    _subs.add(player.onPositionChanged.listen((p) {
      if (mounted) setState(() => pos = p);
    }));
    _subs.add(player.onDurationChanged.listen((d) {
      if (mounted) setState(() => dur = d);
    }));
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    player.dispose();
    super.dispose();
  }

  Future<void> toggle() async {
    if (playing) {
      await player.pause();
    } else if (player.state == PlayerState.paused) {
      await player.resume();
    } else {
      try {
        await player.play(UrlSource(await store.urlFor(widget.path)));
        await player.setPlaybackRate(rate);
      } catch (_) {
        if (mounted) snack(context, trn('پخش نشد'));
      }
    }
  }

  Future<void> cycleRate() async {
    final next = rate == 1.0 ? 1.5 : rate == 1.5 ? 2.0 : 1.0;
    setState(() => rate = next);
    try {
      await player.setPlaybackRate(next);
    } catch (_) {}
  }

  String fmt(Duration d) => '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final fg = IconTheme.of(context).color ?? cText;
    final max = dur.inMilliseconds <= 0 ? 1.0 : dur.inMilliseconds.toDouble();
    final v = pos.inMilliseconds.clamp(0, max.toInt()).toDouble();
    final bars = decodeWave(widget.wave, widget.path);
    final prog = max <= 1.0 ? 0.0 : (v / max).clamp(0.0, 1.0);
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(
      width: 240,
      child: Row(children: [
        InkWell(onTap: toggle, child: Icon(playing ? Icons.pause_circle : Icons.play_circle, size: 40)),
        const SizedBox(width: 6),
        Expanded(child: WaveBars(bars: bars, progress: prog, color: fg, onSeek: (x) => player.seek(Duration(milliseconds: (x * max).toInt())))),
        const SizedBox(width: 6),
        Column(mainAxisSize: MainAxisSize.min, children: [
          Text(fmt(playing || pos > Duration.zero ? pos : dur), style: const TextStyle(fontSize: 11)),
          InkWell(onTap: cycleRate, child: Text('${rate == rate.roundToDouble() ? rate.toInt() : rate}x', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))),
        ]),
      ]),
    ),
      VoiceTranscript(widget.path),
    ]);
  }
}

class FileBubble extends StatelessWidget {
  final String path, name;
  const FileBubble(this.path, this.name, {super.key});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: () async {
          try {
            await launchUrl(Uri.parse(await store.urlFor(path)), mode: LaunchMode.externalApplication);
          } catch (_) {
            if (context.mounted) snack(context, trn('باز نشد'));
          }
        },
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.insert_drive_file),
          const SizedBox(width: 8),
          Flexible(child: Text(name, style: const TextStyle(decoration: TextDecoration.underline))),
        ]),
      );
}
