import 'package:flutter/material.dart';

const primary = Color(0xFF7B5CFF);
const accent = Color(0xFFC8B4FF);
const bg = Color(0xFF0B0B14);

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'tia',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(
            primary: primary,
            secondary: accent,
            surface: bg,
            onSurface: Colors.white,
          ),
          appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: Colors.white, surfaceTintColor: Colors.transparent),
          dividerColor: const Color(0xFF1C1C2E),
        ),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: const ChatList(),
      );
}

class Msg {
  final String text;
  final bool mine;
  Msg(this.text, this.mine);
}

final contacts = ['علی رضایی', 'مریم احمدی', 'گروه دوستان', 'سارا کریمی', 'پشتیبانی'];
final Map<String, List<Msg>> store = {for (var c in contacts) c: []};

class ChatList extends StatefulWidget {
  const ChatList({super.key});
  @override
  State<ChatList> createState() => _ChatListState();
}

class _ChatListState extends State<ChatList> {
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Row(children: [
            ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/icon.png', width: 32, height: 32)),
            const SizedBox(width: 10),
            const Text('tia'),
          ]),
        ),
        body: ListView.separated(
          itemCount: contacts.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (c, i) {
            final name = contacts[i];
            final last = store[name]!.isEmpty ? 'پیامی نیست' : store[name]!.last.text;
            return ListTile(
              leading: CircleAvatar(backgroundColor: primary, foregroundColor: Colors.white, child: Text(name[0])),
              title: Text(name),
              subtitle: Text(last, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: accent)),
              onTap: () async {
                await Navigator.push(c, MaterialPageRoute(builder: (_) => ChatPage(name)));
                setState(() {});
              },
            );
          },
        ),
      );
}

class ChatPage extends StatefulWidget {
  final String name;
  const ChatPage(this.name, {super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctrl = TextEditingController();
  List<Msg> get msgs => store[widget.name]!;

  void send() {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    setState(() => msgs.add(Msg(t, true)));
    ctrl.clear();
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) setState(() => msgs.add(Msg('پیام شما دریافت شد ✅', false)));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.name)),
        body: Column(children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: msgs.length,
              itemBuilder: (c, i) {
                final m = msgs[i];
                return Align(
                  alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: m.mine ? primary : const Color(0xFF1C1C2E),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(m.text, style: const TextStyle(color: Colors.white)),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    controller: ctrl,
                    onSubmitted: (_) => send(),
                    decoration: const InputDecoration(hintText: 'پیام بنویسید...', border: OutlineInputBorder()),
                  ),
                ),
                IconButton(icon: const Icon(Icons.send), onPressed: send),
              ]),
            ),
          ),
        ]),
      );
}
