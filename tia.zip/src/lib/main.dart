import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const primary = Color(0xFF7B5CFF);
const accent = Color(0xFFC8B4FF);
const bg = Color(0xFF0B0B14);
const card = Color(0xFF1C1C2E);

final messengerKey = GlobalKey<ScaffoldMessengerState>();
SupabaseClient get sb => Supabase.instance.client;
String? get me => sb.auth.currentUser?.id;

String hm(String iso) {
  final t = DateTime.parse(iso).toLocal();
  return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
}

class Settings extends ChangeNotifier {
  bool notifications = true, sound = true;
  double textScale = 1.0;
  late SharedPreferences _p;
  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    notifications = _p.getBool('notif') ?? true;
    sound = _p.getBool('sound') ?? true;
    textScale = _p.getDouble('scale') ?? 1.0;
  }

  void save() {
    _p.setBool('notif', notifications);
    _p.setBool('sound', sound);
    _p.setDouble('scale', textScale);
    notifyListeners();
  }
}

final settings = Settings();

class Store extends ChangeNotifier {
  List<Map<String, dynamic>> msgs = [];
  final people = <String, Map<String, dynamic>>{};
  List<String> contactIds = [];
  StreamSubscription? _sub;
  int _lastId = -1;
  bool _first = true;

  String peerOf(Map<String, dynamic> m) => (m['sender_id'] == me ? m['receiver_id'] : m['sender_id']) as String;
  String name(String id) => (people[id]?['name'] as String?) ?? 'کاربر';
  List<Map<String, dynamic>> msgsWith(String peer) => msgs.where((m) => peerOf(m) == peer).toList();

  Future<void> start() async {
    stop();
    _first = true;
    _lastId = -1;
    await loadPeople([me!]);
    await loadContacts();
    _sub = sb.from('messages').stream(primaryKey: ['id']).order('created_at').listen((rows) async {
      msgs = rows;
      await loadPeople(rows.map(peerOf));
      if (rows.isNotEmpty) {
        final l = rows.last;
        if (!_first && (l['id'] as int) > _lastId && l['receiver_id'] == me && settings.notifications) {
          messengerKey.currentState?.showSnackBar(SnackBar(content: Text('پیام جدید از ${name(l['sender_id'] as String)}')));
        }
        _lastId = l['id'] as int;
      }
      _first = false;
      notifyListeners();
    });
  }

  void stop() {
    _sub?.cancel();
    _sub = null;
    msgs = [];
    people.clear();
    contactIds = [];
  }

  Future<void> loadPeople(Iterable<String> ids) async {
    final missing = ids.where((i) => !people.containsKey(i)).toSet().toList();
    if (missing.isEmpty) return;
    final rows = await sb.from('profiles').select().inFilter('id', missing);
    for (final r in rows) {
      people[r['id'] as String] = r;
    }
  }

  Future<void> loadContacts() async {
    final rows = await sb.from('contacts').select('contact_id').eq('owner_id', me!);
    contactIds = rows.map((r) => r['contact_id'] as String).toList();
    await loadPeople(contactIds);
    notifyListeners();
  }

  Future<String?> addContact(String phone) async {
    final r = await sb.from('profiles').select().eq('phone', phone).maybeSingle();
    if (r == null) return 'کاربری با این شماره ثبت‌نام نکرده است';
    if (r['id'] == me) return 'این شماره‌ی خودتان است';
    people[r['id'] as String] = r;
    await sb.from('contacts').upsert({'owner_id': me, 'contact_id': r['id']});
    await loadContacts();
    return null;
  }

  Future<void> removeContact(String id) async {
    await sb.from('contacts').delete().eq('owner_id', me!).eq('contact_id', id);
    await loadContacts();
  }

  Future<void> send(String peer, String text) => sb.from('messages').insert({'sender_id': me, 'receiver_id': peer, 'text': text});

  Future<void> rename(String v) async {
    await sb.from('profiles').update({'name': v}).eq('id', me!);
    people[me!] = {...people[me!]!, 'name': v};
    notifyListeners();
  }
}

final store = Store();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await settings.load();
  await Supabase.initialize(
    url: const String.fromEnvironment('SUPABASE_URL'),
    anonKey: const String.fromEnvironment('SUPABASE_ANON_KEY'),
  );
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: settings,
        builder: (context, _) => MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'tia',
          scaffoldMessengerKey: messengerKey,
          theme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.dark,
            scaffoldBackgroundColor: bg,
            colorScheme: const ColorScheme.dark(primary: primary, secondary: accent, surface: bg, onSurface: Colors.white),
            appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: Colors.white, surfaceTintColor: Colors.transparent),
            navigationBarTheme: const NavigationBarThemeData(backgroundColor: card, indicatorColor: primary),
            dividerColor: card,
          ),
          builder: (c, w) => MediaQuery(
            data: MediaQuery.of(c).copyWith(textScaler: TextScaler.linear(settings.textScale)),
            child: Directionality(textDirection: TextDirection.rtl, child: w!),
          ),
          home: StreamBuilder<AuthState>(
            stream: sb.auth.onAuthStateChange,
            builder: (c, _) => sb.auth.currentSession == null ? const LoginPage() : const Home(),
          ),
        ),
      );
}

Future<String?> inputDialog(BuildContext c, String title, String label, [String init = '', bool phone = false]) {
  final t = TextEditingController(text: init);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(controller: t, keyboardType: phone ? TextInputType.phone : null, decoration: InputDecoration(labelText: label)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('انصراف')),
        FilledButton(
          onPressed: () {
            if (t.text.trim().isNotEmpty) Navigator.pop(c, t.text.trim().replaceAll(' ', ''));
          },
          child: const Text('تایید'),
        ),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext c, String text) async =>
    await showDialog<bool>(
      context: c,
      builder: (_) => AlertDialog(
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('خیر')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('بله')),
        ],
      ),
    ) ??
    false;

Widget avatar(String name) =>
    CircleAvatar(backgroundColor: primary, foregroundColor: Colors.white, child: Text(name.isEmpty ? '?' : name[0]));

void snack(BuildContext c, String t) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(t)));

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool signup = false, busy = false;
  String? err;
  final phone = TextEditingController(), name = TextEditingController(), pass = TextEditingController();

  Future<void> submit() async {
    final p = phone.text.trim().replaceAll(' ', '');
    if (p.length < 10 || pass.text.length < 6 || (signup && name.text.trim().isEmpty)) {
      setState(() => err = 'شماره (حداقل ۱۰ رقم)، رمز (حداقل ۶ کاراکتر) و نام را کامل وارد کنید');
      return;
    }
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final email = '$p@tia.chat';
      if (signup) {
        final r = await sb.auth.signUp(email: email, password: pass.text);
        if (r.session == null) throw 'confirm';
        await sb.from('profiles').insert({'id': r.user!.id, 'phone': p, 'name': name.text.trim()});
      } else {
        await sb.auth.signInWithPassword(email: email, password: pass.text);
      }
    } catch (e) {
      err = e == 'confirm' ? 'در Supabase گزینه‌ی Confirm email را خاموش کنید' : 'ناموفق بود. اطلاعات و اینترنت را بررسی کنید.\n$e';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/icon.png', width: 110)),
              const SizedBox(height: 24),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره موبایل', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              if (signup) ...[
                TextField(controller: name, decoration: const InputDecoration(labelText: 'نام', border: OutlineInputBorder())),
                const SizedBox(height: 12),
              ],
              TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'رمز عبور', border: OutlineInputBorder())),
              if (err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(err!, style: const TextStyle(color: Colors.redAccent))),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: busy ? null : submit, child: Text(busy ? '...' : (signup ? 'ثبت‌نام' : 'ورود'))),
              ),
              TextButton(
                onPressed: () => setState(() => signup = !signup),
                child: Text(signup ? 'حساب دارید؟ وارد شوید' : 'حساب ندارید؟ ثبت‌نام کنید'),
              ),
            ]),
          ),
        ),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int i = 0;
  @override
  void initState() {
    super.initState();
    store.start();
  }

  @override
  void dispose() {
    store.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: const [ChatsTab(), ContactsTab(), SettingsTab()][i],
        bottomNavigationBar: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (v) => setState(() => i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'چت‌ها'),
            NavigationDestination(icon: Icon(Icons.people_outline), label: 'مخاطبین'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'تنظیمات'),
          ],
        ),
      );
}

Future<void> openChat(BuildContext c, String id) => Navigator.push(c, MaterialPageRoute(builder: (_) => ChatPage(id)));

class ChatsTab extends StatelessWidget {
  const ChatsTab({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final last = <String, Map<String, dynamic>>{};
          for (final m in store.msgs) {
            last[store.peerOf(m)] = m;
          }
          final ids = last.keys.toList()..sort((a, b) => (last[b]!['created_at'] as String).compareTo(last[a]!['created_at'] as String));
          return Scaffold(
            appBar: AppBar(
              title: Row(children: [
                ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/icon.png', width: 32, height: 32)),
                const SizedBox(width: 10),
                const Text('tia'),
              ]),
            ),
            body: ids.isEmpty
                ? const Center(child: Text('هنوز گفتگویی ندارید.\nاز دکمه‌ی پایین پیام جدید بفرستید.', textAlign: TextAlign.center))
                : ListView.separated(
                    itemCount: ids.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (c, n) {
                      final id = ids[n], m = last[id]!;
                      return ListTile(
                        leading: avatar(store.name(id)),
                        title: Text(store.name(id)),
                        subtitle: Text(m['text'] as String, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: accent)),
                        trailing: Text(hm(m['created_at'] as String), style: const TextStyle(fontSize: 12)),
                        onTap: () => openChat(c, id),
                      );
                    },
                  ),
            floatingActionButton: FloatingActionButton(
              backgroundColor: primary,
              foregroundColor: Colors.white,
              child: const Icon(Icons.edit),
              onPressed: () async {
                final id = await showModalBottomSheet<String>(
                  context: context,
                  builder: (c) => Directionality(
                    textDirection: TextDirection.rtl,
                    child: ListView(children: [
                      const ListTile(title: Text('ارسال پیام به...')),
                      if (store.contactIds.isEmpty) const ListTile(title: Text('ابتدا از بخش مخاطبین، مخاطب اضافه کنید')),
                      for (final id in store.contactIds) ListTile(leading: avatar(store.name(id)), title: Text(store.name(id)), onTap: () => Navigator.pop(c, id)),
                    ]),
                  ),
                );
                if (id != null && context.mounted) openChat(context, id);
              },
            ),
          );
        },
      );
}

class ContactsTab extends StatefulWidget {
  const ContactsTab({super.key});
  @override
  State<ContactsTab> createState() => _ContactsTabState();
}

class _ContactsTabState extends State<ContactsTab> {
  String q = '';
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final ids = store.contactIds.where((id) => store.name(id).contains(q) || ((store.people[id]?['phone'] as String?) ?? '').contains(q)).toList();
          return Scaffold(
            appBar: AppBar(title: const Text('مخاطبین')),
            body: Column(children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  onChanged: (v) => setState(() => q = v),
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'جستجو...', border: OutlineInputBorder()),
                ),
              ),
              Expanded(
                child: ids.isEmpty
                    ? const Center(child: Text('مخاطبی نیست. با دکمه‌ی پایین، با شماره اضافه کنید.'))
                    : ListView.builder(
                        itemCount: ids.length,
                        itemBuilder: (c, n) {
                          final id = ids[n];
                          return ListTile(
                            leading: avatar(store.name(id)),
                            title: Text(store.name(id)),
                            subtitle: Text((store.people[id]?['phone'] as String?) ?? '', style: const TextStyle(color: accent)),
                            onTap: () => openChat(c, id),
                            onLongPress: () async {
                              if (await confirm(c, 'مخاطب «${store.name(id)}» حذف شود؟')) store.removeContact(id);
                            },
                          );
                        },
                      ),
              ),
            ]),
            floatingActionButton: FloatingActionButton(
              backgroundColor: primary,
              foregroundColor: Colors.white,
              child: const Icon(Icons.person_add),
              onPressed: () async {
                final p = await inputDialog(context, 'مخاطب جدید', 'شماره موبایل', '', true);
                if (p == null) return;
                String? e;
                try {
                  e = await store.addContact(p);
                } catch (_) {
                  e = 'خطا در ارتباط با سرور';
                }
                if (e != null && context.mounted) snack(context, e);
              },
            ),
          );
        },
      );
}

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('تنظیمات')),
        body: ListenableBuilder(
          listenable: Listenable.merge([settings, store]),
          builder: (c, _) {
            final mine = store.people[me ?? ''];
            final nm = (mine?['name'] as String?) ?? '';
            return ListView(children: [
              ListTile(
                leading: avatar(nm),
                title: Text(nm),
                subtitle: Text((mine?['phone'] as String?) ?? ''),
                trailing: const Icon(Icons.edit),
                onTap: () async {
                  final v = await inputDialog(c, 'ویرایش نام', 'نام', nm);
                  if (v != null) store.rename(v);
                },
              ),
              const Divider(),
              SwitchListTile(
                title: const Text('اعلان پیام جدید'),
                value: settings.notifications,
                onChanged: (v) {
                  settings.notifications = v;
                  settings.save();
                },
              ),
              SwitchListTile(
                title: const Text('صدای پیام'),
                value: settings.sound,
                onChanged: (v) {
                  settings.sound = v;
                  settings.save();
                },
              ),
              ListTile(
                title: const Text('اندازه‌ی متن'),
                subtitle: Slider(
                  value: settings.textScale,
                  min: 0.8,
                  max: 1.3,
                  divisions: 5,
                  onChanged: (v) {
                    settings.textScale = v;
                    settings.save();
                  },
                ),
              ),
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('درباره‌ی tia'),
                onTap: () => showAboutDialog(context: c, applicationName: 'tia', applicationVersion: '1.0.0'),
              ),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.redAccent),
                title: const Text('خروج از حساب'),
                onTap: () async {
                  if (await confirm(c, 'از حساب خارج می‌شوید؟')) await sb.auth.signOut();
                },
              ),
            ]);
          },
        ),
      );
}

class ChatPage extends StatefulWidget {
  final String peer;
  const ChatPage(this.peer, {super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctrl = TextEditingController();

  Future<void> send() async {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    ctrl.clear();
    try {
      await store.send(widget.peer, t);
    } catch (_) {
      if (mounted) snack(context, 'ارسال نشد. اینترنت را بررسی کنید.');
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) {
          final list = store.msgsWith(widget.peer).reversed.toList();
          return Scaffold(
            appBar: AppBar(title: Text(store.name(widget.peer))),
            body: Column(children: [
              Expanded(
                child: ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(12),
                  itemCount: list.length,
                  itemBuilder: (c, n) {
                    final m = list[n];
                    final mine = m['sender_id'] == me;
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(color: mine ? primary : card, borderRadius: BorderRadius.circular(14)),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
                          Text(m['text'] as String, style: const TextStyle(color: Colors.white)),
                          Text(hm(m['created_at'] as String), style: const TextStyle(color: accent, fontSize: 10)),
                        ]),
                      ),
                    );
                  },
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Row(children: [
                    Expanded(
                      child: TextField(
                        controller: ctrl,
                        onSubmitted: (_) => send(),
                        decoration: const InputDecoration(hintText: 'پیام بنویسید...', border: OutlineInputBorder()),
                      ),
                    ),
                    IconButton(icon: const Icon(Icons.send, color: primary), onPressed: send),
                  ]),
                ),
              ),
            ]),
          );
        },
      );
}
