import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'main.dart';
import 'social.dart';
import 'l10n.dart';

class VideoBubble extends StatelessWidget {
  final String path;
  const VideoBubble(this.path, {super.key});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPage(path))),
        child: Container(
          width: 220,
          height: 130,
          decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(12)),
          child: const Center(child: Icon(Icons.play_circle_fill, size: 52, color: Colors.white)),
        ),
      );
}

class VideoPage extends StatefulWidget {
  final String path;
  const VideoPage(this.path, {super.key});
  @override
  State<VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  VideoPlayerController? c;
  String? err;

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    try {
      final url = await store.urlFor(widget.path);
      final ctl = VideoPlayerController.networkUrl(Uri.parse(url));
      await ctl.initialize();
      ctl.addListener(() {
        if (mounted) setState(() {});
      });
      if (!mounted) {
        ctl.dispose();
        return;
      }
      setState(() => c = ctl);
      await ctl.play();
    } catch (_) {
      if (mounted) setState(() => err = trn('ویدئو پخش نشد'));
    }
  }

  @override
  void dispose() {
    c?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ctl = c;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
      body: Center(
        child: ctl == null
            ? (err != null ? Text(err!, style: const TextStyle(color: Colors.white)) : const CircularProgressIndicator())
            : Column(mainAxisSize: MainAxisSize.min, children: [
                AspectRatio(aspectRatio: ctl.value.aspectRatio, child: VideoPlayer(ctl)),
                VideoProgressIndicator(ctl, allowScrubbing: true, padding: const EdgeInsets.all(12)),
                IconButton(
                  icon: Icon(ctl.value.isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 38),
                  onPressed: () => ctl.value.isPlaying ? ctl.pause() : ctl.play(),
                ),
              ]),
      ),
    );
  }
}

class SharedMediaPage extends StatelessWidget {
  final String title;
  final List<Map<String, dynamic>> msgs;
  const SharedMediaPage(this.title, this.msgs, {super.key});

  Future<void> openUrl(String u) async {
    try {
      await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  Widget empty() => Center(child: Text(trn('موردی نیست')));

  @override
  Widget build(BuildContext context) {
    final rev = msgs.reversed.toList();
    final images = rev.where((m) => kindOf(m) == 'image').toList();
    final videos = rev.where((m) => kindOf(m) == 'video').toList();
    final files = rev.where((m) => kindOf(m) == 'file').toList();
    final voices = rev.where((m) => kindOf(m) == 'audio').toList();
    final links = <String>[];
    for (final m in rev) {
      if (kindOf(m) != 'text') continue;
      for (final x in RegExp(r'https?://[^\s]+').allMatches(m['text'] as String)) {
        links.add(x.group(0)!);
      }
    }
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          title: Text(title),
          bottom: TabBar(isScrollable: true, tabs: [Tab(text: trn('عکس')), Tab(text: trn('ویدئو')), Tab(text: trn('فایل')), Tab(text: trn('لینک')), Tab(text: trn('صدا'))]),
        ),
        body: TabBarView(children: [
          images.isEmpty
              ? empty()
              : GridView.builder(
                  padding: const EdgeInsets.all(8),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 4, crossAxisSpacing: 4),
                  itemCount: images.length,
                  itemBuilder: (c, i) => FutureBuilder<String>(
                    future: store.urlFor(images[i]['file_path'] as String),
                    builder: (c, s) {
                      if (!s.hasData) return Container(color: card);
                      final url = s.data!;
                      return GestureDetector(
                        onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(), body: Center(child: InteractiveViewer(child: Image.network(url)))))),
                        child: Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: card)),
                      );
                    },
                  ),
                ),
          videos.isEmpty
              ? empty()
              : ListView(children: [
                  for (final m in videos)
                    ListTile(
                      leading: const Icon(Icons.play_circle_outline),
                      title: Text((m['file_name'] as String?) ?? trn('ویدئو')),
                      subtitle: Text(hm(m['created_at'] as String)),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPage(m['file_path'] as String))),
                    ),
                ]),
          files.isEmpty
              ? empty()
              : ListView(children: [
                  for (final m in files)
                    ListTile(
                      leading: const Icon(Icons.insert_drive_file_outlined),
                      title: Text((m['file_name'] as String?) ?? trn('فایل')),
                      subtitle: Text(hm(m['created_at'] as String)),
                      onTap: () async => openUrl(await store.urlFor(m['file_path'] as String)),
                    ),
                ]),
          links.isEmpty
              ? empty()
              : ListView(children: [
                  for (final l in links) ListTile(leading: const Icon(Icons.link), title: Text(l, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr), onTap: () => openUrl(l)),
                ]),
          voices.isEmpty
              ? empty()
              : ListView(padding: const EdgeInsets.all(12), children: [
                  for (final m in voices) Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: VoiceBubble(m['file_path'] as String)),
                ]),
        ]),
      ),
    );
  }
}


class LocationBubble extends StatelessWidget {
  final String coords;
  const LocationBubble(this.coords, {super.key});

  Future<void> open() async {
    final p = coords.split(',');
    if (p.length != 2) return;
    final lat = p[0].trim(), lng = p[1].trim();
    for (final u in ['geo:$lat,$lng?q=$lat,$lng', 'https://www.openstreetmap.org/?mlat=$lat&mlon=$lng#map=16/$lat/$lng']) {
      try {
        if (await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication)) return;
      } catch (_) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    final fg = IconTheme.of(context).color ?? cText;
    return InkWell(
      onTap: open,
      child: Container(
        width: 230,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Color.lerp(Colors.transparent, fg, 0.12), borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          const Icon(Icons.location_on, size: 38),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(trn('موقعیت مکانی'), style: TextStyle(fontWeight: FontWeight.bold)),
              Text(coords, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 11)),
              Text(trn('برای باز کردن در نقشه لمس کنید'), style: TextStyle(fontSize: 11)),
            ]),
          ),
        ]),
      ),
    );
  }
}

class ContactBubble extends StatefulWidget {
  final String uid;
  const ContactBubble(this.uid, {super.key});
  @override
  State<ContactBubble> createState() => _ContactBubbleState();
}

class _ContactBubbleState extends State<ContactBubble> {
  @override
  void initState() {
    super.initState();
    store.loadPeople([widget.uid]).then((_) {
      if (mounted) setState(() {});
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    final un = (store.people[widget.uid]?['username'] as String?) ?? '';
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(widget.uid))),
      child: SizedBox(
        width: 230,
        child: Row(children: [
          avatarFor(widget.uid, r: 22),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(store.name(widget.uid), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(un.isEmpty ? trn('مخاطب') : '@$un', style: const TextStyle(fontSize: 12)),
            ]),
          ),
        ]),
      ),
    );
  }
}
