import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'l10n.dart';
import 'main.dart';

/// دستیار هوشمند Tia: سوال را از طریق Edge Function «tia-ai» (روی Supabase) به یک مدل زبانی می‌فرستد.
/// گفتگوها و «حافظه» روی همین گوشی (جدا برای هر حساب) ذخیره می‌شوند.

class AiMsg {
  final bool mine;
  final String text;
  const AiMsg(this.mine, this.text);
  Map<String, dynamic> toJson() => {'m': mine ? 1 : 0, 't': text};
  static AiMsg fromJson(Map<String, dynamic> j) => AiMsg(j['m'] == 1, (j['t'] as String?) ?? '');
}

class AiChat {
  final String id;
  String title;
  int updated;
  final List<AiMsg> msgs;
  AiChat(this.id, this.title, this.updated, this.msgs);
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'u': updated, 'msgs': [for (final m in msgs) m.toJson()]};
  static AiChat fromJson(Map<String, dynamic> j) => AiChat(
        j['id'] as String,
        (j['title'] as String?) ?? '',
        (j['u'] as int?) ?? 0,
        [for (final m in (j['msgs'] as List? ?? const [])) AiMsg.fromJson(Map<String, dynamic>.from(m as Map))],
      );
}

class AiStore extends ChangeNotifier {
  AiStore._();
  static final AiStore I = AiStore._();
  static const maxChats = 60, maxMsgs = 200, maxMemory = 20;

  List<AiChat> chats = [];
  List<String> memory = [];
  bool memoryOn = true;
  String? _uid;
  bool loaded = false;

  String get _kChats => 'ai_chats_${me ?? 'x'}';
  String get _kMem => 'ai_memory_${me ?? 'x'}';
  String get _kMemOn => 'ai_memory_on_${me ?? 'x'}';

  Future<void> load() async {
    if (loaded && _uid == me) return;
    _uid = me;
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString(_kChats);
      chats = raw == null ? [] : [for (final e in jsonDecode(raw) as List) AiChat.fromJson(Map<String, dynamic>.from(e as Map))];
      memory = p.getStringList(_kMem) ?? [];
      memoryOn = p.getBool(_kMemOn) ?? true;
    } catch (_) {
      chats = [];
      memory = [];
    }
    loaded = true;
    notifyListeners();
  }

  Future<void> save() async {
    try {
      chats.sort((a, b) => b.updated.compareTo(a.updated));
      if (chats.length > maxChats) chats.removeRange(maxChats, chats.length);
      final p = await SharedPreferences.getInstance();
      await p.setString(_kChats, jsonEncode([for (final c in chats) c.toJson()]));
      await p.setStringList(_kMem, memory);
      await p.setBool(_kMemOn, memoryOn);
    } catch (_) {}
    notifyListeners();
  }

  void refresh() => notifyListeners();

  AiChat create() => AiChat(DateTime.now().microsecondsSinceEpoch.toRadixString(36), '', DateTime.now().millisecondsSinceEpoch, []);

  Future<void> remove(AiChat c) async {
    chats.removeWhere((x) => x.id == c.id);
    await save();
  }

  Future<void> addMemory(String s) async {
    final t = s.trim();
    if (t.isEmpty) return;
    memory.removeWhere((x) => x == t);
    memory.add(t.length > 200 ? t.substring(0, 200) : t);
    if (memory.length > maxMemory) memory.removeAt(0);
    await save();
  }

  Future<void> removeMemory(int i) async {
    if (i >= 0 && i < memory.length) memory.removeAt(i);
    await save();
  }

  Future<void> setMemoryOn(bool v) async {
    memoryOn = v;
    await save();
  }
}

// «یادت باشه …» یا «remember …» به‌طور خودکار در حافظه ذخیره می‌شود
final _rememberRe = RegExp(r'^\s*(?:یادت\s*باشه|یادت\s*باشد|به\s*خاطر\s*بسپار|بخاطر\s*بسپار|remember(?:\s+that)?)\s*[:،,\-]?\s*(.{3,})$', caseSensitive: false, dotAll: true);

String _stamp(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  final n = DateTime.now();
  String two(int x) => x.toString().padLeft(2, '0');
  if (d.year == n.year && d.month == n.month && d.day == n.day) return '${two(d.hour)}:${two(d.minute)}';
  return '${d.month}/${d.day}';
}

/// تب «هوش»: فهرست گفتگوها با دستیار
class AiTab extends StatefulWidget {
  const AiTab({super.key});
  @override
  State<AiTab> createState() => _AiTabState();
}

class _AiTabState extends State<AiTab> {
  @override
  void initState() {
    super.initState();
    AiStore.I.load();
  }

  void open(AiChat? c) => Navigator.push(context, MaterialPageRoute(builder: (_) => AiChatPage(chat: c))).then((_) => AiStore.I.refresh());

  void actions(AiChat c) => showModalBottomSheet(
        context: context,
        builder: (bc) => SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: Text(trn('تغییر نام')),
              onTap: () async {
                Navigator.pop(bc);
                final ctl = TextEditingController(text: c.title);
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (d) => AlertDialog(
                    title: Text(trn('تغییر نام')),
                    content: TextField(controller: ctl, maxLength: 60, autofocus: true),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(d, false), child: Text(trn('انصراف'))),
                      TextButton(onPressed: () => Navigator.pop(d, true), child: Text(trn('تایید'))),
                    ],
                  ),
                );
                if (ok == true && ctl.text.trim().isNotEmpty) {
                  c.title = ctl.text.trim();
                  await AiStore.I.save();
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
              title: Text(trn('حذف گفتگو'), style: const TextStyle(color: Colors.redAccent)),
              onTap: () async {
                Navigator.pop(bc);
                if (await confirm(context, trn('این گفتگو حذف شود؟'))) await AiStore.I.remove(c);
              },
            ),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(trn('هوش تیا')),
          actions: [
            IconButton(
              tooltip: trn('حافظه‌ی دستیار'),
              icon: const Icon(Icons.psychology_alt_outlined),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiMemoryPage())),
            ),
            IconButton(tooltip: trn('گفتگوی جدید'), icon: const Icon(Icons.add_comment_outlined), onPressed: () => open(null)),
          ],
        ),
        body: ListenableBuilder(
          listenable: AiStore.I,
          builder: (c, _) {
            final l = AiStore.I.chats;
            if (!AiStore.I.loaded) return const Center(child: CircularProgressIndicator());
            if (l.isEmpty) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.auto_awesome, size: 56, color: accent),
                    const SizedBox(height: 14),
                    Text(trn('سلام! من دستیار هوشمند تیا هستم. هر سوالی داری بپرس 🌟'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, height: 1.6)),
                    const SizedBox(height: 18),
                    FilledButton.icon(onPressed: () => open(null), icon: const Icon(Icons.add), label: Text(trn('گفتگوی جدید'))),
                  ]),
                ),
              );
            }
            return ListView(padding: const EdgeInsets.only(bottom: 110), children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 6),
                child: Row(children: [
                  Text(trn('گفتگوها'), style: TextStyle(color: cTextDim, fontWeight: FontWeight.w700)),
                  const SizedBox(width: 6),
                  Text('${l.length}', style: TextStyle(color: cTextFaint)),
                ]),
              ),
              for (final ch in l)
                ListTile(
                  leading: CircleAvatar(backgroundColor: accent.withOpacity(0.15), child: Icon(Icons.auto_awesome, color: accent, size: 20)),
                  title: Text(ch.title.isEmpty ? trn('گفتگوی جدید') : ch.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: ch.msgs.isEmpty ? null : Text(ch.msgs.last.text.replaceAll('\n', ' '), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: cTextFaint, fontSize: 12)),
                  trailing: Text(_stamp(ch.updated), style: TextStyle(color: cTextFaint, fontSize: 11)),
                  onTap: () => open(ch),
                  onLongPress: () => actions(ch),
                ),
            ]);
          },
        ),
      );
}

/// صفحه‌ی گفتگو با دستیار
class AiChatPage extends StatefulWidget {
  final AiChat? chat;
  const AiChatPage({super.key, this.chat});
  @override
  State<AiChatPage> createState() => _AiChatPageState();
}

class _AiChatPageState extends State<AiChatPage> {
  late final AiChat chat = widget.chat ?? AiStore.I.create();
  final input = TextEditingController();
  final scroll = ScrollController();
  bool busy = false;

  @override
  void initState() {
    super.initState();
    AiStore.I.load();
    WidgetsBinding.instance.addPostFrameCallback((_) => _toEnd(jump: true));
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  void _toEnd({bool jump = false}) => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!scroll.hasClients) return;
        if (jump) {
          scroll.jumpTo(scroll.position.maxScrollExtent);
        } else {
          scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
        }
      });

  String _errText(Object e) {
    if (e is FunctionException) {
      if (e.status == 429) {
        final d = e.details;
        if (d is Map && d['error'] == 'busy') return trn('ظرفیت رایگان سرویس مدل الان پر است؛ چند دقیقه بعد دوباره امتحان کنید.');
        return trn('سهمیه‌ی امروز تمام شده؛ فردا دوباره امتحان کنید.');
      }
      if (e.status == 503) return trn('دستیار هوشمند هنوز روی سرور راه‌اندازی نشده است.');
    }
    final code = e is FunctionException ? '${e.status}' : e.runtimeType.toString();
    return '${trn('پاسخ دریافت نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.')} [$code]';
  }

  Future<void> _persist() async {
    final st = AiStore.I;
    if (!st.chats.any((c) => c.id == chat.id)) st.chats.add(chat);
    if (chat.msgs.length > AiStore.maxMsgs) chat.msgs.removeRange(0, chat.msgs.length - AiStore.maxMsgs);
    chat.updated = DateTime.now().millisecondsSinceEpoch;
    await st.save();
  }

  Future<void> send() async {
    final t = input.text.trim();
    if (t.isEmpty || busy) return;
    final st = AiStore.I;
    await st.load();
    setState(() {
      chat.msgs.add(AiMsg(true, t));
      if (chat.title.isEmpty) chat.title = t.length > 40 ? '${t.substring(0, 40)}…' : t;
      input.clear();
      busy = true;
    });
    _toEnd();
    // «یادت باشه ...» => ذخیره در حافظه
    final m = st.memoryOn ? _rememberRe.firstMatch(t) : null;
    if (m != null) {
      await st.addMemory(m.group(1)!);
      if (mounted) snack(context, trn('✅ در حافظه‌ی دستیار ذخیره شد'));
    }
    await _persist();
    try {
      final hist = chat.msgs.length > 12 ? chat.msgs.sublist(chat.msgs.length - 12) : chat.msgs;
      final body = {
        'messages': [for (final x in hist) {'role': x.mine ? 'user' : 'assistant', 'content': x.text}],
        if (st.memoryOn && st.memory.isNotEmpty) 'memory': st.memory,
      };
      final res = await sb.functions.invoke('tia-ai', body: body).timeout(const Duration(seconds: 90));
      final data = res.data;
      final answer = data is Map ? (data['answer'] as String?) : null;
      if (answer == null || answer.isEmpty) throw 'empty';
      if (mounted) setState(() => chat.msgs.add(AiMsg(false, answer)));
    } catch (e) {
      if (mounted) setState(() => chat.msgs.add(AiMsg(false, '⚠️ ${_errText(e)}')));
    } finally {
      await _persist();
      if (mounted) setState(() => busy = false);
      _toEnd();
    }
  }

  Widget _bubble(AiMsg m) => Align(
        alignment: m.mine ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
        child: GestureDetector(
          onLongPress: () {
            Clipboard.setData(ClipboardData(text: m.text));
            snack(context, trn('کپی شد'));
          },
          child: Container(
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.84),
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: bubbleDeco(m.mine),
            child: SelectableText(m.text, style: TextStyle(color: bubbleFg(m.mine), height: 1.5, fontSize: 15)),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(chat.title.isEmpty ? trn('دستیار هوشمند') : chat.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          actions: [
            IconButton(
              tooltip: trn('حافظه‌ی دستیار'),
              icon: const Icon(Icons.psychology_alt_outlined),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiMemoryPage())),
            ),
          ],
        ),
        body: Column(children: [
          Expanded(
            child: chat.msgs.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.auto_awesome, size: 54, color: accent),
                        const SizedBox(height: 14),
                        Text(trn('سلام! من دستیار هوشمند تیا هستم. هر سوالی داری بپرس 🌟'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, height: 1.6)),
                      ]),
                    ),
                  )
                : ListView(controller: scroll, padding: const EdgeInsets.only(top: 8, bottom: 8), children: [
                    for (final m in chat.msgs) _bubble(m),
                    if (busy)
                      Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(children: [
                          const SizedBox(width: 6),
                          const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                          const SizedBox(width: 10),
                          Text(trn('در حال فکر کردن…'), style: TextStyle(color: cTextDim)),
                        ]),
                      ),
                  ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 2),
            child: Text(trn('پاسخ هوش مصنوعی ممکن است اشتباه باشد؛ برای موارد مهم بررسی کنید.'), style: TextStyle(fontSize: 11, color: cTextFaint)),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 4, 10, 8),
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Expanded(
                  child: TextField(
                    controller: input,
                    minLines: 1,
                    maxLines: 5,
                    maxLength: 4000,
                    textInputAction: TextInputAction.newline,
                    decoration: fieldDeco(hintText: trn('پیام خود را بنویسید...'), radius: 24).copyWith(counterText: ''),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: busy ? null : send, icon: const Icon(Icons.send_rounded)),
              ]),
            ),
          ),
        ]),
      );
}

/// حافظه‌ی دستیار: مواردی که دستیار در همه‌ی گفتگوها به خاطر دارد
class AiMemoryPage extends StatefulWidget {
  const AiMemoryPage({super.key});
  @override
  State<AiMemoryPage> createState() => _AiMemoryPageState();
}

class _AiMemoryPageState extends State<AiMemoryPage> {
  final input = TextEditingController();

  @override
  void initState() {
    super.initState();
    AiStore.I.load();
  }

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('حافظه‌ی دستیار'))),
        body: ListenableBuilder(
          listenable: AiStore.I,
          builder: (c, _) {
            final st = AiStore.I;
            return Column(children: [
              SwitchListTile(
                title: Text(trn('حافظه فعال')),
                subtitle: Text(trn('دستیار موارد زیر را در همه‌ی گفتگوها به خاطر دارد. این موارد فقط روی همین گوشی ذخیره می‌شوند و همراه سوال‌ها به سرویس مدل فرستاده می‌شوند.'), style: const TextStyle(fontSize: 12)),
                value: st.memoryOn,
                onChanged: st.setMemoryOn,
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Text(trn('نکته: در گفتگو بنویسید «یادت باشه …» تا خودکار اینجا ذخیره شود.'), style: TextStyle(fontSize: 12, color: cTextFaint)),
              ),
              Expanded(
                child: st.memory.isEmpty
                    ? Center(child: Text(trn('حافظه خالی است'), style: TextStyle(color: cTextFaint)))
                    : ListView(children: [
                        for (var i = 0; i < st.memory.length; i++)
                          ListTile(
                            leading: Icon(Icons.bookmark_outline, color: accent),
                            title: Text(st.memory[i]),
                            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => st.removeMemory(i)),
                          ),
                      ]),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10, 4, 10, 8),
                  child: Row(children: [
                    Expanded(child: TextField(controller: input, maxLength: 200, decoration: fieldDeco(hintText: trn('به خاطر بسپار...'), radius: 24).copyWith(counterText: ''))),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      icon: const Icon(Icons.add),
                      onPressed: () async {
                        final t = input.text;
                        input.clear();
                        await st.addMemory(t);
                      },
                    ),
                  ]),
                ),
              ),
            ]);
          },
        ),
      );
}
