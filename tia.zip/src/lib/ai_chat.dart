import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'l10n.dart';
import 'main.dart';

/// دستیار هوشمند Tia: هر سوالی را از طریق Edge Function «tia-ai» (روی Supabase) به یک مدل زبانی می‌فرستد.
class _AiMsg {
  final bool mine;
  final String text;
  const _AiMsg(this.mine, this.text);
}

class AiAssistantPage extends StatefulWidget {
  const AiAssistantPage({super.key});
  @override
  State<AiAssistantPage> createState() => _AiAssistantPageState();
}

class _AiAssistantPageState extends State<AiAssistantPage> {
  static final List<_AiMsg> _history = []; // تا بستن برنامه می‌ماند
  final input = TextEditingController();
  final scroll = ScrollController();
  bool busy = false;

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  void _toEnd() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      });

  String _errText(Object e) {
    if (e is FunctionException) {
      if (e.status == 429) {
        final d = e.details;
        if (d is Map && d['error'] == 'busy') return trn('ظرفیت رایگان سرویس مدل الان پر است؛ چند دقیقه بعد دوباره امتحان کنید.');
        return trn('سهمیه‌ی امروز تمام شده؛ فردا دوباره امتحان کنید.');
      }
      if (e.status == 503) return trn('دستیار هوشمند هنوز روی سرور راه‌اندازی نشده است.');
    }
    return trn('پاسخ دریافت نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.');
  }

  Future<void> send() async {
    final t = input.text.trim();
    if (t.isEmpty || busy) return;
    setState(() {
      _history.add(_AiMsg(true, t));
      input.clear();
      busy = true;
    });
    _toEnd();
    try {
      final msgs = [
        for (final m in _history.length > 12 ? _history.sublist(_history.length - 12) : _history) {'role': m.mine ? 'user' : 'assistant', 'content': m.text}
      ];
      final res = await sb.functions.invoke('tia-ai', body: {'messages': msgs}).timeout(const Duration(seconds: 60));
      final data = res.data;
      final answer = data is Map ? (data['answer'] as String?) : null;
      if (answer == null || answer.isEmpty) throw 'empty';
      if (mounted) setState(() => _history.add(_AiMsg(false, answer)));
    } catch (e) {
      if (mounted) setState(() => _history.add(_AiMsg(false, '⚠️ ${_errText(e)}')));
    } finally {
      if (mounted) setState(() => busy = false);
      _toEnd();
    }
  }

  Widget _bubble(_AiMsg m) => Align(
        alignment: m.mine ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
        child: GestureDetector(
          onLongPress: () {
            Clipboard.setData(ClipboardData(text: m.text));
            snack(context, trn('کپی شد'));
          },
          child: Container(
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.84),
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: bubbleDeco(m.mine),
            child: SelectableText(m.text, style: TextStyle(color: bubbleFg(m.mine), height: 1.5, fontSize: 15)),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(trn('دستیار هوشمند')),
          actions: [
            IconButton(
              tooltip: trn('گفتگوی جدید'),
              icon: const Icon(Icons.add_comment_outlined),
              onPressed: busy ? null : () => setState(_history.clear),
            ),
          ],
        ),
        body: Column(children: [
          Expanded(
            child: _history.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.auto_awesome, size: 54, color: accent),
                        const SizedBox(height: 14),
                        Text(trn('سلام! من دستیار هوشمند تیا هستم. هر سوالی داری بپرس 🌟'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, height: 1.6)),
                      ]),
                    ),
                  )
                : ListView(controller: scroll, padding: const EdgeInsets.only(top: 8, bottom: 8), children: [
                    for (final m in _history) _bubble(m),
                    if (busy)
                      Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(children: [
                          const SizedBox(width: 6),
                          const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                          const SizedBox(width: 10),
                          Text(trn('در حال فکر کردن…'), style: TextStyle(color: cTextDim)),
                        ]),
                      ),
                  ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 2),
            child: Text(trn('پاسخ هوش مصنوعی ممکن است اشتباه باشد؛ برای موارد مهم بررسی کنید.'), style: TextStyle(fontSize: 11, color: cTextFaint)),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 4, 10, 8),
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Expanded(
                  child: TextField(
                    controller: input,
                    minLines: 1,
                    maxLines: 5,
                    maxLength: 4000,
                    textInputAction: TextInputAction.newline,
                    decoration: fieldDeco(hintText: trn('پیام خود را بنویسید...'), radius: 24).copyWith(counterText: ''),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: busy ? null : send, icon: const Icon(Icons.send_rounded)),
              ]),
            ),
          ),
        ]),
      );
}
