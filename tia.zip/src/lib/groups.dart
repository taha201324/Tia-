import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'chat.dart';
import 'main.dart';
import 'social.dart';

const gCols = 'id,kind,title,description,owner_id,members_send_messages,members_send_media,members_send_links,created_at';

class GroupStore extends ChangeNotifier {
  final groups = <int, Map<String, dynamic>>{};
  final members = <int, List<Map<String, dynamic>>>{};
  List<Map<String, dynamic>> msgs = [];
  StreamSubscription? _s1, _s2;
  int _lastId = -1;
  bool _first = true;

  Map<String, dynamic>? myMember(int gid) {
    for (final m in members[gid] ?? <Map<String, dynamic>>[]) {
      if (m['user_id'] == me) return m;
    }
    return null;
  }

  String roleOf(int gid) => (myMember(gid)?['role'] as String?) ?? '';

  bool right(int gid, String r) {
    final m = myMember(gid);
    if (m == null) return false;
    if (m['role'] == 'owner') return true;
    if (m['role'] != 'admin') return false;
    switch (r) {
      case 'delete':
        return m['can_delete'] == true;
      case 'members':
        return m['can_manage_members'] == true;
      case 'info':
        return m['can_edit_info'] == true;
      case 'post':
        return m['can_post'] == true;
      default:
        return false;
    }
  }

  // kind: text | media | link
  bool canSend(int gid, String kind) {
    final g = groups[gid], m = myMember(gid);
    if (g == null || m == null) return false;
    if (g['kind'] == 'channel') return right(gid, 'post');
    if (m['role'] != 'member') return true;
    final mu = m['muted_until'] as String?;
    if (mu != null && DateTime.parse(mu).isAfter(DateTime.now())) return false;
    if (g['members_send_messages'] != true) return false;
    if (kind == 'media' && g['members_send_media'] != true) return false;
    if (kind == 'link' && g['members_send_links'] != true) return false;
    return true;
  }

  List<Map<String, dynamic>> msgsOf(int gid) => msgs.where((m) => m['group_id'] == gid).toList();

  void dropMsg(int id) {
    msgs.removeWhere((m) => m['id'] == id);
    notifyListeners();
  }

  Future<void> load() async {
    final gm = await sb.from('group_members').select();
    members.clear();
    for (final r in gm) {
      members.putIfAbsent(r['group_id'] as int, () => []).add(r);
    }
    groups.clear();
    if (members.isNotEmpty) {
      final g = await sb.from('groups').select(gCols).inFilter('id', members.keys.toList());
      for (final r in g) {
        groups[r['id'] as int] = r;
      }
    }
    await store.loadPeople(members.values.expand((l) => l).map((m) => m['user_id'] as String));
    notifyListeners();
  }

  Future<void> start() async {
    stop();
    _first = true;
    _lastId = -1;
    try {
      await load();
    } catch (_) {}
    _s1 = sb.from('group_members').stream(primaryKey: ['group_id', 'user_id']).listen((_) async {
      try {
        await load();
      } catch (_) {}
    }, onError: (_) {});
    _s2 = sb.from('group_messages').stream(primaryKey: ['id']).order('created_at').listen((rows) async {
      final sorted = [...rows]..sort((a, b) => (a['id'] as int).compareTo(b['id'] as int));
      msgs = sorted;
      await store.loadPeople(sorted.map((m) => m['sender_id'] as String));
      if (sorted.isNotEmpty) {
        final l = sorted.last;
        if (!_first && (l['id'] as int) > _lastId && l['sender_id'] != me && settings.notifications) {
          messengerKey.currentState?.showSnackBar(SnackBar(content: Text('پیام جدید در ${groups[l['group_id']]?['title'] ?? 'گروه'}')));
        }
        _lastId = l['id'] as int;
      }
      _first = false;
      notifyListeners();
    }, onError: (_) {});
  }

  void stop() {
    _s1?.cancel();
    _s2?.cancel();
    _s1 = _s2 = null;
    groups.clear();
    members.clear();
    msgs = [];
  }

  Future<int> create(String kind, String title, String desc, List<String> ids) async {
    final g = await sb.from('groups').insert({'kind': kind, 'title': title, 'description': desc, 'owner_id': me}).select(gCols).single();
    final gid = g['id'] as int;
    if (ids.isNotEmpty) {
      await sb.from('group_members').insert([for (final u in ids) {'group_id': gid, 'user_id': u, 'role': 'member'}]);
    }
    await load();
    return gid;
  }

  Future<void> sendMsg(int gid, Map<String, dynamic> d) => sb.from('group_messages').insert({'group_id': gid, 'sender_id': me, ...d});

  Future<void> addMembers(int gid, List<String> ids) async {
    await sb.from('group_members').insert([for (final u in ids) {'group_id': gid, 'user_id': u, 'role': 'member'}]);
    await load();
  }

  Future<void> removeMember(int gid, String uid) async {
    await sb.from('group_members').delete().eq('group_id', gid).eq('user_id', uid);
    await load();
  }

  Future<void> updateMember(int gid, String uid, Map<String, dynamic> d) async {
    await sb.from('group_members').update(d).eq('group_id', gid).eq('user_id', uid);
    await load();
  }

  Future<void> updateGroup(int gid, Map<String, dynamic> d) async {
    await sb.from('groups').update(d).eq('id', gid);
    await load();
  }

  Future<void> deleteGroup(int gid) async {
    await sb.from('groups').delete().eq('id', gid);
    await load();
  }
}

final gs = GroupStore();

Widget groupAvatar(int gid, {double r = 20}) {
  final ch = gs.groups[gid]?['kind'] == 'channel';
  return CircleAvatar(radius: r, backgroundColor: primary, foregroundColor: Colors.white, child: Icon(ch ? Icons.campaign : Icons.group));
}

Future<void> openGroup(BuildContext c, int gid) => Navigator.push(c, MaterialPageRoute(builder: (_) => ChatPage(gid: gid)));

String phoneVisLabel(String? v) => v == 'everybody' ? 'همه' : v == 'nobody' ? 'هیچ‌کس' : 'فقط مخاطبین من';

Future<void> choosePhoneVisibility(BuildContext c) async {
  final v = await showDialog<String>(
    context: c,
    builder: (d) => SimpleDialog(title: const Text('چه کسانی شماره‌ی من را ببینند؟'), children: [
      SimpleDialogOption(onPressed: () => Navigator.pop(d, 'everybody'), child: const Text('همه')),
      SimpleDialogOption(onPressed: () => Navigator.pop(d, 'contacts'), child: const Text('فقط مخاطبین من')),
      SimpleDialogOption(onPressed: () => Navigator.pop(d, 'nobody'), child: const Text('هیچ‌کس')),
    ]),
  );
  if (v == null) return;
  try {
    await sb.from('profiles').update({'phone_visibility': v}).eq('id', me!);
    store.refreshPerson(me!, {...store.people[me!]!, 'phone_visibility': v});
  } catch (_) {
    if (c.mounted) snack(c, 'ذخیره نشد');
  }
}

// ---------- chats list (direct + groups + channels) ----------
class ChatsTab extends StatelessWidget {
  const ChatsTab({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([store, gs]),
        builder: (context, _) {
          final last = <String, Map<String, dynamic>>{};
          for (final m in store.msgs) {
            last[store.peerOf(m)] = m;
          }
          final items = <Map<String, dynamic>>[];
          for (final e in last.entries) {
            items.add({'t': e.value['created_at'], 'u': e.key, 'sub': preview(e.value), 'time': e.value['created_at']});
          }
          for (final g in gs.groups.entries) {
            Map<String, dynamic>? lm;
            for (final m in gs.msgs) {
              if (m['group_id'] == g.key) lm = m;
            }
            items.add({
              't': lm?['created_at'] ?? g.value['created_at'],
              'g': g.key,
              'sub': lm == null ? 'گفتگوی جدید' : '${store.name(lm['sender_id'] as String)}: ${preview(lm)}',
              'time': lm?['created_at'],
            });
          }
          items.sort((a, b) => (b['t'] as String).compareTo(a['t'] as String));
          return Scaffold(
            appBar: AppBar(
              title: Row(children: [
                ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/icon.png', width: 32, height: 32)),
                const SizedBox(width: 10),
                const Text('Tia'),
              ]),
              actions: [IconButton(icon: const Icon(Icons.search), tooltip: 'جستجوی کاربر با نام کاربری', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage())))],
            ),
            body: items.isEmpty
                ? const Center(child: Text('هنوز گفتگویی ندارید.\nاز دکمه‌ی پایین شروع کنید.', textAlign: TextAlign.center))
                : ListView.separated(
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (c, n) {
                      final it = items[n];
                      final u = it['u'] as String?;
                      final g = it['g'] as int?;
                      return ListTile(
                        leading: u != null ? avatarFor(u) : groupAvatar(g!),
                        title: u != null ? nameWithBadge(u) : Text('${gs.groups[g]?['title']}'),
                        subtitle: Text(it['sub'] as String, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: accent)),
                        trailing: Text(it['time'] == null ? '' : hm(it['time'] as String), style: const TextStyle(fontSize: 12)),
                        onTap: () => u != null ? openChat(c, u) : openGroup(c, g!),
                      );
                    },
                  ),
            floatingActionButton: FloatingActionButton(
              backgroundColor: primary,
              foregroundColor: Colors.white,
              child: const Icon(Icons.edit),
              onPressed: () async {
                final r = await showModalBottomSheet<String>(
                  context: context,
                  builder: (c) => Directionality(
                    textDirection: TextDirection.rtl,
                    child: ListView(children: [
                      ListTile(leading: const Icon(Icons.group_add), title: const Text('گروه جدید'), onTap: () => Navigator.pop(c, 'group')),
                      ListTile(leading: const Icon(Icons.campaign), title: const Text('کانال جدید'), onTap: () => Navigator.pop(c, 'channel')),
                      const Divider(),
                      const ListTile(title: Text('ارسال پیام به...')),
                      if (store.contactIds.isEmpty) const ListTile(title: Text('ابتدا از بخش مخاطبین، مخاطب اضافه کنید')),
                      for (final id in store.contactIds) ListTile(leading: avatarFor(id), title: Text(store.name(id)), onTap: () => Navigator.pop(c, 'u:$id')),
                    ]),
                  ),
                );
                if (r == null || !context.mounted) return;
                if (r.startsWith('u:')) {
                  openChat(context, r.substring(2));
                } else {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => CreateGroupPage(r)));
                }
              },
            ),
          );
        },
      );
}

class CreateGroupPage extends StatefulWidget {
  final String kind;
  const CreateGroupPage(this.kind, {super.key});
  @override
  State<CreateGroupPage> createState() => _CreateGroupPageState();
}

class _CreateGroupPageState extends State<CreateGroupPage> {
  final title = TextEditingController(), desc = TextEditingController();
  final sel = <String>{};
  bool busy = false;

  Future<void> create() async {
    if (title.text.trim().isEmpty) return;
    setState(() => busy = true);
    try {
      final gid = await gs.create(widget.kind, title.text.trim(), desc.text.trim(), sel.toList());
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatPage(gid: gid)));
    } catch (_) {
      if (mounted) {
        snack(context, 'ساخته نشد. SQL گروه‌ها اجرا شده است؟');
        setState(() => busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ch = widget.kind == 'channel';
    return Scaffold(
      appBar: AppBar(title: Text(ch ? 'کانال جدید' : 'گروه جدید'), actions: [TextButton(onPressed: busy ? null : create, child: const Text('ساخت'))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: title, decoration: InputDecoration(labelText: ch ? 'نام کانال' : 'نام گروه', border: const OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: desc, maxLines: 2, decoration: const InputDecoration(labelText: 'توضیحات (اختیاری)', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        const Text('افزودن عضو از مخاطبین', style: TextStyle(fontWeight: FontWeight.bold)),
        if (store.contactIds.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('مخاطبی ندارید. بعداً هم می‌توانید عضو اضافه کنید.')),
        for (final id in store.contactIds)
          CheckboxListTile(
            secondary: avatarFor(id),
            title: Text(store.name(id)),
            value: sel.contains(id),
            onChanged: (v) => setState(() => v == true ? sel.add(id) : sel.remove(id)),
          ),
        if (busy) const LinearProgressIndicator(),
      ]),
    );
  }
}

// ---------- group / channel info + management ----------
Future<void> adminRightsDialog(BuildContext c, int gid, Map<String, dynamic> m) async {
  final r = <String, bool>{
    'can_delete': m['can_delete'] == true,
    'can_manage_members': m['can_manage_members'] == true,
    'can_edit_info': m['can_edit_info'] == true,
    'can_post': m['can_post'] == true,
  };
  const labels = {
    'can_delete': 'حذف پیام‌ها',
    'can_manage_members': 'مدیریت اعضا (افزودن، حذف، سکوت)',
    'can_edit_info': 'ویرایش اطلاعات و دسترسی‌ها',
    'can_post': 'ارسال پیام یا پست',
  };
  final ok = await showDialog<bool>(
    context: c,
    builder: (_) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: Text('دسترسی‌های ${store.name(m['user_id'] as String)}'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final k in r.keys) SwitchListTile(title: Text(labels[k]!), value: r[k]!, onChanged: (v) => set(() => r[k] = v)),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ذخیره')),
        ],
      ),
    ),
  );
  if (ok == true) {
    try {
      await gs.updateMember(gid, m['user_id'] as String, {'role': 'admin', ...r});
    } catch (e) {
      if (c.mounted) snack(c, errText(e));
    }
  }
}

class GroupInfoPage extends StatelessWidget {
  final int gid;
  const GroupInfoPage(this.gid, {super.key});

  Future<void> run(BuildContext c, Future<void> Function() f) async {
    try {
      await f();
    } catch (e) {
      if (c.mounted) snack(c, errText(e));
    }
  }

  Future<void> addMember(BuildContext c) async {
    final have = (gs.members[gid] ?? []).map((m) => m['user_id']).toSet();
    final cands = store.contactIds.where((id) => !have.contains(id)).toList();
    final id = await showModalBottomSheet<String>(
      context: c,
      builder: (sc) => Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(children: [
          const ListTile(title: Text('افزودن عضو')),
          if (cands.isEmpty) const ListTile(title: Text('مخاطب دیگری برای افزودن نیست')),
          for (final u in cands) ListTile(leading: avatarFor(u), title: Text(store.name(u)), onTap: () => Navigator.pop(sc, u)),
        ]),
      ),
    );
    if (id != null && c.mounted) await run(c, () => gs.addMembers(gid, [id]));
  }

  void memberMenu(BuildContext c, Map<String, dynamic> m, bool channel) {
    final uid = m['user_id'] as String;
    final role = m['role'] as String;
    final isOwner = gs.roleOf(gid) == 'owner';
    final canMembers = gs.right(gid, 'members');
    final canRemove = role != 'owner' && ((isOwner) || (canMembers && role == 'member')) && uid != me;
    Widget item(IconData i, String t, Future<void> Function() f, {Color? color}) => ListTile(
          leading: Icon(i, color: color),
          title: Text(t),
          onTap: () {
            Navigator.pop(c);
            run(c, f);
          },
        );
    showModalBottomSheet(
      context: c,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Wrap(children: [
          item(Icons.person, 'مشاهده‌ی پروفایل', () async => Navigator.push(c, MaterialPageRoute(builder: (_) => ProfilePage(uid)))),
          if (isOwner && role == 'member') item(Icons.admin_panel_settings, 'ارتقا به مدیر', () => adminRightsDialog(c, gid, m)),
          if (isOwner && role == 'admin') item(Icons.tune, 'تنظیم دسترسی‌های مدیر', () => adminRightsDialog(c, gid, m)),
          if (isOwner && role == 'admin') item(Icons.person_remove_alt_1, 'برکناری از مدیریت', () => gs.updateMember(gid, uid, {'role': 'member'})),
          if (!channel && canMembers && role == 'member') ...[
            item(Icons.volume_off, 'ساکت کردن به مدت ۱ ساعت', () => gs.updateMember(gid, uid, {'muted_until': DateTime.now().toUtc().add(const Duration(hours: 1)).toIso8601String()})),
            item(Icons.volume_off, 'ساکت کردن به مدت ۱ روز', () => gs.updateMember(gid, uid, {'muted_until': DateTime.now().toUtc().add(const Duration(days: 1)).toIso8601String()})),
            item(Icons.volume_up, 'لغو سکوت', () => gs.updateMember(gid, uid, {'muted_until': null})),
          ],
          if (canRemove) item(Icons.remove_circle_outline, 'حذف از ${channel ? 'کانال' : 'گروه'}', () => gs.removeMember(gid, uid), color: Colors.redAccent),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: gs,
        builder: (c, _) {
          final g = gs.groups[gid];
          if (g == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('این گفتگو دیگر در دسترس نیست')));
          final channel = g['kind'] == 'channel';
          final role = gs.roleOf(gid);
          final isOwner = role == 'owner';
          final canInfo = gs.right(gid, 'info');
          final canMembers = gs.right(gid, 'members');
          const order = {'owner': 0, 'admin': 1, 'member': 2};
          final list = [...(gs.members[gid] ?? <Map<String, dynamic>>[])]..sort((a, b) => order[a['role']]!.compareTo(order[b['role']]!));
          String roleLabel(Map<String, dynamic> m) {
            final base = m['role'] == 'owner' ? 'مالک' : m['role'] == 'admin' ? 'مدیر' : 'عضو';
            final mu = m['muted_until'] as String?;
            return (mu != null && DateTime.parse(mu).isAfter(DateTime.now())) ? '$base · ساکت‌شده' : base;
          }

          return Scaffold(
            appBar: AppBar(title: Text(channel ? 'اطلاعات کانال' : 'اطلاعات گروه')),
            body: ListView(children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  groupAvatar(gid, r: 44),
                  const SizedBox(height: 8),
                  Text('${g['title']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  if ((g['description'] as String).isNotEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(g['description'] as String, textAlign: TextAlign.center)),
                  Text('${list.length} عضو · مالک: ${store.name(g['owner_id'] as String)}', style: TextStyle(color: accent, fontSize: 12)),
                ]),
              ),
              if (canInfo) ...[
                ListTile(
                  leading: const Icon(Icons.edit),
                  title: const Text('ویرایش نام'),
                  onTap: () async {
                    final v = await inputDialog(c, 'ویرایش نام', 'نام', g['title'] as String);
                    if (v != null && c.mounted) await run(c, () => gs.updateGroup(gid, {'title': v}));
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.notes),
                  title: const Text('ویرایش توضیحات'),
                  onTap: () async {
                    final v = await inputDialog(c, 'ویرایش توضیحات', 'توضیحات', g['description'] as String);
                    if (v != null && c.mounted) await run(c, () => gs.updateGroup(gid, {'description': v}));
                  },
                ),
              ],
              if (!channel) ...[
                const Divider(),
                const Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 0), child: Text('دسترسی اعضا', style: TextStyle(fontWeight: FontWeight.bold))),
                for (final t in [
                  ['members_send_messages', 'اعضا بتوانند پیام بفرستند'],
                  ['members_send_media', 'اعضا بتوانند عکس، فایل و صدا بفرستند'],
                  ['members_send_links', 'اعضا بتوانند لینک بفرستند'],
                ])
                  SwitchListTile(
                    title: Text(t[1]),
                    value: g[t[0]] == true,
                    onChanged: canInfo ? (v) => run(c, () => gs.updateGroup(gid, {t[0]: v})) : null,
                  ),
              ],
              const Divider(),
              Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 0), child: Text('اعضا (${list.length})', style: const TextStyle(fontWeight: FontWeight.bold))),
              if (canMembers) ListTile(leading: const Icon(Icons.person_add), title: const Text('افزودن عضو'), onTap: () => addMember(c)),
              for (final m in list)
                ListTile(
                  leading: avatarFor(m['user_id'] as String),
                  title: nameWithBadge(m['user_id'] as String),
                  subtitle: Text(roleLabel(m), style: TextStyle(color: accent)),
                  trailing: m['user_id'] == me ? null : const Icon(Icons.more_vert),
                  onTap: m['user_id'] == me ? null : () => memberMenu(c, m, channel),
                ),
              const Divider(),
              if (!isOwner)
                ListTile(
                  leading: const Icon(Icons.exit_to_app, color: Colors.redAccent),
                  title: Text('ترک ${channel ? 'کانال' : 'گروه'}'),
                  onTap: () async {
                    if (await confirm(c, 'از ${channel ? 'کانال' : 'گروه'} خارج می‌شوید؟')) {
                      await run(c, () => gs.removeMember(gid, me!));
                      if (c.mounted) Navigator.popUntil(c, (r) => r.isFirst);
                    }
                  },
                ),
              if (isOwner)
                ListTile(
                  leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
                  title: Text('حذف ${channel ? 'کانال' : 'گروه'}'),
                  onTap: () async {
                    if (await confirm(c, 'همه‌ی پیام‌ها و اعضا حذف می‌شوند. مطمئن هستید؟')) {
                      await run(c, () => gs.deleteGroup(gid));
                      if (c.mounted) Navigator.popUntil(c, (r) => r.isFirst);
                    }
                  },
                ),
            ]),
          );
        },
      );
}
