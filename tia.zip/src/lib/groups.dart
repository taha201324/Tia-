import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'chat.dart';
import 'extras.dart';
import 'media.dart';
import 'msgsearch.dart';
import 'safety.dart';
import 'main.dart';
import 'social.dart';

const gCols = 'id,kind,title,description,owner_id,members_send_messages,members_send_media,members_send_links,slow_mode,avatar_path,created_at';

class GroupStore extends ChangeNotifier {
  final groups = <int, Map<String, dynamic>>{};
  final members = <int, List<Map<String, dynamic>>>{};
  List<Map<String, dynamic>> msgs = [];
  StreamSubscription? _s1, _s2;
  int _lastId = -1;
  bool _first = true;

  Map<String, dynamic>? myMember(int gid) {
    for (final m in members[gid] ?? <Map<String, dynamic>>[]) {
      if (m['user_id'] == me) return m;
    }
    return null;
  }

  String roleOf(int gid) => (myMember(gid)?['role'] as String?) ?? '';

  bool right(int gid, String r) {
    final m = myMember(gid);
    if (m == null) return false;
    if (m['role'] == 'owner') return true;
    if (m['role'] != 'admin') return false;
    switch (r) {
      case 'delete':
        return m['can_delete'] == true;
      case 'members':
        return m['can_manage_members'] == true;
      case 'info':
        return m['can_edit_info'] == true;
      case 'post':
        return m['can_post'] == true;
      default:
        return false;
    }
  }

  // kind: text | media | link
  bool canSend(int gid, String kind) {
    final g = groups[gid], m = myMember(gid);
    if (g == null || m == null) return false;
    if (g['kind'] == 'channel') return right(gid, 'post');
    if (m['role'] != 'member') return true;
    final mu = m['muted_until'] as String?;
    if (mu != null && DateTime.parse(mu).isAfter(DateTime.now())) return false;
    if (g['members_send_messages'] != true) return false;
    if (kind == 'media' && g['members_send_media'] != true) return false;
    if (kind == 'link' && g['members_send_links'] != true) return false;
    return true;
  }

  List<Map<String, dynamic>> msgsOf(int gid) => msgs.where((m) => m['group_id'] == gid && safety.visible('g', '$gid', m)).toList();

  void dropMsg(int id) {
    msgs.removeWhere((m) => m['id'] == id);
    notifyListeners();
  }

  Future<void> load() async {
    final gm = await sb.from('group_members').select();
    members.clear();
    for (final r in gm) {
      members.putIfAbsent(r['group_id'] as int, () => []).add(r);
    }
    groups.clear();
    if (members.isNotEmpty) {
      final g = await sb.from('groups').select(gCols).inFilter('id', members.keys.toList());
      for (final r in g) {
        groups[r['id'] as int] = r;
      }
    }
    await store.loadPeople(members.values.expand((l) => l).map((m) => m['user_id'] as String));
    notifyListeners();
  }

  Future<void> start() async {
    stop();
    _first = true;
    _lastId = -1;
    try {
      await load();
    } catch (_) {}
    _s1 = sb.from('group_members').stream(primaryKey: ['group_id', 'user_id']).listen((_) async {
      try {
        await load();
      } catch (_) {}
    }, onError: (_) {});
    _s2 = sb.from('group_messages').stream(primaryKey: ['id']).order('created_at').listen((rows) async {
      final sorted = [...rows]..sort((a, b) => (a['id'] as int).compareTo(b['id'] as int));
      msgs = sorted;
      await store.loadPeople(sorted.map((m) => m['sender_id'] as String));
      if (sorted.isNotEmpty) {
        final l = sorted.last;
        if (!_first && (l['id'] as int) > _lastId && l['sender_id'] != me && settings.notifications && !safety.flag('g', '${l['group_id']}', 'muted')) {
          messengerKey.currentState?.showSnackBar(SnackBar(content: Text('پیام جدید در ${groups[l['group_id']]?['title'] ?? 'گروه'}')));
        }
        _lastId = l['id'] as int;
      }
      _first = false;
      notifyListeners();
    }, onError: (_) {});
  }

  void stop() {
    _s1?.cancel();
    _s2?.cancel();
    _s1 = _s2 = null;
    groups.clear();
    members.clear();
    msgs = [];
  }

  int lastRead(int gid) => (myMember(gid)?['last_read_id'] as int?) ?? 0;

  int unread(int gid) => msgs.where((m) => m['group_id'] == gid && m['sender_id'] != me && (m['id'] as int) > lastRead(gid) && safety.visible('g', '$gid', m)).length;

  bool _marking = false;
  Future<void> markRead(int gid) async {
    if (_marking) return;
    final list = msgsOf(gid);
    if (list.isEmpty) return;
    final lastId = list.last['id'] as int;
    if (lastId <= lastRead(gid)) return;
    _marking = true;
    try {
      await sb.from('group_members').update({'last_read_id': lastId}).eq('group_id', gid).eq('user_id', me!);
      await load();
    } catch (_) {}
    _marking = false;
  }

  Future<int> create(String kind, String title, String desc, List<String> ids) async {
    final g = await sb.from('groups').insert({'kind': kind, 'title': title, 'description': desc, 'owner_id': me}).select(gCols).single();
    final gid = g['id'] as int;
    if (ids.isNotEmpty) {
      await sb.from('group_members').insert([for (final u in ids) {'group_id': gid, 'user_id': u, 'role': 'member'}]);
    }
    await load();
    return gid;
  }

  Future<void> sendMsg(int gid, Map<String, dynamic> d) => sb.from('group_messages').insert({'group_id': gid, 'sender_id': me, ...d});

  Future<void> addMembers(int gid, List<String> ids) async {
    await sb.from('group_members').insert([for (final u in ids) {'group_id': gid, 'user_id': u, 'role': 'member'}]);
    await load();
  }

  Future<void> removeMember(int gid, String uid) async {
    await sb.from('group_members').delete().eq('group_id', gid).eq('user_id', uid);
    await load();
  }

  Future<void> updateMember(int gid, String uid, Map<String, dynamic> d) async {
    await sb.from('group_members').update(d).eq('group_id', gid).eq('user_id', uid);
    await load();
  }

  Future<void> updateGroup(int gid, Map<String, dynamic> d) async {
    await sb.from('groups').update(d).eq('id', gid);
    await load();
  }

  Future<void> deleteGroup(int gid) async {
    await sb.from('groups').delete().eq('id', gid);
    await load();
  }
}

final gs = GroupStore();

Widget groupAvatar(int gid, {double r = 20}) {
  final gr = gs.groups[gid];
  final ap = gr?['avatar_path'] as String?;
  if (ap != null && ap.isNotEmpty) {
    return CircleAvatar(radius: r, backgroundImage: NetworkImage(sb.storage.from('avatars').getPublicUrl(ap)));
  }
  final ch = gr?['kind'] == 'channel';
  return CircleAvatar(radius: r, backgroundColor: primary, foregroundColor: cOnPrimary, child: Icon(ch ? Icons.campaign : Icons.group));
}

String slowLabel(int s) => s == 0 ? 'خاموش' : s < 60 ? '$s ثانیه' : '${s ~/ 60} دقیقه';

Future<void> changeGroupPhoto(BuildContext c, int gid) async {
  final f = await pickImage();
  if (f == null) return;
  try {
    final path = await uploadFile('avatars', f.path!, f.name);
    await gs.updateGroup(gid, {'avatar_path': path});
  } catch (e) {
    if (c.mounted) snack(c, errText(e));
  }
}

Future<void> chooseSlowMode(BuildContext c, int gid) async {
  final v = await showDialog<int>(
    context: c,
    builder: (d) => SimpleDialog(title: const Text('حالت آهسته'), children: [
      for (final s in const [0, 10, 30, 60, 300]) SimpleDialogOption(onPressed: () => Navigator.pop(d, s), child: Text(slowLabel(s))),
    ]),
  );
  if (v == null) return;
  try {
    await gs.updateGroup(gid, {'slow_mode': v});
  } catch (e) {
    if (c.mounted) snack(c, errText(e));
  }
}

Future<void> openGroup(BuildContext c, int gid) => Navigator.push(c, MaterialPageRoute(builder: (_) => ChatPage(gid: gid)));

String phoneVisLabel(String? v) => v == 'everybody' ? 'همه' : v == 'nobody' ? 'هیچ‌کس' : 'فقط مخاطبین من';

Future<void> choosePhoneVisibility(BuildContext c) async {
  final v = await showDialog<String>(
    context: c,
    builder: (d) => SimpleDialog(title: const Text('چه کسانی شماره‌ی من را ببینند؟'), children: [
      SimpleDialogOption(onPressed: () => Navigator.pop(d, 'everybody'), child: const Text('همه')),
      SimpleDialogOption(onPressed: () => Navigator.pop(d, 'contacts'), child: const Text('فقط مخاطبین من')),
      SimpleDialogOption(onPressed: () => Navigator.pop(d, 'nobody'), child: const Text('هیچ‌کس')),
    ]),
  );
  if (v == null) return;
  try {
    await sb.from('profiles').update({'phone_visibility': v}).eq('id', me!);
    store.refreshPerson(me!, {...store.people[me!]!, 'phone_visibility': v});
  } catch (_) {
    if (c.mounted) snack(c, 'ذخیره نشد');
  }
}

// ---------- chats list (direct + groups + channels) ----------
class ChatsTab extends StatefulWidget {
  const ChatsTab({super.key});
  @override
  State<ChatsTab> createState() => _ChatsTabState();
}

class _ChatsTabState extends State<ChatsTab> {
  String filter = 'all';
  static const filters = [
    ['all', 'همه'],
    ['personal', 'شخصی'],
    ['group', 'گروه'],
    ['channel', 'کانال'],
    ['unread', 'نخوانده'],
    ['archived', 'بایگانی'],
  ];

  bool keep(Map<String, dynamic> it) {
    if (filter == 'archived') return it['archived'] == true;
    if (it['archived'] == true) return false;
    switch (filter) {
      case 'personal':
        return it['u'] != null;
      case 'group':
        return it['kind'] == 'group';
      case 'channel':
        return it['kind'] == 'channel';
      case 'unread':
        return (it['unread'] as int) > 0;
      default:
        return true;
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([store, gs, safety]),
        builder: (context, _) {
          final last = <String, Map<String, dynamic>>{};
          for (final m in store.msgs) {
            final p = store.peerOf(m);
            if (safety.visible('d', p, m)) last[p] = m;
          }
          final items = <Map<String, dynamic>>[];
          for (final e in last.entries) {
            if (e.key == me) continue;
            items.add({'t': e.value['created_at'], 'u': e.key, 'sub': preview(e.value), 'time': e.value['created_at'], 'unread': store.unread(e.key), 'pinned': safety.flag('d', e.key, 'pinned'), 'muted': safety.flag('d', e.key, 'muted'), 'archived': safety.flag('d', e.key, 'archived')});
          }
          for (final g in gs.groups.entries) {
            Map<String, dynamic>? lm;
            for (final m in gs.msgs) {
              if (m['group_id'] == g.key && safety.visible('g', '${g.key}', m)) lm = m;
            }
            items.add({
              't': lm?['created_at'] ?? g.value['created_at'],
              'g': g.key,
              'kind': g.value['kind'],
              'sub': lm == null ? 'گفتگوی جدید' : '${store.name(lm['sender_id'] as String)}: ${preview(lm)}',
              'time': lm?['created_at'],
              'unread': gs.unread(g.key),
              'pinned': safety.flag('g', '${g.key}', 'pinned'),
              'muted': safety.flag('g', '${g.key}', 'muted'),
              'archived': safety.flag('g', '${g.key}', 'archived'),
            });
          }
          items.sort((a, b) {
            final pa = a['pinned'] == true ? 1 : 0, pb = b['pinned'] == true ? 1 : 0;
            if (pa != pb) return pb - pa;
            return (b['t'] as String).compareTo(a['t'] as String);
          });
          final shown = items.where(keep).toList();
          final showSaved = filter == 'all' || filter == 'personal';
          final savedMsgs = store.msgsWith(me ?? '');
          return Scaffold(
            appBar: AppBar(
              title: Row(children: [
                ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/icon.png', width: 32, height: 32)),
                const SizedBox(width: 10),
                const Text('Tia'),
              ]),
              actions: [
                IconButton(icon: const Icon(Icons.manage_search), tooltip: 'جستجو در پیام‌ها', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MessageSearchPage()))),
                IconButton(icon: const Icon(Icons.person_search), tooltip: 'جستجوی کاربر با نام کاربری', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage()))),
              ],
            ),
            body: Column(children: [
              SizedBox(
                height: 48,
                child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
                  for (final f in filters)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                      child: ChoiceChip(label: Text(f[1]), selected: filter == f[0], onSelected: (_) => setState(() => filter = f[0])),
                    ),
                ]),
              ),
              Expanded(
                child: ListView(children: [
                  if (showSaved)
                    cardTile(ListTile(
                      dense: settings.dense,
                      leading: CircleAvatar(backgroundColor: primary, foregroundColor: cOnPrimary, child: Icon(Icons.bookmark)),
                      title: const Text('پیام‌های ذخیره‌شده'),
                      subtitle: Text(savedMsgs.isEmpty ? 'پیام‌ها و فایل‌های مهم' : preview(savedMsgs.last), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: accent)),
                      onTap: () => openChat(context, me!),
                    )),
                  if (shown.isEmpty && !showSaved) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('گفتگویی در این دسته نیست'))),
                  for (final it in shown)
                    cardTile(ListTile(
                      dense: settings.dense,
                      leading: it['u'] != null ? avatarFor(it['u'] as String) : groupAvatar(it['g'] as int),
                      title: it['u'] != null ? nameWithBadge(it['u'] as String) : Text('${gs.groups[it['g']]?['title']}'),
                      subtitle: Text(it['sub'] as String, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: accent)),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        if (it['pinned'] == true) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.push_pin, size: 14)),
                        if (it['muted'] == true) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.volume_off, size: 14)),
                        if ((it['unread'] as int) > 0)
                          Container(
                            margin: const EdgeInsets.only(left: 6),
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, Color.lerp(primary, const Color(0xFFFF4FA3), 0.45)!]), borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: primary.withOpacity(0.4), blurRadius: 8)]),
                            child: Text('${it['unread']}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                          ),
                        Text(it['time'] == null ? '' : hm(it['time'] as String), style: const TextStyle(fontSize: 12)),
                      ]),
                      onLongPress: () => chatActions(context, it['u'] != null ? 'd' : 'g', it['u'] != null ? it['u'] as String : '${it['g']}'),
                      onTap: () => it['u'] != null ? openChat(context, it['u'] as String) : openGroup(context, it['g'] as int),
                    )),
                ]),
              ),
            ]),
            floatingActionButton: FloatingActionButton(
              backgroundColor: primary,
              foregroundColor: cOnPrimary,
              child: const Icon(Icons.edit),
              onPressed: () async {
                final r = await showModalBottomSheet<String>(
                  context: context,
                  builder: (c) => Directionality(
                    textDirection: TextDirection.rtl,
                    child: ListView(children: [
                      ListTile(leading: const Icon(Icons.group_add), title: const Text('گروه جدید'), onTap: () => Navigator.pop(c, 'group')),
                      ListTile(leading: const Icon(Icons.campaign), title: const Text('کانال جدید'), onTap: () => Navigator.pop(c, 'channel')),
                      ListTile(leading: const Icon(Icons.link), title: const Text('پیوستن با لینک دعوت'), onTap: () => Navigator.pop(c, 'join')),
                      const Divider(),
                      const ListTile(title: Text('ارسال پیام به...')),
                      if (store.contactIds.isEmpty) const ListTile(title: Text('ابتدا از بخش مخاطبین، مخاطب اضافه کنید')),
                      for (final id in store.contactIds) ListTile(leading: avatarFor(id), title: Text(store.name(id)), onTap: () => Navigator.pop(c, 'u:$id')),
                    ]),
                  ),
                );
                if (r == null || !context.mounted) return;
                if (r.startsWith('u:')) {
                  openChat(context, r.substring(2));
                } else if (r == 'join') {
                  joinByCode(context);
                } else {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => CreateGroupPage(r)));
                }
              },
            ),
          );
        },
      );
}

class CreateGroupPage extends StatefulWidget {
  final String kind;
  const CreateGroupPage(this.kind, {super.key});
  @override
  State<CreateGroupPage> createState() => _CreateGroupPageState();
}

class _CreateGroupPageState extends State<CreateGroupPage> {
  final title = TextEditingController(), desc = TextEditingController();
  final sel = <String>{};
  bool busy = false;

  Future<void> create() async {
    if (title.text.trim().isEmpty) return;
    setState(() => busy = true);
    try {
      final gid = await gs.create(widget.kind, title.text.trim(), desc.text.trim(), sel.toList());
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatPage(gid: gid)));
    } catch (_) {
      if (mounted) {
        snack(context, 'ساخته نشد. SQL گروه‌ها اجرا شده است؟');
        setState(() => busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ch = widget.kind == 'channel';
    return Scaffold(
      appBar: AppBar(title: Text(ch ? 'کانال جدید' : 'گروه جدید'), actions: [TextButton(onPressed: busy ? null : create, child: const Text('ساخت'))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: title, decoration: fieldDeco(labelText: ch ? 'نام کانال' : 'نام گروه')),
        const SizedBox(height: 12),
        TextField(controller: desc, maxLines: 2, decoration: fieldDeco(labelText: 'توضیحات (اختیاری)')),
        const SizedBox(height: 16),
        const Text('افزودن عضو از مخاطبین', style: TextStyle(fontWeight: FontWeight.bold)),
        if (store.contactIds.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('مخاطبی ندارید. بعداً هم می‌توانید عضو اضافه کنید.')),
        for (final id in store.contactIds)
          CheckboxListTile(
            secondary: avatarFor(id),
            title: Text(store.name(id)),
            value: sel.contains(id),
            onChanged: (v) => setState(() => v == true ? sel.add(id) : sel.remove(id)),
          ),
        if (busy) const LinearProgressIndicator(),
      ]),
    );
  }
}

// ---------- group / channel info + management ----------
Future<void> adminRightsDialog(BuildContext c, int gid, Map<String, dynamic> m) async {
  final r = <String, bool>{
    'can_delete': m['can_delete'] == true,
    'can_manage_members': m['can_manage_members'] == true,
    'can_edit_info': m['can_edit_info'] == true,
    'can_post': m['can_post'] == true,
  };
  const labels = {
    'can_delete': 'حذف پیام‌ها',
    'can_manage_members': 'مدیریت اعضا (افزودن، حذف، سکوت)',
    'can_edit_info': 'ویرایش اطلاعات و دسترسی‌ها',
    'can_post': 'ارسال پیام یا پست',
  };
  final ok = await showDialog<bool>(
    context: c,
    builder: (_) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: Text('دسترسی‌های ${store.name(m['user_id'] as String)}'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final k in r.keys) SwitchListTile(title: Text(labels[k]!), value: r[k]!, onChanged: (v) => set(() => r[k] = v)),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ذخیره')),
        ],
      ),
    ),
  );
  if (ok == true) {
    try {
      await gs.updateMember(gid, m['user_id'] as String, {'role': 'admin', ...r});
    } catch (e) {
      if (c.mounted) snack(c, errText(e));
    }
  }
}

class GroupInfoPage extends StatelessWidget {
  final int gid;
  const GroupInfoPage(this.gid, {super.key});

  Future<void> run(BuildContext c, Future<void> Function() f) async {
    try {
      await f();
    } catch (e) {
      if (c.mounted) snack(c, errText(e));
    }
  }

  Future<void> addMember(BuildContext c) async {
    final have = (gs.members[gid] ?? []).map((m) => m['user_id']).toSet();
    final cands = store.contactIds.where((id) => !have.contains(id)).toList();
    final id = await showModalBottomSheet<String>(
      context: c,
      builder: (sc) => Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(children: [
          const ListTile(title: Text('افزودن عضو')),
          if (cands.isEmpty) const ListTile(title: Text('مخاطب دیگری برای افزودن نیست')),
          for (final u in cands) ListTile(leading: avatarFor(u), title: Text(store.name(u)), onTap: () => Navigator.pop(sc, u)),
        ]),
      ),
    );
    if (id != null && c.mounted) await run(c, () => gs.addMembers(gid, [id]));
  }

  void memberMenu(BuildContext c, Map<String, dynamic> m, bool channel) {
    final uid = m['user_id'] as String;
    final role = m['role'] as String;
    final isOwner = gs.roleOf(gid) == 'owner';
    final canMembers = gs.right(gid, 'members');
    final canRemove = role != 'owner' && ((isOwner) || (canMembers && role == 'member')) && uid != me;
    Widget item(IconData i, String t, Future<void> Function() f, {Color? color}) => ListTile(
          leading: Icon(i, color: color),
          title: Text(t),
          onTap: () {
            Navigator.pop(c);
            run(c, f);
          },
        );
    showModalBottomSheet(
      context: c,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Wrap(children: [
          item(Icons.person, 'مشاهده‌ی پروفایل', () async => Navigator.push(c, MaterialPageRoute(builder: (_) => ProfilePage(uid)))),
          if (isOwner && role == 'member') item(Icons.admin_panel_settings, 'ارتقا به مدیر', () => adminRightsDialog(c, gid, m)),
          if (isOwner && role == 'admin') item(Icons.tune, 'تنظیم دسترسی‌های مدیر', () => adminRightsDialog(c, gid, m)),
          if (isOwner && role == 'admin') item(Icons.person_remove_alt_1, 'برکناری از مدیریت', () => gs.updateMember(gid, uid, {'role': 'member'})),
          if (!channel && canMembers && role == 'member') ...[
            item(Icons.volume_off, 'ساکت کردن به مدت ۱ ساعت', () => gs.updateMember(gid, uid, {'muted_until': DateTime.now().toUtc().add(const Duration(hours: 1)).toIso8601String()})),
            item(Icons.volume_off, 'ساکت کردن به مدت ۱ روز', () => gs.updateMember(gid, uid, {'muted_until': DateTime.now().toUtc().add(const Duration(days: 1)).toIso8601String()})),
            item(Icons.volume_up, 'لغو سکوت', () => gs.updateMember(gid, uid, {'muted_until': null})),
          ],
          if (canRemove) item(Icons.remove_circle_outline, 'حذف از ${channel ? 'کانال' : 'گروه'}', () => gs.removeMember(gid, uid), color: Colors.redAccent),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: gs,
        builder: (c, _) {
          final g = gs.groups[gid];
          if (g == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('این گفتگو دیگر در دسترس نیست')));
          final channel = g['kind'] == 'channel';
          final role = gs.roleOf(gid);
          final isOwner = role == 'owner';
          final canInfo = gs.right(gid, 'info');
          final canMembers = gs.right(gid, 'members');
          const order = {'owner': 0, 'admin': 1, 'member': 2};
          final list = [...(gs.members[gid] ?? <Map<String, dynamic>>[])]..sort((a, b) => order[a['role']]!.compareTo(order[b['role']]!));
          String roleLabel(Map<String, dynamic> m) {
            final base = m['role'] == 'owner' ? 'مالک' : m['role'] == 'admin' ? 'مدیر' : 'عضو';
            final mu = m['muted_until'] as String?;
            return (mu != null && DateTime.parse(mu).isAfter(DateTime.now())) ? '$base · ساکت‌شده' : base;
          }

          return Scaffold(
            appBar: AppBar(title: Text(channel ? 'اطلاعات کانال' : 'اطلاعات گروه')),
            body: ListView(children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(children: [
                  groupAvatar(gid, r: 44),
                  const SizedBox(height: 8),
                  Text('${g['title']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  if ((g['description'] as String).isNotEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(g['description'] as String, textAlign: TextAlign.center)),
                  Text('${list.length} عضو · مالک: ${store.name(g['owner_id'] as String)}', style: TextStyle(color: accent, fontSize: 12)),
                ]),
              ),
              if (canInfo) ...[
                ListTile(
                  leading: const Icon(Icons.edit),
                  title: const Text('ویرایش نام'),
                  onTap: () async {
                    final v = await inputDialog(c, 'ویرایش نام', 'نام', g['title'] as String);
                    if (v != null && c.mounted) await run(c, () => gs.updateGroup(gid, {'title': v}));
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.notes),
                  title: const Text('ویرایش توضیحات'),
                  onTap: () async {
                    final v = await inputDialog(c, 'ویرایش توضیحات', 'توضیحات', g['description'] as String);
                    if (v != null && c.mounted) await run(c, () => gs.updateGroup(gid, {'description': v}));
                  },
                ),
              ],
              ListTile(
                leading: const Icon(Icons.perm_media_outlined),
                title: const Text('رسانه‌ها، فایل‌ها و لینک‌ها'),
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => SharedMediaPage('${g['title']}', gs.msgsOf(gid)))),
              ),
              if (canInfo) ListTile(leading: const Icon(Icons.photo_camera_outlined), title: const Text('تغییر عکس'), onTap: () => changeGroupPhoto(c, gid)),
              if (canInfo && !channel)
                ListTile(
                  leading: const Icon(Icons.hourglass_bottom),
                  title: const Text('حالت آهسته'),
                  subtitle: Text('فاصله‌ی بین پیام‌های هر عضو: ${slowLabel((g['slow_mode'] as int?) ?? 0)}'),
                  onTap: () => chooseSlowMode(c, gid),
                ),
              if (!channel) ...[
                const Divider(),
                const Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 0), child: Text('دسترسی اعضا', style: TextStyle(fontWeight: FontWeight.bold))),
                for (final t in [
                  ['members_send_messages', 'اعضا بتوانند پیام بفرستند'],
                  ['members_send_media', 'اعضا بتوانند عکس، فایل و صدا بفرستند'],
                  ['members_send_links', 'اعضا بتوانند لینک بفرستند'],
                ])
                  SwitchListTile(
                    title: Text(t[1]),
                    value: g[t[0]] == true,
                    onChanged: canInfo ? (v) => run(c, () => gs.updateGroup(gid, {t[0]: v})) : null,
                  ),
              ],
              const Divider(),
              Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 0), child: Text('اعضا (${list.length})', style: const TextStyle(fontWeight: FontWeight.bold))),
              if (canMembers) ListTile(leading: const Icon(Icons.person_add), title: const Text('افزودن عضو'), onTap: () => addMember(c)),
              for (final m in list)
                ListTile(
                  leading: avatarFor(m['user_id'] as String),
                  title: nameWithBadge(m['user_id'] as String),
                  subtitle: Text(roleLabel(m), style: TextStyle(color: accent)),
                  trailing: m['user_id'] == me ? null : const Icon(Icons.more_vert),
                  onTap: m['user_id'] == me ? null : () => memberMenu(c, m, channel),
                ),
              const Divider(),
              if (canMembers) ListTile(leading: const Icon(Icons.link), title: const Text('لینک دعوت'), onTap: () => showInvite(c, gid)),
              ListTile(leading: const Icon(Icons.flag_outlined), title: Text('گزارش ${channel ? 'کانال' : 'گروه'}'), onTap: () => reportDialog(c, 'group', '$gid')),
              if (!isOwner)
                ListTile(
                  leading: const Icon(Icons.exit_to_app, color: Colors.redAccent),
                  title: Text('ترک ${channel ? 'کانال' : 'گروه'}'),
                  onTap: () async {
                    if (await confirm(c, 'از ${channel ? 'کانال' : 'گروه'} خارج می‌شوید؟')) {
                      await run(c, () => gs.removeMember(gid, me!));
                      if (c.mounted) Navigator.popUntil(c, (r) => r.isFirst);
                    }
                  },
                ),
              if (isOwner)
                ListTile(
                  leading: const Icon(Icons.delete_forever, color: Colors.redAccent),
                  title: Text('حذف ${channel ? 'کانال' : 'گروه'}'),
                  onTap: () async {
                    if (await confirm(c, 'همه‌ی پیام‌ها و اعضا حذف می‌شوند. مطمئن هستید؟')) {
                      await run(c, () => gs.deleteGroup(gid));
                      if (c.mounted) Navigator.popUntil(c, (r) => r.isFirst);
                    }
                  },
                ),
            ]),
          );
        },
      );
}
