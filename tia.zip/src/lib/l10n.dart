import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'l10n_en.dart';

/// زبان برنامه: 'fa' یا 'en'
String appLang = 'fa';

TextDirection get appDir => appLang == 'en' ? TextDirection.ltr : TextDirection.rtl;

/// ترجمه‌ی متن‌های رابط. اگر ترجمه‌ای نبود، همان متن فارسی برمی‌گردد.
String trn(String fa) => appLang == 'en' ? (enStrings[fa] ?? fa) : fa;

Future<void> loadAppLang() async {
  final p = await SharedPreferences.getInstance();
  appLang = p.getString('lang') == 'en' ? 'en' : 'fa';
}

Future<void> saveAppLang(String v) async {
  appLang = v == 'en' ? 'en' : 'fa';
  final p = await SharedPreferences.getInstance();
  await p.setString('lang', appLang);
}

/// ترجمه‌ی متن دارای متغیر: در الگو، {0} و {1} … با آرگومان‌ها جایگزین می‌شوند.
String trf(String fa, List<Object?> args) {
  var t = trn(fa);
  for (var i = 0; i < args.length; i++) {
    t = t.replaceAll('{$i}', '${args[i]}');
  }
  return t;
}
