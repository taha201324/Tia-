import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:archive/archive_io.dart';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:google_mlkit_language_id/google_mlkit_language_id.dart';
import 'package:google_mlkit_translation/google_mlkit_translation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vosk_flutter/vosk_flutter.dart' as vosk;
import 'chat.dart';
import 'main.dart';
import 'rich.dart';
import 'l10n.dart';

// ===========================================================================
// وضعیت و تنظیمات هوش تیا
// ===========================================================================
final ai = AiState();

class AiState extends ChangeNotifier {
  bool smartBar = true, autoStt = false, wavVoice = true, live = false;
  String liveTo = 'fa', sttLang = 'fa';
  final Map<String, String> transcripts = {};
  SharedPreferences? _p;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _p = p;
    smartBar = p.getBool('ai_smart') ?? true;
    autoStt = p.getBool('ai_auto_stt') ?? false;
    wavVoice = p.getBool('ai_wav') ?? true;
    live = p.getBool('ai_live') ?? false;
    liveTo = p.getString('ai_live_to') ?? 'fa';
    sttLang = p.getString('ai_stt_lang') ?? 'fa';
    try {
      final raw = p.getString('ai_tr');
      if (raw != null) {
        final m = jsonDecode(raw) as Map<String, dynamic>;
        m.forEach((k, v) => transcripts[k] = '$v');
      }
    } catch (_) {}
  }

  void save() {
    final p = _p;
    if (p != null) {
      p.setBool('ai_smart', smartBar);
      p.setBool('ai_auto_stt', autoStt);
      p.setBool('ai_wav', wavVoice);
      p.setBool('ai_live', live);
      p.setString('ai_live_to', liveTo);
      p.setString('ai_stt_lang', sttLang);
    }
    notifyListeners();
  }

  void putTranscript(String path, String text) {
    transcripts[path] = text;
    while (transcripts.length > 400) {
      transcripts.remove(transcripts.keys.first);
    }
    _p?.setString('ai_tr', jsonEncode(transcripts));
    notifyListeners();
  }

  void clearTranscripts() {
    transcripts.clear();
    _p?.remove('ai_tr');
    notifyListeners();
  }

  String? transcriptFor(String? path) => path == null ? null : transcripts[path];
}

// متنی که برای جست‌وجو استفاده می‌شود (برای ویس‌ها، متن تبدیل‌شده هم حساب می‌شود)
String searchText(Map<String, dynamic> m) {
  final base = snippet(m);
  if (kindOf(m) == 'audio') {
    final t = ai.transcriptFor(m['file_path'] as String?);
    if (t != null) return '$base $t';
  }
  return base;
}

// متنی که در نتایج نشان داده می‌شود
String shownText(Map<String, dynamic> m) {
  if (kindOf(m) == 'audio') {
    final t = ai.transcriptFor(m['file_path'] as String?);
    if (t != null) return '🎤 $t';
  }
  return snippet(m);
}

// ===========================================================================
// ابزارهای متنی فارسی/انگلیسی
// ===========================================================================
String normFa(String s) {
  var o = s.replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll('ۀ', 'ه').replaceAll('ة', 'ه');
  o = o.replaceAll(RegExp('[\u064B-\u065F\u0640]'), '').replaceAll(RegExp('[\u200c\u200d\u200e\u200f]'), '');
  const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
  for (var i = 0; i < 10; i++) {
    o = o.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
  }
  return o.toLowerCase();
}

final _wordRe = RegExp(r'[\p{L}\p{N}]+', unicode: true);

final Set<String> _stop = <String>{
  'و', 'در', 'به', 'از', 'که', 'این', 'آن', 'با', 'برای', 'را', 'است', 'بود', 'شد', 'می', 'هم', 'یا', 'تا', 'هر', 'یک', 'نه',
  'اگر', 'ولی', 'اما', trn('من'), 'تو', 'او', 'ما', 'شما', 'چه', 'چی', 'کی', 'کجا', 'چرا', 'چطور', 'هست', 'نیست', 'بی', 'هیچ',
  'دیگه', 'دیگر', trn('همه'), 'خیلی', 'بر', 'بعد', 'قبل', 'مثل', 'باید', 'میشه', 'بود', 'باشه', 'هستم', 'هستی', 'کنم', 'کنی',
  'کرد', 'کردم', 'شده', 'بشه', 'اون', 'این', 'ای', 'ها', 'رو', 'تا', 'پس', 'چند', 'چقدر', 'آیا', 'ولی', 'فقط', 'هم',
  'the', 'a', 'an', 'of', 'to', 'in', 'is', 'are', 'and', 'or', 'for', 'on', 'with', 'i', 'you', 'he', 'she', 'it', 'we',
  'they', 'that', 'this', 'what', 'when', 'where', 'who', 'how', 'do', 'does', 'did', 'was', 'were', 'be', 'at', 'my', 'me',
};

String _stem(String w) {
  for (final suf in const ['های', 'ها', 'ان', 'ات']) {
    if (w.endsWith(suf) && w.length - suf.length >= 3) return w.substring(0, w.length - suf.length);
  }
  return w;
}

List<String> _tokens(String s) => [for (final m in _wordRe.allMatches(normFa(s))) _stem(m.group(0)!)];

List<String> _content(String s) => [for (final t in _tokens(s)) if (t.length >= 2 && !_stop.contains(t)) t];

// ===========================================================================
// خلاصه‌سازی (استخراجی، کاملاً روی گوشی)
// ===========================================================================
class AiSummary {
  final String text;
  final List<String> keywords;
  const AiSummary(this.text, this.keywords);
}

List<String> _topKeywords(Iterable<String> toks, int n) {
  final f = <String, int>{};
  for (final t in toks) {
    f[t] = (f[t] ?? 0) + 1;
  }
  final es = f.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
  return [for (final e in es.take(n)) e.key];
}

AiSummary summarizeText(String text, {int max = 3}) {
  var sents = text.split(RegExp(r'(?<=[.!?؟…])\s+|\n+')).map((e) => e.trim()).where((e) => e.length >= 6).toList();
  if (sents.length < 3) {
    sents = text.split(RegExp(r'(?<=[،,؛;])\s+|(?<=[.!?؟…])\s+|\n+')).map((e) => e.trim()).where((e) => e.length >= 6).toList();
  }
  final kw = _topKeywords(_content(text), 6);
  if (sents.length <= max) {
    final t = text.trim();
    return AiSummary(t.length > 220 ? '${t.substring(0, 220)}…' : t, kw);
  }
  final toks = [for (final s in sents) _content(s)];
  final freq = <String, int>{};
  for (final l in toks) {
    for (final t in l) {
      freq[t] = (freq[t] ?? 0) + 1;
    }
  }
  final scores = <int, double>{};
  for (var i = 0; i < sents.length; i++) {
    if (toks[i].isEmpty) continue;
    var sc = 0.0;
    for (final t in toks[i]) {
      sc += freq[t] ?? 0;
    }
    sc = sc / math.sqrt(toks[i].length);
    if (i == 0) sc *= 1.25;
    if (sents[i].length < 20) sc *= 0.6;
    scores[i] = sc;
  }
  final top = scores.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
  final pick = [for (final e in top.take(max)) e.key]..sort();
  return AiSummary(pick.map((i) => sents[i]).join(' '), kw);
}

final _timeRe = RegExp(r'(\d{1,2}[:٫.]\d{2})|ساعت\s*\d+|فردا|امروز|پس ?فردا|امشب|جمعه|شنبه|یکشنبه|دوشنبه|سه ?شنبه|چهارشنبه|پنج ?شنبه|\d{1,2}\s*(فروردین|اردیبهشت|خرداد|تیر|مرداد|شهریور|مهر|آبان|آذر|دی|بهمن|اسفند)');

String summarizeChat(List<Map<String, dynamic>> msgs, String Function(String) nameOf) {
  final recent = msgs.length > 120 ? msgs.sublist(msgs.length - 120) : msgs;
  final who = <String, int>{};
  final media = <String, int>{};
  final texts = <Map<String, dynamic>>[];
  for (final m in recent) {
    final k = kindOf(m);
    final sid = (m['sender_id'] as String?) ?? '';
    who[sid] = (who[sid] ?? 0) + 1;
    final st = searchText(m);
    if (k == 'text' || (k == 'audio' && st.length > 12 && ai.transcriptFor(m['file_path'] as String?) != null)) {
      if (st.trim().isNotEmpty) texts.add(m);
    } else {
      media[k] = (media[k] ?? 0) + 1;
    }
  }
  if (texts.isEmpty) return trn('پیام متنی کافی برای خلاصه‌کردن نیست.');
  final out = <String>[];
  final people = who.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
  out.add('📊 ${recent.length} پیام اخیر: ${people.take(4).map((e) => '${nameOf(e.key)} ${e.value}').join('، ')}');
  if (media.isNotEmpty) {
    const names = {'image': 'عکس', 'audio': 'ویس', 'video': 'ویدئو', 'file': 'فایل', 'gif': 'گیف', 'sticker': 'استیکر', 'poll': 'نظرسنجی', 'location': 'موقعیت', 'contact': 'مخاطب'};
    out.add('📎 ${media.entries.map((e) => '${e.value} ${names[e.key] ?? e.key}').join('، ')}');
  }
  final all = <String>[];
  for (final m in texts) {
    all.addAll(_content(searchText(m)));
  }
  final kw = _topKeywords(all, 6);
  if (kw.isNotEmpty) out.add('🏷 موضوعات اصلی: ${kw.join('، ')}');
  String cut(String s, int n) => s.length > n ? '${s.substring(0, n)}…' : s;
  final qs = [for (final m in texts) if (searchText(m).contains('؟') || searchText(m).contains('?')) m];
  if (qs.isNotEmpty) {
    out.add('❓ پرسش‌ها:');
    for (final m in qs.reversed.take(3).toList().reversed) {
      out.add('  • ${nameOf(m['sender_id'] as String)}: ${cut(searchText(m).replaceAll('\n', ' '), 90)}');
    }
  }
  final times = [for (final m in texts) if (_timeRe.hasMatch(normFa(searchText(m)))) m];
  if (times.isNotEmpty) {
    out.add('⏰ زمان/قرارها:');
    for (final m in times.reversed.take(3).toList().reversed) {
      out.add('  • ${nameOf(m['sender_id'] as String)}: ${cut(searchText(m).replaceAll('\n', ' '), 90)}');
    }
  }
  final links = [for (final m in texts) if (hasLink(searchText(m))) m];
  if (links.isNotEmpty) out.add('🔗 ${links.length} پیام شامل لینک');
  final freq = <String, int>{};
  for (final t in all) {
    freq[t] = (freq[t] ?? 0) + 1;
  }
  final scored = <MapEntry<Map<String, dynamic>, double>>[];
  for (final m in texts) {
    final s = searchText(m);
    if (s.length < 40) continue;
    final tk = _content(s);
    if (tk.isEmpty) continue;
    var sc = 0.0;
    for (final t in tk) {
      sc += freq[t] ?? 0;
    }
    scored.add(MapEntry(m, sc / math.sqrt(tk.length)));
  }
  scored.sort((a, b) => b.value.compareTo(a.value));
  final key = [for (final e in scored.take(3)) e.key]..sort((a, b) => (a['created_at'] as String).compareTo(b['created_at'] as String));
  if (key.isNotEmpty) {
    out.add('📌 مهم‌ترین پیام‌ها:');
    for (final m in key) {
      out.add('  • ${nameOf(m['sender_id'] as String)}: ${cut(summarizeText(searchText(m), max: 1).text.replaceAll('\n', ' '), 120)}');
    }
  }
  return out.join('\n');
}

// ===========================================================================
// پیشنهاد پاسخ (قانون‌محور، فوری و بدون اینترنت)
// ===========================================================================
List<String> smartReplies(String text) {
  final n = normFa(text).trim();
  if (n.isEmpty) return [];
  final out = <String>[];
  void add(List<String> xs) {
    for (final x in xs) {
      if (!out.contains(x) && out.length < 3) out.add(x);
    }
  }

  bool has(List<String> ws) => ws.any((w) => n.contains(w));
  final isQ = n.contains('؟') || n.contains('?');
  if (!looksPersian(text)) {
    if (RegExp(r'\b(hi|hello|hey)\b').hasMatch(n)) add(['Hi! How are you?', 'Hello 👋', 'Hey!']);
    if (has(['thank'])) add(["You're welcome!", 'No problem 😊', 'Anytime!']);
    if (has(['sorry'])) add(["It's okay", 'No worries', "Don't worry about it"]);
    if (has(['bye', 'good night'])) add(['Bye! 👋', 'Good night 🌙', 'See you!']);
    if (isQ) add(['Yes, sure', "Sorry, I can't", "Let me check and get back to you"]);
    add(['OK 👍', 'Got it', 'Sounds good']);
    return out;
  }
  if (has(['خداحافظ', 'شب بخیر', 'فعلا', 'بدرود', 'به امید دیدار'])) add(['شب بخیر 🌙', 'به امید دیدار 🌹', 'فعلاً!']);
  if (has(['سلام', 'درود', 'صبح بخیر', 'عصر بخیر', 'وقت بخیر'])) add(['سلام! خوبی؟', 'سلام، چطوری؟', 'درود 🌹']);
  if (has(['خوبی', 'حالت', 'چطوری', 'احوال', 'چه خبر'])) add(['خوبم ممنون، تو چطوری؟', 'شکر، تو چه خبر؟', 'عالی‌ام! تو خوبی؟']);
  if (has(['ممنون', 'مرسی', 'متشکر', 'دمت گرم', 'تشکر', 'سپاس'])) add(['خواهش می‌کنم 🌹', 'قابلی نداشت!', 'وظیفه بود 😊']);
  if (has(['ببخشید', 'عذر', 'متاسف', 'شرمنده'])) add(['اشکالی نداره', 'مهم نیست، نگران نباش', 'باشه، فراموشش کن 🌹']);
  if (has(['تبریک', 'مبارک'])) add(['ممنونم 🌹', 'لطف داری 🙏', 'مرسی! 😍']);
  if (has(['کجایی', 'کجا هستی', 'کجایین'])) add(['تو راهم', 'خونه‌ام', 'الان بیرونم، بعداً می‌گم']);
  if (has(['ناراحت', 'غمگین', 'خسته', 'حالم بد'])) add(['ناراحت نباش، درست میشه 🌷', 'چی شده؟ بگو', 'من کنارتم 🤝']);
  if (has([trn('عکس'), 'تصویر'])) add(['عالیه! 😍', 'خیلی قشنگه', 'ممنون که فرستادی']);
  if (n.contains('😂') || has(['هاها', 'خخخ', 'هههه'])) add(['😂😂', 'خیلی باحال بود', 'هاهاها']);
  if (has(['لطفا', 'خواهش میکنم', 'میشه'])) add(['حتماً', 'چشم', 'باشه، انجامش میدم']);
  if (isQ) {
    if (has(['کی ', 'چه ساعتی', 'ساعت چند', 'فردا', 'امشب', 'قرار', 'کی؟'])) {
      add(['ساعت ۸ خوبه؟', 'فردا بهت خبر میدم', 'هر وقت تو بگی']);
    }
    if (has(['میتونی', 'میشه', 'میای', 'میری', 'داری', 'آیا', 'هست'])) {
      add(['آره، حتماً', 'نه، متاسفانه نمیشه', 'بذار ببینم، بعداً خبر میدم']);
    }
    add(['فکر کنم آره', 'نمیدونم، بذار بررسی کنم', 'بعداً بهت می‌گم']);
  }
  add(['باشه 👍', 'متوجه شدم', 'چشم']);
  return out;
}

// ===========================================================================
// تاریخ شمسی و ماشین‌حساب (برای پاسخ به پرسش‌ها)
// ===========================================================================
List<int> gregorianToJalali(int gy, int gm, int gd) {
  const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  final gy2 = gm > 2 ? gy + 1 : gy;
  var days = 355666 + (365 * gy) + ((gy2 + 3) ~/ 4) - ((gy2 + 99) ~/ 100) + ((gy2 + 399) ~/ 400) + gd + gdm[gm - 1];
  var jy = -1595 + (33 * (days ~/ 12053));
  days %= 12053;
  jy += 4 * (days ~/ 1461);
  days %= 1461;
  if (days > 365) {
    jy += (days - 1) ~/ 365;
    days = (days - 1) % 365;
  }
  int jm, jd;
  if (days < 186) {
    jm = 1 + (days ~/ 31);
    jd = 1 + (days % 31);
  } else {
    jm = 7 + ((days - 186) ~/ 30);
    jd = 1 + ((days - 186) % 30);
  }
  return [jy, jm, jd];
}

const _jMonths = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
const _jDays = {6: 'شنبه', 7: 'یکشنبه', 1: 'دوشنبه', 2: 'سه‌شنبه', 3: 'چهارشنبه', 4: 'پنج‌شنبه', 5: 'جمعه'};

class _Calc {
  final String s;
  int i = 0;
  _Calc(this.s);
  void ws() {
    while (i < s.length && s[i] == ' ') {
      i++;
    }
  }

  bool eat(String c) {
    ws();
    if (i < s.length && s[i] == c) {
      i++;
      return true;
    }
    return false;
  }

  double expr() {
    var v = term();
    while (true) {
      if (eat('+')) {
        v += term();
      } else if (eat('-')) {
        v -= term();
      } else {
        return v;
      }
    }
  }

  double term() {
    var v = power();
    while (true) {
      if (eat('*')) {
        v *= power();
      } else if (eat('/')) {
        v /= power();
      } else {
        return v;
      }
    }
  }

  double power() {
    final b = unary();
    if (eat('^')) return math.pow(b, power()).toDouble();
    return b;
  }

  double unary() {
    if (eat('-')) return -unary();
    if (eat('+')) return unary();
    return atom();
  }

  double atom() {
    ws();
    if (eat('(')) {
      final v = expr();
      if (!eat(')')) throw const FormatException('p');
      return v;
    }
    final st = i;
    while (i < s.length && (RegExp(r'[0-9.]').hasMatch(s[i]))) {
      i++;
    }
    if (st == i) throw const FormatException('n');
    return double.parse(s.substring(st, i));
  }
}

String? _tryCalc(String qn) {
  var q = qn.replaceAll('×', '*').replaceAll('÷', '/').replaceAll('٫', '.').replaceAll(',', '').replaceAll('٬', '');
  q = q.replaceAllMapped(RegExp(r'(?<=\d)\s*[xX]\s*(?=\d)'), (_) => '*');
  final ms = RegExp(r'[\d(][\d\s+\-*/^().]*[\d)]').allMatches(q).toList();
  if (ms.isEmpty) return null;
  ms.sort((a, b) => b.group(0)!.length.compareTo(a.group(0)!.length));
  final e = ms.first.group(0)!;
  if (!RegExp(r'[+\-*/^]').hasMatch(e) || !RegExp(r'\d').hasMatch(e)) return null;
  if (RegExp(r'\d+-\d+-\d+').hasMatch(e)) return null;
  try {
    final p = _Calc(e);
    final v = p.expr();
    if (!v.isFinite) return null;
    final r = v == v.roundToDouble() && v.abs() < 1e15 ? v.toInt().toString() : v.toStringAsFixed(4).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    return '${e.trim()} = $r';
  } catch (_) {
    return null;
  }
}

// ===========================================================================
// پرسش و پاسخ: ماشین‌حساب، تاریخ/ساعت، و جست‌وجوی هوشمند در همین گفتگو
// ===========================================================================
class AiAnswer {
  final String text;
  final List<Map<String, dynamic>> refs;
  const AiAnswer(this.text, [this.refs = const []]);
}

AiAnswer answerQuestion(String q, List<Map<String, dynamic>> msgs, String Function(String) nameOf) {
  final qn = normFa(q).trim();
  if (qn.isEmpty) return const AiAnswer('پرسشت را بنویس.');
  final calc = _tryCalc(qn);
  if (calc != null) return AiAnswer('🧮 $calc');
  final now = DateTime.now();
  if (qn.contains('امروز') && RegExp(r'تاریخ|چندم|چه روزی|چه تاریخی|روز').hasMatch(qn)) {
    final j = gregorianToJalali(now.year, now.month, now.day);
    return AiAnswer('📅 امروز ${_jDays[now.weekday]} ${j[2]} ${_jMonths[j[1] - 1]} ${j[0]} است.\nمیلادی: ${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}');
  }
  if (qn.contains('ساعت') && RegExp(r'چنده|چند است|الان|الآن|کنون').hasMatch(qn)) {
    return AiAnswer('🕒 ساعت ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')} است.');
  }
  final qt = _content(qn).toSet();
  if (qt.isEmpty) return const AiAnswer('پرسش را کمی دقیق‌تر بنویس تا در گفتگو جستجو کنم.');
  final scored = <MapEntry<Map<String, dynamic>, double>>[];
  for (var idx = 0; idx < msgs.length; idx++) {
    final m = msgs[idx];
    final st = searchText(m);
    if (st.trim().isEmpty) continue;
    final toks = _tokens(st).toSet();
    var sc = 0.0;
    for (final t in qt) {
      if (toks.contains(t)) {
        sc += 1;
      } else if (t.length >= 4) {
        final pre = t.substring(0, t.length - 1);
        if (toks.any((x) => x.startsWith(pre))) sc += 0.6;
      }
    }
    if (sc > 0) scored.add(MapEntry(m, sc + idx / (msgs.length * 50 + 1)));
  }
  if (scored.isEmpty) {
    return const AiAnswer('در این گفتگو چیز مرتبطی پیدا نکردم.\n(دستیار محلی تیا به ماشین‌حساب، تاریخ، ساعت و محتوای همین گفتگو جواب می‌دهد.)');
  }
  scored.sort((a, b) => b.value.compareTo(a.value));
  final top = [for (final e in scored.take(3)) e.key];
  final b = StringBuffer('این‌ها را در گفتگو پیدا کردم:');
  for (final m in top) {
    var s = shownText(m).replaceAll('\n', ' ');
    if (s.length > 140) s = '${s.substring(0, 140)}…';
    b.write('\n• ${nameOf(m['sender_id'] as String)} (${hm(m['created_at'] as String)}): $s');
  }
  final firstText = normFa(searchText(top.first));
  if (RegExp(r'ساعت|کی|چه ساعتی|چه زمانی|چه موقع').hasMatch(qn)) {
    final t = RegExp(r'\d{1,2}[:٫.]\d{2}|ساعت\s*\d+').firstMatch(firstText)?.group(0);
    if (t != null) b.write('\n\n⏰ زمان ذکرشده: $t');
  } else if (RegExp(r'چند|چقدر|قیمت|مبلغ|تعداد').hasMatch(qn)) {
    final nums = RegExp(r'\d[\d,.]*').allMatches(firstText).map((e) => e.group(0)!).take(4).toList();
    if (nums.isNotEmpty) b.write('\n\n🔢 عددهای ذکرشده: ${nums.join('، ')}');
  }
  return AiAnswer(b.toString(), top);
}

// ===========================================================================
// ترجمه‌ی روی گوشی (ML Kit) با پشتیبان آنلاین برای فارسی/انگلیسی
// ===========================================================================
const trLangs = {'fa': 'فارسی', 'en': 'انگلیسی', 'ar': 'عربی', 'tr': 'ترکی', 'de': 'آلمانی', 'fr': 'فرانسوی', 'es': 'اسپانیایی', 'ru': 'روسی'};

TranslateLanguage? _tl(String code) {
  for (final l in TranslateLanguage.values) {
    if (l.bcpCode == code) return l;
  }
  return null;
}

final OnDeviceTranslatorModelManager _mgr = OnDeviceTranslatorModelManager();
LanguageIdentifier? _langId;
final Map<String, String> _trCache = {};

Future<String> detectLang(String text) async {
  if (looksPersian(text)) return 'fa';
  try {
    _langId ??= LanguageIdentifier(confidenceThreshold: 0.4);
    final c = await _langId!.identifyLanguage(text);
    if (c != 'und' && c.isNotEmpty) return c;
  } catch (_) {}
  return 'en';
}

Future<bool> trModelReady(String code) async {
  try {
    return await _mgr.isModelDownloaded(code);
  } catch (_) {
    return false;
  }
}

Future<bool> downloadTrModel(String code) async {
  try {
    return await _mgr.downloadModel(code, isWifiRequired: false);
  } catch (_) {
    return false;
  }
}

// اگر مدل لازم دانلود نشده باشد 'model_missing' پرتاب می‌شود
Future<String> aiTranslate(String text, {required String to, bool allowOnline = true}) async {
  final key = '$to|$text';
  final hit = _trCache[key];
  if (hit != null) return hit;
  final from = await detectLang(text);
  if (from == to) return text;
  final sl = _tl(from), tl = _tl(to);
  if (sl != null && tl != null && await trModelReady(from) && await trModelReady(to)) {
    final tr = OnDeviceTranslator(sourceLanguage: sl, targetLanguage: tl);
    try {
      final r = await tr.translateText(text);
      _trCache[key] = r;
      return r;
    } finally {
      await tr.close();
    }
  }
  if (allowOnline && (to == 'fa' || to == 'en') && (from == 'fa' || from == 'en')) {
    try {
      final r = await translateText(text, to: to);
      _trCache[key] = r;
      return r;
    } catch (_) {}
  }
  throw 'model_missing';
}

Future<bool> _confirm(BuildContext c, String title, String body, String yes) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (d) => AlertDialog(
      title: Text(title),
      content: Text(body, style: const TextStyle(height: 1.6)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: Text(trn('بعداً'))),
        FilledButton(onPressed: () => Navigator.pop(d, true), child: Text(yes)),
      ],
    ),
  );
  return r == true;
}

Future<T> _withBusy<T>(BuildContext c, String msg, Future<T> Function() job) async {
  showDialog(
    context: c,
    barrierDismissible: false,
    useRootNavigator: true,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(content: Row(children: [const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 3)), const SizedBox(width: 16), Expanded(child: Text(msg))])),
    ),
  );
  try {
    return await job();
  } finally {
    if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  }
}

Future<T> _withProgress<T>(BuildContext c, String title, Future<T> Function(ValueNotifier<double?> p, ValueNotifier<String> msg) job) async {
  final p = ValueNotifier<double?>(null);
  final msg = ValueNotifier<String>('');
  showDialog(
    context: c,
    barrierDismissible: false,
    useRootNavigator: true,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(
        title: Text(title, style: const TextStyle(fontSize: 16)),
        content: ValueListenableBuilder<double?>(
          valueListenable: p,
          builder: (_, v, __) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            LinearProgressIndicator(value: v),
            const SizedBox(height: 12),
            ValueListenableBuilder<String>(valueListenable: msg, builder: (_, m, __) => Text(v == null ? m : '${(v * 100).round()}٪  $m', textAlign: TextAlign.center)),
          ]),
        ),
      ),
    ),
  );
  try {
    return await job(p, msg);
  } finally {
    if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  }
}

Future<bool> ensureTrModels(BuildContext c, List<String> codes) async {
  final missing = <String>[];
  for (final k in codes) {
    if (!await trModelReady(k)) missing.add(k);
  }
  if (missing.isEmpty) return true;
  if (!c.mounted) return false;
  final ok = await _confirm(c, trn('دانلود مدل ترجمه'), trf('برای ترجمه‌ی روی گوشی، یک‌بار مدل زبان‌های {0} دانلود می‌شود (حدود ۳۰ مگابایت برای هر زبان). بعد از آن بدون اینترنت کار می‌کند.', [missing.map((e) => trn(trLangs[e] ?? e)).join(trn(' و '))]), trn('دانلود'));
  if (!ok || !c.mounted) return false;
  final res = await _withProgress(c, trn('دانلود مدل ترجمه'), (p, msg) async {
    var all = true;
    for (var i = 0; i < missing.length; i++) {
      msg.value = trf('مدل {0} ({1} از {2}) — ML Kit درصد دقیق اعلام نمی‌کند', [trn(trLangs[missing[i]] ?? missing[i]), i + 1, missing.length]);
      if (!await downloadTrModel(missing[i])) all = false;
    }
    return all;
  });
  if (!res && c.mounted) snack(c, 'دانلود مدل از سرور گوگل انجام نشد (معمولاً بدون VPN ممکن نیست). ترجمه‌ی آنلاین فارسی↔انگلیسی بدون مدل کار می‌کند.');
  return res;
}

class _TrSheet extends StatefulWidget {
  final String text;
  const _TrSheet(this.text);
  @override
  State<_TrSheet> createState() => _TrSheetState();
}

class _TrSheetState extends State<_TrSheet> {
  late String to = looksPersian(widget.text) ? 'en' : 'fa';
  String? result, error;
  bool busy = true;

  @override
  void initState() {
    super.initState();
    run();
  }

  Future<void> run() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final r = await aiTranslate(widget.text, to: to);
      if (mounted) setState(() => result = r);
    } catch (e) {
      if (e == 'model_missing') {
        final from = await detectLang(widget.text);
        if (!mounted) return;
        final ok = await ensureTrModels(context, [from, to]);
        if (ok && mounted) {
          try {
            final r = await aiTranslate(widget.text, to: to, allowOnline: false);
            if (mounted) setState(() => result = r);
          } catch (_) {
            if (mounted) setState(() => error = trn('ترجمه انجام نشد.'));
          }
        } else if (mounted) {
          setState(() => error = trn('مدل ترجمه دانلود نشده است.'));
        }
      } else if (mounted) {
        setState(() => error = trn('ترجمه انجام نشد.'));
      }
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [
              Text(trn('ترجمه به'), style: TextStyle(color: accent, fontWeight: FontWeight.bold)),
              const SizedBox(width: 10),
              DropdownButton<String>(
                value: to,
                underline: const SizedBox.shrink(),
                items: [for (final e in trLangs.entries) DropdownMenuItem(value: e.key, child: Text(trn(e.value)))],
                onChanged: (v) {
                  if (v == null) return;
                  setState(() {
                    to = v;
                    result = null;
                  });
                  run();
                },
              ),
              const Spacer(),
              Icon(Icons.offline_bolt_outlined, size: 16, color: cTextFaint),
              Text(trn(' روی گوشی'), style: TextStyle(color: cTextFaint, fontSize: 12)),
            ]),
            const SizedBox(height: 10),
            if (busy)
              const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()))
            else if (error != null)
              Text(error!)
            else if (result != null)
              SelectableText(result!, textDirection: (to == 'fa' || to == 'ar') ? TextDirection.rtl : TextDirection.ltr, style: const TextStyle(fontSize: 16, height: 1.6)),
            if (!busy && result != null)
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: TextButton.icon(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: result!));
                    snack(context, trn('کپی شد'));
                  },
                  icon: const Icon(Icons.copy, size: 16),
                  label: Text(trn('کپی')),
                ),
              ),
          ]),
        ),
      );
}

Future<void> aiTranslateSheet(BuildContext context, String text) => showModalBottomSheet(context: context, showDragHandle: true, isScrollControlled: true, builder: (_) => _TrSheet(text));

// ترجمه‌ی زنده: زیر هر پیام دریافتی ترجمه نشان داده می‌شود
class LiveTr extends StatefulWidget {
  final String text;
  const LiveTr(this.text, {super.key});
  @override
  State<LiveTr> createState() => _LiveTrState();
}

class _LiveTrState extends State<LiveTr> {
  Future<String>? f;
  @override
  void initState() {
    super.initState();
    f = aiTranslate(widget.text, to: ai.liveTo, allowOnline: false);
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
        future: f,
        builder: (c, s) {
          if (s.hasError) {
            return s.error == 'model_missing' ? Padding(padding: const EdgeInsets.only(top: 4), child: Text(trn('مدل ترجمه دانلود نشده (دستیار ← ترجمه‌ی زنده)'), style: TextStyle(fontSize: 10.5, color: cTextFaint))) : const SizedBox.shrink();
          }
          if (!s.hasData || s.data == widget.text) return const SizedBox.shrink();
          return Container(
            margin: const EdgeInsets.only(top: 6),
            padding: const EdgeInsets.only(top: 6),
            decoration: BoxDecoration(border: Border(top: BorderSide(color: cLine))),
            child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.translate, size: 13, color: cTextFaint),
              const SizedBox(width: 5),
              Flexible(child: Text(s.data!, textDirection: (ai.liveTo == 'fa' || ai.liveTo == 'ar') ? TextDirection.rtl : TextDirection.ltr, style: const TextStyle(fontSize: 13.5, fontStyle: FontStyle.italic, height: 1.5))),
            ]),
          );
        },
      );
}

// ===========================================================================
// تبدیل گفتار به متن روی گوشی (Vosk)
// ===========================================================================
const sttUrls = {
  'fa': 'https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip',
  'en': 'https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip',
};

class _Wav {
  final Int16List samples;
  final int rate;
  const _Wav(this.samples, this.rate);
}

_Wav _parseWav(Uint8List b) {
  if (b.length < 44 || String.fromCharCodes(b.sublist(0, 4)) != 'RIFF' || String.fromCharCodes(b.sublist(8, 12)) != 'WAVE') throw 'format';
  final bd = ByteData.sublistView(b);
  var pos = 12, ch = 1, rate = 16000, bits = 16, fmt = 1, dataStart = -1, dataLen = 0;
  while (pos + 8 <= b.length) {
    final id = String.fromCharCodes(b.sublist(pos, pos + 4));
    final sz = bd.getUint32(pos + 4, Endian.little);
    final body = pos + 8;
    if (id == 'fmt ' && body + 16 <= b.length) {
      fmt = bd.getUint16(body, Endian.little);
      ch = bd.getUint16(body + 2, Endian.little);
      rate = bd.getUint32(body + 4, Endian.little);
      bits = bd.getUint16(body + 14, Endian.little);
    } else if (id == 'data') {
      dataStart = body;
      dataLen = (sz == 0 || body + sz > b.length) ? b.length - body : sz;
      break;
    }
    pos = body + sz + (sz & 1);
  }
  if (dataStart < 0 || bits != 16 || ch < 1 || (fmt != 1 && fmt != 0xFFFE)) throw 'format';
  final frames = dataLen ~/ (2 * ch);
  final mono = Int16List(frames);
  for (var i = 0; i < frames; i++) {
    var s = 0;
    for (var c = 0; c < ch; c++) {
      s += bd.getInt16(dataStart + (i * ch + c) * 2, Endian.little);
    }
    mono[i] = s ~/ ch;
  }
  return _Wav(mono, rate);
}

Int16List _resample(Int16List x, int from, int to) {
  if (from == to || x.isEmpty) return x;
  final n = (x.length * to / from).floor();
  final o = Int16List(n);
  for (var i = 0; i < n; i++) {
    final p = i * from / to;
    final i0 = p.floor();
    final i1 = math.min(i0 + 1, x.length - 1);
    final f = p - i0;
    o[i] = (x[i0] * (1 - f) + x[i1] * f).round();
  }
  return o;
}

String _voskText(String j) {
  try {
    return (((jsonDecode(j) as Map)['text']) as String? ?? '').trim();
  } catch (_) {
    return '';
  }
}

void _unzip(List<String> a) => extractFileToDisk(a[0], a[1]);

class LocalStt {
  static vosk.Model? _model;
  static String? _lang;

  static Future<bool> isReady(String lang) async {
    final p = await SharedPreferences.getInstance();
    return p.getBool('stt_ok_$lang') ?? false;
  }

  static String _name(String lang) => sttUrls[lang]!.split('/').last.replaceAll('.zip', '');

  static Future<String> _dir(String lang) async => '${(await getApplicationSupportDirectory()).path}/vosk/${_name(lang)}';

  static Future<void> download(String lang, [ValueNotifier<double?>? prog, ValueNotifier<String>? msg]) async {
    final root = Directory('${(await getApplicationSupportDirectory()).path}/vosk');
    await root.create(recursive: true);
    final zip = File('${root.path}/${_name(lang)}.zip');
    final client = HttpClient();
    try {
      final req = await client.getUrl(Uri.parse(sttUrls[lang]!));
      final res = await req.close();
      if (res.statusCode != 200) throw 'http';
      final total = res.contentLength;
      final sink = zip.openWrite();
      var got = 0;
      await for (final chunk in res) {
        sink.add(chunk);
        got += chunk.length;
        if (total > 0 && prog != null) {
          prog.value = got / total * 0.92;
          msg?.value = trf('{0} از {1} مگابایت', [(got / 1048576).toStringAsFixed(1), (total / 1048576).toStringAsFixed(1)]);
        }
      }
      await sink.close();
    } finally {
      client.close();
    }
    msg?.value = trn('در حال باز کردن فایل‌ها…');
    prog?.value = 0.95;
    await compute(_unzip, [zip.path, root.path]);
    try {
      await zip.delete();
    } catch (_) {}
    prog?.value = 1;
    final p = await SharedPreferences.getInstance();
    await p.setBool('stt_ok_$lang', true);
  }

  static Future<vosk.Model> _load(String lang) async {
    if (_model != null && _lang == lang) return _model!;
    final path = await _dir(lang);
    // مدل ناقص/خراب باعث کرش بومی (بسته‌شدن ناگهانی برنامه) می‌شود؛ قبل از بارگذاری بررسی می‌کنیم
    final okFiles = await File('$path/am/final.mdl').exists() && await Directory('$path/conf').exists() && await Directory('$path/graph').exists();
    if (!okFiles) {
      final p = await SharedPreferences.getInstance();
      await p.setBool('stt_ok_$lang', false);
      try {
        await Directory(path).delete(recursive: true);
      } catch (_) {}
      throw 'nomodel';
    }
    _model = await vosk.VoskFlutterPlugin.instance().createModel(path);
    _lang = lang;
    return _model!;
  }

  static Future<String> transcribe(Uint8List bytes, String lang) async {
    final w = _parseWav(bytes);
    final pcm = _resample(w.samples, w.rate, 16000);
    final model = await _load(lang);
    final rec = await vosk.VoskFlutterPlugin.instance().createRecognizer(model: model, sampleRate: 16000);
    final parts = <String>[];
    try {
      final raw = pcm.buffer.asUint8List(pcm.offsetInBytes, pcm.lengthInBytes);
      const chunk = 16000;
      for (var i = 0; i < raw.length; i += chunk) {
        final end = math.min(i + chunk, raw.length);
        final done = await rec.acceptWaveformBytes(raw.sublist(i, end));
        if (done) parts.add(_voskText(await rec.getResult()));
      }
      parts.add(_voskText(await rec.getFinalResult()));
    } finally {
      await rec.dispose();
    }
    return parts.where((e) => e.isNotEmpty).join(' ').trim();
  }
}

Future<void> _sttQueue = Future.value();
Future<T> _enqueue<T>(Future<T> Function() f) {
  final c = Completer<T>();
  _sttQueue = _sttQueue.then((_) async {
    try {
      c.complete(await f());
    } catch (e) {
      c.completeError(e);
    }
  });
  return c.future;
}

Future<bool> ensureSttModel(BuildContext c, String lang) async {
  if (await LocalStt.isReady(lang)) return true;
  if (!c.mounted) return false;
  final ok = await _confirm(c, 'دانلود مدل تبدیل گفتار به متن', 'برای تبدیل ویس به متن، یک‌بار مدل ${lang == 'fa' ? trn('فارسی') : trn('انگلیسی')} (حدود ${lang == 'fa' ? '۴۷' : '۴۰'} مگابایت) دانلود می‌شود. بعد از آن بدون اینترنت کار می‌کند.', trn('دانلود'));
  if (!ok || !c.mounted) return false;
  try {
    await _withProgress(c, 'دانلود مدل گفتار', (p, m) => LocalStt.download(lang, p, m));
    return true;
  } catch (_) {
    if (c.mounted) snack(c, trn('دانلود انجام نشد. اینترنت را بررسی کنید.'));
    return false;
  }
}

String aiErr(Object e) {
  if (e == 'old') return trn('این ویس با فرمت قدیمی ذخیره شده و قابل تبدیل نیست. ویس‌های جدید قابل تبدیل‌اند.');
  if (e == 'nomodel') return trn('مدل گفتار هنوز دانلود نشده است.');
  if (e == 'format') return trn('فرمت صدا پشتیبانی نمی‌شود.');
  return trn('تبدیل به متن انجام نشد.');
}

// ویس را به متن تبدیل می‌کند و در حافظه‌ی گوشی نگه می‌دارد (برای جست‌وجو)
Future<String?> aiTranscribe(BuildContext? ctx, String path, {bool silent = false}) async {
  final cached = ai.transcripts[path];
  if (cached != null) return cached;
  if (!path.toLowerCase().endsWith('.wav')) throw 'old';
  final lang = ai.sttLang;
  if (!await LocalStt.isReady(lang)) {
    if (silent || ctx == null || !ctx.mounted) throw 'nomodel';
    if (!await ensureSttModel(ctx, lang)) return null;
  }
  final bytes = await sb.storage.from('chat-files').download(path);
  final text = await _enqueue(() => LocalStt.transcribe(bytes, lang));
  final t = text.isEmpty ? trn('(متنی تشخیص داده نشد)') : text;
  ai.putTranscript(path, t);
  return t;
}

class VoiceTranscript extends StatefulWidget {
  final String path;
  const VoiceTranscript(this.path, {super.key});
  @override
  State<VoiceTranscript> createState() => _VoiceTranscriptState();
}

class _VoiceTranscriptState extends State<VoiceTranscript> {
  bool busy = false;
  String? err;

  @override
  void initState() {
    super.initState();
    ai.addListener(_r);
    if (ai.autoStt && widget.path.toLowerCase().endsWith('.wav') && ai.transcripts[widget.path] == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => run(silent: true));
    }
  }

  void _r() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    ai.removeListener(_r);
    super.dispose();
  }

  Future<void> run({bool silent = false}) async {
    if (busy) return;
    setState(() {
      busy = true;
      err = null;
    });
    try {
      await aiTranscribe(context, widget.path, silent: silent);
    } catch (e) {
      if (!silent && mounted) setState(() => err = aiErr(e));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final t = ai.transcripts[widget.path];
    if (t != null) {
      return Container(
        width: 240,
        margin: const EdgeInsets.only(top: 6),
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
        decoration: BoxDecoration(border: BorderDirectional(start: BorderSide(color: accent, width: 2.5))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.subtitles_outlined, size: 14),
            const SizedBox(width: 4),
            Text(trn('متن ویس'), style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
            const Spacer(),
            InkWell(
              onTap: () {
                Clipboard.setData(ClipboardData(text: t));
                snack(context, trn('کپی شد'));
              },
              child: const Icon(Icons.copy, size: 14),
            ),
          ]),
          const SizedBox(height: 4),
          SelectableText(t, style: const TextStyle(fontSize: 13.5, height: 1.5)),
        ]),
      );
    }
    if (busy) {
      return Padding(padding: EdgeInsets.only(top: 6), child: Row(mainAxisSize: MainAxisSize.min, children: [SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)), SizedBox(width: 8), Text(trn('در حال تبدیل به متن…'), style: TextStyle(fontSize: 12))]));
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
      InkWell(
        onTap: run,
        child: Padding(padding: EdgeInsets.only(top: 6), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.subtitles_outlined, size: 15), SizedBox(width: 5), Text(trn('تبدیل به متن'), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700))])),
      ),
      if (err != null) SizedBox(width: 240, child: Text(err!, style: const TextStyle(fontSize: 11))),
    ]);
  }
}

// تبدیل گروهی ویس‌های اخیر برای اینکه در جست‌وجو پیدا شوند
Future<void> transcribeRecent(BuildContext c, List<Map<String, dynamic>> all) async {
  final todo = <String>[];
  for (final m in all.reversed) {
    if (kindOf(m) != 'audio') continue;
    final p = m['file_path'] as String?;
    if (p == null || !p.toLowerCase().endsWith('.wav') || ai.transcripts[p] != null) continue;
    todo.add(p);
    if (todo.length >= 20) break;
  }
  if (todo.isEmpty) {
    snack(c, trn('ویس تازه‌ای برای تبدیل پیدا نشد (فقط ویس‌های جدید قابل تبدیل‌اند)'));
    return;
  }
  if (!await ensureSttModel(c, ai.sttLang)) return;
  if (!c.mounted) return;
  var done = 0;
  await _withBusy(c, 'تبدیل ${todo.length} ویس به متن… (ممکن است چند دقیقه طول بکشد)', () async {
    for (final p in todo) {
      try {
        await aiTranscribe(null, p);
        done++;
      } catch (_) {}
    }
  });
  if (c.mounted) snack(c, trf('{0} ویس به متن تبدیل شد', [done]));
}

// ===========================================================================
// صفحه‌های رابط: خلاصه، پیشنهاد پاسخ، دستیار
// ===========================================================================
Future<void> showSummarySheet(BuildContext context, String text) {
  final s = summarizeText(text);
  return showModalBottomSheet(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(trn('✨ خلاصه'), style: TextStyle(color: accent, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            SelectableText(s.text, style: const TextStyle(fontSize: 15.5, height: 1.7)),
            if (s.keywords.isNotEmpty) ...[
              const SizedBox(height: 12),
              Wrap(spacing: 6, runSpacing: 6, children: [for (final k in s.keywords) Chip(label: Text(k), visualDensity: VisualDensity.compact)]),
            ],
          ]),
        ),
      ),
    ),
  );
}

Future<void> showSuggestSheet(BuildContext context, String incoming, void Function(String) onPick) {
  final rs = smartReplies(incoming);
  return showModalBottomSheet(
    context: context,
    showDragHandle: true,
    builder: (sc) => Directionality(
      textDirection: TextDirection.rtl,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(trn('✨ پیشنهاد پاسخ'), style: TextStyle(color: accent, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            for (final r in rs)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.pop(sc);
                    onPick(r);
                  },
                  child: Text(r),
                ),
              ),
          ]),
        ),
      ),
    ),
  );
}

class _AiSheet extends StatefulWidget {
  final List<Map<String, dynamic>> msgs;
  final String currentText;
  final void Function(String) onInsert;
  final void Function(int) onJump;
  final VoidCallback onChanged;
  const _AiSheet({required this.msgs, required this.currentText, required this.onInsert, required this.onJump, required this.onChanged});
  @override
  State<_AiSheet> createState() => _AiSheetState();
}

class _AiSheetState extends State<_AiSheet> {
  final qc = TextEditingController();
  String? summary;
  AiAnswer? answer;
  String? trResult;
  bool trBusy = false;

  String nameOf(String id) => id == me ? trn('من') : store.name(id);

  Widget action(IconData i, String t, String sub, VoidCallback f) => ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Icon(i, color: accent),
        title: Text(t, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(sub, style: const TextStyle(fontSize: 12)),
        onTap: f,
      );

  Future<void> translateDraft() async {
    final t = widget.currentText.trim();
    if (t.isEmpty) {
      snack(context, trn('اول متنی در کادر پیام بنویس'));
      return;
    }
    setState(() => trBusy = true);
    try {
      final to = looksPersian(t) ? 'en' : 'fa';
      String r;
      try {
        r = await aiTranslate(t, to: to);
      } catch (e) {
        if (e != 'model_missing') rethrow;
        final from = await detectLang(t);
        if (!mounted) return;
        if (!await ensureTrModels(context, [from, to])) {
          if (mounted) setState(() => trBusy = false);
          return;
        }
        r = await aiTranslate(t, to: to, allowOnline: false);
      }
      if (mounted) setState(() => trResult = r);
    } catch (_) {
      if (mounted) snack(context, trn('ترجمه انجام نشد'));
    }
    if (mounted) setState(() => trBusy = false);
  }

  @override
  Widget build(BuildContext context) {
    final last = widget.msgs.isEmpty ? null : widget.msgs.last;
    final incoming = (last != null && last['sender_id'] != me && kindOf(last) == 'text') ? last['text'] as String : null;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.8,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        builder: (c, sc) => ListView(controller: sc, padding: const EdgeInsets.fromLTRB(18, 0, 18, 24), children: [
          Row(children: [
            Icon(Icons.auto_awesome, color: accent),
            const SizedBox(width: 8),
            Text(trn('دستیار هوش تیا'), style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const Spacer(),
            Icon(Icons.offline_bolt_outlined, size: 16, color: cTextFaint),
            Text(trn(' روی گوشی'), style: TextStyle(color: cTextFaint, fontSize: 12)),
          ]),
          const SizedBox(height: 10),
          TextField(
            controller: qc,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => setState(() => answer = answerQuestion(qc.text, widget.msgs, nameOf)),
            decoration: fieldDeco(hintText: trn('بپرس: «قرار ساعت چند بود؟» یا «۱۲×۳۴+۵» یا «امروز چندمه؟»'), radius: 20).copyWith(
              suffixIcon: IconButton(icon: const Icon(Icons.send_rounded), onPressed: () => setState(() => answer = answerQuestion(qc.text, widget.msgs, nameOf))),
            ),
          ),
          if (answer != null)
            Container(
              margin: const EdgeInsets.only(top: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: cLine)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                SelectableText(answer!.text, style: const TextStyle(height: 1.7)),
                if (answer!.refs.isNotEmpty)
                  Wrap(spacing: 6, children: [
                    for (var i = 0; i < answer!.refs.length; i++)
                      ActionChip(
                        label: Text(trf('پرش به پیام {0}', [i + 1])),
                        onPressed: () {
                          Navigator.pop(context);
                          widget.onJump(answer!.refs[i]['id'] as int);
                        },
                      ),
                  ]),
              ]),
            ),
          const Divider(height: 28),
          action(Icons.summarize_outlined, trn('خلاصه‌ی این گفتگو'), trn('موضوعات، پرسش‌ها، قرارها و مهم‌ترین پیام‌ها'), () => setState(() => summary = summarizeChat(widget.msgs, nameOf))),
          if (summary != null)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: cLine)),
              child: SelectableText(summary!, style: const TextStyle(height: 1.8)),
            ),
          if (incoming != null) ...[
            action(Icons.quickreply_outlined, trn('پیشنهاد پاسخ'), trn('برای آخرین پیامی که برایت آمده'), () {}),
            Wrap(spacing: 8, runSpacing: 4, children: [
              for (final r in smartReplies(incoming))
                ActionChip(
                  label: Text(r),
                  onPressed: () {
                    Navigator.pop(context);
                    widget.onInsert(r);
                  },
                ),
            ]),
            const SizedBox(height: 6),
          ],
          action(Icons.translate, trn('ترجمه‌ی متن در حال نوشتن'), trn('متن کادر پیام را به فارسی/انگلیسی برمی‌گرداند'), translateDraft),
          if (trBusy) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator()),
          if (trResult != null)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: cLine)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                SelectableText(trResult!, style: const TextStyle(height: 1.6)),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    widget.onInsert(trResult!);
                  },
                  child: Text(trn('جایگزین کردن در کادر پیام')),
                ),
              ]),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            secondary: Icon(Icons.g_translate, color: accent),
            title: Text(trn('ترجمه‌ی زنده'), style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Row(children: [
              Text(trn('ترجمه‌ی خودکار پیام‌های دریافتی به '), style: TextStyle(fontSize: 12)),
              DropdownButton<String>(
                value: ai.liveTo,
                isDense: true,
                underline: const SizedBox.shrink(),
                items: [for (final e in trLangs.entries) DropdownMenuItem(value: e.key, child: Text(trn(e.value), style: const TextStyle(fontSize: 12)))],
                onChanged: (v) {
                  if (v == null) return;
                  ai.liveTo = v;
                  ai.save();
                  widget.onChanged();
                  setState(() {});
                },
              ),
            ]),
            value: ai.live,
            onChanged: (v) async {
              if (v) {
                final ok = await ensureTrModels(context, [ai.liveTo]);
                if (!ok) return;
              }
              ai.live = v;
              ai.save();
              widget.onChanged();
              if (mounted) setState(() {});
            },
          ),
        ]),
      ),
    );
  }
}

Future<void> showAiSheet(BuildContext context, {required List<Map<String, dynamic>> msgs, required String currentText, required void Function(String) onInsert, required void Function(int) onJump, required VoidCallback onChanged}) =>
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _AiSheet(msgs: msgs, currentText: currentText, onInsert: onInsert, onJump: onJump, onChanged: onChanged),
    );

// ===========================================================================
// تنظیمات هوش تیا
// ===========================================================================
class AiSettingsPage extends StatefulWidget {
  const AiSettingsPage({super.key});
  @override
  State<AiSettingsPage> createState() => _AiSettingsPageState();
}

class _AiSettingsPageState extends State<AiSettingsPage> {
  Widget head(String t) => Padding(padding: const EdgeInsets.only(top: 22, bottom: 6), child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: cText)));

  Widget modelTile(String title, Future<bool> ready, Future<void> Function() get) => FutureBuilder<bool>(
        future: ready,
        builder: (c, s) => ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(title),
          subtitle: Text(s.data == true ? trn('دانلود شده ✓') : trn('دانلود نشده')),
          trailing: s.data == true ? null : FilledButton.tonal(onPressed: () async {
            await get();
            if (mounted) setState(() {});
          }, child: Text(trn('دانلود'))),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('هوش تیا'))),
        body: ListenableBuilder(
          listenable: ai,
          builder: (c, _) => ListView(padding: const EdgeInsets.all(16), children: [
            head(trn('گفتگو')),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(trn('نوار پیشنهاد پاسخ بالای کادر پیام')), value: ai.smartBar, onChanged: (v) {
              ai.smartBar = v;
              ai.save();
            }),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('ضبط ویس به‌صورت قابل تبدیل به متن')),
              subtitle: Text(trn('ویس‌ها با فرمت WAV ارسال می‌شوند؛ حجم حدود ۱۰ برابر بیشتر از قبل')),
              value: ai.wavVoice,
              onChanged: (v) {
                ai.wavVoice = v;
                ai.save();
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('تبدیل خودکار ویس‌ها به متن')),
              subtitle: Text(trn('هر ویس WAV که در چت دیده شود، در پس‌زمینه تبدیل می‌شود (مصرف باتری)')),
              value: ai.autoStt,
              onChanged: (v) {
                ai.autoStt = v;
                ai.save();
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('زبان گفتار ویس‌ها')),
              trailing: DropdownButton<String>(
                value: ai.sttLang,
                underline: const SizedBox.shrink(),
                items: [DropdownMenuItem(value: 'fa', child: Text(trn('فارسی'))), DropdownMenuItem(value: 'en', child: Text(trn('انگلیسی')))],
                onChanged: (v) {
                  if (v == null) return;
                  ai.sttLang = v;
                  ai.save();
                },
              ),
            ),
            head(trn('مدل‌های روی گوشی')),
            modelTile(trn('گفتار فارسی (حدود ۴۷ مگابایت)'), LocalStt.isReady('fa'), () async {
              await ensureSttModel(context, 'fa');
            }),
            modelTile(trn('گفتار انگلیسی (حدود ۴۰ مگابایت)'), LocalStt.isReady('en'), () async {
              await ensureSttModel(context, 'en');
            }),
            modelTile(trn('ترجمه‌ی فارسی'), trModelReady('fa'), () async {
              await ensureTrModels(context, ['fa']);
            }),
            modelTile(trn('ترجمه‌ی انگلیسی'), trModelReady('en'), () async {
              await ensureTrModels(context, ['en']);
            }),
            head(trn('داده‌ها')),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
              title: Text(trf('پاک‌کردن متن ویس‌های ذخیره‌شده ({0})', [ai.transcripts.length])),
              onTap: () {
                ai.clearTranscripts();
                snack(context, trn('پاک شد'));
              },
            ),
          ]),
        ),
      );
}
