import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:archive/archive_io.dart';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vosk_flutter/vosk_flutter.dart' as vosk;
import 'chat.dart';
import 'main.dart';
import 'rich.dart';
import 'l10n.dart';
import 'smart.dart' show mlReady, mlDownload;

// ===========================================================================
// وضعیت و تنظیمات هوش تیا
// ===========================================================================
final ai = AiState();

class AiState extends ChangeNotifier {
  bool smartBar = true, autoStt = false, wavVoice = true, live = false;
  String liveTo = 'fa', sttLang = 'fa';
  final Map<String, String> transcripts = {};
  SharedPreferences? _p;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _p = p;
    smartBar = p.getBool('ai_smart') ?? true;
    autoStt = p.getBool('ai_auto_stt') ?? false;
    wavVoice = p.getBool('ai_wav') ?? true;
    live = p.getBool('ai_live') ?? false;
    liveTo = p.getString('ai_live_to') ?? 'fa';
    sttLang = p.getString('ai_stt_lang') ?? 'fa';
    try {
      final raw = p.getString('ai_tr');
      if (raw != null) {
        final m = jsonDecode(raw) as Map<String, dynamic>;
        m.forEach((k, v) => transcripts[k] = '$v');
      }
    } catch (_) {}
  }

  void save() {
    final p = _p;
    if (p != null) {
      p.setBool('ai_smart', smartBar);
      p.setBool('ai_auto_stt', autoStt);
      p.setBool('ai_wav', wavVoice);
      p.setBool('ai_live', live);
      p.setString('ai_live_to', liveTo);
      p.setString('ai_stt_lang', sttLang);
    }
    notifyListeners();
  }

  void putTranscript(String path, String text) {
    transcripts[path] = text;
    while (transcripts.length > 400) {
      transcripts.remove(transcripts.keys.first);
    }
    _p?.setString('ai_tr', jsonEncode(transcripts));
    notifyListeners();
  }

  void clearTranscripts() {
    transcripts.clear();
    _p?.remove('ai_tr');
    notifyListeners();
  }

  String? transcriptFor(String? path) => path == null ? null : transcripts[path];
}

// متنی که برای جست‌وجو استفاده می‌شود (برای ویس‌ها، متن تبدیل‌شده هم حساب می‌شود)
String searchText(Map<String, dynamic> m) {
  final base = snippet(m);
  if (kindOf(m) == 'audio') {
    final t = ai.transcriptFor(m['file_path'] as String?);
    if (t != null) return '$base $t';
  }
  return base;
}

// متنی که در نتایج نشان داده می‌شود
String shownText(Map<String, dynamic> m) {
  if (kindOf(m) == 'audio') {
    final t = ai.transcriptFor(m['file_path'] as String?);
    if (t != null) return '🎤 $t';
  }
  return snippet(m);
}

// ===========================================================================
// ابزارهای متنی فارسی/انگلیسی
// ===========================================================================
String normFa(String s) {
  var o = s.replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll('ۀ', 'ه').replaceAll('ة', 'ه');
  o = o.replaceAll(RegExp('[\u064B-\u065F\u0640]'), '').replaceAll(RegExp('[\u200c\u200d\u200e\u200f]'), '');
  const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
  for (var i = 0; i < 10; i++) {
    o = o.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
  }
  return o.toLowerCase();
}

Future<bool> _confirm(BuildContext c, String title, String body, String yes) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (d) => AlertDialog(
      title: Text(title),
      content: Text(body, style: const TextStyle(height: 1.6)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: Text(trn('بعداً'))),
        FilledButton(onPressed: () => Navigator.pop(d, true), child: Text(yes)),
      ],
    ),
  );
  return r == true;
}

Future<T> _withBusy<T>(BuildContext c, String msg, Future<T> Function() job) async {
  showDialog(
    context: c,
    barrierDismissible: false,
    useRootNavigator: true,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(content: Row(children: [const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 3)), const SizedBox(width: 16), Expanded(child: Text(msg))])),
    ),
  );
  try {
    return await job();
  } finally {
    if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  }
}

Future<T> _withProgress<T>(BuildContext c, String title, Future<T> Function(ValueNotifier<double?> p, ValueNotifier<String> msg) job) async {
  final p = ValueNotifier<double?>(null);
  final msg = ValueNotifier<String>('');
  showDialog(
    context: c,
    barrierDismissible: false,
    useRootNavigator: true,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(
        title: Text(title, style: const TextStyle(fontSize: 16)),
        content: ValueListenableBuilder<double?>(
          valueListenable: p,
          builder: (_, v, __) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            LinearProgressIndicator(value: v),
            const SizedBox(height: 12),
            ValueListenableBuilder<String>(valueListenable: msg, builder: (_, m, __) => Text(v == null ? m : '${(v * 100).round()}٪  $m', textAlign: TextAlign.center)),
          ]),
        ),
      ),
    ),
  );
  try {
    return await job(p, msg);
  } finally {
    if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  }
}

// ===========================================================================
// تبدیل گفتار به متن روی گوشی (Vosk)
// ===========================================================================
const sttUrls = {
  'fa': 'https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip',
  'en': 'https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip',
};

class _Wav {
  final Int16List samples;
  final int rate;
  const _Wav(this.samples, this.rate);
}

_Wav _parseWav(Uint8List b) {
  if (b.length < 44 || String.fromCharCodes(b.sublist(0, 4)) != 'RIFF' || String.fromCharCodes(b.sublist(8, 12)) != 'WAVE') throw 'format';
  final bd = ByteData.sublistView(b);
  var pos = 12, ch = 1, rate = 16000, bits = 16, fmt = 1, dataStart = -1, dataLen = 0;
  while (pos + 8 <= b.length) {
    final id = String.fromCharCodes(b.sublist(pos, pos + 4));
    final sz = bd.getUint32(pos + 4, Endian.little);
    final body = pos + 8;
    if (id == 'fmt ' && body + 16 <= b.length) {
      fmt = bd.getUint16(body, Endian.little);
      ch = bd.getUint16(body + 2, Endian.little);
      rate = bd.getUint32(body + 4, Endian.little);
      bits = bd.getUint16(body + 14, Endian.little);
    } else if (id == 'data') {
      dataStart = body;
      dataLen = (sz == 0 || body + sz > b.length) ? b.length - body : sz;
      break;
    }
    pos = body + sz + (sz & 1);
  }
  if (dataStart < 0 || bits != 16 || ch < 1 || (fmt != 1 && fmt != 0xFFFE)) throw 'format';
  final frames = dataLen ~/ (2 * ch);
  final mono = Int16List(frames);
  for (var i = 0; i < frames; i++) {
    var s = 0;
    for (var c = 0; c < ch; c++) {
      s += bd.getInt16(dataStart + (i * ch + c) * 2, Endian.little);
    }
    mono[i] = s ~/ ch;
  }
  return _Wav(mono, rate);
}

Int16List _resample(Int16List x, int from, int to) {
  if (from == to || x.isEmpty) return x;
  final n = (x.length * to / from).floor();
  final o = Int16List(n);
  for (var i = 0; i < n; i++) {
    final p = i * from / to;
    final i0 = p.floor();
    final i1 = math.min(i0 + 1, x.length - 1);
    final f = p - i0;
    o[i] = (x[i0] * (1 - f) + x[i1] * f).round();
  }
  return o;
}

String _voskText(String j) {
  try {
    return (((jsonDecode(j) as Map)['text']) as String? ?? '').trim();
  } catch (_) {
    return '';
  }
}

void _unzip(List<String> a) => extractFileToDisk(a[0], a[1]);

class LocalStt {
  static vosk.Model? _model;
  static String? _lang;

  static Future<bool> isReady(String lang) async {
    final p = await SharedPreferences.getInstance();
    return p.getBool('stt_ok_$lang') ?? false;
  }

  static String _name(String lang) => sttUrls[lang]!.split('/').last.replaceAll('.zip', '');

  static Future<String> _dir(String lang) async => '${(await getApplicationSupportDirectory()).path}/vosk/${_name(lang)}';

  static Future<void> download(String lang, [ValueNotifier<double?>? prog, ValueNotifier<String>? msg]) async {
    final root = Directory('${(await getApplicationSupportDirectory()).path}/vosk');
    await root.create(recursive: true);
    final zip = File('${root.path}/${_name(lang)}.zip');
    final client = HttpClient();
    try {
      final req = await client.getUrl(Uri.parse(sttUrls[lang]!));
      final res = await req.close();
      if (res.statusCode != 200) throw 'http';
      final total = res.contentLength;
      final sink = zip.openWrite();
      var got = 0;
      await for (final chunk in res) {
        sink.add(chunk);
        got += chunk.length;
        if (total > 0 && prog != null) {
          prog.value = got / total * 0.92;
          msg?.value = trf('{0} از {1} مگابایت', [(got / 1048576).toStringAsFixed(1), (total / 1048576).toStringAsFixed(1)]);
        }
      }
      await sink.close();
    } finally {
      client.close();
    }
    msg?.value = trn('در حال باز کردن فایل‌ها…');
    prog?.value = 0.95;
    await compute(_unzip, [zip.path, root.path]);
    try {
      await zip.delete();
    } catch (_) {}
    prog?.value = 1;
    final p = await SharedPreferences.getInstance();
    await p.setBool('stt_ok_$lang', true);
  }

  static Future<vosk.Model> _load(String lang) async {
    if (_model != null && _lang == lang) return _model!;
    final path = await _dir(lang);
    // مدل ناقص/خراب باعث کرش بومی (بسته‌شدن ناگهانی برنامه) می‌شود؛ قبل از بارگذاری بررسی می‌کنیم
    final okFiles = await File('$path/am/final.mdl').exists() && await Directory('$path/conf').exists() && await Directory('$path/graph').exists();
    if (!okFiles) {
      final p = await SharedPreferences.getInstance();
      await p.setBool('stt_ok_$lang', false);
      try {
        await Directory(path).delete(recursive: true);
      } catch (_) {}
      throw 'nomodel';
    }
    _model = await vosk.VoskFlutterPlugin.instance().createModel(path);
    _lang = lang;
    return _model!;
  }

  static Future<String> transcribe(Uint8List bytes, String lang) async {
    final w = _parseWav(bytes);
    final pcm = _resample(w.samples, w.rate, 16000);
    final model = await _load(lang);
    final rec = await vosk.VoskFlutterPlugin.instance().createRecognizer(model: model, sampleRate: 16000);
    final parts = <String>[];
    try {
      final raw = pcm.buffer.asUint8List(pcm.offsetInBytes, pcm.lengthInBytes);
      const chunk = 16000;
      for (var i = 0; i < raw.length; i += chunk) {
        final end = math.min(i + chunk, raw.length);
        final done = await rec.acceptWaveformBytes(raw.sublist(i, end));
        if (done) parts.add(_voskText(await rec.getResult()));
      }
      parts.add(_voskText(await rec.getFinalResult()));
    } finally {
      await rec.dispose();
    }
    return parts.where((e) => e.isNotEmpty).join(' ').trim();
  }
}

Future<void> _sttQueue = Future.value();
Future<T> _enqueue<T>(Future<T> Function() f) {
  final c = Completer<T>();
  _sttQueue = _sttQueue.then((_) async {
    try {
      c.complete(await f());
    } catch (e) {
      c.completeError(e);
    }
  });
  return c.future;
}

Future<bool> ensureSttModel(BuildContext c, String lang) async {
  if (await LocalStt.isReady(lang)) return true;
  if (!c.mounted) return false;
  final ok = await _confirm(c, 'دانلود مدل تبدیل گفتار به متن', 'برای تبدیل ویس به متن، یک‌بار مدل ${lang == 'fa' ? trn('فارسی') : trn('انگلیسی')} (حدود ${lang == 'fa' ? '۴۷' : '۴۰'} مگابایت) دانلود می‌شود. بعد از آن بدون اینترنت کار می‌کند.', trn('دانلود'));
  if (!ok || !c.mounted) return false;
  try {
    await _withProgress(c, 'دانلود مدل گفتار', (p, m) => LocalStt.download(lang, p, m));
    return true;
  } catch (_) {
    if (c.mounted) snack(c, trn('دانلود انجام نشد. اینترنت را بررسی کنید.'));
    return false;
  }
}

String aiErr(Object e) {
  if (e == 'old') return trn('این ویس با فرمت قدیمی ذخیره شده و قابل تبدیل نیست. ویس‌های جدید قابل تبدیل‌اند.');
  if (e == 'nomodel') return trn('مدل گفتار هنوز دانلود نشده است.');
  if (e == 'format') return trn('فرمت صدا پشتیبانی نمی‌شود.');
  return trn('تبدیل به متن انجام نشد.');
}

// ویس را به متن تبدیل می‌کند و در حافظه‌ی گوشی نگه می‌دارد (برای جست‌وجو)
Future<String?> aiTranscribe(BuildContext? ctx, String path, {bool silent = false}) async {
  final cached = ai.transcripts[path];
  if (cached != null) return cached;
  if (!path.toLowerCase().endsWith('.wav')) throw 'old';
  final lang = ai.sttLang;
  if (!await LocalStt.isReady(lang)) {
    if (silent || ctx == null || !ctx.mounted) throw 'nomodel';
    if (!await ensureSttModel(ctx, lang)) return null;
  }
  final bytes = await sb.storage.from('chat-files').download(path);
  final text = await _enqueue(() => LocalStt.transcribe(bytes, lang));
  final t = text.isEmpty ? trn('(متنی تشخیص داده نشد)') : text;
  ai.putTranscript(path, t);
  return t;
}

class VoiceTranscript extends StatefulWidget {
  final String path;
  const VoiceTranscript(this.path, {super.key});
  @override
  State<VoiceTranscript> createState() => _VoiceTranscriptState();
}

class _VoiceTranscriptState extends State<VoiceTranscript> {
  bool busy = false;
  String? err;

  @override
  void initState() {
    super.initState();
    ai.addListener(_r);
    if (ai.autoStt && widget.path.toLowerCase().endsWith('.wav') && ai.transcripts[widget.path] == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => run(silent: true));
    }
  }

  void _r() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    ai.removeListener(_r);
    super.dispose();
  }

  Future<void> run({bool silent = false}) async {
    if (busy) return;
    setState(() {
      busy = true;
      err = null;
    });
    try {
      await aiTranscribe(context, widget.path, silent: silent);
    } catch (e) {
      if (!silent && mounted) setState(() => err = aiErr(e));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final t = ai.transcripts[widget.path];
    if (t != null) {
      return Container(
        width: 240,
        margin: const EdgeInsets.only(top: 6),
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
        decoration: BoxDecoration(border: BorderDirectional(start: BorderSide(color: accent, width: 2.5))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.subtitles_outlined, size: 14),
            const SizedBox(width: 4),
            Text(trn('متن ویس'), style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
            const Spacer(),
            InkWell(
              onTap: () {
                Clipboard.setData(ClipboardData(text: t));
                snack(context, trn('کپی شد'));
              },
              child: const Icon(Icons.copy, size: 14),
            ),
          ]),
          const SizedBox(height: 4),
          SelectableText(t, style: const TextStyle(fontSize: 13.5, height: 1.5)),
        ]),
      );
    }
    if (busy) {
      return Padding(padding: EdgeInsets.only(top: 6), child: Row(mainAxisSize: MainAxisSize.min, children: [SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)), SizedBox(width: 8), Text(trn('در حال تبدیل به متن…'), style: TextStyle(fontSize: 12))]));
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
      InkWell(
        onTap: run,
        child: Padding(padding: EdgeInsets.only(top: 6), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.subtitles_outlined, size: 15), SizedBox(width: 5), Text(trn('تبدیل به متن'), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700))])),
      ),
      if (err != null) SizedBox(width: 240, child: Text(err!, style: const TextStyle(fontSize: 11))),
    ]);
  }
}

// تبدیل گروهی ویس‌های اخیر برای اینکه در جست‌وجو پیدا شوند
Future<void> transcribeRecent(BuildContext c, List<Map<String, dynamic>> all) async {
  final todo = <String>[];
  for (final m in all.reversed) {
    if (kindOf(m) != 'audio') continue;
    final p = m['file_path'] as String?;
    if (p == null || !p.toLowerCase().endsWith('.wav') || ai.transcripts[p] != null) continue;
    todo.add(p);
    if (todo.length >= 20) break;
  }
  if (todo.isEmpty) {
    snack(c, trn('ویس تازه‌ای برای تبدیل پیدا نشد (فقط ویس‌های جدید قابل تبدیل‌اند)'));
    return;
  }
  if (!await ensureSttModel(c, ai.sttLang)) return;
  if (!c.mounted) return;
  var done = 0;
  await _withBusy(c, 'تبدیل ${todo.length} ویس به متن… (ممکن است چند دقیقه طول بکشد)', () async {
    for (final p in todo) {
      try {
        await aiTranscribe(null, p);
        done++;
      } catch (_) {}
    }
  });
  if (c.mounted) snack(c, trf('{0} ویس به متن تبدیل شد', [done]));
}

// ===========================================================================
// تنظیمات دستیار روی گوشی: ترجمه، خلاصه، پیشنهاد پاسخ و ویس به متن
// ===========================================================================
// ===========================================================================
// تنظیمات هوش تیا
// ===========================================================================
class AiSettingsPage extends StatefulWidget {
  const AiSettingsPage({super.key});
  @override
  State<AiSettingsPage> createState() => _AiSettingsPageState();
}

class _AiSettingsPageState extends State<AiSettingsPage> {
  Widget head(String t) => Padding(padding: const EdgeInsets.only(top: 22, bottom: 6), child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: cText)));

  Widget modelTile(String title, Future<bool> ready, Future<void> Function() get) => FutureBuilder<bool>(
        future: ready,
        builder: (c, s) => ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(title),
          subtitle: Text(s.data == true ? trn('دانلود شده ✓') : trn('دانلود نشده')),
          trailing: s.data == true ? null : FilledButton.tonal(onPressed: () async {
            await get();
            if (mounted) setState(() {});
          }, child: Text(trn('دانلود'))),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('هوش روی گوشی'))),
        body: ListenableBuilder(
          listenable: ai,
          builder: (c, _) => ListView(padding: const EdgeInsets.all(16), children: [
            head(trn('دستیار پیام‌ها')),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('نوار پیشنهاد پاسخ بالای کادر پیام')),
              subtitle: Text(trn('پیشنهادهای آماده برای پاسخ به آخرین پیام، ترجمه‌ی متن در حال نوشتن و تکمیل جمله')),
              value: ai.smartBar,
              onChanged: (v) {
                ai.smartBar = v;
                ai.save();
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('ترجمه‌ی زنده‌ی پیام‌های دریافتی')),
              subtitle: Text(trn('ترجمه زیر هر پیام نشان داده می‌شود. متن پیام برای ترجمه به سرویس ترجمه‌ی آنلاین فرستاده می‌شود.')),
              value: ai.live,
              onChanged: (v) async {
                if (v && !await _confirm(context, trn('ترجمه‌ی زنده'), trn('متن پیام‌های دریافتی برای ترجمه به یک سرویس ترجمه‌ی آنلاین فرستاده می‌شود. ادامه می‌دهید؟'), trn('روشن کن'))) return;
                ai.live = v;
                ai.save();
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('ترجمه‌ی زنده به')),
              trailing: DropdownButton<String>(
                value: ai.liveTo,
                underline: const SizedBox.shrink(),
                items: [DropdownMenuItem(value: 'fa', child: Text(trn('فارسی'))), DropdownMenuItem(value: 'en', child: Text(trn('انگلیسی')))],
                onChanged: (v) {
                  if (v == null) return;
                  ai.liveTo = v;
                  ai.save();
                },
              ),
            ),
            head(trn('گفتگو')),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('ضبط ویس به‌صورت قابل تبدیل به متن')),
              subtitle: Text(trn('ویس‌ها با فرمت WAV ارسال می‌شوند؛ حجم حدود ۱۰ برابر بیشتر از قبل')),
              value: ai.wavVoice,
              onChanged: (v) {
                ai.wavVoice = v;
                ai.save();
              },
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('تبدیل خودکار ویس‌ها به متن')),
              subtitle: Text(trn('هر ویس WAV که در چت دیده شود، در پس‌زمینه تبدیل می‌شود (مصرف باتری)')),
              value: ai.autoStt,
              onChanged: (v) {
                ai.autoStt = v;
                ai.save();
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(trn('زبان گفتار ویس‌ها')),
              trailing: DropdownButton<String>(
                value: ai.sttLang,
                underline: const SizedBox.shrink(),
                items: [DropdownMenuItem(value: 'fa', child: Text(trn('فارسی'))), DropdownMenuItem(value: 'en', child: Text(trn('انگلیسی')))],
                onChanged: (v) {
                  if (v == null) return;
                  ai.sttLang = v;
                  ai.save();
                },
              ),
            ),
            head(trn('مدل‌های روی گوشی')),
            modelTile(trn('گفتار فارسی (حدود ۴۷ مگابایت)'), LocalStt.isReady('fa'), () async {
              await ensureSttModel(context, 'fa');
            }),
            modelTile(trn('گفتار انگلیسی (حدود ۴۰ مگابایت)'), LocalStt.isReady('en'), () async {
              await ensureSttModel(context, 'en');
            }),
            modelTile(trn('ترجمه‌ی فارسی'), mlReady('fa'), () async {
              final ok = await _withBusy(context, trn('دانلود مدل ترجمه'), () => mlDownload('fa'));
              if (!ok && context.mounted) snack(context, trn('دانلود انجام نشد. اینترنت را بررسی کنید.'));
            }),
            modelTile(trn('ترجمه‌ی انگلیسی'), mlReady('en'), () async {
              final ok = await _withBusy(context, trn('دانلود مدل ترجمه'), () => mlDownload('en'));
              if (!ok && context.mounted) snack(context, trn('دانلود انجام نشد. اینترنت را بررسی کنید.'));
            }),
            head(trn('داده‌ها')),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
              title: Text(trf('پاک‌کردن متن ویس‌های ذخیره‌شده ({0})', [ai.transcripts.length])),
              onTap: () {
                ai.clearTranscripts();
                snack(context, trn('پاک شد'));
              },
            ),
          ]),
        ),
      );
}
