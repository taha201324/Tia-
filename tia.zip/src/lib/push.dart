import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'chat.dart';
import 'main.dart';
import 'notifications.dart';

const _apiKey = String.fromEnvironment('FIREBASE_API_KEY');
const _appId = String.fromEnvironment('FIREBASE_APP_ID');
const _senderId = String.fromEnvironment('FIREBASE_SENDER_ID');
const _projectId = String.fromEnvironment('FIREBASE_PROJECT_ID');

bool pushAvailable = false;

Future<void> initPush() async {
  if (_apiKey.isEmpty || _appId.isEmpty || _senderId.isEmpty || _projectId.isEmpty) return;
  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(apiKey: _apiKey, appId: _appId, messagingSenderId: _senderId, projectId: _projectId),
    );
    pushAvailable = true;
  } catch (_) {}
}

class PushService {
  static bool _listening = false;

  static Future<void> register() async {
    if (!pushAvailable || me == null) return;
    final m = FirebaseMessaging.instance;
    await m.requestPermission();
    final t = await m.getToken();
    if (t != null) await _save(t);
    if (!_listening) {
      _listening = true;
      m.onTokenRefresh.listen((t) {
        _save(t).catchError((_) {});
      });
      FirebaseMessaging.onMessageOpenedApp.listen(_open);
      final first = await m.getInitialMessage();
      if (first != null) Future.delayed(const Duration(milliseconds: 700), () => _open(first));
    }
  }

  static Future<void> _save(String t) => sb.rpc('register_token', params: {
        'p_token': t,
        'p_preview': settings.pushPreview,
        'p_msgs': settings.pushMessages,
        'p_groups': settings.pushGroups,
        'p_social': settings.pushSocial,
      });

  static Future<void> refresh() async {
    if (!pushAvailable || me == null) return;
    final t = await FirebaseMessaging.instance.getToken();
    if (t != null) await _save(t);
  }

  static Future<void> unregister() async {
    if (!pushAvailable) return;
    try {
      final t = await FirebaseMessaging.instance.getToken();
      if (t != null) await sb.from('device_tokens').delete().eq('token', t);
    } catch (_) {}
  }

  static void _open(RemoteMessage m) {
    final type = m.data['type'];
    final id = m.data['id'];
    final nav = navKey.currentState;
    if (nav == null || id == null) return;
    if (type == 'g') {
      final g = int.tryParse(id);
      if (g != null) nav.push(MaterialPageRoute(builder: (_) => ChatPage(gid: g)));
    } else if (type == 'd') {
      nav.push(MaterialPageRoute(builder: (_) => ChatPage(peer: id)));
    } else if (type == 'social') {
      nav.push(MaterialPageRoute(builder: (_) => const NotificationsPage()));
    }
  }
}
