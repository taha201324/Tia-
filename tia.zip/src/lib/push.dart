import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'chat.dart';
import 'groups.dart';
import 'main.dart';
import 'l10n.dart';

// Tia Push بدون سرور جدا کار می‌کند و فقط از همان Supabase پروژه استفاده می‌کند.
const _supaUrl = String.fromEnvironment('SUPABASE_URL');
const _supaKey = String.fromEnvironment('SUPABASE_ANON_KEY');
const _appVersion = '1.4.0';

/// پل Flutter ← سرویس بومی اندروید (Tia Push). هیچ وابستگی به Firebase یا Google Play Services ندارد.
class TiaPush with WidgetsBindingObserver {
  TiaPush._();
  static final TiaPush instance = TiaPush._();
  static const _ch = MethodChannel('tia/push');

  bool get supported => Platform.isAndroid && _supaUrl.startsWith('https://') && _supaKey.isNotEmpty;

  bool _started = false, _busy = false, _again = false;
  StreamSubscription<AuthState>? _sub;
  Timer? _retry;
  int _retryN = 0;
  String lastError = '';

  /// از Home.initState صدا زده می‌شود. چند بار صدا زدن بی‌خطر است.
  Future<void> start() async {
    if (!supported) return;
    if (!_started) {
      _started = true;
      WidgetsBinding.instance.addObserver(this);
      _sub = sb.auth.onAuthStateChange.listen((s) {
        if (s.event == AuthChangeEvent.signedOut) {
          _clearNative();
        } else if (s.session != null && (s.event == AuthChangeEvent.signedIn || s.event == AuthChangeEvent.initialSession)) {
          sync();
        }
      });
    }
    await sync();
    WidgetsBinding.instance.addPostFrameCallback((_) => _openPending());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && sb.auth.currentSession != null) {
      sync();
      _openPending();
    }
  }

  Future<Map<String, dynamic>> status() async {
    if (!supported) return {'state': 'unsupported'};
    try {
      return Map<String, dynamic>.from(await _ch.invokeMethod('status') as Map);
    } catch (_) {
      return {'state': 'unknown'};
    }
  }

  /// ثبت دستگاه (در صورت نیاز) و هماهنگی سرویس بومی با وضعیت ورود، تنظیم اعلان و مجوز.
  Future<void> sync({bool force = false}) async {
    if (!supported) return;
    if (_busy) {
      _again = true;
      return;
    }
    _busy = true;
    try {
      final user = sb.auth.currentUser;
      if (sb.auth.currentSession == null || user == null) return;
      if (!settings.notifications) {
        await _ch.invokeMethod('setEnabled', {'enabled': false});
        return;
      }
      var st = await status();
      if (st['notificationsAllowed'] != true) {
        final p = await SharedPreferences.getInstance();
        if (p.getBool('push_perm_asked') != true) {
          await p.setBool('push_perm_asked', true);
          await _ch.invokeMethod('requestNotificationPermission');
          st = await status();
        }
      }
      final needReg = force || st['configured'] != true || st['authFailed'] == true || st['userId'] != user.id;
      if (needReg) {
        await _register(user.id);
      } else {
        await _ch.invokeMethod('setEnabled', {'enabled': true});
      }
      _retryN = 0;
      _retry?.cancel();
      lastError = '';
    } catch (e) {
      lastError = e.toString();
      _scheduleRetry();
    } finally {
      _busy = false;
      if (_again) {
        _again = false;
        sync();
      }
    }
  }

  Future<void> _register(String uid) async {
    final deviceId = await _ch.invokeMethod('deviceId') as String;
    final token = await sb.rpc('register_push_device', params: {
      'p_device_id': deviceId,
      'p_platform': 'android',
      'p_app_version': _appVersion,
    });
    await _ch.invokeMethod('configure', {'url': _supaUrl, 'anon': _supaKey, 'token': token as String, 'userId': uid, 'enabled': true});
  }

  void _scheduleRetry() {
    _retry?.cancel();
    final secs = (15 << (_retryN < 5 ? _retryN : 5)).clamp(15, 600).toInt(); // 15,30,60,120,240,480,600 ثانیه
    _retryN++;
    _retry = Timer(Duration(seconds: secs), sync);
  }

  /// قبل از خروج از حساب صدا زده شود: دستگاه از سرور حذف و سرویس بومی پاک می‌شود.
  Future<void> unregister() async {
    if (!supported) return;
    try {
      final id = await _ch.invokeMethod('deviceId') as String;
      await sb.rpc('unregister_push_device', params: {'p_device_id': id}).timeout(const Duration(seconds: 6));
    } catch (_) {
      // اگر آفلاین بودیم، دستگاه در ورود بعدی به حساب جدید منتقل می‌شود (و صف حساب قبلی روی سرور پاک می‌شود)
    }
    await _clearNative();
  }

  /// بدون حذف دستگاه از سرور، فقط اتصال و اعلان‌های همین گوشی را قطع می‌کند (هنگام افزودن حساب)
  Future<void> releaseLocal() => _clearNative();

  Future<void> _clearNative() async {
    _retry?.cancel();
    if (!supported) return;
    try {
      await _ch.invokeMethod('clear');
    } catch (_) {}
  }

  Future<void> _openPending() async {
    if (!supported) return;
    try {
      final m = await _ch.invokeMethod('takePendingOpen');
      if (m == null) return;
      final c = navKey.currentContext;
      if (c == null) return;
      final mm = m as Map;
      final id = mm['id'] as String;
      if (mm['kind'] == 'group') {
        final gid = int.tryParse(id);
        if (gid != null) openGroup(c, gid);
      } else {
        openChat(c, id);
      }
    } catch (_) {}
  }

  Future<bool> requestPermission() async => (await _ch.invokeMethod('requestNotificationPermission')) == true;
  Future<void> openNotificationSettings() => _ch.invokeMethod('openNotificationSettings');
  Future<void> openBatterySettings() => _ch.invokeMethod('openBatterySettings');
  Future<void> openChannelSettings() => _ch.invokeMethod('openChannelSettings');
  Future<void> setInstant(bool v) => _ch.invokeMethod('setInstant', {'instant': v});
}

/// ردیف وضعیت اعلان آنی در تنظیمات
class PushSettingsTile extends StatefulWidget {
  const PushSettingsTile({super.key});
  @override
  State<PushSettingsTile> createState() => _PushSettingsTileState();
}

class _PushSettingsTileState extends State<PushSettingsTile> {
  Map<String, dynamic> st = const {};
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 4), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final s = await TiaPush.instance.status();
    if (mounted) setState(() => st = s);
  }

  String get _label {
    if (!TiaPush.instance.supported) return trn('آدرس Supabase هنگام ساخت برنامه وارد نشده');
    if (!settings.notifications) return trn('خاموش (با کلید بالا روشن کنید)');
    if (st['notificationsAllowed'] == false) return trn('مجوز اعلان داده نشده');
    switch (st['state']) {
      case 'polling':
        return trn('فعال (بررسی خودکار هر چند دقیقه)');
      case 'connected':
        return trn('متصل (آنی)');
      case 'connecting':
        return trn('در حال اتصال…');
      case 'disconnected':
        return trn('قطع شد؛ تلاش خودکار برای اتصال دوباره');
      case 'auth_failed':
        return trn('نیاز به ثبت مجدد دستگاه');
      default:
        return trn('غیرفعال');
    }
  }

  @override
  Widget build(BuildContext context) => ListTile(
        leading: const Icon(Icons.bolt_outlined),
        title: Text(trn('اعلان آنی Tia')),
        subtitle: Text(_label),
        onTap: !TiaPush.instance.supported
            ? null
            : () => showDialog(
                  context: context,
                  builder: (d) => AlertDialog(
                    title: Text(trn('اعلان آنی Tia')),
                    content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(trf('وضعیت: {0}', [_label])),
                      const SizedBox(height: 8),
                      Text(st['ignoringBatteryOptimizations'] == true
                          ? trn('محدودیت باتری برای Tia برداشته شده است.')
                          : trn('در حالت عادی هیچ اعلان ثابتی نشان داده نمی‌شود و اعلان‌ها هر چند دقیقه به‌صورت خودکار بررسی می‌شوند. اگر اعلان آنی (اتصال دائمی) را روشن کنید، اندروید یک اعلان کوچک ثابت نشان می‌دهد. برای پایدارتر ماندن، در تنظیمات باتری، Tia را از «بهینه‌سازی» مستثنی کنید. در برخی گوشی‌ها (مثل شیائومی و هواوی) باید «شروع خودکار» را هم روشن کنید.')),
                    ]),
                    actions: [
                      TextButton(
                        onPressed: () async {
                          Navigator.pop(d);
                          if (st['notificationsAllowed'] == false && !await TiaPush.instance.requestPermission()) {
                            await TiaPush.instance.openNotificationSettings();
                          }
                          await TiaPush.instance.sync(force: st['authFailed'] == true);
                          _load();
                        },
                        child: Text(trn('بررسی دوباره')),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(d);
                          TiaPush.instance.openBatterySettings();
                        },
                        child: Text(trn('تنظیم باتری')),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(d);
                          TiaPush.instance.openChannelSettings();
                        },
                        child: Text(trn('اعلان ثابت')),
                      ),
                      TextButton(onPressed: () => Navigator.pop(d), child: Text(trn('بستن'))),
                    ],
                  ),
                ),
      );
}


/// کلید «اعلان آنی (اتصال دائمی)»؛ پیش‌فرض خاموش تا اعلان ثابت دیده نشود
class PushInstantSwitch extends StatefulWidget {
  const PushInstantSwitch({super.key});
  @override
  State<PushInstantSwitch> createState() => _PushInstantSwitchState();
}

class _PushInstantSwitchState extends State<PushInstantSwitch> {
  bool on = false;

  @override
  void initState() {
    super.initState();
    TiaPush.instance.status().then((s) {
      if (mounted) setState(() => on = s['instant'] == true);
    });
  }

  @override
  Widget build(BuildContext context) => SwitchListTile(
        secondary: const Icon(Icons.flash_on_outlined),
        title: Text(trn('اعلان آنی (اتصال دائمی)')),
        subtitle: Text(trn('اعلان‌ها فوری می‌رسند، ولی اندروید یک اعلان کوچک ثابت نشان می‌دهد. خاموش: بدون اعلان ثابت و با چند دقیقه تأخیر.'), style: TextStyle(fontSize: 12)),
        value: on,
        onChanged: !TiaPush.instance.supported
            ? null
            : (v) async {
                setState(() => on = v);
                try {
                  await TiaPush.instance.setInstant(v);
                } catch (_) {
                  if (mounted) setState(() => on = !v);
                }
              },
      );
}
