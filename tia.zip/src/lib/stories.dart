import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'main.dart';
import 'social.dart';

const storyGrads = [
  [0xFF7B5CFF, 0xFF3F51B5],
  [0xFFE91E63, 0xFFFF9800],
  [0xFF00BFA5, 0xFF2196F3],
  [0xFF232526, 0xFF414345],
  [0xFFF44336, 0xFF9C27B0],
  [0xFF4CAF50, 0xFFCDDC39],
];

Gradient storyGradient(int i) {
  final g = storyGrads[i.clamp(0, storyGrads.length - 1)];
  return LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(g[0]), Color(g[1])]);
}

class StoriesBar extends StatefulWidget {
  const StoriesBar({super.key});
  @override
  State<StoriesBar> createState() => _StoriesBarState();
}

class _StoriesBarState extends State<StoriesBar> {
  final byUser = <String, List<Map<String, dynamic>>>{};
  Set<int> seen = {};
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final f = await sb.from('follows').select('followee_id').eq('follower_id', me!).eq('status', 'accepted');
      final ids = {me!, ...f.map((r) => r['followee_id'] as String)};
      final since = DateTime.now().toUtc().subtract(const Duration(hours: 24)).toIso8601String();
      final rows = await sb.from('stories').select().gt('created_at', since).inFilter('user_id', ids.toList()).order('created_at');
      await store.loadPeople(ids);
      final v = rows.isEmpty
          ? <Map<String, dynamic>>[]
          : await sb.from('story_views').select('story_id').eq('viewer_id', me!).inFilter('story_id', rows.map((r) => r['id'] as int).toList());
      final map = <String, List<Map<String, dynamic>>>{};
      for (final r in rows) {
        map.putIfAbsent(r['user_id'] as String, () => []).add(r);
      }
      if (!mounted) return;
      setState(() {
        byUser
          ..clear()
          ..addAll(map);
        seen = v.map((r) => r['story_id'] as int).toSet();
        loaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => loaded = true);
    }
  }

  bool allSeen(String u) => byUser[u]!.every((s) => seen.contains(s['id']));
  String lastTime(String u) => byUser[u]!.last['created_at'] as String;

  Widget ring(String id, {required bool unseen, required VoidCallback onTap, String? label, bool plus = false}) => GestureDetector(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Stack(children: [
              Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: unseen ? LinearGradient(colors: [primary, accent]) : null,
                  border: unseen ? null : Border.all(color: cLine, width: 2),
                ),
                child: Container(padding: EdgeInsets.all(2), decoration: BoxDecoration(shape: BoxShape.circle, color: bg), child: avatarFor(id, r: 26)),
              ),
              if (plus) Positioned(bottom: 0, right: 0, child: CircleAvatar(radius: 10, backgroundColor: primary, child: Icon(Icons.add, size: 14, color: cOnPrimary))),
            ]),
            const SizedBox(height: 4),
            SizedBox(width: 64, child: Text(label ?? store.name(id), maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11))),
          ]),
        ),
      );

  Future<void> compose() async {
    final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const StoryComposePage()));
    if (ok == true) load();
  }

  Future<void> openViewer(List<String> order, int index) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => StoryViewer(order: order, index: index, byUser: byUser)));
    if (mounted) load();
  }

  Future<void> myTap(List<Map<String, dynamic>> mine, List<String> order) async {
    if (mine.isEmpty) {
      await compose();
      return;
    }
    final a = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(leading: const Icon(Icons.play_circle_outline), title: const Text('مشاهده‌ی استوری‌های من'), onTap: () => Navigator.pop(c, 'view')),
            ListTile(leading: const Icon(Icons.add_circle_outline), title: const Text('افزودن استوری جدید'), onTap: () => Navigator.pop(c, 'add')),
          ]),
        ),
      ),
    );
    if (a == 'view') await openViewer(order, 0);
    if (a == 'add') await compose();
  }

  @override
  Widget build(BuildContext context) {
    final mine = byUser[me] ?? <Map<String, dynamic>>[];
    final others = byUser.keys.where((u) => u != me).toList()
      ..sort((a, b) {
        final ua = allSeen(a), ub = allSeen(b);
        if (ua != ub) return ua ? 1 : -1;
        return lastTime(b).compareTo(lastTime(a));
      });
    final order = [if (mine.isNotEmpty) me!, ...others];
    return SizedBox(
      height: 94,
      child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), children: [
        ring(me!, unseen: false, plus: mine.isEmpty, label: 'استوری شما', onTap: () => myTap(mine, order)),
        for (final u in others) ring(u, unseen: !allSeen(u), onTap: () => openViewer(order, order.indexOf(u))),
      ]),
    );
  }
}

class StoryViewer extends StatefulWidget {
  final List<String> order;
  final int index;
  final Map<String, List<Map<String, dynamic>>> byUser;
  const StoryViewer({super.key, required this.order, required this.index, required this.byUser});
  @override
  State<StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<StoryViewer> with SingleTickerProviderStateMixin {
  late final AnimationController ac = AnimationController(vsync: this, duration: const Duration(seconds: 5));
  late int ui = widget.index;
  int si = 0;
  final reply = TextEditingController();
  final focus = FocusNode();

  String get uid => widget.order[ui];
  List<Map<String, dynamic>> get list => widget.byUser[uid] ?? <Map<String, dynamic>>[];
  Map<String, dynamic> get cur => list[si];

  @override
  void initState() {
    super.initState();
    ac.addStatusListener((s) {
      if (s == AnimationStatus.completed) next();
    });
    focus.addListener(() {
      if (focus.hasFocus) {
        ac.stop();
      } else if (mounted) {
        ac.forward();
      }
    });
    start();
  }

  @override
  void dispose() {
    ac.dispose();
    reply.dispose();
    focus.dispose();
    super.dispose();
  }

  void start() {
    if (list.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) Navigator.pop(context);
      });
      return;
    }
    ac.forward(from: 0);
    if (uid != me) {
      sb.from('story_views').upsert({'story_id': cur['id'], 'viewer_id': me}, ignoreDuplicates: true).catchError((_) {});
    }
  }

  void next() {
    if (si < list.length - 1) {
      setState(() => si++);
      start();
    } else if (ui < widget.order.length - 1) {
      setState(() {
        ui++;
        si = 0;
      });
      start();
    } else if (mounted) {
      Navigator.pop(context);
    }
  }

  void prev() {
    if (si > 0) {
      setState(() => si--);
    } else if (ui > 0) {
      final n = widget.byUser[widget.order[ui - 1]]?.length ?? 1;
      setState(() {
        ui--;
        si = n - 1;
      });
    }
    start();
  }

  Future<void> sendReply(String t) async {
    final x = t.trim();
    if (x.isEmpty) return;
    reply.clear();
    focus.unfocus();
    try {
      await store.sendRaw(uid, {'text': '↩️ پاسخ به استوری: $x', 'kind': 'text'});
      if (mounted) snack(context, 'ارسال شد');
    } catch (_) {
      if (mounted) snack(context, 'ارسال نشد');
    }
  }

  Future<void> viewers() async {
    ac.stop();
    try {
      final rows = await sb.from('story_views').select('viewer_id,viewed_at').eq('story_id', cur['id'] as int).order('viewed_at', ascending: false);
      await store.loadPeople(rows.map((r) => r['viewer_id'] as String));
      if (!mounted) return;
      await showModalBottomSheet(
        context: context,
        builder: (c) => Directionality(
          textDirection: TextDirection.rtl,
          child: SafeArea(
            child: ListView(shrinkWrap: true, children: [
              ListTile(title: Text('${rows.length} بازدید')),
              for (final r in rows)
                ListTile(leading: avatarFor(r['viewer_id'] as String), title: nameWithBadge(r['viewer_id'] as String), subtitle: Text(ago(r['viewed_at'] as String))),
            ]),
          ),
        ),
      );
    } catch (_) {}
    if (mounted) ac.forward();
  }

  Future<void> deleteStory() async {
    ac.stop();
    if (!await confirm(context, 'این استوری حذف شود؟')) {
      if (mounted) ac.forward();
      return;
    }
    try {
      await sb.from('stories').delete().eq('id', cur['id'] as int);
      widget.byUser[uid]?.removeAt(si);
      if (!mounted) return;
      if (list.isEmpty) {
        Navigator.pop(context);
        return;
      }
      if (si >= list.length) si = list.length - 1;
      setState(() {});
      start();
    } catch (_) {
      if (mounted) {
        snack(context, 'حذف نشد');
        ac.forward();
      }
    }
  }

  Widget content(Map<String, dynamic> s) {
    if (s['kind'] == 'image') {
      return FutureBuilder<String>(
        future: postUrl(s['image_path'] as String),
        builder: (c, snap) => snap.hasData
            ? Image.network(snap.data!, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image, color: Colors.white)))
            : const Center(child: CircularProgressIndicator()),
      );
    }
    return Container(
      decoration: BoxDecoration(gradient: storyGradient((s['bg'] as int?) ?? 0)),
      alignment: Alignment.center,
      padding: const EdgeInsets.all(28),
      child: Text(s['text'] as String, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w700)),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (list.isEmpty) return const Scaffold(backgroundColor: Colors.black);
    final s = cur;
    final mine = uid == me;
    final caption = s['kind'] == 'image' ? (s['text'] as String? ?? '') : '';
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(children: [
          Positioned.fill(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapUp: (d) {
                if (focus.hasFocus) {
                  focus.unfocus();
                  return;
                }
                d.globalPosition.dx < MediaQuery.of(context).size.width / 2 ? prev() : next();
              },
              onLongPressStart: (_) => ac.stop(),
              onLongPressEnd: (_) => ac.forward(),
              child: content(s),
            ),
          ),
          Positioned(
            top: 8,
            left: 8,
            right: 8,
            child: Column(children: [
              Row(children: [
                for (var i = 0; i < list.length; i++)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: i == si
                          ? AnimatedBuilder(animation: ac, builder: (_, __) => LinearProgressIndicator(value: ac.value, minHeight: 3, backgroundColor: Colors.white30, color: Colors.white))
                          : LinearProgressIndicator(value: i < si ? 1 : 0, minHeight: 3, backgroundColor: Colors.white30, color: Colors.white),
                    ),
                  ),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                avatarFor(uid, r: 18),
                const SizedBox(width: 8),
                Expanded(child: Text('${store.name(uid)} · ${ago(s['created_at'] as String)}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, shadows: [Shadow(blurRadius: 4)]))),
                IconButton(icon: const Icon(Icons.close, color: Colors.white), onPressed: () => Navigator.pop(context)),
              ]),
            ]),
          ),
          if (caption.isNotEmpty)
            Positioned(
              bottom: 84,
              left: 16,
              right: 16,
              child: Container(color: Colors.black54, padding: const EdgeInsets.all(10), child: Text(caption, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 16))),
            ),
          Positioned(
            bottom: 12,
            left: 12,
            right: 12,
            child: mine
                ? Row(children: [
                    FilledButton.tonalIcon(icon: const Icon(Icons.visibility), label: const Text('بازدیدها'), onPressed: viewers),
                    const Spacer(),
                    IconButton(icon: const Icon(Icons.delete_outline, color: Colors.white), onPressed: deleteStory),
                  ])
                : TextField(controller: reply, focusNode: focus, onSubmitted: sendReply, decoration: fieldDeco(hintText: 'پاسخ به استوری...')),
          ),
        ]),
      ),
    );
  }
}

class StoryComposePage extends StatefulWidget {
  const StoryComposePage({super.key});
  @override
  State<StoryComposePage> createState() => _StoryComposePageState();
}

class _StoryComposePageState extends State<StoryComposePage> {
  PlatformFile? img;
  final text = TextEditingController();
  int bgIdx = 0;
  bool busy = false;

  Future<void> pick() async {
    final f = await pickImage();
    if (f != null) setState(() => img = f);
  }

  Future<void> post() async {
    final t = text.text.trim();
    if (img == null && t.isEmpty) return;
    setState(() => busy = true);
    try {
      if (img != null) {
        final up = await uploadFile('post-images', img!.path!, img!.name);
        await sb.from('stories').insert({'user_id': me, 'kind': 'image', 'image_path': up, 'text': t});
      } else {
        await sb.from('stories').insert({'user_id': me, 'kind': 'text', 'text': t, 'bg': bgIdx});
      }
      if (mounted) Navigator.pop(context, true);
    } catch (_) {
      if (mounted) {
        snack(context, 'منتشر نشد. SQL استوری اجرا شده است؟');
        setState(() => busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          title: const Text('استوری جدید'),
          actions: [TextButton(onPressed: busy ? null : post, child: const Text('انتشار'))],
        ),
        body: Column(children: [
          Expanded(
            child: img != null
                ? Image.file(File(img!.path!), fit: BoxFit.contain)
                : Container(
                    decoration: BoxDecoration(gradient: storyGradient(bgIdx)),
                    alignment: Alignment.center,
                    padding: const EdgeInsets.all(24),
                    child: TextField(
                      controller: text,
                      maxLines: null,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w700),
                      decoration: const InputDecoration(border: InputBorder.none, hintText: 'متن استوری...', hintStyle: TextStyle(color: Colors.white70)),
                    ),
                  ),
          ),
          if (img != null) Padding(padding: EdgeInsets.all(12), child: TextField(controller: text, decoration: fieldDeco(hintText: 'توضیح (اختیاری)'))),
          if (busy) const LinearProgressIndicator(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                TextButton.icon(onPressed: pick, icon: const Icon(Icons.image, color: Colors.white), label: Text(img == null ? 'انتخاب عکس' : 'تغییر عکس', style: const TextStyle(color: Colors.white))),
                if (img != null) TextButton(onPressed: () => setState(() => img = null), child: const Text('حذف عکس')),
                const Spacer(),
                if (img == null)
                  for (var i = 0; i < storyGrads.length; i++)
                    GestureDetector(
                      onTap: () => setState(() => bgIdx = i),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(shape: BoxShape.circle, gradient: storyGradient(i), border: Border.all(color: Colors.white, width: bgIdx == i ? 3 : 1)),
                      ),
                    ),
              ]),
            ),
          ),
        ]),
      );
}
