import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'chat.dart';
import 'groups.dart';
import 'main.dart';

// ---------- reactions ----------
class ReactionStore extends ChangeNotifier {
  final byMsg = <String, List<Map<String, dynamic>>>{};
  StreamSubscription? _s;

  void start() {
    stop();
    _s = sb.from('reactions').stream(primaryKey: ['scope', 'message_id', 'user_id']).listen((rows) {
      byMsg.clear();
      for (final r in rows) {
        byMsg.putIfAbsent('${r['scope']}:${r['message_id']}', () => []).add(r);
      }
      notifyListeners();
    }, onError: (_) {});
  }

  void stop() {
    _s?.cancel();
    _s = null;
    byMsg.clear();
  }

  List<Map<String, dynamic>> of(String scope, int id) => byMsg['$scope:$id'] ?? [];

  Future<void> toggle(String scope, int id, String emoji) async {
    final mine = of(scope, id).where((r) => r['user_id'] == me).toList();
    if (mine.isNotEmpty && mine.first['emoji'] == emoji) {
      await sb.from('reactions').delete().eq('scope', scope).eq('message_id', id).eq('user_id', me!);
    } else {
      await sb.from('reactions').upsert({'scope': scope, 'message_id': id, 'user_id': me, 'emoji': emoji});
    }
  }
}

final rx = ReactionStore();

Widget reactionChips(String scope, int id) {
  final rows = rx.of(scope, id);
  if (rows.isEmpty) return const SizedBox.shrink();
  final counts = <String, int>{};
  for (final r in rows) {
    final e = r['emoji'] as String;
    counts[e] = (counts[e] ?? 0) + 1;
  }
  final mine = rows.where((r) => r['user_id'] == me).map((r) => r['emoji']).toSet();
  return Padding(
    padding: const EdgeInsets.only(top: 4),
    child: Wrap(spacing: 4, runSpacing: 4, children: [
      for (final e in counts.entries)
        InkWell(
          onTap: () => rx.toggle(scope, id, e.key).catchError((_) {}),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: mine.contains(e.key) ? accent : Colors.white24)),
            child: Text('${e.key} ${e.value}', style: const TextStyle(fontSize: 12, color: Colors.white)),
          ),
        ),
    ]),
  );
}

// ---------- polls ----------
class PollBubble extends StatefulWidget {
  final int id;
  const PollBubble(this.id, {super.key});
  @override
  State<PollBubble> createState() => _PollBubbleState();
}

class _PollBubbleState extends State<PollBubble> {
  Map<String, dynamic>? poll;
  List<Map<String, dynamic>> votes = [];
  StreamSubscription? _s;

  @override
  void initState() {
    super.initState();
    load();
    _s = sb.from('poll_votes').stream(primaryKey: ['poll_id', 'user_id', 'option_idx']).eq('poll_id', widget.id).listen((rows) {
      if (mounted) setState(() => votes = rows);
    }, onError: (_) {});
  }

  Future<void> load() async {
    try {
      final r = await sb.from('polls').select().eq('id', widget.id).maybeSingle();
      if (mounted) setState(() => poll = r);
    } catch (_) {}
  }

  @override
  void dispose() {
    _s?.cancel();
    super.dispose();
  }

  Future<void> vote(int idx) async {
    final multiple = poll!['multiple'] == true;
    final mine = votes.where((v) => v['user_id'] == me).map((v) => v['option_idx'] as int).toSet();
    try {
      if (mine.contains(idx)) {
        await sb.from('poll_votes').delete().eq('poll_id', widget.id).eq('user_id', me!).eq('option_idx', idx);
      } else {
        if (!multiple && mine.isNotEmpty) {
          await sb.from('poll_votes').delete().eq('poll_id', widget.id).eq('user_id', me!);
        }
        await sb.from('poll_votes').insert({'poll_id': widget.id, 'user_id': me, 'option_idx': idx});
      }
    } catch (_) {
      if (mounted) snack(context, 'رأی ثبت نشد');
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = poll;
    if (p == null) return const SizedBox(width: 240, height: 60, child: Center(child: CircularProgressIndicator()));
    final opts = (p['options'] as List).map((e) => '$e').toList();
    final counts = List<int>.filled(opts.length, 0);
    for (final v in votes) {
      final i = v['option_idx'] as int;
      if (i < counts.length) counts[i]++;
    }
    final voters = votes.map((v) => v['user_id']).toSet().length;
    final mine = votes.where((v) => v['user_id'] == me).map((v) => v['option_idx'] as int).toSet();
    return SizedBox(
      width: 240,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        Text('📊 ${p['question']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        for (var i = 0; i < opts.length; i++)
          InkWell(
            onTap: () => vote(i),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(mine.contains(i) ? Icons.check_circle : Icons.radio_button_unchecked, size: 18, color: Colors.white),
                  const SizedBox(width: 6),
                  Expanded(child: Text(opts[i], style: const TextStyle(color: Colors.white))),
                  Text('${counts[i]}', style: const TextStyle(color: Colors.white70)),
                ]),
                const SizedBox(height: 2),
                LinearProgressIndicator(value: voters == 0 ? 0 : counts[i] / voters, minHeight: 4, backgroundColor: Colors.white24, color: accent),
              ]),
            ),
          ),
        Text('$voters رأی${p['multiple'] == true ? ' · چندگزینه‌ای' : ''}', style: TextStyle(color: accent, fontSize: 11)),
      ]),
    );
  }
}

Future<Map<String, dynamic>?> createPoll(BuildContext c) async {
  final q = TextEditingController();
  final opts = List.generate(4, (_) => TextEditingController());
  var multiple = false;
  final ok = await showDialog<bool>(
    context: c,
    builder: (_) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: const Text('نظرسنجی جدید'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: q, decoration: const InputDecoration(labelText: 'سوال')),
            for (var i = 0; i < 4; i++) TextField(controller: opts[i], decoration: InputDecoration(labelText: 'گزینه ${i + 1}${i < 2 ? '' : ' (اختیاری)'}')),
            SwitchListTile(title: const Text('چندگزینه‌ای'), value: multiple, onChanged: (v) => set(() => multiple = v)),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ایجاد')),
        ],
      ),
    ),
  );
  if (ok != true) return null;
  final list = opts.map((e) => e.text.trim()).where((e) => e.isNotEmpty).toList();
  if (q.text.trim().isEmpty || list.length < 2) {
    if (c.mounted) snack(c, 'سوال و حداقل دو گزینه لازم است');
    return null;
  }
  final r = await sb.from('polls').insert({'question': q.text.trim(), 'options': list, 'multiple': multiple, 'created_by': me}).select('id').single();
  return {'id': r['id'] as int, 'q': q.text.trim()};
}

// ---------- scheduled messages ----------
Future<void> scheduleMessage(BuildContext c, {required bool group, required String target, required String text}) async {
  final d = await showDatePicker(context: c, initialDate: DateTime.now(), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)));
  if (d == null || !c.mounted) return;
  final t = await showTimePicker(context: c, initialTime: TimeOfDay.fromDateTime(DateTime.now().add(const Duration(minutes: 5))));
  if (t == null || !c.mounted) return;
  final dt = DateTime(d.year, d.month, d.day, t.hour, t.minute);
  if (!dt.isAfter(DateTime.now())) {
    snack(c, 'زمان باید در آینده باشد');
    return;
  }
  try {
    await sb.from('scheduled_messages').insert({'sender_id': me, 'scope': group ? 'g' : 'd', 'target': target, 'text': text, 'send_at': dt.toUtc().toIso8601String()});
    if (c.mounted) snack(c, 'پیام زمان‌بندی شد');
  } catch (_) {
    if (c.mounted) snack(c, 'زمان‌بندی نشد. SQL مرحله‌ی جدید اجرا شده است؟');
  }
}

class ScheduledPage extends StatefulWidget {
  final bool group;
  final String target;
  const ScheduledPage({super.key, required this.group, required this.target});
  @override
  State<ScheduledPage> createState() => _ScheduledPageState();
}

class _ScheduledPageState extends State<ScheduledPage> {
  List<Map<String, dynamic>> rows = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await sb.from('scheduled_messages').select().eq('scope', widget.group ? 'g' : 'd').eq('target', widget.target).eq('status', 'pending').order('send_at');
      if (mounted) setState(() => rows = r);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('پیام‌های زمان‌بندی‌شده')),
        body: rows.isEmpty
            ? const Center(child: Text('پیام زمان‌بندی‌شده‌ای نیست'))
            : ListView(children: [
                for (final r in rows)
                  ListTile(
                    title: Text(r['text'] as String, maxLines: 2, overflow: TextOverflow.ellipsis),
                    subtitle: Text(() {
                      final t = DateTime.parse(r['send_at'] as String).toLocal();
                      return '${t.year}/${t.month}/${t.day}  ${hm(r['send_at'] as String)}';
                    }(), style: TextStyle(color: accent)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        try {
                          await sb.from('scheduled_messages').delete().eq('id', r['id'] as int);
                        } catch (_) {}
                        load();
                      },
                    ),
                  ),
              ]),
      );
}

// ---------- invite links ----------
Future<void> showInvite(BuildContext c, int gid) async {
  try {
    final code = await sb.rpc('create_invite', params: {'gid': gid}) as String;
    final link = 'tia://join/$code';
    if (!c.mounted) return;
    await showDialog(
      context: c,
      builder: (d) => AlertDialog(
        title: const Text('لینک دعوت'),
        content: SelectableText(link, textDirection: TextDirection.ltr),
        actions: [
          TextButton(
            onPressed: () async {
              try {
                await sb.rpc('revoke_invites', params: {'gid': gid});
              } catch (_) {}
              if (d.mounted) Navigator.pop(d);
            },
            child: const Text('لغو لینک'),
          ),
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: link));
              Navigator.pop(d);
            },
            child: const Text('کپی'),
          ),
        ],
      ),
    );
  } catch (e) {
    if (c.mounted) snack(c, errText(e));
  }
}

Future<void> joinByCode(BuildContext c) async {
  final v = await inputDialog(c, 'پیوستن با لینک', 'لینک یا کد دعوت');
  if (v == null) return;
  final code = v.split('/').last.trim();
  try {
    final gid = await sb.rpc('join_group', params: {'p_code': code}) as int;
    await gs.load();
    if (c.mounted) openGroup(c, gid);
  } catch (e) {
    if (c.mounted) snack(c, errText(e));
  }
}
