import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'chat.dart';
import 'groups.dart';
import 'main.dart';
import 'social.dart';
import 'l10n.dart';

// ---------- reactions ----------
class ReactionStore extends ChangeNotifier {
  final byMsg = <String, List<Map<String, dynamic>>>{};
  StreamSubscription? _s;

  void start() {
    stop();
    _s = sb.from('reactions').stream(primaryKey: ['scope', 'message_id', 'user_id']).listen((rows) {
      byMsg.clear();
      for (final r in rows) {
        byMsg.putIfAbsent('${r['scope']}:${r['message_id']}', () => []).add(r);
      }
      notifyListeners();
    }, onError: (_) {});
  }

  void stop() {
    _s?.cancel();
    _s = null;
    byMsg.clear();
  }

  List<Map<String, dynamic>> of(String scope, int id) => byMsg['$scope:$id'] ?? [];

  Future<void> toggle(String scope, int id, String emoji) async {
    final mine = of(scope, id).where((r) => r['user_id'] == me).toList();
    if (mine.isNotEmpty && mine.first['emoji'] == emoji) {
      await sb.from('reactions').delete().eq('scope', scope).eq('message_id', id).eq('user_id', me!);
    } else {
      await sb.from('reactions').upsert({'scope': scope, 'message_id': id, 'user_id': me, 'emoji': emoji});
    }
  }
}

final rx = ReactionStore();

Widget reactionChips(String scope, int id) {
  final rows = rx.of(scope, id);
  if (rows.isEmpty) return const SizedBox.shrink();
  final counts = <String, int>{};
  for (final r in rows) {
    final e = r['emoji'] as String;
    counts[e] = (counts[e] ?? 0) + 1;
  }
  final mine = rows.where((r) => r['user_id'] == me).map((r) => r['emoji']).toSet();
  return Padding(
    padding: const EdgeInsets.only(top: 4),
    child: Wrap(spacing: 4, runSpacing: 4, children: [
      for (final e in counts.entries)
        InkWell(
          onTap: () => rx.toggle(scope, id, e.key).catchError((_) {}),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: mine.contains(e.key) ? accent : cLine)),
            child: Text('${e.key} ${e.value}', style: const TextStyle(fontSize: 12)),
          ),
        ),
    ]),
  );
}

// ---------- polls ----------
class PollBubble extends StatefulWidget {
  final int id;
  const PollBubble(this.id, {super.key});
  @override
  State<PollBubble> createState() => _PollBubbleState();
}

class _PollBubbleState extends State<PollBubble> {
  Map<String, dynamic>? poll;
  List<Map<String, dynamic>> votes = [];
  Map<int, int>? anonCounts; // شمارش رأی‌ها در نظرسنجی ناشناس
  StreamSubscription? _s;
  Timer? _t;

  bool get anonymous => poll?['anonymous'] == true;
  DateTime? get closesAt => DateTime.tryParse('${poll?['closes_at'] ?? ''}')?.toLocal();
  bool get closed => closesAt != null && !closesAt!.isAfter(DateTime.now());

  @override
  void initState() {
    super.initState();
    load();
    _s = sb.from('poll_votes').stream(primaryKey: ['poll_id', 'user_id', 'option_idx']).eq('poll_id', widget.id).listen((rows) {
      if (mounted) setState(() => votes = rows);
    }, onError: (_) {});
    _t = Timer.periodic(const Duration(seconds: 8), (_) {
      if (!mounted) return;
      if (anonymous) loadCounts();
      if (closesAt != null) setState(() {}); // بسته‌شدن زمان‌دار
    });
  }

  Future<void> load() async {
    try {
      final r = await sb.from('polls').select().eq('id', widget.id).maybeSingle();
      if (mounted) setState(() => poll = r);
      if (r != null && r['anonymous'] == true) await loadCounts();
    } catch (_) {}
  }

  Future<void> loadCounts() async {
    try {
      final r = await sb.rpc('poll_counts', params: {'pid': widget.id});
      final m = <int, int>{for (final x in (r as List)) (x['option_idx'] as int): (x['n'] as num).toInt()};
      if (mounted) setState(() => anonCounts = m);
    } catch (_) {}
  }

  @override
  void dispose() {
    _s?.cancel();
    _t?.cancel();
    super.dispose();
  }

  Future<void> vote(int idx) async {
    if (closed) {
      snack(context, trn('نظرسنجی بسته شده است'));
      return;
    }
    final multiple = poll!['multiple'] == true;
    final mine = votes.where((v) => v['user_id'] == me).map((v) => v['option_idx'] as int).toSet();
    try {
      if (mine.contains(idx)) {
        await sb.from('poll_votes').delete().eq('poll_id', widget.id).eq('user_id', me!).eq('option_idx', idx);
      } else {
        if (!multiple && mine.isNotEmpty) {
          await sb.from('poll_votes').delete().eq('poll_id', widget.id).eq('user_id', me!);
        }
        await sb.from('poll_votes').insert({'poll_id': widget.id, 'user_id': me, 'option_idx': idx});
      }
      if (anonymous) await loadCounts();
    } catch (_) {
      if (mounted) snack(context, trn('رأی ثبت نشد'));
    }
  }

  /// فهرست رأی‌دهندگان هر گزینه (فقط در نظرسنجی غیرناشناس)
  Future<void> showVoters(List<String> opts) async {
    final ids = votes.map((v) => v['user_id'] as String).toSet().toList();
    await store.loadPeople(ids);
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (bc) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.7),
          child: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
            Text(trn('رأی‌دهندگان'), style: TextStyle(color: accent, fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            if (votes.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(trn('کسی رأی نداده'), style: TextStyle(color: cTextFaint))),
            for (var i = 0; i < opts.length; i++) ...[
              Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 4),
                child: Text('${opts[i]}  (${votes.where((v) => v['option_idx'] == i).length})', style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
              for (final v in votes.where((v) => v['option_idx'] == i)) ListTile(dense: true, contentPadding: EdgeInsets.zero, leading: avatarFor(v['user_id'] as String), title: Text(store.name(v['user_id'] as String))),
            ],
          ]),
        ),
      ),
    );
  }

  String _when(DateTime d) {
    String two(int x) => x.toString().padLeft(2, '0');
    return '${d.year}/${two(d.month)}/${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    final p = poll;
    if (p == null) return const SizedBox(width: 240, height: 60, child: Center(child: CircularProgressIndicator()));
    final opts = (p['options'] as List).map((e) => '$e').toList();
    final counts = List<int>.filled(opts.length, 0);
    if (anonymous && anonCounts != null) {
      anonCounts!.forEach((i, n) {
        if (i < counts.length) counts[i] = n;
      });
    } else {
      for (final v in votes) {
        final i = v['option_idx'] as int;
        if (i < counts.length) counts[i]++;
      }
    }
    final voters = (anonymous && anonCounts != null) ? counts.fold<int>(0, (a, b) => a + b) : votes.map((v) => v['user_id']).toSet().length;
    final mine = votes.where((v) => v['user_id'] == me).map((v) => v['option_idx'] as int).toSet();
    final c = closesAt;
    return SizedBox(
      width: 240,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
        Text('📊 ${p['question']}', style: const TextStyle(fontWeight: FontWeight.bold)),
        if (anonymous || c != null)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(
              [if (anonymous) trn('🕶 ناشناس'), if (c != null) (closed ? trn('🔒 بسته شد') : trf('تا {0}', [_when(c)]))].join('  ·  '),
              style: const TextStyle(fontSize: 11),
            ),
          ),
        const SizedBox(height: 6),
        for (var i = 0; i < opts.length; i++)
          InkWell(
            onTap: () => vote(i),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(mine.contains(i) ? Icons.check_circle : Icons.radio_button_unchecked, size: 18),
                  const SizedBox(width: 6),
                  Expanded(child: Text(opts[i])),
                  Text('${counts[i]}'),
                ]),
                const SizedBox(height: 2),
                LinearProgressIndicator(value: voters == 0 ? 0 : counts[i] / voters, minHeight: 4, backgroundColor: Colors.black26, color: DefaultTextStyle.of(context).style.color),
              ]),
            ),
          ),
        Row(children: [
          Expanded(child: Text(trf('{0} رأی{1}', [voters, p['multiple'] == true ? trn(' · چندگزینه‌ای') : '']), style: const TextStyle(fontSize: 11))),
          if (!anonymous && votes.isNotEmpty)
            InkWell(onTap: () => showVoters(opts), child: Text(trn('رأی‌دهندگان'), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, decoration: TextDecoration.underline))),
        ]),
      ]),
    );
  }
}

Future<Map<String, dynamic>?> createPoll(BuildContext c) async {
  final q = TextEditingController();
  final opts = List.generate(4, (_) => TextEditingController());
  var multiple = false, anonymous = false;
  var durIdx = 0;
  const durs = [null, Duration(hours: 1), Duration(days: 1), Duration(days: 7)];
  final ok = await showDialog<bool>(
    context: c,
    builder: (_) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: Text(trn('نظرسنجی جدید')),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: q, decoration: fieldDeco(labelText: trn('سوال'))),
            for (var i = 0; i < 4; i++) TextField(controller: opts[i], decoration: fieldDeco(labelText: trf('گزینه {0}{1}', [i + 1, i < 2 ? '' : trn(' (اختیاری)')]))),
            SwitchListTile(title: Text(trn('چندگزینه‌ای')), value: multiple, onChanged: (v) => set(() => multiple = v)),
            SwitchListTile(title: Text(trn('ناشناس (رأی‌دهندگان دیده نمی‌شوند)')), value: anonymous, onChanged: (v) => set(() => anonymous = v)),
            ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16),
              title: Text(trn('مدت نظرسنجی')),
              trailing: DropdownButton<int>(
                value: durIdx,
                underline: const SizedBox.shrink(),
                items: [for (var i = 0; i < 4; i++) DropdownMenuItem(value: i, child: Text([trn('بدون محدودیت زمانی'), trn('۱ ساعت'), trn('۱ روز'), trn('۱ هفته')][i]))],
                onChanged: (v) => set(() => durIdx = v ?? 0),
              ),
            ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(trn('انصراف'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(trn('ایجاد'))),
        ],
      ),
    ),
  );
  if (ok != true) return null;
  final list = opts.map((e) => e.text.trim()).where((e) => e.isNotEmpty).toList();
  if (q.text.trim().isEmpty || list.length < 2) {
    if (c.mounted) snack(c, trn('سوال و حداقل دو گزینه لازم است'));
    return null;
  }
  final row = <String, dynamic>{'question': q.text.trim(), 'options': list, 'multiple': multiple, 'created_by': me};
  if (anonymous) row['anonymous'] = true;
  if (durs[durIdx] != null) row['closes_at'] = DateTime.now().add(durs[durIdx]!).toUtc().toIso8601String();
  try {
    final r = await sb.from('polls').insert(row).select('id').single();
    return {'id': r['id'] as int, 'q': q.text.trim()};
  } catch (_) {
    // ستون‌های جدید وجود ندارند: supabase_polls2.sql اجرا نشده
    if (c.mounted) snack(c, trn('انجام نشد. SQL مرحله‌ی جدید اجرا شده است؟'));
    return null;
  }
}

// ---------- scheduled messages ----------
Future<void> scheduleMessage(BuildContext c, {required bool group, required String target, required String text}) async {
  final d = await showDatePicker(context: c, initialDate: DateTime.now(), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)));
  if (d == null || !c.mounted) return;
  final t = await showTimePicker(context: c, initialTime: TimeOfDay.fromDateTime(DateTime.now().add(const Duration(minutes: 5))));
  if (t == null || !c.mounted) return;
  final dt = DateTime(d.year, d.month, d.day, t.hour, t.minute);
  if (!dt.isAfter(DateTime.now())) {
    snack(c, trn('زمان باید در آینده باشد'));
    return;
  }
  try {
    await sb.from('scheduled_messages').insert({'sender_id': me, 'scope': group ? 'g' : 'd', 'target': target, 'text': text, 'send_at': dt.toUtc().toIso8601String()});
    if (c.mounted) snack(c, trn('پیام زمان‌بندی شد'));
  } catch (_) {
    if (c.mounted) snack(c, trn('زمان‌بندی نشد. SQL مرحله‌ی جدید اجرا شده است؟'));
  }
}

class ScheduledPage extends StatefulWidget {
  final bool group;
  final String target;
  const ScheduledPage({super.key, required this.group, required this.target});
  @override
  State<ScheduledPage> createState() => _ScheduledPageState();
}

class _ScheduledPageState extends State<ScheduledPage> {
  List<Map<String, dynamic>> rows = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await sb.from('scheduled_messages').select().eq('scope', widget.group ? 'g' : 'd').eq('target', widget.target).eq('status', 'pending').order('send_at');
      if (mounted) setState(() => rows = r);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(trn('پیام‌های زمان‌بندی‌شده'))),
        body: rows.isEmpty
            ? Center(child: Text(trn('پیام زمان‌بندی‌شده‌ای نیست')))
            : ListView(children: [
                for (final r in rows)
                  ListTile(
                    title: Text(r['text'] as String, maxLines: 2, overflow: TextOverflow.ellipsis),
                    subtitle: Text(() {
                      final t = DateTime.parse(r['send_at'] as String).toLocal();
                      return '${t.year}/${t.month}/${t.day}  ${hm(r['send_at'] as String)}';
                    }(), style: TextStyle(color: accent)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        try {
                          await sb.from('scheduled_messages').delete().eq('id', r['id'] as int);
                        } catch (_) {}
                        load();
                      },
                    ),
                  ),
              ]),
      );
}

// ---------- invite links ----------
Future<void> showInvite(BuildContext c, int gid) async {
  try {
    final code = await sb.rpc('create_invite', params: {'gid': gid}) as String;
    final link = 'tia://join/$code';
    if (!c.mounted) return;
    await showDialog(
      context: c,
      builder: (d) => AlertDialog(
        title: Text(trn('لینک دعوت')),
        content: SelectableText(link, textDirection: TextDirection.ltr),
        actions: [
          TextButton(
            onPressed: () async {
              try {
                await sb.rpc('revoke_invites', params: {'gid': gid});
              } catch (_) {}
              if (d.mounted) Navigator.pop(d);
            },
            child: Text(trn('لغو لینک')),
          ),
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: link));
              Navigator.pop(d);
            },
            child: Text(trn('کپی')),
          ),
        ],
      ),
    );
  } catch (e) {
    if (c.mounted) snack(c, errText(e));
  }
}

Future<void> joinByCode(BuildContext c) async {
  final v = await inputDialog(c, trn('پیوستن با لینک'), trn('لینک یا کد دعوت'));
  if (v == null) return;
  final code = v.split('/').last.trim();
  try {
    final gid = await sb.rpc('join_group', params: {'p_code': code}) as int;
    await gs.load();
    if (c.mounted) openGroup(c, gid);
  } catch (e) {
    if (c.mounted) snack(c, errText(e));
  }
}
