import 'dart:convert';
import 'package:crypto/crypto.dart' as hash;
import 'package:cryptography/cryptography.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'cyber.dart';
import 'l10n.dart';
import 'main.dart';
import 'smart.dart' show faDigits;

/// رمزنگاری سرتاسری پیام‌های متنیِ گفتگوهای خصوصی (X25519 + AES-256-GCM).
/// هر دستگاه کلید خودش را می‌سازد؛ کلید خصوصی هرگز از گوشی بیرون نمی‌رود.
/// پیام یک بار با کلید تصادفی رمز می‌شود و آن کلید برای هر دستگاه گیرنده و دستگاه‌های خود فرستنده جدا بسته‌بندی می‌شود.
class _Dev {
  final String id;
  final String uid;
  final List<int> pub;
  const _Dev(this.id, this.uid, this.pub);
}

class E2ee extends ChangeNotifier {
  static const prefix = 'e2e:v1:';
  final _x = X25519();
  final _aes = AesGcm.with256bits();
  final _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
  final _vault = const FlutterSecureStorage();
  SimpleKeyPairData? _kp;
  String _dev = '';
  List<int> _myPub = const [];
  bool ready = false; // کلید این دستگاه ساخته و در سرور ثبت شده
  final _cache = <String, MapEntry<DateTime, List<_Dev>>>{};
  final _plain = <String, String>{};

  Future<void> init() async {
    final uid = me;
    if (uid == null) return;
    try {
      final k = 'tia_e2e_$uid';
      final raw = await _vault.read(key: k);
      if (raw != null) {
        final j = jsonDecode(raw) as Map<String, dynamic>;
        _dev = j['d'] as String;
        _myPub = base64Decode(j['pub'] as String);
        _kp = SimpleKeyPairData(base64Decode(j['priv'] as String), publicKey: SimplePublicKey(_myPub, type: KeyPairType.x25519), type: KeyPairType.x25519);
      } else {
        final kp = await _x.newKeyPair();
        final data = await kp.extract();
        final pub = (await kp.extractPublicKey()).bytes;
        final rnd = await _aes.newSecretKey();
        _dev = base64Url.encode((await rnd.extractBytes()).sublist(0, 9)).replaceAll('=', '');
        _myPub = pub;
        _kp = data;
        await _vault.write(key: k, value: jsonEncode({'d': _dev, 'pub': base64Encode(pub), 'priv': base64Encode(await data.extractPrivateKeyBytes())}));
      }
      await sb.from('user_keys').upsert({'user_id': uid, 'device_id': _dev, 'public_key': base64Encode(_myPub)});
      ready = true;
    } catch (_) {
      ready = false; // جدول user_keys ساخته نشده یا شبکه قطع است؛ پیام‌ها بدون رمزنگاری می‌روند
    }
    notifyListeners();
  }

  Future<List<_Dev>> _keysOf(String uid) async {
    final hit = _cache[uid];
    if (hit != null && DateTime.now().difference(hit.key).inMinutes < 10) return hit.value;
    try {
      final rows = await sb.from('user_keys').select('device_id,public_key').eq('user_id', uid);
      final l = [for (final r in rows) _Dev(r['device_id'] as String, uid, base64Decode(r['public_key'] as String))];
      _cache[uid] = MapEntry(DateTime.now(), l);
      return l;
    } catch (_) {
      return hit?.value ?? const [];
    }
  }

  /// آیا گفتگو با این کاربر رمزنگاری سرتاسری دارد؟
  Future<bool> active(String peer) async => ready && (await _keysOf(peer)).isNotEmpty;

  Future<SecretKey> _wrapKey(SecretKey shared) => _hkdf.deriveKey(secretKey: shared, info: utf8.encode('tia-e2e-v1-wrap'));

  /// متن را برای [peer] رمز می‌کند. اگر طرف مقابل کلید ندارد null برمی‌گرداند (ارسال بدون رمزنگاری).
  Future<String?> encrypt(String text, String peer) async {
    if (!ready || text.isEmpty) return null;
    try {
      final theirs = await _keysOf(peer);
      if (theirs.isEmpty) return null;
      final mine = await _keysOf(me!);
      final devs = <String, _Dev>{for (final d in [...theirs, ...mine]) d.id: d, _dev: _Dev(_dev, me!, _myPub)};
      final k = await _aes.newSecretKey();
      final kb = await k.extractBytes();
      final box = await _aes.encrypt(utf8.encode(text), secretKey: k);
      final eph = await _x.newKeyPair();
      final ephPub = (await eph.extractPublicKey()).bytes;
      final wraps = <String, String>{};
      for (final d in devs.values) {
        final sh = await _x.sharedSecretKey(keyPair: eph, remotePublicKey: SimplePublicKey(d.pub, type: KeyPairType.x25519));
        final wk = await _wrapKey(sh);
        wraps[d.id] = base64Encode((await _aes.encrypt(kb, secretKey: wk)).concatenation());
      }
      return prefix + jsonEncode({'e': base64Encode(ephPub), 'c': base64Encode(box.concatenation()), 'k': wraps});
    } catch (_) {
      return null;
    }
  }

  Future<String?> _decrypt(String text) async {
    try {
      final j = jsonDecode(text.substring(prefix.length)) as Map<String, dynamic>;
      final w = (j['k'] as Map)[_dev] as String?;
      if (w == null || _kp == null) return null;
      final sh = await _x.sharedSecretKey(keyPair: _kp!, remotePublicKey: SimplePublicKey(base64Decode(j['e'] as String), type: KeyPairType.x25519));
      final wk = await _wrapKey(sh);
      final kb = await _aes.decrypt(SecretBox.fromConcatenation(base64Decode(w), nonceLength: 12, macLength: 16), secretKey: wk);
      final p = await _aes.decrypt(SecretBox.fromConcatenation(base64Decode(j['c'] as String), nonceLength: 12, macLength: 16), secretKey: SecretKey(kb));
      return utf8.decode(p);
    } catch (_) {
      return null;
    }
  }

  /// پیام‌های رمزشده را برای نمایش باز می‌کند (نتیجه در حافظه کش می‌شود تا هر پیام فقط یک بار محاسبه شود)
  Future<List<Map<String, dynamic>>> open(Iterable<Map<String, dynamic>> rows) async {
    final out = <Map<String, dynamic>>[];
    for (final r in rows) {
      final t = r['text'];
      if (t is String && t.startsWith(prefix)) {
        final m = Map<String, dynamic>.from(r);
        var p = _plain[t];
        if (p == null) {
          p = await _decrypt(t);
          if (p != null) {
            _plain[t] = p;
            if (_plain.length > 2000) _plain.remove(_plain.keys.first);
          }
        }
        m['text'] = p ?? trn('🔒 این پیام روی این دستگاه قابل خواندن نیست');
        m['e2e'] = true;
        out.add(m);
      } else {
        out.add(r);
      }
    }
    return out;
  }

  /// کد امنیتی مشترک بین دو نفر (۶۰ رقم). اگر روی هر دو گوشی یکی باشد، کسی وسط راه نیست.
  Future<String?> safetyCode(String peer) async {
    final a = await _keysOf(me!), b = await _keysOf(peer);
    if (a.isEmpty || b.isEmpty) return null;
    final ks = [for (final d in [...a, ...b]) '${d.uid}:${base64Encode(d.pub)}']..sort();
    final dg = hash.sha256.convert(utf8.encode(ks.join('|'))).bytes;
    final g = <String>[];
    for (var i = 0; i < 12; i++) {
      g.add((((dg[2 * i] << 8) | dg[2 * i + 1]) % 100000).toString().padLeft(5, '0'));
    }
    return g.join(' ');
  }
}

final e2ee = E2ee();

/// نوار کوچک بالای گفتگو؛ شلوغ نیست و فقط وقتی رمزنگاری واقعاً فعال است دیده می‌شود
class E2eePill extends StatelessWidget {
  final String peer;
  const E2eePill(this.peer, {super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: e2ee.active(peer),
      builder: (c, s) {
        if (s.data != true) return const SizedBox.shrink();
        return Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => E2eeInfoPage(peer: peer))),
              child: Container(
                constraints: const BoxConstraints(maxWidth: 330),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: Color.lerp(card, accent, 0.12),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: cy.enabled ? cy.c1.withOpacity(0.4) : cLine),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.lock_rounded, size: 14, color: accent),
                  const SizedBox(width: 8),
                  Flexible(child: Text(trn('پیام‌های متنی این گفتگو رمزنگاری سرتاسری شده‌اند. برای جزئیات لمس کنید.'), textAlign: TextAlign.center, style: TextStyle(color: cTextDim, fontSize: 11.5, height: 1.5))),
                ]),
              ),
            ),
          ),
        );
      },
    );
  }
}

class E2eeInfoPage extends StatelessWidget {
  final String? peer;
  const E2eeInfoPage({super.key, this.peer});

  Widget _pt(IconData i, String t) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(i, size: 20, color: accent),
          const SizedBox(width: 10),
          Expanded(child: Text(t, style: TextStyle(color: cText, height: 1.6))),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(trn('رمزنگاری سرتاسری'))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Center(child: Icon(Icons.lock_rounded, size: 64, color: accent)),
        const SizedBox(height: 14),
        _pt(Icons.chat_bubble_outline, trn('پیام‌های متنی گفتگوهای خصوصی روی گوشی شما رمز می‌شوند و فقط روی گوشی طرف مقابل باز می‌شوند.')),
        _pt(Icons.cloud_off_outlined, trn('سرور فقط متن رمزشده را می‌بیند؛ نه ما و نه هیچ‌کس دیگر نمی‌تواند آن را بخواند.')),
        _pt(Icons.devices_outlined, trn('اگر با حساب خود روی دستگاه تازه‌ای وارد شوید، پیام‌های قبلیِ گفتگوهای خصوصی روی آن دستگاه باز نمی‌شوند.')),
        _pt(Icons.info_outline, trn('فعلاً شامل گروه‌ها، کانال‌ها، فایل‌ها و عکس‌ها نمی‌شود. این‌ها با رمزنگاری معمولیِ انتقال محافظت می‌شوند.')),
        if (peer != null)
          FutureBuilder<String?>(
            future: e2ee.safetyCode(peer!),
            builder: (c, s) {
              final code = s.data;
              if (code == null) return const SizedBox.shrink();
              return Container(
                margin: const EdgeInsets.only(top: 10),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16), border: Border.all(color: cLine)),
                child: Column(children: [
                  Text(trn('کد امنیتی'), style: TextStyle(color: cText, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  Directionality(textDirection: TextDirection.ltr, child: SelectableText(faDigits(code), textAlign: TextAlign.center, style: TextStyle(color: accent, fontSize: 17, height: 1.9, letterSpacing: 1.5))),
                  const SizedBox(height: 10),
                  Text(trn('اگر این کد روی گوشی طرف مقابل هم دقیقاً همین باشد، گفتگوی شما امن است.'), textAlign: TextAlign.center, style: TextStyle(color: cTextDim, fontSize: 12.5, height: 1.6)),
                ]),
              );
            },
          ),
        if (peer == null)
          ListenableBuilder(
            listenable: e2ee,
            builder: (c, _) => Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(e2ee.ready ? trn('وضعیت: روی این دستگاه فعال است.') : trn('وضعیت: روی این دستگاه هنوز فعال نشده (جدول کلیدها در سرور ساخته نشده یا اینترنت قطع است).'), style: TextStyle(color: e2ee.ready ? accent : Colors.orangeAccent)),
            ),
          ),
      ]),
    );
  }
}
