import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'main.dart';
import 'ai.dart';
import 'l10n.dart';

// ---------------------------------------------------------------------------
// پیش‌نمایش لینک
// ---------------------------------------------------------------------------
final _urlRe = RegExp(r'https?://[^\s<>"]+', caseSensitive: false);

String? firstUrl(String text) {
  final m = _urlRe.firstMatch(text);
  if (m == null) return null;
  return m.group(0)!.replaceAll(RegExp(r'[.,;:!؟،)\]]+$'), '');
}

class LinkMeta {
  final String url;
  final String? title, desc, image, site;
  const LinkMeta(this.url, {this.title, this.desc, this.image, this.site});
  bool get empty => (title ?? '').isEmpty && (desc ?? '').isEmpty && (image ?? '').isEmpty;
}

final Map<String, Future<LinkMeta>> _metaCache = {};

String _unesc(String s) => s
    .replaceAll('&amp;', '&')
    .replaceAll('&quot;', '"')
    .replaceAll('&#39;', "'")
    .replaceAll('&#x27;', "'")
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .trim();

String? _metaTag(String html, String key) {
  for (final attr in ['property', 'name']) {
    final a = RegExp('<meta[^>]*$attr=["\']$key["\'][^>]*content=["\']([^"\']*)["\']', caseSensitive: false).firstMatch(html);
    if (a != null) return _unesc(a.group(1)!);
    final b = RegExp('<meta[^>]*content=["\']([^"\']*)["\'][^>]*$attr=["\']$key["\']', caseSensitive: false).firstMatch(html);
    if (b != null) return _unesc(b.group(1)!);
  }
  return null;
}

Future<LinkMeta> fetchLinkMeta(String url) => _metaCache.putIfAbsent(url, () async {
      final c = HttpClient()
        ..connectionTimeout = const Duration(seconds: 6)
        ..userAgent = 'Mozilla/5.0 (compatible; TiaBot/1.0)';
      try {
        final req = await c.getUrl(Uri.parse(url));
        req.headers.set('Accept', 'text/html');
        final res = await req.close().timeout(const Duration(seconds: 8));
        final ct = res.headers.contentType?.mimeType ?? '';
        if (res.statusCode >= 400 || !ct.contains('html')) return LinkMeta(url);
        final bytes = <int>[];
        await for (final chunk in res) {
          bytes.addAll(chunk);
          if (bytes.length > 200 * 1024) break;
        }
        final html = utf8.decode(bytes, allowMalformed: true);
        final head = html.length > 80000 ? html.substring(0, 80000) : html;
        var title = _metaTag(head, 'og:title') ?? _metaTag(head, 'twitter:title');
        title ??= RegExp(r'<title[^>]*>([^<]*)</title>', caseSensitive: false).firstMatch(head)?.group(1);
        final desc = _metaTag(head, 'og:description') ?? _metaTag(head, 'description');
        var image = _metaTag(head, 'og:image') ?? _metaTag(head, 'twitter:image');
        if (image != null && image.isNotEmpty) image = Uri.parse(url).resolve(image).toString();
        return LinkMeta(url, title: title == null ? null : _unesc(title), desc: desc, image: image, site: _metaTag(head, 'og:site_name') ?? Uri.parse(url).host);
      } catch (_) {
        return LinkMeta(url);
      } finally {
        c.close(force: true);
      }
    });

class LinkPreviewCard extends StatelessWidget {
  final String url;
  const LinkPreviewCard(this.url, {super.key});

  @override
  Widget build(BuildContext context) {
    final fg = IconTheme.of(context).color ?? cText;
    return FutureBuilder<LinkMeta>(
      future: fetchLinkMeta(url),
      builder: (c, s) {
        final m = s.data;
        if (m == null || m.empty) return const SizedBox.shrink();
        return GestureDetector(
          onTap: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
          child: Container(
            margin: const EdgeInsets.only(top: 6),
            clipBehavior: Clip.antiAlias,
            width: 250,
            decoration: BoxDecoration(
              color: Color.lerp(Colors.transparent, fg, 0.12),
              borderRadius: BorderRadius.circular(12),
              border: Border(right: BorderSide(color: fg.withOpacity(0.6), width: 3)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (m.image != null && m.image!.isNotEmpty)
                Image.network(m.image!, height: 130, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(m.site ?? '', style: TextStyle(fontSize: 10, color: fg.withOpacity(0.7)), textDirection: TextDirection.ltr),
                  if ((m.title ?? '').isNotEmpty) Text(m.title!, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  if ((m.desc ?? '').isNotEmpty) Text(m.desc!, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                ]),
              ),
            ]),
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// موج صوتی
// ---------------------------------------------------------------------------
// موج هر پیام صوتی به‌صورت رشته‌ی ارقام ۰ تا ۹ در فیلد text ذخیره می‌شود: "~w" + ارقام
const waveBars = 40;

String encodeWave(List<double> dbSamples) {
  if (dbSamples.isEmpty) return '';
  final out = StringBuffer('~w');
  for (var i = 0; i < waveBars; i++) {
    final a = (i * dbSamples.length / waveBars).floor();
    final b = max(a + 1, ((i + 1) * dbSamples.length / waveBars).floor());
    var peak = -160.0;
    for (var k = a; k < min(b, dbSamples.length); k++) {
      peak = max(peak, dbSamples[k]);
    }
    final norm = ((peak + 50) / 50).clamp(0.0, 1.0);
    out.write((norm * 9).round());
  }
  return out.toString();
}

List<double> decodeWave(String? text, String seed) {
  if (text != null && text.startsWith('~w') && text.length >= 2 + waveBars) {
    return [for (var i = 0; i < waveBars; i++) (int.tryParse(text[2 + i]) ?? 0) / 9];
  }
  // پیام‌های قدیمی: موج تزئینی ثابت بر اساس نام فایل
  final r = Random(seed.hashCode);
  return [for (var i = 0; i < waveBars; i++) 0.25 + r.nextDouble() * 0.6];
}

class WaveBars extends StatelessWidget {
  final List<double> bars;
  final double progress; // ۰ تا ۱
  final Color color;
  final void Function(double)? onSeek;
  const WaveBars({super.key, required this.bars, required this.progress, required this.color, this.onSeek});

  @override
  Widget build(BuildContext context) => LayoutBuilder(
        builder: (c, box) => GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: onSeek == null ? null : (d) => onSeek!((d.localPosition.dx / box.maxWidth).clamp(0.0, 1.0)),
          onHorizontalDragUpdate: onSeek == null ? null : (d) => onSeek!((d.localPosition.dx / box.maxWidth).clamp(0.0, 1.0)),
          child: SizedBox(
            height: 32,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                for (var i = 0; i < bars.length; i++)
                  Expanded(
                    child: Center(
                      child: Container(
                        width: 3,
                        height: 5 + bars[i] * 25,
                        decoration: BoxDecoration(
                          color: i / bars.length <= progress ? color : color.withOpacity(0.32),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
}

// ---------------------------------------------------------------------------
// ترجمه‌ی پیام (سرویس رایگان MyMemory؛ ممکن است بسته به شبکه در دسترس نباشد)
// ---------------------------------------------------------------------------
bool looksPersian(String s) => RegExp(r'[\u0600-\u06FF]').allMatches(s).length > s.replaceAll(RegExp(r'\s'), '').length / 3;

Future<String> translateText(String text, {required String to}) async {
  final from = to == 'fa' ? 'en' : 'fa';
  final q = text.length > 450 ? text.substring(0, 450) : text;
  try {
    return await _translateMyMemory(q, from, to);
  } catch (_) {
    // پشتیبان: اگر MyMemory در دسترس نبود
    return await _translateGtx(q, from, to);
  }
}

Future<String> _translateMyMemory(String q, String from, String to) async {
  final url = 'https://api.mymemory.translated.net/get?q=${Uri.encodeQueryComponent(q)}&langpair=$from|$to';
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final req = await c.getUrl(Uri.parse(url));
    final res = await req.close().timeout(const Duration(seconds: 12));
    final body = await res.transform(utf8.decoder).join();
    final j = jsonDecode(body) as Map<String, dynamic>;
    final t = ((j['responseData'] as Map?)?['translatedText'] as String?) ?? '';
    if (t.isEmpty || t.toUpperCase().contains('MYMEMORY WARNING')) throw 'fail';
    return t;
  } finally {
    c.close(force: true);
  }
}

// سرویس غیررسمی ترجمه‌ی گوگل (بدون کلید)؛ فقط پشتیبان است و ممکن است بسته به شبکه کار نکند
Future<String> _translateGtx(String q, String from, String to) async {
  final url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=$from&tl=$to&dt=t&q=${Uri.encodeQueryComponent(q)}';
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
  try {
    final req = await c.getUrl(Uri.parse(url));
    final res = await req.close().timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) throw 'fail';
    final body = await res.transform(utf8.decoder).join();
    final j = jsonDecode(body) as List;
    final parts = (j[0] as List).map((e) => (e as List)[0] as String? ?? '').join();
    if (parts.trim().isEmpty) throw 'fail';
    return parts;
  } finally {
    c.close(force: true);
  }
}

Future<void> translateMessage(BuildContext context, String text) => aiTranslateSheet(context, text);

Future<void> translateMessageOnline(BuildContext context, String text) async {
  final to = looksPersian(text) ? 'en' : 'fa';
  final fut = translateText(text, to: to);
  await showModalBottomSheet(
    context: context,
    showDragHandle: true,
    builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
        child: FutureBuilder<String>(
          future: fut,
          builder: (c, s) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(to == 'fa' ? trn('ترجمه به فارسی') : trn('ترجمه به انگلیسی'), style: TextStyle(color: accent, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              if (s.connectionState != ConnectionState.done)
                const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()))
              else if (s.hasError)
                Text(trn('ترجمه انجام نشد. اینترنت را بررسی کنید؛ ممکن است سرویس ترجمه در شبکه‌ی شما در دسترس نباشد.'))
              else
                SelectableText(s.data!, textDirection: to == 'fa' ? TextDirection.rtl : TextDirection.ltr, style: const TextStyle(fontSize: 16, height: 1.6)),
            ],
          ),
        ),
      ),
    ),
  );
}
