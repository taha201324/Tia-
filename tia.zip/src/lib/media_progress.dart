import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'l10n.dart';
import 'main.dart';
import 'net.dart';

/// حلقه‌ی پیشرفت: درصد دقیق = بایت‌های ارسال‌شده ÷ حجم کل فایل (بدون انیمیشن تخمینی)
class _RingPainter extends CustomPainter {
  final double value;
  final Color color, track;
  final double stroke;
  _RingPainter(this.value, this.color, this.track, this.stroke);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = (Offset.zero & size).deflate(stroke / 2);
    canvas.drawArc(rect, 0, 2 * math.pi, false, Paint()..style = PaintingStyle.stroke..strokeWidth = stroke..color = track);
    if (value > 0) {
      canvas.drawArc(rect, -math.pi / 2, 2 * math.pi * value.clamp(0.0, 1.0), false,
          Paint()..style = PaintingStyle.stroke..strokeWidth = stroke..strokeCap = StrokeCap.round..color = color);
    }
  }

  @override
  bool shouldRepaint(_RingPainter o) => o.value != value || o.color != color || o.track != track;
}

String fmtBytes(int b) => b >= 1048576 ? '${(b / 1048576).toStringAsFixed(1)} MB' : '${(b / 1024).round()} KB';

/// دکمه‌ی گرد با حلقه‌ی درصد دور آن و ضربدر لغو؛ یک کامپوننت یکپارچه برای همه‌ی انواع رسانه
class RingButton extends StatelessWidget {
  final double value, size;
  final Color ring, icon;
  final Color? bg;
  final VoidCallback? onTap;
  const RingButton({super.key, required this.value, this.size = 48, required this.ring, required this.icon, this.bg, this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(shape: BoxShape.circle, color: bg),
          child: CustomPaint(
            painter: _RingPainter(value, ring, ring.withOpacity(0.25), size >= 52 ? 3.5 : 3),
            child: Center(child: Icon(Icons.close_rounded, color: icon, size: size * 0.46)),
          ),
        ),
      );
}

/// پیام رسانه‌ای در حال ارسال (عکس، گیف، ویدئو، ویس، فایل) با درصد دقیق آپلود
class PendingMedia extends StatelessWidget {
  final Map<String, dynamic> m;
  const PendingMedia(this.m, {super.key});

  @override
  Widget build(BuildContext context) {
    final cid = m['cid'] as String?;
    final path = m['local_path'] as String;
    final kind = (m['pending_kind'] as String?) ?? 'file';
    final name = (m['pending_name'] as String?) ?? 'file';
    int total = 0;
    try {
      total = File(path).lengthSync();
    } catch (_) {}
    void cancel() => outbox.cancel(m['id'] as int);

    return ValueListenableBuilder<int>(
      valueListenable: uploadsChanged,
      builder: (c, _, __) {
        final n = cid == null ? null : uploadProgress[cid];
        if (n == null) return _body(context, kind, path, name, total, 0, true, cancel);
        return ValueListenableBuilder<double>(
          valueListenable: n,
          builder: (c, v, _) => _body(context, kind, path, name, total, v, false, cancel),
        );
      },
    );
  }

  Widget _label(double v, int total, bool waiting, Color color) => Directionality(
        textDirection: TextDirection.ltr,
        child: Text(
          waiting ? trn('در صف ارسال') : '${(v * 100).floor()}%  ·  ${fmtBytes((v * total).round())} / ${fmtBytes(total)}',
          style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600),
        ),
      );

  Widget _body(BuildContext context, String kind, String path, String name, int total, double v, bool waiting, VoidCallback cancel) {
    final fg = IconTheme.of(context).color ?? cText;
    if (kind == 'image' || kind == 'gif' || kind == 'video') {
      return SizedBox(
        width: 220,
        height: 170,
        child: Stack(alignment: Alignment.center, children: [
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: kind == 'video'
                  ? Container(color: const Color(0xFF1B1B26), child: const Icon(Icons.videocam_rounded, color: Colors.white24, size: 54))
                  : Image.file(File(path), fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: const Color(0xFF1B1B26))),
            ),
          ),
          Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(color: const Color(0x55000000), borderRadius: BorderRadius.circular(10)))),
          RingButton(value: v, size: 58, ring: Colors.white, icon: Colors.white, bg: const Color(0x99000000), onTap: cancel),
          PositionedDirectional(
            start: 8,
            bottom: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
              decoration: BoxDecoration(color: const Color(0x99000000), borderRadius: BorderRadius.circular(8)),
              child: _label(v, total, waiting, Colors.white),
            ),
          ),
        ]),
      );
    }
    if (kind == 'audio') {
      return SizedBox(
        width: 240,
        child: Row(children: [
          RingButton(value: v, size: 44, ring: fg, icon: fg, onTap: cancel),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(trn('🎤 پیام صوتی')),
              const SizedBox(height: 2),
              _label(v, total, waiting, fg),
            ]),
          ),
        ]),
      );
    }
    return SizedBox(
      width: 240,
      child: Row(children: [
        RingButton(value: v, size: 44, ring: fg, icon: fg, onTap: cancel),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 2),
            _label(v, total, waiting, fg),
          ]),
        ),
      ]),
    );
  }
}
