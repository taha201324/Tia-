import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ai.dart' show normFa;
import 'growth.dart';
import 'l10n.dart';
import 'main.dart';
import 'rich.dart' show firstUrl;
import 'smart.dart';

String _who(String id) => id == me ? trn('من') : store.name(id);

String _snippet(Map<String, dynamic> m) {
  final k = kindOf(m);
  if (k == 'text') return (m['text'] as String?) ?? '';
  return preview(m);
}

DateTime? _t(Map<String, dynamic> m) => DateTime.tryParse('${m['created_at'] ?? ''}')?.toLocal();

String _dt(Map<String, dynamic> m) {
  final t = _t(m);
  return t == null ? '' : '${dayLabel(t)} - ${hm(m['created_at'] as String)}';
}

Widget _title(String t) => Padding(padding: const EdgeInsets.fromLTRB(4, 14, 4, 6), child: Text(t, style: TextStyle(color: cTextDim, fontWeight: FontWeight.w800, fontSize: 13)));

// ===========================================================================
// ۱) نوشتن فارسی: اصلاح ی و ک عربی و فاصله‌ها هنگام ارسال
// ===========================================================================
String fixFa(String t) {
  if (detectLang(t) != 'fa') return t;
  var s = t.replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll('ى', 'ی');
  s = s.replaceAll(RegExp(r'[ \t]{2,}'), ' ');
  s = s.replaceAllMapped(RegExp(r'[ \t]+([؟،؛!])'), (m) => m.group(1)!);
  return s;
}

// ===========================================================================
// ۲) ستاره‌دار کردن پیام‌ها (روی همین گوشی)
// ===========================================================================
class Stars {
  static Future<Set<int>> load(String key) async {
    try {
      final l = (await SharedPreferences.getInstance()).getStringList('star_$key') ?? const [];
      return {for (final x in l) if (int.tryParse(x) != null) int.parse(x)};
    } catch (_) {
      return {};
    }
  }

  static Future<void> save(String key, Set<int> s) async {
    try {
      await (await SharedPreferences.getInstance()).setStringList('star_$key', [for (final x in s) '$x']);
    } catch (_) {}
  }
}

class StarsPage extends StatefulWidget {
  final List<Map<String, dynamic>> msgs;
  final Set<int> stars;
  final void Function(int id) jump;
  final void Function(int id) unstar;
  const StarsPage({super.key, required this.msgs, required this.stars, required this.jump, required this.unstar});
  @override
  State<StarsPage> createState() => _StarsPageState();
}

class _StarsPageState extends State<StarsPage> {
  @override
  Widget build(BuildContext context) {
    final l = [for (final m in widget.msgs.reversed) if (widget.stars.contains(m['id'])) m];
    return Scaffold(
      appBar: AppBar(title: Text(trn('پیام‌های ستاره‌دار'))),
      body: l.isEmpty
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(trn('هنوز پیامی را ستاره‌دار نکرده‌اید. روی پیام انگشت را نگه دارید و «ستاره‌دار» را بزنید.'), textAlign: TextAlign.center, style: TextStyle(color: cTextDim, height: 1.7))))
          : ListView.separated(
              itemCount: l.length,
              separatorBuilder: (_, __) => Divider(height: 1, color: cLine),
              itemBuilder: (c, i) {
                final m = l[i];
                return ListTile(
                  leading: const Icon(Icons.star_rounded, color: Colors.amber),
                  title: Text(_snippet(m), maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${_who(m['sender_id'] as String)} • ${_dt(m)}', style: TextStyle(color: cTextFaint, fontSize: 12)),
                  trailing: IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: () {
                      widget.unstar(m['id'] as int);
                      setState(() {});
                    },
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    widget.jump(m['id'] as int);
                  },
                );
              },
            ),
    );
  }
}

// ===========================================================================
// ۳) جستجوی پیشرفته داخل گفتگو (با ریشه‌یابی ساده‌ی فارسی)
// ===========================================================================
String stemFa(String w) {
  var s = normFa(w);
  for (final p in const ['نمی', 'می']) {
    if (s.startsWith(p) && s.length > p.length + 2) {
      s = s.substring(p.length);
      break;
    }
  }
  for (final x in const ['هایی', 'های', 'ها', 'ترین', 'تر', 'ام', 'ات', 'اش', 'مان', 'تان', 'شان', 'یم', 'ید', 'ند']) {
    if (s.endsWith(x) && s.length > x.length + 1) {
      s = s.substring(0, s.length - x.length);
      break;
    }
  }
  return s;
}

List<String> _tokens(String t) => RegExp(r'[\u0600-\u06FFa-z0-9]+').allMatches(normFa(t)).map((m) => m.group(0)!).toList();

bool matchesQuery(String text, String q) {
  final nq = normFa(q.trim());
  if (nq.isEmpty) return true;
  if (normFa(text).contains(nq)) return true;
  final qs = _tokens(q).map(stemFa).where((s) => s.isNotEmpty).toList();
  if (qs.isEmpty) return false;
  final ts = _tokens(text).map(stemFa).toList();
  return qs.every((s) => ts.any((x) => x.contains(s)));
}

class ChatSearchPage extends StatefulWidget {
  final List<Map<String, dynamic>> msgs;
  final void Function(int id) jump;
  const ChatSearchPage({super.key, required this.msgs, required this.jump});
  @override
  State<ChatSearchPage> createState() => _ChatSearchPageState();
}

class _ChatSearchPageState extends State<ChatSearchPage> {
  final ctrl = TextEditingController();
  String who = 'all', type = 'all';
  DateTimeRange? range;

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  bool _typeOk(Map<String, dynamic> m) {
    final k = kindOf(m);
    switch (type) {
      case 'all':
        return true;
      case 'link':
        return k == 'text' && firstUrl((m['text'] as String?) ?? '') != null;
      case 'media':
        return k == 'image' || k == 'video' || k == 'gif';
      default:
        return k == type;
    }
  }

  @override
  Widget build(BuildContext context) {
    final res = <Map<String, dynamic>>[];
    for (final m in widget.msgs.reversed) {
      if (m['pending'] == true) continue;
      if (who == 'me' && m['sender_id'] != me) continue;
      if (who == 'them' && m['sender_id'] == me) continue;
      if (!_typeOk(m)) continue;
      final t = _t(m);
      if (range != null && t != null && (t.isBefore(range!.start) || t.isAfter(range!.end.add(const Duration(days: 1))))) continue;
      if (!matchesQuery(_snippet(m), ctrl.text)) continue;
      res.add(m);
      if (res.length >= 300) break;
    }
    Widget chip(String label, bool sel, VoidCallback f) => Padding(padding: const EdgeInsetsDirectional.only(end: 6), child: ChoiceChip(label: Text(label), selected: sel, onSelected: (_) => setState(f)));
    return Scaffold(
      appBar: AppBar(
        title: TextField(controller: ctrl, autofocus: true, onChanged: (_) => setState(() {}), decoration: InputDecoration(hintText: trn('جستجو در این گفتگو'), border: InputBorder.none)),
        actions: [IconButton(icon: const Icon(Icons.date_range_rounded), tooltip: trn('بازه‌ی تاریخ'), onPressed: () async {
          final r = await showDateRangePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime.now(), initialDateRange: range);
          if (r != null) setState(() => range = r);
        })],
      ),
      body: Column(children: [
        SizedBox(
          height: 46,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), children: [
            chip(trn('همه'), who == 'all', () => who = 'all'),
            chip(trn('من'), who == 'me', () => who = 'me'),
            chip(trn('طرف مقابل'), who == 'them', () => who = 'them'),
            const SizedBox(width: 10),
            chip(trn('هر نوع'), type == 'all', () => type = 'all'),
            chip(trn('متن'), type == 'text', () => type = 'text'),
            chip(trn('عکس و ویدئو'), type == 'media', () => type = 'media'),
            chip(trn('ویس'), type == 'audio', () => type = 'audio'),
            chip(trn('فایل'), type == 'file', () => type = 'file'),
            chip(trn('لینک'), type == 'link', () => type = 'link'),
          ]),
        ),
        if (range != null)
          Align(alignment: AlignmentDirectional.centerStart, child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: ActionChip(avatar: const Icon(Icons.close, size: 16), label: Text('${dayLabel(range!.start)} ← ${dayLabel(range!.end)}'), onPressed: () => setState(() => range = null)))),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4), child: Align(alignment: AlignmentDirectional.centerStart, child: Text(trf('{0} نتیجه', [res.length]), style: TextStyle(color: cTextFaint, fontSize: 12)))),
        Expanded(
          child: ListView.separated(
            itemCount: res.length,
            separatorBuilder: (_, __) => Divider(height: 1, color: cLine),
            itemBuilder: (c, i) {
              final m = res[i];
              return ListTile(
                title: Text(_snippet(m), maxLines: 2, overflow: TextOverflow.ellipsis),
                subtitle: Text('${_who(m['sender_id'] as String)} • ${_dt(m)}', style: TextStyle(color: cTextFaint, fontSize: 12)),
                onTap: () {
                  Navigator.pop(context);
                  widget.jump(m['id'] as int);
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}

// ===========================================================================
// ۴) رسانه، فایل، ویس و لینک‌های گفتگو
// ===========================================================================
class ChatMediaPage extends StatelessWidget {
  final List<Map<String, dynamic>> msgs;
  final void Function(int id) jump;
  const ChatMediaPage({super.key, required this.msgs, required this.jump});

  Widget _list(BuildContext context, List<Map<String, dynamic>> l, IconData ic, String Function(Map<String, dynamic>) title) {
    if (l.isEmpty) return Center(child: Text(trn('چیزی نیست'), style: TextStyle(color: cTextFaint)));
    return ListView.separated(
      itemCount: l.length,
      separatorBuilder: (_, __) => Divider(height: 1, color: cLine),
      itemBuilder: (c, i) {
        final m = l[i];
        return ListTile(
          leading: Icon(ic, color: accent),
          title: Text(title(m), maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text('${_who(m['sender_id'] as String)} • ${_dt(m)}', style: TextStyle(color: cTextFaint, fontSize: 12)),
          onTap: () {
            Navigator.pop(context);
            jump(m['id'] as int);
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final r = [for (final m in msgs.reversed) if (m['pending'] != true) m];
    List<Map<String, dynamic>> by(bool Function(String k) f) => [for (final m in r) if (f(kindOf(m))) m];
    final media = by((k) => k == 'image' || k == 'video' || k == 'gif');
    final files = by((k) => k == 'file');
    final voice = by((k) => k == 'audio');
    final links = [for (final m in r) if (kindOf(m) == 'text' && firstUrl((m['text'] as String?) ?? '') != null) m];
    String fname(Map<String, dynamic> m) => ((m['file_name'] as String?) ?? '').isEmpty ? preview(m) : m['file_name'] as String;
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: Text(trn('رسانه و لینک‌ها')),
          bottom: TabBar(isScrollable: true, tabs: [
            Tab(text: '${trn('رسانه')} (${media.length})'),
            Tab(text: '${trn('فایل')} (${files.length})'),
            Tab(text: '${trn('ویس')} (${voice.length})'),
            Tab(text: '${trn('لینک')} (${links.length})'),
          ]),
        ),
        body: TabBarView(children: [
          _list(context, media, Icons.photo_library_outlined, fname),
          _list(context, files, Icons.insert_drive_file_outlined, fname),
          _list(context, voice, Icons.mic_none_rounded, (m) => preview(m)),
          _list(context, links, Icons.link_rounded, (m) => firstUrl(m['text'] as String) ?? ''),
        ]),
      ),
    );
  }
}

// ===========================================================================
// ۵) آمار گفتگو
// ===========================================================================
class ChatStatsPage extends StatelessWidget {
  final List<Map<String, dynamic>> msgs;
  const ChatStatsPage({super.key, required this.msgs});

  @override
  Widget build(BuildContext context) {
    final r = [for (final m in msgs) if (m['pending'] != true) m];
    final by = <String, int>{};
    final kinds = <String, int>{};
    final hours = List<int>.filled(24, 0);
    var chars = 0, texts = 0;
    for (final m in r) {
      by[m['sender_id'] as String] = (by[m['sender_id'] as String] ?? 0) + 1;
      final k = kindOf(m);
      kinds[k] = (kinds[k] ?? 0) + 1;
      final t = _t(m);
      if (t != null) hours[t.hour]++;
      if (k == 'text') {
        texts++;
        chars += ((m['text'] as String?) ?? '').length;
      }
    }
    var peak = 0;
    for (var i = 1; i < 24; i++) {
      if (hours[i] > hours[peak]) peak = i;
    }
    final words = keywordsOf([for (final m in r) if (kindOf(m) == 'text') (m['text'] as String?) ?? ''], 10);
    final total = r.isEmpty ? 1 : r.length;
    Widget row(String l, int n) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(children: [
            SizedBox(width: 92, child: Text(l, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: cText))),
            Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: n / total, minHeight: 10, backgroundColor: cLine, color: accent))),
            SizedBox(width: 44, child: Text(faDigits('$n'), textAlign: TextAlign.end, style: TextStyle(color: cTextDim))),
          ]),
        );
    final kindNames = {'text': trn('متن'), 'image': trn('عکس'), 'video': trn('ویدئو'), 'audio': trn('ویس'), 'file': trn('فایل'), 'gif': trn('گیف'), 'sticker': trn('استیکر'), 'location': trn('موقعیت مکانی'), 'contact': trn('مخاطب'), 'poll': trn('نظرسنجی')};
    return Scaffold(
      appBar: AppBar(title: Text(trn('آمار گفتگو'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(trf('{0} پیام', [faDigits('${r.length}')]), style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: accent)),
        if (r.isNotEmpty) Text('${_dt(r.first)}  ←  ${_dt(r.last)}', style: TextStyle(color: cTextFaint, fontSize: 12)),
        _title(trn('سهم هر نفر')),
        for (final e in (by.entries.toList()..sort((a, b) => b.value.compareTo(a.value))).take(8)) row(_who(e.key), e.value),
        _title(trn('نوع پیام‌ها')),
        for (final e in (kinds.entries.toList()..sort((a, b) => b.value.compareTo(a.value)))) row(kindNames[e.key] ?? e.key, e.value),
        _title(trn('شلوغ‌ترین ساعت')),
        Text(r.isEmpty ? '-' : faDigits('${peak.toString().padLeft(2, '0')}:00 - ${(peak + 1) % 24}:00'), style: TextStyle(color: cText, fontSize: 18)),
        if (texts > 0) ...[_title(trn('میانگین طول پیام متنی')), Text(trf('{0} نویسه', [faDigits('${chars ~/ texts}')]), style: TextStyle(color: cText, fontSize: 18))],
        if (words.isNotEmpty) ...[_title(trn('کلمات پرتکرار')), Wrap(spacing: 6, runSpacing: 6, children: [for (final w in words) Chip(label: Text(w), visualDensity: VisualDensity.compact)])],
      ]),
    );
  }
}

// ===========================================================================
// ۶) کارها و قول‌ها
// ===========================================================================
final RegExp _taskRe = RegExp(r'باید|یادت نره|یادت باشه|فراموش نکن|فراموش نکنی|لطفا|انجام بده|بفرست|بیار|هماهنگ کن|زنگ بزن|یادآوری|todo|don\x27t forget|remember to|please|need to|must |deadline|تا فردا|تا آخر هفته');

class TasksPage extends StatelessWidget {
  final List<Map<String, dynamic>> msgs;
  final void Function(int id) jump;
  const TasksPage({super.key, required this.msgs, required this.jump});

  @override
  Widget build(BuildContext context) {
    final l = [for (final m in msgs.reversed) if (m['pending'] != true && kindOf(m) == 'text' && _taskRe.hasMatch(normFa((m['text'] as String?) ?? ''))) m];
    return Scaffold(
      appBar: AppBar(title: Text(trn('کارها و قول‌ها'))),
      body: l.isEmpty
          ? Center(child: Text(trn('موردی پیدا نشد'), style: TextStyle(color: cTextFaint)))
          : ListView.separated(
              itemCount: l.length > 100 ? 100 : l.length,
              separatorBuilder: (_, __) => Divider(height: 1, color: cLine),
              itemBuilder: (c, i) {
                final m = l[i];
                return ListTile(
                  leading: Icon(Icons.check_circle_outline_rounded, color: accent),
                  title: Text(m['text'] as String, maxLines: 3, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${_who(m['sender_id'] as String)} • ${_dt(m)}', style: TextStyle(color: cTextFaint, fontSize: 12)),
                  onTap: () {
                    Navigator.pop(context);
                    jump(m['id'] as int);
                  },
                );
              },
            ),
    );
  }
}

// ===========================================================================
// ۷) کپی کل گفتگو
// ===========================================================================
String chatAsText(List<Map<String, dynamic>> msgs) {
  final b = StringBuffer();
  for (final m in msgs) {
    if (m['pending'] == true) continue;
    final k = kindOf(m);
    final body = k == 'text' ? ((m['text'] as String?) ?? '') : '[${preview(m)}]';
    b.writeln('[${_dt(m)}] ${_who(m['sender_id'] as String)}: $body');
  }
  return b.toString();
}

// ===========================================================================
// ۸) تشخیص ساعت، شماره و ایمیل داخل پیام
// ===========================================================================
DateTime? timeIn(String text) {
  final n = normFa(text);
  final m = RegExp(r'([0-9]{1,2}):([0-9]{2})').firstMatch(n);
  final m2 = m == null ? RegExp(r'ساعت\s*([0-9]{1,2})').firstMatch(n) : null;
  if (m == null && m2 == null) return null;
  final h = int.parse((m ?? m2)!.group(1)!);
  final mi = m != null ? int.parse(m.group(2)!) : 0;
  if (h > 23 || mi > 59) return null;
  final now = DateTime.now();
  var t = DateTime(now.year, now.month, now.day, h, mi);
  if (!t.isAfter(now)) t = t.add(const Duration(days: 1));
  return t;
}

String? phoneIn(String text) {
  final m = RegExp(r'(?:\+98|0098|0)?9[0-9]{9}|\+?[0-9]{10,13}').firstMatch(normFa(text).replaceAll(RegExp(r'[\s\-]'), ''));
  return m?.group(0);
}

String? emailIn(String text) => RegExp(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}').firstMatch(text)?.group(0);

// ===========================================================================
// ۹) پیشنهاد ایموجی از روی متن در حال نوشتن
// ===========================================================================
final List<MapEntry<RegExp, String>> _emo = [
  MapEntry(RegExp(r'خنده|ههه|جک|lol|haha'), '😂'),
  MapEntry(RegExp(r'دوستت دارم|عشق|دلم تنگ|love'), '❤️'),
  MapEntry(RegExp(r'ممنون|مرسی|تشکر|thank'), '🙏'),
  MapEntry(RegExp(r'تبریک|مبارک|congrat'), '🎉'),
  MapEntry(RegExp(r'ناراحت|غم|گریه|sad'), '😢'),
  MapEntry(RegExp(r'عالی|ایول|آفرین|great|awesome'), '👏'),
  MapEntry(RegExp(r'سلام|درود|hello|hi '), '👋'),
  MapEntry(RegExp(r'شب بخیر|خواب|good night'), '🌙'),
  MapEntry(RegExp(r'صبح بخیر|good morning'), '☀️'),
  MapEntry(RegExp(r'غذا|ناهار|شام|گرسنه|pizza|food'), '🍕'),
  MapEntry(RegExp(r'قهوه|چای|coffee'), '☕'),
  MapEntry(RegExp(r'فوتبال|بازی'), '⚽'),
  MapEntry(RegExp(r'پول|کارت|واریز'), '💰'),
  MapEntry(RegExp(r'جلسه|پروژه|کار '), '💼'),
  MapEntry(RegExp(r'تولد|birthday'), '🎂'),
  MapEntry(RegExp(r'باران|بارون'), '🌧️'),
  MapEntry(RegExp(r'سفر|فرودگاه'), '✈️'),
  MapEntry(RegExp(r'ماشین|ترافیک'), '🚗'),
  MapEntry(RegExp(r'دکتر|مریض|سرما'), '🤒'),
  MapEntry(RegExp(r'باشه|اوکی|حله|okay'), '👍'),
];

List<String> emojiHints(String typed) {
  final n = '${normFa(typed)} ';
  return [for (final e in _emo) if (e.key.hasMatch(n)) e.value].take(5).toList();
}

/// تکمیل از روی پیام‌های قبلیِ خود کاربر
List<String> completionsFrom(String typed, List<String> history, {int max = 4}) {
  final q = normFa(typed.trim());
  if (q.length < 2) return const [];
  final out = <String>[];
  for (final h in history) {
    final nh = normFa(h);
    if (nh.startsWith(q) && nh.length > q.length && h.length < 120 && !out.contains(h)) out.add(h);
    if (out.length >= max) break;
  }
  return out;
}

Future<void> copyChat(BuildContext context, List<Map<String, dynamic>> msgs) async {
  final t = chatAsText(msgs);
  await Clipboard.setData(ClipboardData(text: t));
  if (context.mounted) snack(context, trf('{0} پیام کپی شد', [faDigits('${msgs.length}')]));
}
