import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'e2ee.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'groups.dart';
import 'main.dart';
import 'social.dart';
import 'l10n.dart';

const _supaUrl = String.fromEnvironment('SUPABASE_URL');
const _supaKey = String.fromEnvironment('SUPABASE_ANON_KEY');

/// درصد آپلود هر پیام در صف (کلید: cid پیام)
final Map<String, ValueNotifier<double>> uploadProgress = {};
final ValueNotifier<int> uploadsChanged = ValueNotifier(0);

/// آپلود فایل با گزارش پیشرفت (REST خود Supabase Storage)
final Map<String, void Function()> uploadCancel = {};

Future<void> uploadWithProgress(String bucket, String path, File f, String contentType, void Function(double p) onProgress, {String? cid}) async {
  final token = sb.auth.currentSession?.accessToken;
  if (token == null) throw 'auth';
  final len = await f.length();
  final base = _supaUrl.endsWith('/') ? _supaUrl.substring(0, _supaUrl.length - 1) : _supaUrl;
  final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  if (cid != null) uploadCancel[cid] = () => c.close(force: true);
  try {
    final req = await c.postUrl(Uri.parse('$base/storage/v1/object/$bucket/$path'));
    req.headers.set('Authorization', 'Bearer $token');
    req.headers.set('apikey', _supaKey);
    req.headers.set('Content-Type', contentType);
    req.headers.set('Cache-Control', 'max-age=3600');
    req.contentLength = len;
    var sent = 0;
    await req.addStream(f.openRead().map((chunk) {
      sent += chunk.length;
      onProgress(len == 0 ? 0.99 : min(0.99, sent / len)); // تا تأیید سرور هرگز ۱۰۰٪ نشان داده نمی‌شود
      return chunk;
    }));
    final res = await req.close().timeout(const Duration(minutes: 3));
    await res.drain<void>();
    if (res.statusCode < 200 || res.statusCode >= 300) throw 'upload ${res.statusCode}';
    onProgress(1.0);
  } finally {
    if (cid != null) uploadCancel.remove(cid);
    c.close(force: true);
  }
}

// آیا خطا از نوع قطع اینترنت است (نه پاسخ منفی سرور)؟
bool isNetErr(Object e) {
  if (e is SocketException || e is TimeoutException || e is HandshakeException) return true;
  if (e is PostgrestException) return false;
  final s = e.toString();
  return s.contains('SocketException') ||
      s.contains('ClientException') ||
      s.contains('Failed host lookup') ||
      s.contains('Connection') ||
      s.contains('timed out') ||
      s.contains('HandshakeException') ||
      s.contains('TimeoutException');
}

enum NetStatus { online, connecting, offline }

// ---------------------------------------------------------------------------
// پایش اتصال، همگام‌سازی و polling پشتیبان
// ---------------------------------------------------------------------------
class NetMonitor extends ChangeNotifier with WidgetsBindingObserver {
  NetStatus status = NetStatus.connecting;
  bool active = false, syncing = false, justReconnected = false, wsSuspect = false;
  int _fails = 0;
  bool _everOnline = false, _busy = false;
  Timer? _timer, _hideTimer;
  DateTime _lastPing = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _lastPoll = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _lastResub = DateTime.fromMillisecondsSinceEpoch(0);

  void start() {
    if (active) return;
    active = true;
    status = NetStatus.connecting;
    _fails = 0;
    _everOnline = false;
    WidgetsBinding.instance.addObserver(this);
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _tick());
    notifyListeners();
    _tick(force: true);
  }

  void stop() {
    active = false;
    syncing = false;
    justReconnected = false;
    _timer?.cancel();
    _hideTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed && active) _tick(force: true);
  }

  void _set(NetStatus s) {
    if (status != s) {
      status = s;
      notifyListeners();
    }
  }

  void reportFailure() {
    _fails++;
    _set(_fails >= 2 ? NetStatus.offline : NetStatus.connecting);
    _lastPing = DateTime.fromMillisecondsSinceEpoch(0);
  }

  void noteStreamError() {
    wsSuspect = true;
  }

  void noteStreamOk() {
    wsSuspect = false;
  }

  Future<bool> _ping() async {
    if (_supaUrl.isEmpty) return true;
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 6);
    try {
      final req = await c.getUrl(Uri.parse('$_supaUrl/auth/v1/health'));
      req.headers.set('apikey', _supaKey);
      final res = await req.close().timeout(const Duration(seconds: 7));
      await res.drain<void>();
      return res.statusCode < 500;
    } catch (_) {
      return false;
    } finally {
      c.close(force: true);
    }
  }

  Future<void> catchUpAll() async {
    try {
      await Future.wait([store.catchUp(), gs.catchUp()]);
    } catch (e) {
      if (isNetErr(e)) reportFailure();
    }
  }

  Future<void> _regained() async {
    final first = !_everOnline;
    _everOnline = true;
    if (!first) {
      syncing = true;
    }
    _set(NetStatus.online);
    notifyListeners();
    try {
      if (!first) {
        store.resubscribe();
        gs.resubscribe();
      }
      outbox.wake();
      await outbox.flush();
      await catchUpAll();
    } catch (_) {}
    syncing = false;
    if (!first) {
      justReconnected = true;
      _hideTimer?.cancel();
      _hideTimer = Timer(const Duration(milliseconds: 2500), () {
        justReconnected = false;
        notifyListeners();
      });
    }
    notifyListeners();
  }

  Future<void> _tick({bool force = false}) async {
    if (!active || _busy) return;
    final now = DateTime.now();
    final pingEvery = status == NetStatus.online ? const Duration(seconds: 20) : const Duration(seconds: 4);
    _busy = true;
    try {
      if (force || now.difference(_lastPing) >= pingEvery) {
        _lastPing = now;
        final ok = await _ping();
        if (!active) return;
        if (ok) {
          _fails = 0;
          if (status != NetStatus.online) await _regained();
        } else {
          _fails++;
          _set(_fails >= 2 ? NetStatus.offline : NetStatus.connecting);
        }
      }
      if (active && status == NetStatus.online) {
        if (outbox.hasDue) {
          final n = await outbox.flush();
          if (n > 0) {
            _lastPoll = now;
            await catchUpAll();
          }
        }
        // polling سبک: اگر WebSocket مشکوک است سریع‌تر، وگرنه به‌عنوان شبکه‌ی ایمنی
        final every = wsSuspect ? 6 : 25;
        if (now.difference(_lastPoll).inSeconds >= every) {
          _lastPoll = now;
          await catchUpAll();
        }
        if (wsSuspect && now.difference(_lastResub).inSeconds >= 45) {
          _lastResub = now;
          store.resubscribe();
          gs.resubscribe();
        }
      }
    } finally {
      _busy = false;
    }
  }
}

final net = NetMonitor();

// ---------------------------------------------------------------------------
// صف ارسال آفلاین (ذخیره‌ی محلی + تلاش دوباره با فاصله‌ی افزایشی)
// ---------------------------------------------------------------------------
class Outbox extends ChangeNotifier {
  final List<Map<String, dynamic>> items = [];
  bool useClientId = true;
  int _localSeq = 0;
  bool _flushing = false;
  final _rnd = Random.secure();

  String get _key => 'outbox_${me ?? ''}';
  int get count => items.length;
  bool get hasDue {
    final n = DateTime.now().millisecondsSinceEpoch;
    return items.any((e) => ((e['nextAt'] as int?) ?? 0) <= n);
  }

  void wake() {
    for (final e in items) {
      e['nextAt'] = 0;
    }
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    items.clear();
    for (final s in p.getStringList(_key) ?? <String>[]) {
      try {
        final e = Map<String, dynamic>.from(jsonDecode(s) as Map);
        e['localId'] = --_localSeq;
        e['nextAt'] = 0;
        items.add(e);
      } catch (_) {}
    }
    _refreshViews();
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_key, [for (final e in items) jsonEncode(e)]);
  }

  void _refreshViews() {
    store.refreshPending();
    gs.refreshPending();
    notifyListeners();
  }

  Map<String, dynamic> _view(Map<String, dynamic> e) {
    final b = Map<String, dynamic>.from(e['body'] as Map);
    final m = <String, dynamic>{'id': e['localId'], 'cid': e['cid'], 'sender_id': me, 'text': '', 'kind': 'text', 'read_at': null, 'pending': true, 'created_at': e['createdAt']};
    m.addAll(b);
    if (e['scope'] == 'dm') {
      m['receiver_id'] = e['peer'];
    } else {
      m['group_id'] = e['gid'];
    }
    final shown = (e['file'] ?? e['preview']) as String?;
    if (shown != null) {
      final k = (b['kind'] as String?) ?? 'file';
      const names = {'image': '🖼 عکس', 'video': '🎬 ویدیو', 'audio': '🎤 پیام صوتی', 'gif': '🎞 گیف'};
      m['kind'] = 'text';
      m['text'] = trf('{0} در صف ارسال...', [trn(names[k] ?? trn('📎 فایل'))]);
      m['pending_kind'] = k;
      m['local_path'] = shown;
      m['pending_name'] = e['fileName'];
    }
    return m;
  }

  List<Map<String, dynamic>> pendingDm() => [for (final e in items) if (e['scope'] == 'dm') _view(e)];
  List<Map<String, dynamic>> pendingGroup() => [for (final e in items) if (e['scope'] == 'group') _view(e)];

  Future<void> cancel(int localId) async {
    for (final e in items.where((e) => e['localId'] == localId)) {
      e['cancelled'] = true;
      uploadCancel[e['cid']]?.call(); // آپلود در حال انجام همین‌جا قطع می‌شود
    }
    final gone = [for (final e in items) if (e['localId'] == localId) e];
    items.removeWhere((e) => e['localId'] == localId);
    for (final e in gone) {
      _dropStaged(e);
    }
    await _save();
    _refreshViews();
  }

  // فایل‌های در صف ارسال در پوشه‌ی برنامه کپی می‌شوند تا اگر فایل اصلی (مثل ویس موقت) پاک شد، آپلود خراب نشود
  Future<String> _stage(String src, String cid, String name) async {
    try {
      final base = await getApplicationSupportDirectory();
      final dir = Directory('${base.path}/outbox');
      if (!await dir.exists()) await dir.create(recursive: true);
      final safe = name.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
      final dst = '${dir.path}/${cid}_$safe';
      await File(src).copy(dst);
      return dst;
    } catch (_) {
      return src;
    }
  }

  void _dropStaged(Map<String, dynamic> e) {
    for (final k in ['file', 'preview']) {
      final p = e[k] as String?;
      if (p != null && p.contains('/outbox/')) {
        try {
          File(p).deleteSync();
        } catch (_) {}
      }
    }
  }

  // بعد از تحویل: پیام واقعی را فوراً بگیر تا پیام «در حال ارسال» بدون پرش جایگزین شود
  void _afterSent(Map<String, dynamic> e) {
    _dropStaged(e);
    if (e['scope'] == 'dm') {
      store.catchUp().catchError((_) {});
    } else {
      gs.catchUp().catchError((_) {});
    }
  }

  Future<void> _insert(Map<String, dynamic> e, Map<String, dynamic> body) async {
    if (e['scope'] == 'dm') {
      await sb.from('messages').insert({'sender_id': me, 'receiver_id': e['peer'], ...body});
    } else {
      await sb.from('group_messages').insert({'group_id': e['gid'], 'sender_id': me, ...body});
    }
  }

  Future<void> _deliver(Map<String, dynamic> e) async {
    try {
      await _deliver0(e);
    } finally {
      if (uploadProgress.remove(e['cid']) != null) uploadsChanged.value++;
    }
  }

  Future<void> _deliver0(Map<String, dynamic> e) async {
    final stored = e['body'] as Map;
    final file = e['file'] as String?;
    if (file != null) {
      final f = File(file);
      if (!await f.exists()) throw 'gone';
      final nm = (e['fileName'] as String?) ?? 'file';
      final path = '${me!}/${DateTime.now().millisecondsSinceEpoch}${extOf(nm)}';
      final prog = uploadProgress.putIfAbsent(e['cid'] as String, () => ValueNotifier<double>(0));
      prog.value = 0;
      uploadsChanged.value++;
      await uploadWithProgress('chat-files', path, f, mimeOf(nm), (p) => prog.value = p, cid: e['cid'] as String);
      stored['file_path'] = path;
      stored['file_name'] = nm;
      e['file'] = null; // آپلود شد؛ در تلاش‌های بعدی دوباره آپلود نمی‌شود
      await _save();
    }
    final body = Map<String, dynamic>.from(stored);
    if (e['scope'] == 'dm' && ((body['kind'] as String?) ?? 'text') == 'text' && body['text'] is String && (body['text'] as String).isNotEmpty && !(body['text'] as String).startsWith(E2ee.prefix)) {
      final enc = await e2ee.encrypt(body['text'] as String, e['peer'] as String);
      if (enc != null) body['text'] = enc;
    }
    if (useClientId) body['client_id'] = e['cid'];
    try {
      await _insert(e, body);
    } on PostgrestException catch (err) {
      if (err.code == '23505') return; // قبلاً ثبت شده بود
      if (useClientId && (err.code == 'PGRST204' || err.code == '42703' || err.message.contains('client_id'))) {
        useClientId = false; // ستون client_id در سرور ساخته نشده
        body.remove('client_id');
        await _insert(e, body);
        return;
      }
      rethrow;
    }
  }

  /// ارسال پیام. اگر اینترنت نبود، پیام در صف می‌ماند و برای کاربر خطا نمی‌آید.
  Future<void> send(String scope, {String? peer, int? gid, required Map<String, dynamic> body, String? file, String? fileName}) async {
    final e = <String, dynamic>{
      'cid': '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}${_rnd.nextInt(1 << 30).toRadixString(36)}',
      'scope': scope,
      'peer': peer,
      'gid': gid,
      'body': Map<String, dynamic>.from(body),
      'file': file,
      'fileName': fileName,
      'attempts': 0,
      'nextAt': DateTime.now().millisecondsSinceEpoch + 3000,
      'createdAt': DateTime.now().toUtc().toIso8601String(),
      'localId': --_localSeq,
    };
    if (file != null) {
      // فایل: اول در صف می‌آید تا حباب با حلقه‌ی درصد فوراً دیده شود؛ آپلود در پس‌زمینه انجام می‌شود
      final staged = await _stage(file, e['cid'] as String, fileName ?? 'file');
      e['file'] = staged;
      e['preview'] = staged;
      e['nextAt'] = 0;
      items.add(e);
      await _save();
      _refreshViews();
      flush();
      return;
    }
    if (items.isEmpty) {
      try {
        await _deliver(e).timeout(const Duration(seconds: 12));
        return;
      } on Object catch (err) {
        if (!isNetErr(err)) rethrow;
        net.reportFailure();
      }
    }
    items.add(e);
    await _save();
    _refreshViews();
  }

  /// تعداد پیام‌های تحویل‌شده را برمی‌گرداند
  Future<int> flush() async {
    if (_flushing) return 0;
    _flushing = true;
    var sent = 0;
    try {
      while (items.isNotEmpty) {
        final e = items.first;
        final now = DateTime.now().millisecondsSinceEpoch;
        if (((e['nextAt'] as int?) ?? 0) > now) break;
        try {
          await _deliver(e).timeout(Duration(seconds: e['file'] != null ? 600 : 40));
          items.remove(e);
          sent++;
          await _save();
          _refreshViews();
          _afterSent(e);
        } on Object catch (err) {
          if (e['cancelled'] == true) continue; // کاربر خودش لغو کرد؛ پیام خطا نشان داده نمی‌شود
          if (isNetErr(err)) {
            final a = ((e['attempts'] as int?) ?? 0) + 1;
            e['attempts'] = a;
            final delay = min(120, 2 << min(a, 6)); // ۴، ۸، ۱۶، ۳۲، ۶۴، ۱۲۰ ثانیه
            e['nextAt'] = now + delay * 1000 + _rnd.nextInt(1000);
            net.reportFailure();
            break;
          }
          items.remove(e);
          _dropStaged(e);
          messengerKey.currentState?.showSnackBar(SnackBar(content: Text(trn('یک پیام در صف ارسال نشد و حذف شد'))));
        }
        await _save();
      }
    } finally {
      _flushing = false;
      await _save();
      _refreshViews();
    }
    return sent;
  }
}

final outbox = Outbox();

// ---------------------------------------------------------------------------
// نوار وضعیت اتصال بالای برنامه
// ---------------------------------------------------------------------------
class NetShell extends StatelessWidget {
  final Widget child;
  const NetShell({super.key, required this.child});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([net, outbox]),
        builder: (c, _) {
          String? text;
          final n = outbox.count;
          final q = n > 0 ? trf(' • {0} پیام در صف ارسال', [n]) : '';
          if (net.active) {
            if (net.status == NetStatus.offline) {
              text = trf('اینترنت قطع است{0}', [q]);
            } else if (net.status == NetStatus.connecting) {
              text = trf('در حال اتصال...{0}', [q]);
            } else if (net.syncing) {
              text = trn('در حال همگام‌سازی...');
            } else if (n > 0) {
              text = trf('در حال ارسال {0} پیام در صف...', [n]);
            } else if (net.justReconnected) {
              text = trn('متصل شد');
            }
          }
          final show = text != null;
          return Column(children: [
            AnimatedSize(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutCubic,
              alignment: Alignment.topCenter,
              child: !show
                  ? const SizedBox(width: double.infinity)
                  : Material(
                      color: bg,
                      child: SafeArea(
                        bottom: false,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
                          child: SizedBox(width: double.infinity, child: Text(text!, textAlign: TextAlign.center, style: TextStyle(color: cTextDim, fontSize: 12, fontWeight: FontWeight.w600), overflow: TextOverflow.ellipsis)),
                        ),
                      ),
                    ),
            ),
            Expanded(child: MediaQuery.removePadding(context: c, removeTop: show, child: child)),
          ]);
        },
      );
}
