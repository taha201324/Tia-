import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'main.dart';
import 'social.dart';

class SafetyStore extends ChangeNotifier {
  final blocked = <String>{};
  final prefs = <String, Map<String, dynamic>>{};

  String _k(String scope, String target) => '$scope:$target';

  Future<void> load() async {
    final b = await sb.from('blocks').select('blocked_id').eq('blocker_id', me!);
    blocked
      ..clear()
      ..addAll(b.map((r) => r['blocked_id'] as String));
    final p = await sb.from('chat_prefs').select().eq('user_id', me!);
    prefs.clear();
    for (final r in p) {
      prefs[_k(r['scope'] as String, r['target'] as String)] = r;
    }
    notifyListeners();
  }

  void clear() {
    blocked.clear();
    prefs.clear();
  }

  bool isBlocked(String id) => blocked.contains(id);
  Map<String, dynamic>? pref(String scope, String target) => prefs[_k(scope, target)];
  bool flag(String scope, String target, String k) => pref(scope, target)?[k] == true;

  bool visible(String scope, String target, Map<String, dynamic> m) {
    final c = pref(scope, target)?['cleared_at'] as String?;
    return c == null || (m['created_at'] as String).compareTo(c) > 0;
  }

  Future<void> setFlag(String scope, String target, String k, bool v) async {
    await sb.from('chat_prefs').upsert({'user_id': me, 'scope': scope, 'target': target, k: v});
    await load();
  }

  Future<void> clearChat(String scope, String target) async {
    await sb.rpc('clear_chat', params: {'sc': scope, 'tg': target});
    await load();
  }

  Future<void> block(String id) async {
    await sb.from('blocks').upsert({'blocker_id': me, 'blocked_id': id});
    try {
      await sb.from('follows').delete().eq('follower_id', me!).eq('followee_id', id);
      await sb.from('follows').delete().eq('follower_id', id).eq('followee_id', me!);
    } catch (_) {}
    await load();
  }

  Future<void> unblock(String id) async {
    await sb.from('blocks').delete().eq('blocker_id', me!).eq('blocked_id', id);
    await load();
  }

  Future<void> report(String kind, String target, String reason, String details) =>
      sb.from('reports').insert({'reporter_id': me, 'kind': kind, 'target': target, 'reason': reason, 'details': details});
}

final safety = SafetyStore();

Future<void> reportDialog(BuildContext c, String kind, String target) async {
  const reasons = ['اسپم یا تبلیغات مزاحم', 'آزار و توهین', 'محتوای نامناسب یا خشونت‌آمیز', 'جعل هویت یا حساب جعلی', 'سایر'];
  final details = TextEditingController();
  var sel = 0;
  final ok = await showDialog<bool>(
    context: c,
    builder: (_) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: const Text('گزارش تخلف'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (var i = 0; i < reasons.length; i++)
              ListTile(
                dense: true,
                leading: Icon(sel == i ? Icons.radio_button_checked : Icons.radio_button_unchecked, color: sel == i ? primary : null),
                title: Text(reasons[i]),
                onTap: () => set(() => sel = i),
              ),
            const SizedBox(height: 8),
            TextField(controller: details, maxLines: 2, decoration: fieldDeco(hintText: 'توضیح بیشتر (اختیاری)')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ارسال گزارش')),
        ],
      ),
    ),
  );
  if (ok != true) return;
  try {
    await safety.report(kind, target, reasons[sel], details.text.trim());
    if (c.mounted) snack(c, 'گزارش شما ثبت شد');
  } catch (_) {
    if (c.mounted) snack(c, 'گزارش ثبت نشد');
  }
}

Future<void> blockDialog(BuildContext c, String id) async {
  if (!await confirm(c, 'کاربر «${store.name(id)}» مسدود شود؟ او دیگر نمی‌تواند به شما پیام بدهد یا شما را دنبال کند و دنبال‌کردن‌های دو طرف حذف می‌شود.')) return;
  try {
    await safety.block(id);
    if (c.mounted) snack(c, 'کاربر مسدود شد');
  } catch (_) {
    if (c.mounted) snack(c, 'انجام نشد');
  }
}

Future<void> chatActions(BuildContext c, String scope, String target) async {
  final pinned = safety.flag(scope, target, 'pinned');
  final muted = safety.flag(scope, target, 'muted');
  final archived = safety.flag(scope, target, 'archived');
  final direct = scope == 'd' && target != me;
  final blocked = direct && safety.isBlocked(target);
  final a = await showModalBottomSheet<String>(
    context: c,
    builder: (sc) => Directionality(
      textDirection: TextDirection.rtl,
      child: SafeArea(
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(leading: Icon(pinned ? Icons.push_pin : Icons.push_pin_outlined), title: Text(pinned ? 'برداشتن سنجاق گفتگو' : 'سنجاق گفتگو به بالای لیست'), onTap: () => Navigator.pop(sc, 'pin')),
            ListTile(leading: Icon(muted ? Icons.volume_up_outlined : Icons.volume_off_outlined), title: Text(muted ? 'فعال‌کردن اعلان‌ها' : 'بی‌صدا کردن اعلان‌ها'), onTap: () => Navigator.pop(sc, 'mute')),
            ListTile(leading: Icon(archived ? Icons.unarchive_outlined : Icons.archive_outlined), title: Text(archived ? 'خروج از بایگانی' : 'بایگانی گفتگو'), onTap: () => Navigator.pop(sc, 'archive')),
            ListTile(leading: const Icon(Icons.delete_sweep_outlined, color: Colors.redAccent), title: const Text('حذف گفتگو (فقط برای من)'), onTap: () => Navigator.pop(sc, 'clear')),
            if (direct) ListTile(leading: Icon(blocked ? Icons.lock_open : Icons.block), title: Text(blocked ? 'رفع مسدودی' : 'مسدود کردن کاربر'), onTap: () => Navigator.pop(sc, 'block')),
            if (scope == 'g' || direct) ListTile(leading: const Icon(Icons.flag_outlined), title: Text(scope == 'g' ? 'گزارش گروه یا کانال' : 'گزارش کاربر'), onTap: () => Navigator.pop(sc, 'report')),
          ]),
        ),
      ),
    ),
  );
  if (a == null || !c.mounted) return;
  try {
    switch (a) {
      case 'pin':
        await safety.setFlag(scope, target, 'pinned', !pinned);
        break;
      case 'mute':
        await safety.setFlag(scope, target, 'muted', !muted);
        break;
      case 'archive':
        await safety.setFlag(scope, target, 'archived', !archived);
        break;
      case 'clear':
        if (await confirm(c, 'پیام‌های این گفتگو فقط برای شما پاک می‌شوند و طرف مقابل همچنان آن‌ها را دارد. ادامه می‌دهید؟')) {
          await safety.clearChat(scope, target);
        }
        break;
      case 'block':
        if (blocked) {
          await safety.unblock(target);
        } else {
          await blockDialog(c, target);
        }
        break;
      case 'report':
        await reportDialog(c, scope == 'g' ? 'group' : 'user', target);
        break;
    }
  } catch (_) {
    if (c.mounted) snack(c, 'انجام نشد. SQL مرحله‌ی جدید اجرا شده است؟');
  }
}

class BlockedPage extends StatefulWidget {
  const BlockedPage({super.key});
  @override
  State<BlockedPage> createState() => _BlockedPageState();
}

class _BlockedPageState extends State<BlockedPage> {
  @override
  void initState() {
    super.initState();
    store.loadPeople(safety.blocked).then((_) {
      if (mounted) setState(() {});
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('کاربران مسدودشده')),
        body: ListenableBuilder(
          listenable: safety,
          builder: (c, _) => safety.blocked.isEmpty
              ? const Center(child: Text('کاربر مسدودشده‌ای ندارید'))
              : ListView(children: [
                  for (final id in safety.blocked)
                    ListTile(
                      leading: avatarFor(id),
                      title: nameWithBadge(id),
                      trailing: TextButton(
                        onPressed: () async {
                          try {
                            await safety.unblock(id);
                          } catch (_) {
                            if (c.mounted) snack(c, 'انجام نشد');
                          }
                        },
                        child: const Text('رفع مسدودی'),
                      ),
                    ),
                ]),
        ),
      );
}

Future<void> chooseLastSeen(BuildContext c) async {
  final v = await showDialog<String>(
    context: c,
    builder: (d) => SimpleDialog(title: const Text('چه کسانی آخرین بازدید من را ببینند؟'), children: [
      SimpleDialogOption(onPressed: () => Navigator.pop(d, 'everybody'), child: const Text('همه')),
      SimpleDialogOption(onPressed: () => Navigator.pop(d, 'contacts'), child: const Text('فقط مخاطبین من')),
      SimpleDialogOption(onPressed: () => Navigator.pop(d, 'nobody'), child: const Text('هیچ‌کس')),
    ]),
  );
  if (v == null) return;
  try {
    await sb.from('profiles').update({'last_seen_visibility': v}).eq('id', me!);
    store.refreshPerson(me!, {...store.people[me!]!, 'last_seen_visibility': v});
  } catch (_) {
    if (c.mounted) snack(c, 'ذخیره نشد');
  }
}

Future<void> changePasswordFlow(BuildContext c) async {
  final oldC = TextEditingController(), newC = TextEditingController();
  final ok = await showDialog<bool>(
    context: c,
    builder: (d) => AlertDialog(
      title: const Text('تغییر رمز عبور'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: oldC, obscureText: true, decoration: fieldDeco(labelText: 'رمز فعلی')),
        const SizedBox(height: 12),
        TextField(controller: newC, obscureText: true, decoration: fieldDeco(labelText: 'رمز جدید (حداقل ۶ کاراکتر)')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('انصراف')),
        FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('تغییر')),
      ],
    ),
  );
  if (ok != true || !c.mounted) return;
  if (newC.text.length < 6) {
    snack(c, 'رمز جدید حداقل ۶ کاراکتر باشد');
    return;
  }
  try {
    final email = sb.auth.currentUser?.email;
    if (email == null) throw 'no email';
    await sb.auth.signInWithPassword(email: email, password: oldC.text);
    await sb.auth.updateUser(UserAttributes(password: newC.text));
    if (c.mounted) snack(c, 'رمز عبور تغییر کرد');
  } catch (_) {
    if (c.mounted) snack(c, 'تغییر رمز انجام نشد. رمز فعلی را بررسی کنید.');
  }
}

Future<void> logoutOthersFlow(BuildContext c) async {
  if (!await confirm(c, 'از همه‌ی دستگاه‌های دیگر خارج می‌شوید؟')) return;
  try {
    await sb.auth.signOut(scope: SignOutScope.others);
    if (c.mounted) snack(c, 'از سایر دستگاه‌ها خارج شدید');
  } catch (_) {
    if (c.mounted) snack(c, 'انجام نشد');
  }
}

Future<void> deleteAccountFlow(BuildContext c) async {
  if (!await confirm(c, 'حساب شما همراه با پیام‌ها، پست‌ها و گروه‌هایی که مالک آن‌ها هستید برای همیشه حذف می‌شود. این کار قابل بازگشت نیست. ادامه می‌دهید؟')) return;
  if (!c.mounted) return;
  if (!await confirm(c, 'آیا کاملاً مطمئن هستید؟')) return;
  try {
    await sb.rpc('delete_my_account');
  } catch (_) {
    if (c.mounted) snack(c, 'حذف حساب انجام نشد');
    return;
  }
  try {
    await sb.auth.signOut();
  } catch (_) {}
}
