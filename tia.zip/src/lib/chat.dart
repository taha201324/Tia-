import 'dart:async';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:file_picker/file_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'ai.dart';
import 'cyber.dart';
import 'extras.dart';
import 'emoji.dart';
import 'gif.dart';
import 'media_progress.dart';
import 'net.dart';
import 'rich.dart';
import 'groups.dart';
import 'media.dart';
import 'main.dart';
import 'safety.dart';
import 'smart.dart';
import 'e2ee.dart';
import 'chatprefs.dart';
import 'ui_kit.dart';
import 'social.dart';
import 'l10n.dart';

final _linkRe = RegExp(r'(https?://|www\.|t\.me/|[a-z0-9-]+\.(com|ir|org|net|me|io)\b)', caseSensitive: false);
bool hasLink(String t) => _linkRe.hasMatch(t);
String errText(Object e) => e is PostgrestException ? e.message : trn('ارسال نشد. اینترنت را بررسی کنید.');
String snippet(Map<String, dynamic> m) => kindOf(m) == 'text' ? (m['text'] as String) : preview(m);

Future<void> openChat(BuildContext c, String id) => Navigator.push(c, MaterialPageRoute(builder: (_) => ChatPage(peer: id)));

class ChatPage extends StatefulWidget {
  final String? peer;
  final int? gid;
  final int? jumpTo;
  const ChatPage({super.key, this.peer, this.gid, this.jumpTo});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctrl = TextEditingController();
  final rec = AudioRecorder();
  String _recExt = 'm4a';
  bool recording = false, uploading = false;
  int secs = 0;
  Timer? timer;
  final List<double> _amps = [];
  StreamSubscription? _ampSub;
  Map<String, dynamic>? replyTo;
  int? editing;
  RealtimeChannel? _ch;
  final typers = <String, DateTime>{};
  DateTime _lastTyping = DateTime(2000);
  bool searching = false;
  String q = '';
  final itemScroll = ItemScrollController();
  final selected = <int>{};
  final _bkeys = <int, GlobalKey>{};
  Map<String, dynamic> cprefs = {};
  String get ckey => '$scope:${isGroup ? gid : peer}';
  Future<void> saveCprefs() async {
    await ChatPrefs.save(ckey, cprefs);
    if (mounted) setState(() {});
  }
  GlobalKey _keyFor(int id) => _bkeys.putIfAbsent(id, () => GlobalKey());
  int? flash;
  List<Map<String, dynamic>> _lastList = [];
  bool get selecting => selected.isNotEmpty;

  bool get isGroup => widget.gid != null;
  int get gid => widget.gid!;
  String get peer => widget.peer!;
  List<Map<String, dynamic>> get msgs {
    final all = isGroup ? gs.msgsOf(gid) : store.msgsWith(peer);
    if (ttl <= 0) return all;
    final cut = DateTime.now().subtract(Duration(seconds: ttl));
    return all.where((m) => DateTime.parse(m['created_at'] as String).isAfter(cut)).toList();
  }
  bool get textOk => !isGroup || gs.canSend(gid, 'text');
  bool get mediaOk => !isGroup || gs.canSend(gid, 'media');
  bool get isSaved => !isGroup && peer == me;
  String get _draftKey => 'draft:${isGroup ? 'g$gid' : peer}';
  String get scope => isGroup ? 'g' : 'd';
  bool get canPin => !isGroup || gs.right(gid, 'info');
  bool showEmoji = false;
  int ttl = 0;
  String get ttlKey => isGroup ? '$gid' : ([me!, peer]..sort()).join('_');

  @override
  void initState() {
    super.initState();
    ChatPrefs.load(ckey).then((v) {
      if (mounted) setState(() => cprefs = v);
    });
    if (widget.jumpTo != null) Future.delayed(const Duration(milliseconds: 700), () => jumpTo(widget.jumpTo!));
    if (!isSaved) {
      sb.from('chat_ttl').select('seconds').eq('scope', scope).eq('key', ttlKey).maybeSingle().then((r) {
        if (mounted && r != null) setState(() => ttl = (r['seconds'] as int?) ?? 0);
      }).catchError((_) {});
    }
    SharedPreferences.getInstance().then((p) {
      final d = p.getString(_draftKey);
      if (d != null && d.isNotEmpty && mounted && ctrl.text.isEmpty) setState(() => ctrl.text = d);
    });
    if (!isSaved) {
      final room = isGroup ? 'g$gid' : ([me!, peer]..sort()).join('_');
      _ch = sb.channel('typing:$room')
        ..onBroadcast(
          event: 'typing',
          callback: (p) {
            final u = (p['user'] ?? (p['payload'] as Map?)?['user']) as String?;
            if (u != null && u != me) {
              typers[u] = DateTime.now();
              if (mounted) setState(() {});
              Timer(const Duration(seconds: 4), () {
                if (mounted) setState(() {});
              });
            }
          },
        )
        ..subscribe();
    }
  }

  void typing() {
    final now = DateTime.now();
    if (_ch != null && now.difference(_lastTyping).inSeconds >= 2) {
      _lastTyping = now;
      try {
        _ch!.sendBroadcastMessage(event: 'typing', payload: {'user': me});
      } catch (_) {}
    }
  }

  @override
  void dispose() {
    _ampSub?.cancel();
    timer?.cancel();
    final draft = editing == null ? ctrl.text.trim() : '';
    final dk = _draftKey;
    SharedPreferences.getInstance().then((p) => draft.isEmpty ? p.remove(dk) : p.setString(dk, draft));
    rec.dispose();
    ctrl.dispose();
    if (_ch != null) sb.removeChannel(_ch!);
    super.dispose();
  }

  void jumpTo(int id) {
    final i = _lastList.indexWhere((m) => m['id'] == id);
    if (i < 0) {
      if (mounted) snack(context, trn('پیام پیدا نشد'));
      return;
    }
    try {
      itemScroll.scrollTo(index: i, duration: const Duration(milliseconds: 350), alignment: 0.4);
    } catch (_) {}
    setState(() => flash = id);
    Timer(const Duration(milliseconds: 1600), () {
      if (mounted) setState(() => flash = null);
    });
  }

  void toggleSel(int id) => setState(() {
        if (!selected.remove(id)) selected.add(id);
      });

  List<Map<String, dynamic>> selectedMsgs() => msgs.where((m) => selected.contains(m['id'])).toList()..sort((a, b) => (a['id'] as int).compareTo(b['id'] as int));

  bool canDelete(Map<String, dynamic> m) => m['sender_id'] == me || (isGroup && gs.right(gid, 'delete'));

  List<Widget> selActions() => [
        IconButton(
          icon: const Icon(Icons.copy),
          tooltip: trn('کپی'),
          onPressed: () {
            final t = selectedMsgs().where((m) => kindOf(m) == 'text').map((m) => m['text'] as String).join('\n');
            if (t.isNotEmpty) {
              Clipboard.setData(ClipboardData(text: t));
              snack(context, trn('کپی شد'));
            }
            setState(selected.clear);
          },
        ),
        IconButton(
          icon: const Icon(Icons.forward),
          tooltip: trn('بازارسال'),
          onPressed: () async {
            await forwardMany(selectedMsgs());
            if (mounted) setState(selected.clear);
          },
        ),
        IconButton(icon: const Icon(Icons.delete_outline), tooltip: trn('حذف'), onPressed: deleteSelected),
      ];

  Future<void> deleteSelected() async {
    final ms = selectedMsgs().where(canDelete).toList();
    if (ms.isEmpty) {
      snack(context, trn('فقط پیام‌های خودتان (یا با دسترسی مدیر) قابل حذف است'));
      return;
    }
    if (!await confirm(context, trf('{0} پیام حذف شود؟', [ms.length]))) return;
    for (final m in ms) {
      try {
        await sb.from(isGroup ? 'group_messages' : 'messages').delete().eq('id', m['id'] as int);
        if (isGroup) {
          gs.dropMsg(m['id'] as int);
        } else {
          store.dropMsg(m['id'] as int);
        }
      } catch (_) {}
    }
    if (mounted) setState(selected.clear);
  }

  Future<void> openMedia(Map<String, dynamic> m) async {
    final p = m['file_path'] as String?;
    if (p == null) return;
    try {
      await launchUrl(Uri.parse(await store.urlFor(p)), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) snack(context, trn('باز نشد'));
    }
  }

  Widget mentionBar() {
    if (!isGroup) return const SizedBox.shrink();
    final m = RegExp(r'@([A-Za-z0-9_]*)$').firstMatch(ctrl.text);
    if (m == null) return const SizedBox.shrink();
    final q = m.group(1)!.toLowerCase();
    final cands = (gs.members[gid] ?? [])
        .map((x) => x['user_id'] as String)
        .where((id) => id != me)
        .map((id) => store.people[id])
        .where((p) => p != null && ((p['username'] as String?) ?? '').isNotEmpty && (p['username'] as String).startsWith(q))
        .take(8)
        .toList();
    if (cands.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 48,
      child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
        for (final p in cands)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
            child: ActionChip(
              avatar: avatarFor(p!['id'] as String, r: 10),
              label: Text('@${p['username']}'),
              onPressed: () {
                ctrl.text = ctrl.text.replaceRange(m.start, ctrl.text.length, '@${p['username']} ');
                ctrl.selection = TextSelection.collapsed(offset: ctrl.text.length);
                setState(() {});
              },
            ),
          ),
      ]),
    );
  }

  Future<void> sendLocation() async {
    if (!await confirm(context, trn('موقعیت فعلی شما برای این گفتگو ارسال شود؟'))) return;
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        if (mounted) snack(context, trn('اجازه‌ی موقعیت مکانی داده نشد'));
        return;
      }
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (mounted) snack(context, trn('GPS گوشی را روشن کنید'));
        return;
      }
      final p = await Geolocator.getCurrentPosition().timeout(const Duration(seconds: 25));
      await insertMsg({'text': '${p.latitude.toStringAsFixed(6)},${p.longitude.toStringAsFixed(6)}', 'kind': 'location'});
    } catch (e) {
      if (mounted) snack(context, trn('موقعیت دریافت نشد'));
    }
  }

  Future<void> sendContact() async {
    final id = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(children: [
          ListTile(title: Text(trn('ارسال مخاطب'))),
          if (store.contactIds.isEmpty) ListTile(title: Text(trn('مخاطبی ندارید'))),
          for (final u in store.contactIds) ListTile(leading: avatarFor(u), title: Text(store.name(u)), onTap: () => Navigator.pop(c, u)),
        ]),
      ),
    );
    if (id == null) return;
    try {
      await insertMsg({'text': id, 'kind': 'contact'});
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  Future<void> sendSticker(String e) async {
    try {
      await insertMsg({'text': e, 'kind': 'sticker'});
      if (mounted) setState(() => replyTo = null);
    } catch (err) {
      if (mounted) snack(context, errText(err));
    }
  }

  Future<void> sendGif(GifEntry g) async {
    try {
      if (g.path != null) {
        await insertMsg({'text': '', 'kind': 'gif', 'file_path': g.path, 'file_name': g.title.isEmpty ? 'gif.gif' : g.title});
      } else {
        await insertMsg({'text': g.url, 'kind': 'gif'});
      }
      if (mounted) {
        setState(() {
          replyTo = null;
          showEmoji = false;
        });
      }
    } catch (err) {
      if (mounted) snack(context, errText(err));
    }
  }

  Future<void> pickGifFile() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['gif']);
    final f = r?.files.single;
    if (f == null || f.path == null) return;
    await sendFileMsg(f.path!, f.name, 'gif');
    if (mounted) setState(() => showEmoji = false);
  }

  void insertEmoji(String e) {
    final t = ctrl.text;
    final sel = ctrl.selection;
    final s = sel.isValid ? sel.start : t.length;
    final en = sel.isValid ? sel.end : t.length;
    ctrl.text = t.replaceRange(s, en, e);
    ctrl.selection = TextSelection.collapsed(offset: s + e.length);
    setState(() {});
  }

  String ttlLabel(int s) => s == 0 ? trn('خاموش') : s < 86400 ? trf('{0} ساعت', [s ~/ 3600]) : s < 604800 ? trf('{0} روز', [s ~/ 86400]) : s < 2592000 ? trf('{0} هفته', [s ~/ 604800]) : trf('{0} ماه', [s ~/ 2592000]);

  Future<void> chooseTtl() async {
    final v = await showDialog<int>(
      context: context,
      builder: (d) => SimpleDialog(title: Text(trn('پیام‌های خودحذف‌شونده')), children: [
        for (final s in const [0, 3600, 86400, 604800, 2592000]) SimpleDialogOption(onPressed: () => Navigator.pop(d, s), child: Text(ttlLabel(s))),
      ]),
    );
    if (v == null) return;
    try {
      await sb.from('chat_ttl').upsert({'scope': scope, 'key': ttlKey, 'seconds': v, 'set_by': me});
      if (mounted) setState(() => ttl = v);
    } catch (e) {
      if (mounted) snack(context, trf('تنظیم نشد: {0}', [errText(e)]));
    }
  }

  Map<String, dynamic>? byId(int? id) {
    if (id == null) return null;
    for (final m in msgs) {
      if (m['id'] == id) return m;
    }
    return null;
  }

  Future<void> insertMsg(Map<String, dynamic> body) async {
    final data = {...body, if (replyTo != null) 'reply_to': replyTo!['id']};
    if (isGroup) {
      await gs.sendMsg(gid, data);
    } else {
      await store.sendRaw(peer, data);
    }
  }

  Future<void> sendText() async {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    if (editing != null) {
      await doEdit(t);
      return;
    }
    if (isGroup && hasLink(t) && !gs.canSend(gid, 'link')) {
      snack(context, trn('ارسال لینک در این گروه مجاز نیست'));
      return;
    }
    ctrl.clear();
    setState(() {});
    try {
      await insertMsg({'text': t, 'kind': 'text'});
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
    if (mounted) setState(() => replyTo = null);
  }

  Future<void> doEdit(String t) async {
    final id = editing!;
    try {
      final stored = isGroup ? t : (await e2ee.encrypt(t, peer) ?? t);
      await sb.from(isGroup ? 'group_messages' : 'messages').update({'text': stored, 'edited_at': DateTime.now().toUtc().toIso8601String()}).eq('id', id);
    } catch (_) {
      if (mounted) snack(context, trn('ویرایش نشد'));
    }
    ctrl.clear();
    if (mounted) setState(() => editing = null);
  }

  Future<void> sendFileMsg(String localPath, String name, String kind, {String text = ''}) async {
    if (!mediaOk) {
      snack(context, trn('ارسال رسانه برای شما محدود شده است'));
      return;
    }
    setState(() => uploading = true);
    try {
      final lp = kind == 'image' ? await compressImagePath(localPath) : localPath; // گیف فشرده نمی‌شود تا متحرک بماند
      final nm = lp != localPath ? 'photo.jpg' : name;
      final f = File(lp);
      if (await f.length() > 25 * 1024 * 1024) throw 'big';
      final data = {'text': text, 'kind': kind, if (replyTo != null) 'reply_to': replyTo!['id']};
      if (isGroup) {
        await outbox.send('group', gid: gid, body: data, file: lp, fileName: nm);
      } else {
        await outbox.send('dm', peer: peer, body: data, file: lp, fileName: nm);
      }
      replyTo = null;
    } catch (e) {
      if (mounted) snack(context, e == 'big' ? trn('حجم فایل بیشتر از ۲۵ مگابایت است') : errText(e));
    }
    if (mounted) setState(() => uploading = false);
  }

  Future<void> pick(FileType t, String kind) async {
    final r = await FilePicker.platform.pickFiles(type: t);
    final f = r?.files.single;
    if (f == null || f.path == null) return;
    await sendFileMsg(f.path!, f.name, kind);
  }

  Future<void> pickMany() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image, allowMultiple: true);
    if (r == null) return;
    for (final f in r.files.take(10)) {
      if (f.path == null) continue;
      await sendFileMsg(f.path!, f.name, 'image');
    }
  }

  void attachMenu() => showAttachSheet(context, [
        AttachGroup('رسانه', [
          AttachOption(Icons.photo_rounded, trn('عکس'), const Color(0xFF3D8BFF), () => pick(FileType.image, 'image')),
          AttachOption(Icons.collections_rounded, trn('چند عکس'), const Color(0xFF8E5CFF), pickMany),
          AttachOption(Icons.hd_rounded, trn('عکس اصلی'), const Color(0xFF00A99D), () => pick(FileType.image, 'file')),
          AttachOption(Icons.videocam_rounded, trn('ویدئو'), const Color(0xFFFF5C7A), () => pick(FileType.video, 'video')),
          AttachOption(Icons.insert_drive_file_rounded, trn('فایل'), const Color(0xFFFF9F2E), () => pick(FileType.any, 'file')),
          AttachOption(Icons.gif_box_rounded, trn('گیف'), const Color(0xFFE056C8), pickGifFile),
        ]),
        AttachGroup('بیشتر', [
          AttachOption(Icons.poll_rounded, trn('نظرسنجی'), const Color(0xFF2BB673), sendPoll),
          AttachOption(Icons.location_on_rounded, trn('موقعیت مکانی'), const Color(0xFFE5483B), sendLocation),
          AttachOption(Icons.person_rounded, trn('ارسال مخاطب'), const Color(0xFF3FB4E8), sendContact),
        ]),
      ]);

  Future<void> startRec() async {
    if (!await rec.hasPermission()) {
      if (mounted) snack(context, trn('اجازه‌ی میکروفون داده نشد'));
      return;
    }
    final dir = await getTemporaryDirectory();
    final wav = ai.wavVoice;
    _recExt = wav ? 'wav' : 'm4a';
    await rec.start(
      wav ? const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1) : const RecordConfig(encoder: AudioEncoder.aacLc),
      path: '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.$_recExt',
    );
    secs = 0;
    _amps.clear();
    _ampSub?.cancel();
    _ampSub = rec.onAmplitudeChanged(const Duration(milliseconds: 100)).listen((a) => _amps.add(a.current));
    timer = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => secs++));
    setState(() => recording = true);
  }

  Future<void> stopRec(bool send) async {
    timer?.cancel();
    _ampSub?.cancel();
    final wave = encodeWave(List<double>.from(_amps));
    final p = await rec.stop();
    setState(() => recording = false);
    if (p == null) return;
    if (send && secs >= 1) await sendFileMsg(p, 'voice.$_recExt', 'audio', text: wave);
    try {
      File(p).deleteSync();
    } catch (_) {}
  }

  Future<void> sendPoll() async {
    try {
      final r = await createPoll(context);
      if (r == null) return;
      await insertMsg({'text': r['q'], 'kind': 'poll', 'file_name': '${r['id']}'});
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  Future<void> pin(Map<String, dynamic> m) async {
    try {
      await sb.from(isGroup ? 'group_messages' : 'messages').update({'pinned_at': m['pinned_at'] == null ? DateTime.now().toUtc().toIso8601String() : null}).eq('id', m['id'] as int);
    } catch (_) {
      if (mounted) snack(context, trn('انجام نشد'));
    }
  }

  Future<void> saveMsg(Map<String, dynamic> m) async {
    try {
      await store.sendRaw(me!, {
        'text': m['text'],
        'kind': kindOf(m),
        'file_path': m['file_path'],
        'file_name': m['file_name'],
        'forwarded_from': m['forwarded_from'] ?? store.name(m['sender_id'] as String),
      });
      if (mounted) snack(context, trn('در پیام‌های ذخیره‌شده ذخیره شد'));
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  Future<void> scheduleCurrent() async {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    await scheduleMessage(context, group: isGroup, target: isGroup ? '$gid' : peer, text: t);
    ctrl.clear();
    if (mounted) setState(() {});
  }

  Future<void> deleteMsg(Map<String, dynamic> m) async {
    if (!await confirm(context, trn('این پیام حذف شود؟'))) return;
    try {
      await sb.from(isGroup ? 'group_messages' : 'messages').delete().eq('id', m['id'] as int);
      if (isGroup) {
        gs.dropMsg(m['id'] as int);
      } else {
        store.dropMsg(m['id'] as int);
      }
    } catch (_) {
      if (mounted) snack(context, trn('حذف نشد'));
    }
  }

  Future<void> forwardMany(List<Map<String, dynamic>> ms) async {
    final dest = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(children: [
          ListTile(title: Text(trn('بازارسال به...'))),
          for (final id in store.contactIds) ListTile(leading: avatarFor(id), title: Text(store.name(id)), onTap: () => Navigator.pop(c, 'u:$id')),
          for (final e in gs.groups.entries)
            if (gs.canSend(e.key, 'text')) ListTile(leading: groupAvatar(e.key), title: Text('${e.value['title']}'), onTap: () => Navigator.pop(c, 'g:${e.key}')),
        ]),
      ),
    );
    if (dest == null) return;
    try {
      for (final m in ms) {
        final body = <String, dynamic>{
          'text': m['text'],
          'kind': kindOf(m),
          'file_path': m['file_path'],
          'file_name': m['file_name'],
          'forwarded_from': m['forwarded_from'] ?? store.name(m['sender_id'] as String),
        };
        if (dest.startsWith('g:')) {
          await gs.sendMsg(int.parse(dest.substring(2)), body);
        } else {
          await store.sendRaw(dest.substring(2), body);
        }
      }
      if (mounted) snack(context, ms.length > 1 ? trf('{0} پیام بازارسال شد', [ms.length]) : trn('بازارسال شد'));
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  Future<void> forward(Map<String, dynamic> m) => forwardMany([m]);

  void useText(String t) {
    setState(() {
      ctrl.text = t;
      ctrl.selection = TextSelection.collapsed(offset: t.length);
    });
  }

  Future<void> translateTyped(String to) async {
    final t = ctrl.text.trim();
    if (t.isEmpty) {
      snack(context, trn('اول متنی در کادر پیام بنویس'));
      return;
    }
    snack(context, trn('در حال ترجمه…'));
    try {
      final r = await translateText(t, to);
      if (!mounted) return;
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
      useText(r);
    } catch (_) {
      if (mounted) snack(context, trn('ترجمه انجام نشد. اینترنت را بررسی کنید؛ ممکن است سرویس ترجمه در شبکه‌ی شما در دسترس نباشد.'));
    }
  }

  Widget smartBar(List<Map<String, dynamic>> all) {
    if (!ai.smartBar || recording || editing != null || !textOk || isSaved) return const SizedBox.shrink();
    if (!isGroup && safety.isBlocked(peer)) return const SizedBox.shrink();
    final last = all.isEmpty ? null : all.last;
    final incoming = (last != null && last['sender_id'] != me && last['pending'] != true) ? last : null;
    return SmartBar(
      last: incoming,
      typed: ctrl.text,
      onPick: useText,
      onTranslateTyped: translateTyped,
      onSummary: () => showChatSummarySheet(context, all, jumpTo),
      onMore: () => showRepliesSheet(context, incoming ?? <String, dynamic>{'kind': 'text', 'text': ''}, useText),
    );
  }

  Future<void> menu(Map<String, dynamic> m) async {
    HapticFeedback.mediumImpact();
    final id = m['id'] as int;
    final key = _keyFor(id);
    final rect = rectOf(key);
    ui.Image? snap;
    if (rect != null) snap = await captureBubble(key, MediaQuery.of(context).devicePixelRatio);
    if (!mounted) return;
    final mine = m['sender_id'] == me;
    final anchor = rect ?? Rect.fromCenter(center: MediaQuery.of(context).size.center(Offset.zero), width: 180, height: 48);
    if (m['pending'] == true) {
      showMsgMenu(context, anchor: anchor, mine: true, snapshot: snap, actions: [
        MenuAction(Icons.delete_outline_rounded, trn('حذف از صف ارسال'), () => outbox.cancel(id), danger: true),
      ]);
      return;
    }
    final kind = kindOf(m);
    final text = kind == 'text' ? ((m['text'] as String?) ?? '') : '';
    final canDel = mine || (isGroup && gs.right(gid, 'delete'));
    final canEdit = mine && kind == 'text' && textOk;
    final acts = <MenuAction>[
      if (textOk)
        MenuAction(Icons.reply_rounded, trn('پاسخ'), () {
          setState(() {
            replyTo = m;
            editing = null;
          });
        }),
      MenuAction(Icons.forward_rounded, trn('بازارسال'), () => forward(m)),
      if (kind == 'text')
        MenuAction(Icons.copy_rounded, trn('کپی'), () {
          Clipboard.setData(ClipboardData(text: text));
          snack(context, trn('کپی شد'));
        }),
      if (canEdit)
        MenuAction(Icons.edit_rounded, trn('ویرایش'), () {
          setState(() {
            editing = id;
            replyTo = null;
            ctrl.text = text;
            ctrl.selection = TextSelection.collapsed(offset: text.length);
          });
        }),
      if (canPin) MenuAction(m['pinned_at'] == null ? Icons.push_pin_outlined : Icons.push_pin_rounded, m['pinned_at'] == null ? trn('سنجاق') : trn('برداشتن سنجاق'), () => pin(m)),
      MenuAction(Icons.checklist_rounded, trn('انتخاب چند پیام'), () => setState(() => selected.add(id))),
      if (kind == 'text' && text.trim().isNotEmpty) MenuAction(Icons.translate_rounded, trn('ترجمه'), () => showTranslateSheet(context, text, onUse: textOk ? useText : null), divider: true),
      if (kind == 'text' && text.trim().length > 60) MenuAction(Icons.auto_awesome_rounded, trn('خلاصه‌کردن پیام'), () => showSummarySheet(context, text)),
      if (!mine && textOk && !isSaved)
        MenuAction(Icons.quickreply_rounded, trn('پیشنهاد پاسخ'), () => showRepliesSheet(context, m, (r) {
              setState(() {
                replyTo = m;
                editing = null;
              });
              useText(r);
            })),
      if (kind == 'audio') MenuAction(Icons.subtitles_outlined, trn('تبدیل ویس به متن'), () => transcribeMsg(m), divider: true),
      if (kind == 'gif') MenuAction(Icons.star_border_rounded, trn('ذخیره در گیف‌های من'), () => saveMessageGif(context, m)),
      if (const ['image', 'video', 'file', 'audio'].contains(kind)) MenuAction(Icons.download_rounded, trn('دانلود / باز کردن'), () => openMedia(m)),
      if (!isSaved) MenuAction(Icons.bookmark_add_outlined, trn('ذخیره در پیام‌های ذخیره‌شده'), () => saveMsg(m)),
      if (!mine) MenuAction(Icons.flag_outlined, trn('گزارش پیام'), () => reportDialog(context, 'message', '$scope:$id')),
      if (canDel) MenuAction(Icons.delete_outline_rounded, trn('حذف'), () => deleteMsg(m), danger: true, divider: true),
    ];
    final myReacts = <String>{
      for (final r in rx.of(scope, id))
        if (r['user_id'] == me) r['emoji'] as String,
    };
    showMsgMenu(
      context,
      anchor: anchor,
      mine: mine,
      snapshot: snap,
      actions: acts,
      mineReactions: myReacts,
      onReact: (e) => rx.toggle(scope, id, e).catchError((_) {}),
    );
  }

  Widget content(Map<String, dynamic> m) {
    if (m['pending'] == true && m['local_path'] != null) return PendingMedia(m);
    final path = m['file_path'] as String?;
    switch (kindOf(m)) {
      case 'image':
        return ImageBubble(path!);
      case 'audio':
        return VoiceBubble(path!, wave: m['text'] as String?);
      case 'file':
        return FileBubble(path!, (m['file_name'] as String?) ?? trn('فایل'));
      case 'poll':
        return PollBubble(int.parse(m['file_name'] as String));
      case 'video':
        return VideoBubble(path!);
      case 'location':
        return LocationBubble(m['text'] as String);
      case 'contact':
        return ContactBubble(m['text'] as String);
      case 'gif':
        return GifBubble(url: m['file_path'] == null ? m['text'] as String : null, path: m['file_path'] as String?);
      case 'sticker':
        return Text(m['text'] as String, style: const TextStyle(fontSize: 64));
      default:
        final t = m['text'] as String;
        final u = firstUrl(t);
        final body = richBody(context, t, link: m['sender_id'] == me ? cOnPrimary : null);
        final live = ((ai.live || cprefs['tr'] == true) && m['sender_id'] != me && m['pending'] != true) ? LiveTranslation(t, key: ValueKey('lt${m['id']}_${ai.liveTo}'), color: bubbleFg(false)) : null;
        if (u == null && live == null) return body;
        return Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [body, if (live != null) live, if (u != null) LinkPreviewCard(u)]);
    }
  }

  Widget bubble(Map<String, dynamic> m) {
    final mine = m['sender_id'] == me;
    final sid = m['sender_id'] as String;
    final rt = byId(m['reply_to'] as int?);
    final fwd = m['forwarded_from'] as String?;
    final read = m['read_at'] != null;
    final fg = bubbleFg(mine);
    final dim = mine ? Color.lerp(primary, cOnPrimary, 0.7)! : cTextFaint;
    final id = m['id'] as int;
    final hl = selected.contains(id) || flash == id;
    return Container(
      color: hl ? Color.lerp(Colors.transparent, primary, 0.22) : null,
      child: Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onTap: selecting ? () => toggleSel(id) : null,
        onLongPress: () => selecting ? toggleSel(id) : menu(m),
        onSecondaryTapUp: (_) => selecting ? toggleSel(id) : menu(m),
        child: RepaintBoundary(
          key: _keyFor(id),
          child: Container(
          margin: const EdgeInsets.symmetric(vertical: 3),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
          decoration: kindOf(m) == 'sticker' ? null : bubbleDeco(mine),
          child: DefaultTextStyle.merge(
            style: TextStyle(color: fg, fontSize: 15 * settings.chatTextScale),
            child: IconTheme(
              data: IconThemeData(color: fg),
              child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
                if (isGroup && !mine)
                  GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(sid))),
                    child: Text(store.name(sid), style: TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 12)),
                  ),
                if (fwd != null) Text(trf('↪ بازارسال‌شده از {0}', [fwd]), style: TextStyle(color: dim, fontSize: 11)),
                if (m['reply_to'] != null)
                  GestureDetector(
                    onTap: rt == null ? null : () => jumpTo(rt['id'] as int),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 4),
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(color: Color.lerp(Colors.transparent, fg, 0.14), border: Border(right: BorderSide(color: dim, width: 3))),
                      child: Text(rt == null ? trn('پیام حذف شده') : snippet(rt), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                    ),
                  ),
                content(m),
                reactionChips(scope, m['id'] as int),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  if (m['pinned_at'] != null) Icon(Icons.push_pin, size: 11, color: dim),
                  Text(hm(m['created_at'] as String), style: TextStyle(color: dim, fontSize: 10)),
                  if (m['edited_at'] != null) Text(trn(' • ویرایش‌شده'), style: TextStyle(color: dim, fontSize: 10)),
                  if (m['pending'] == true) ...[
                    const SizedBox(width: 4),
                    Icon(Icons.schedule, size: 13, color: dim),
                  ] else if (mine && !isGroup && !isSaved) ...[
                    const SizedBox(width: 4),
                    Icon(read ? Icons.done_all : Icons.done, size: 13, color: read ? fg : dim),
                  ],
                ]),
              ]),
            ),
          ),
        ),
        ),
      ),
    ));
  }

  Widget titleWidget() {
    final now = DateTime.now();
    final active = typers.entries.where((e) => now.difference(e.value).inSeconds < 4).map((e) => e.key).toList();
    final Widget name = isSaved ? Text(trn('پیام‌های ذخیره‌شده')) : isGroup ? Text('${gs.groups[gid]!['title']}') : nameWithBadge(peer);
    return InkWell(
      onTap: isSaved ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => isGroup ? GroupInfoPage(gid) as Widget : ChatInfoPage(peer))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        name,
        if (active.isNotEmpty) Text(isGroup ? trf('{0} در حال تایپ...', [store.name(active.first)]) : trn('در حال تایپ...'), style: TextStyle(fontSize: 12, color: accent)),
      ]),
    );
  }

  Widget pinBar(List<Map<String, dynamic>> all) {
    final pins = all.where((m) => m['pinned_at'] != null).toList();
    if (pins.isEmpty) return const SizedBox.shrink();
    pins.sort((a, b) => (b['pinned_at'] as String).compareTo(a['pinned_at'] as String));
    return InkWell(
      onTap: () => showModalBottomSheet(
        context: context,
        builder: (c) => Directionality(
          textDirection: TextDirection.rtl,
          child: ListView(children: [
            ListTile(title: Text(trn('پیام‌های سنجاق‌شده'))),
            for (final m in pins)
              ListTile(
                leading: const Icon(Icons.push_pin),
                title: Text(snippet(m), maxLines: 2, overflow: TextOverflow.ellipsis),
                onTap: () {
                  Navigator.pop(c);
                  menu(m);
                },
              ),
          ]),
        ),
      ),
      child: Container(
        width: double.infinity,
        color: card,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(children: [
          Icon(Icons.push_pin, size: 16, color: accent),
          const SizedBox(width: 8),
          Expanded(child: Text(snippet(pins.first), maxLines: 1, overflow: TextOverflow.ellipsis)),
          if (pins.length > 1) Text('+${pins.length - 1}', style: TextStyle(color: accent)),
        ]),
      ),
    );
  }

  Widget banner() {
    final isEdit = editing != null;
    final r = replyTo;
    if (!isEdit && r == null) return const SizedBox.shrink();
    return Container(
      color: card,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(children: [
        Icon(isEdit ? Icons.edit : Icons.reply, size: 18, color: accent),
        const SizedBox(width: 8),
        Expanded(child: Text(isEdit ? trn('ویرایش پیام') : trf('پاسخ به: {0}', [snippet(r!)]), maxLines: 1, overflow: TextOverflow.ellipsis)),
        IconButton(
          icon: const Icon(Icons.close, size: 18),
          onPressed: () {
            ctrl.clear();
            setState(() {
              editing = null;
              replyTo = null;
            });
          },
        ),
      ]),
    );
  }

  Widget inputBar() {
    if (!isGroup && !isSaved && safety.isBlocked(peer)) {
      return Padding(
        padding: const EdgeInsets.all(8),
        child: Row(children: [
          const Icon(Icons.block, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(trn('شما این کاربر را مسدود کرده‌اید'))),
          TextButton(onPressed: () => safety.unblock(peer).catchError((_) {}), child: Text(trn('رفع مسدودی'))),
        ]),
      );
    }
    if (!textOk) {
      final ch = isGroup && gs.groups[gid]?['kind'] == 'channel';
      return Padding(
        padding: const EdgeInsets.all(12),
        child: Center(child: Text(ch ? trn('فقط مدیران می‌توانند پست بگذارند') : trn('ارسال پیام برای شما بسته است'), style: TextStyle(color: cTextFaint))),
      );
    }
    if (recording) {
      return Row(children: [
        IconButton(icon: const Icon(Icons.delete, color: Colors.redAccent), onPressed: () => stopRec(false)),
        const Icon(Icons.fiber_manual_record, color: Colors.redAccent, size: 14),
        const SizedBox(width: 6),
        Text('${secs ~/ 60}:${(secs % 60).toString().padLeft(2, '0')}'),
        const Spacer(),
        IconButton.filled(icon: const Icon(Icons.send), onPressed: () => stopRec(true)),
      ]);
    }
    final empty = ctrl.text.trim().isEmpty;
    return Row(children: [
      IconButton(
        icon: Icon(showEmoji ? Icons.keyboard : Icons.emoji_emotions_outlined),
        onPressed: () {
          FocusManager.instance.primaryFocus?.unfocus();
          setState(() => showEmoji = !showEmoji);
        },
      ),
      if (mediaOk && editing == null) IconButton(icon: const Icon(Icons.attach_file), onPressed: attachMenu),
      Expanded(
        child: TextField(
          controller: ctrl,
          onTap: () => setState(() => showEmoji = false),
          onChanged: (_) {
            typing();
            setState(() {});
          },
          onSubmitted: (_) => sendText(),
          decoration: fieldDeco(hintText: trn('پیام بنویسید...'), radius: 26),
        ),
      ),
      if (!empty && editing == null) IconButton(icon: const Icon(Icons.schedule), tooltip: trn('ارسال در زمان دلخواه'), onPressed: scheduleCurrent),
      empty && mediaOk && editing == null
          ? IconButton.filledTonal(icon: const Icon(Icons.mic_rounded), style: IconButton.styleFrom(minimumSize: const Size(48, 48)), onPressed: startRec)
          : IconButton.filled(icon: const Icon(Icons.send_rounded), style: IconButton.styleFrom(backgroundColor: primary, foregroundColor: cOnPrimary, minimumSize: const Size(48, 48)), onPressed: sendText),
    ]);
  }

  Future<void> transcribeMsg(Map<String, dynamic> m) async {
    try {
      await aiTranscribe(context, m['file_path'] as String);
    } catch (e) {
      if (mounted) snack(context, aiErr(e));
    }
  }

  @override
  Widget build(BuildContext context) => CyberEntry(child: _chatBody(context));

  Widget _chatBody(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([store, gs, rx, safety, ai]),
        builder: (context, _) {
          if (isGroup && gs.groups[gid] == null) {
            return Scaffold(appBar: AppBar(), body: Center(child: Text(trn('این گفتگو در دسترس نیست'))));
          }
          final all = msgs;
          final list = (q.isEmpty ? all : all.where((m) => searchText(m).toLowerCase().contains(q) || ((m['file_name'] as String?) ?? '').toLowerCase().contains(q)).toList()).reversed.toList();
          _lastList = list;
          if (isGroup && gs.unread(gid) > 0) {
            WidgetsBinding.instance.addPostFrameCallback((_) => gs.markRead(gid));
          }
          if (!isGroup && store.msgs.any((m) => m['sender_id'] == peer && m['receiver_id'] == me && m['read_at'] == null)) {
            WidgetsBinding.instance.addPostFrameCallback((_) => store.markRead(peer));
          }
          return Scaffold(
            appBar: AppBar(
              leading: selecting ? IconButton(icon: const Icon(Icons.close), onPressed: () => setState(selected.clear)) : null,
              title: selecting
                  ? Text(trf('{0} پیام انتخاب شد', [selected.length]))
                  : searching
                  ? TextField(
                      autofocus: true,
                      onChanged: (v) => setState(() => q = v.trim().toLowerCase()),
                      decoration: fieldDeco(hintText: trn('جستجو در گفتگو...'), plain: true),
                    )
                  : titleWidget(),
              actions: selecting ? selActions() : [
                IconButton(
                  icon: Icon(searching ? Icons.close : Icons.search),
                  onPressed: () => setState(() {
                    searching = !searching;
                    q = '';
                  }),
                ),
                if (!isSaved)
                  PopupMenuButton<String>(
                    onSelected: (v) {
                      if (v == 'sched') {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => ScheduledPage(group: isGroup, target: isGroup ? '$gid' : peer)));
                      } else if (v == 'ttl') {
                        chooseTtl();
                      } else if (v == 'wall') {
                        ChatPrefs.pickWall(context, cprefs, saveCprefs);
                      } else if (v == 'ctr') {
                        cprefs['tr'] = cprefs['tr'] != true;
                        if (cprefs['tr'] != true) cprefs.remove('tr');
                        saveCprefs();
                      } else {
                        chatActions(context, scope, isGroup ? '$gid' : peer);
                      }
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 'sched', child: Text(trn('پیام‌های زمان‌بندی‌شده'))),
                      PopupMenuItem(value: 'ttl', child: Text(trn('پیام‌های خودحذف‌شونده'))),
                      PopupMenuItem(value: 'wall', child: Text(trn('پس‌زمینه‌ی این گفتگو'))),
                      PopupMenuItem(value: 'ctr', child: Text(cprefs['tr'] == true ? trn('خاموش‌کردن ترجمه‌ی خودکار این گفتگو') : trn('ترجمه‌ی خودکار این گفتگو'))),
                      PopupMenuItem(value: 'more', child: Text(trn('تنظیمات گفتگو (بی‌صدا، حذف، مسدود…)'))),
                    ],
                  ),
              ],
            ),
            body: Container(
              decoration: ChatPrefs.wallOf(cprefs) ?? wallDecoration(),
              child: Column(children: [
                pinBar(all),
                if (ttl > 0)
                  Container(
                    width: double.infinity,
                    color: card,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Text(trf('⏱ پیام‌ها پس از {0} پاک می‌شوند', [ttlLabel(ttl)]), style: TextStyle(color: accent, fontSize: 12)),
                  ),
                Expanded(
                  child: ScrollablePositionedList.builder(
                    itemScrollController: itemScroll,
                    reverse: true,
                    padding: const EdgeInsets.all(12),
                    itemCount: list.length + (isGroup || isSaved ? 0 : 1),
                    itemBuilder: (c, n) => n == list.length ? E2eePill(peer) : bubble(list[n]),
                  ),
                ),
                mentionBar(),
                banner(),
                smartBar(all),
                SafeArea(child: Padding(padding: const EdgeInsets.all(8), child: inputBar())),
                if (showEmoji && !recording) SizedBox(height: 280, child: EmojiPanel(onEmoji: insertEmoji, onSticker: sendSticker, onGif: sendGif, onPickGifFile: pickGifFile)),
              ]),
            ),
          );
        },
      );
}


