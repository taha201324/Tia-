import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'groups.dart';
import 'main.dart';
import 'social.dart';

final _linkRe = RegExp(r'(https?://|www\.|t\.me/|[a-z0-9-]+\.(com|ir|org|net|me|io)\b)', caseSensitive: false);
bool hasLink(String t) => _linkRe.hasMatch(t);
String errText(Object e) => e is PostgrestException ? e.message : 'ارسال نشد. اینترنت را بررسی کنید.';
String snippet(Map<String, dynamic> m) => kindOf(m) == 'text' ? (m['text'] as String) : preview(m);

Future<void> openChat(BuildContext c, String id) => Navigator.push(c, MaterialPageRoute(builder: (_) => ChatPage(peer: id)));

class ChatPage extends StatefulWidget {
  final String? peer;
  final int? gid;
  const ChatPage({super.key, this.peer, this.gid});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctrl = TextEditingController();
  final rec = AudioRecorder();
  bool recording = false, uploading = false;
  int secs = 0;
  Timer? timer;
  Map<String, dynamic>? replyTo;
  int? editing;

  bool get isGroup => widget.gid != null;
  int get gid => widget.gid!;
  String get peer => widget.peer!;
  List<Map<String, dynamic>> get msgs => isGroup ? gs.msgsOf(gid) : store.msgsWith(peer);
  bool get textOk => !isGroup || gs.canSend(gid, 'text');
  bool get mediaOk => !isGroup || gs.canSend(gid, 'media');

  @override
  void dispose() {
    timer?.cancel();
    rec.dispose();
    ctrl.dispose();
    super.dispose();
  }

  Map<String, dynamic>? byId(int? id) {
    if (id == null) return null;
    for (final m in msgs) {
      if (m['id'] == id) return m;
    }
    return null;
  }

  Future<void> insertMsg(Map<String, dynamic> body) async {
    final data = {...body, if (replyTo != null) 'reply_to': replyTo!['id']};
    if (isGroup) {
      await gs.sendMsg(gid, data);
    } else {
      await store.sendRaw(peer, data);
    }
  }

  Future<void> sendText() async {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    if (editing != null) {
      await doEdit(t);
      return;
    }
    if (isGroup && hasLink(t) && !gs.canSend(gid, 'link')) {
      snack(context, 'ارسال لینک در این گروه مجاز نیست');
      return;
    }
    ctrl.clear();
    setState(() {});
    try {
      await insertMsg({'text': t, 'kind': 'text'});
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
    if (mounted) setState(() => replyTo = null);
  }

  Future<void> doEdit(String t) async {
    final id = editing!;
    try {
      await sb.from(isGroup ? 'group_messages' : 'messages').update({'text': t, 'edited_at': DateTime.now().toUtc().toIso8601String()}).eq('id', id);
    } catch (_) {
      if (mounted) snack(context, 'ویرایش نشد');
    }
    ctrl.clear();
    if (mounted) setState(() => editing = null);
  }

  Future<void> sendFileMsg(String localPath, String name, String kind) async {
    if (!mediaOk) {
      snack(context, 'ارسال رسانه برای شما محدود شده است');
      return;
    }
    setState(() => uploading = true);
    try {
      final f = File(localPath);
      if (await f.length() > 25 * 1024 * 1024) throw 'big';
      final path = '${me!}/${DateTime.now().millisecondsSinceEpoch}${extOf(name)}';
      await sb.storage.from('chat-files').upload(path, f, fileOptions: FileOptions(contentType: mimeOf(name)));
      await insertMsg({'text': '', 'kind': kind, 'file_path': path, 'file_name': name});
      replyTo = null;
    } catch (e) {
      if (mounted) snack(context, e == 'big' ? 'حجم فایل بیشتر از ۲۵ مگابایت است' : errText(e));
    }
    if (mounted) setState(() => uploading = false);
  }

  Future<void> pick(FileType t, String kind) async {
    final r = await FilePicker.platform.pickFiles(type: t);
    final f = r?.files.single;
    if (f == null || f.path == null) return;
    await sendFileMsg(f.path!, f.name, kind);
  }

  void attachMenu() => showModalBottomSheet(
        context: context,
        builder: (c) => Directionality(
          textDirection: TextDirection.rtl,
          child: Wrap(children: [
            ListTile(
              leading: const Icon(Icons.image),
              title: const Text('عکس'),
              onTap: () {
                Navigator.pop(c);
                pick(FileType.image, 'image');
              },
            ),
            ListTile(
              leading: const Icon(Icons.insert_drive_file),
              title: const Text('فایل'),
              onTap: () {
                Navigator.pop(c);
                pick(FileType.any, 'file');
              },
            ),
          ]),
        ),
      );

  Future<void> startRec() async {
    if (!await rec.hasPermission()) {
      if (mounted) snack(context, 'اجازه‌ی میکروفون داده نشد');
      return;
    }
    final dir = await getTemporaryDirectory();
    await rec.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a');
    secs = 0;
    timer = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => secs++));
    setState(() => recording = true);
  }

  Future<void> stopRec(bool send) async {
    timer?.cancel();
    final p = await rec.stop();
    setState(() => recording = false);
    if (p == null) return;
    if (send && secs >= 1) await sendFileMsg(p, 'voice.m4a', 'audio');
    try {
      File(p).deleteSync();
    } catch (_) {}
  }

  Future<void> deleteMsg(Map<String, dynamic> m) async {
    if (!await confirm(context, 'این پیام حذف شود؟')) return;
    try {
      await sb.from(isGroup ? 'group_messages' : 'messages').delete().eq('id', m['id'] as int);
      if (isGroup) {
        gs.dropMsg(m['id'] as int);
      } else {
        store.dropMsg(m['id'] as int);
      }
    } catch (_) {
      if (mounted) snack(context, 'حذف نشد');
    }
  }

  Future<void> forward(Map<String, dynamic> m) async {
    final dest = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(children: [
          const ListTile(title: Text('بازارسال به...')),
          for (final id in store.contactIds) ListTile(leading: avatarFor(id), title: Text(store.name(id)), onTap: () => Navigator.pop(c, 'u:$id')),
          for (final e in gs.groups.entries)
            if (gs.canSend(e.key, 'text')) ListTile(leading: groupAvatar(e.key), title: Text('${e.value['title']}'), onTap: () => Navigator.pop(c, 'g:${e.key}')),
        ]),
      ),
    );
    if (dest == null) return;
    final body = <String, dynamic>{
      'text': m['text'],
      'kind': kindOf(m),
      'file_path': m['file_path'],
      'file_name': m['file_name'],
      'forwarded_from': m['forwarded_from'] ?? store.name(m['sender_id'] as String),
    };
    try {
      if (dest.startsWith('g:')) {
        await gs.sendMsg(int.parse(dest.substring(2)), body);
      } else {
        await store.sendRaw(dest.substring(2), body);
      }
      if (mounted) snack(context, 'بازارسال شد');
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  void menu(Map<String, dynamic> m) {
    final mine = m['sender_id'] == me;
    final kind = kindOf(m);
    final canDel = mine || (isGroup && gs.right(gid, 'delete'));
    final canEdit = mine && kind == 'text' && textOk;
    Widget item(IconData i, String t, VoidCallback f, {Color? color}) => ListTile(
          leading: Icon(i, color: color),
          title: Text(t),
          onTap: () {
            Navigator.pop(context);
            f();
          },
        );
    showModalBottomSheet(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: Wrap(children: [
          if (textOk)
            item(Icons.reply, 'پاسخ', () {
              setState(() {
                replyTo = m;
                editing = null;
              });
            }),
          if (kind == 'text')
            item(Icons.copy, 'کپی', () {
              Clipboard.setData(ClipboardData(text: m['text'] as String));
              snack(context, 'کپی شد');
            }),
          item(Icons.forward, 'بازارسال', () => forward(m)),
          if (canEdit)
            item(Icons.edit, 'ویرایش', () {
              setState(() {
                editing = m['id'] as int;
                replyTo = null;
                ctrl.text = m['text'] as String;
              });
            }),
          if (canDel) item(Icons.delete_outline, 'حذف', () => deleteMsg(m), color: Colors.redAccent),
        ]),
      ),
    );
  }

  Widget content(Map<String, dynamic> m) {
    final path = m['file_path'] as String?;
    switch (kindOf(m)) {
      case 'image':
        return ImageBubble(path!);
      case 'audio':
        return VoiceBubble(path!);
      case 'file':
        return FileBubble(path!, (m['file_name'] as String?) ?? 'فایل');
      default:
        return richBody(context, m['text'] as String);
    }
  }

  Widget bubble(Map<String, dynamic> m) {
    final mine = m['sender_id'] == me;
    final sid = m['sender_id'] as String;
    final rt = byId(m['reply_to'] as int?);
    final fwd = m['forwarded_from'] as String?;
    final read = m['read_at'] != null;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => menu(m),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
          decoration: BoxDecoration(color: mine ? primary : card, borderRadius: BorderRadius.circular(14)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
            if (isGroup && !mine)
              GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(sid))),
                child: Text(store.name(sid), style: TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 12)),
              ),
            if (fwd != null) Text('↪ بازارسال‌شده از $fwd', style: TextStyle(color: accent, fontSize: 11)),
            if (m['reply_to'] != null)
              Container(
                margin: const EdgeInsets.only(bottom: 4),
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: Colors.black26, border: Border(right: BorderSide(color: accent, width: 3))),
                child: Text(rt == null ? 'پیام حذف شده' : snippet(rt), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.white70)),
              ),
            content(m),
            Row(mainAxisSize: MainAxisSize.min, children: [
              Text(hm(m['created_at'] as String), style: TextStyle(color: accent, fontSize: 10)),
              if (m['edited_at'] != null) Text(' • ویرایش‌شده', style: TextStyle(color: accent, fontSize: 10)),
              if (mine && !isGroup) ...[
                const SizedBox(width: 4),
                Icon(read ? Icons.done_all : Icons.done, size: 13, color: read ? accent : Colors.white54),
              ],
            ]),
          ]),
        ),
      ),
    );
  }

  Widget banner() {
    final isEdit = editing != null;
    final r = replyTo;
    if (!isEdit && r == null) return const SizedBox.shrink();
    return Container(
      color: card,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(children: [
        Icon(isEdit ? Icons.edit : Icons.reply, size: 18, color: accent),
        const SizedBox(width: 8),
        Expanded(child: Text(isEdit ? 'ویرایش پیام' : 'پاسخ به: ${snippet(r!)}', maxLines: 1, overflow: TextOverflow.ellipsis)),
        IconButton(
          icon: const Icon(Icons.close, size: 18),
          onPressed: () {
            ctrl.clear();
            setState(() {
              editing = null;
              replyTo = null;
            });
          },
        ),
      ]),
    );
  }

  Widget inputBar() {
    if (!textOk) {
      final ch = isGroup && gs.groups[gid]?['kind'] == 'channel';
      return Padding(
        padding: const EdgeInsets.all(12),
        child: Center(child: Text(ch ? 'فقط مدیران می‌توانند پست بگذارند' : 'ارسال پیام برای شما بسته است', style: const TextStyle(color: Colors.white54))),
      );
    }
    if (recording) {
      return Row(children: [
        IconButton(icon: const Icon(Icons.delete, color: Colors.redAccent), onPressed: () => stopRec(false)),
        const Icon(Icons.fiber_manual_record, color: Colors.redAccent, size: 14),
        const SizedBox(width: 6),
        Text('${secs ~/ 60}:${(secs % 60).toString().padLeft(2, '0')}'),
        const Spacer(),
        IconButton(icon: Icon(Icons.send, color: primary), onPressed: () => stopRec(true)),
      ]);
    }
    final empty = ctrl.text.trim().isEmpty;
    return Row(children: [
      if (mediaOk && editing == null) IconButton(icon: const Icon(Icons.attach_file), onPressed: attachMenu),
      Expanded(
        child: TextField(
          controller: ctrl,
          onChanged: (_) => setState(() {}),
          onSubmitted: (_) => sendText(),
          decoration: const InputDecoration(hintText: 'پیام بنویسید...', border: OutlineInputBorder()),
        ),
      ),
      empty && mediaOk && editing == null
          ? IconButton(icon: Icon(Icons.mic, color: primary), onPressed: startRec)
          : IconButton(icon: Icon(Icons.send, color: primary), onPressed: sendText),
    ]);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([store, gs]),
        builder: (context, _) {
          if (isGroup && gs.groups[gid] == null) {
            return Scaffold(appBar: AppBar(), body: const Center(child: Text('این گفتگو در دسترس نیست')));
          }
          final list = msgs.reversed.toList();
          if (!isGroup && store.msgs.any((m) => m['sender_id'] == peer && m['receiver_id'] == me && m['read_at'] == null)) {
            WidgetsBinding.instance.addPostFrameCallback((_) => store.markRead(peer));
          }
          return Scaffold(
            appBar: AppBar(
              title: InkWell(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => isGroup ? GroupInfoPage(gid) as Widget : ChatInfoPage(peer))),
                child: isGroup ? Text('${gs.groups[gid]!['title']}') : nameWithBadge(peer),
              ),
            ),
            body: Container(
              decoration: wallDecoration(),
              child: Column(children: [
                Expanded(
                  child: ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.all(12),
                    itemCount: list.length,
                    itemBuilder: (c, n) => bubble(list[n]),
                  ),
                ),
                if (uploading) const LinearProgressIndicator(),
                banner(),
                SafeArea(child: Padding(padding: const EdgeInsets.all(8), child: inputBar())),
              ]),
            ),
          );
        },
      );
}
