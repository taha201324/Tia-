import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'extras.dart';
import 'groups.dart';
import 'main.dart';
import 'social.dart';

final _linkRe = RegExp(r'(https?://|www\.|t\.me/|[a-z0-9-]+\.(com|ir|org|net|me|io)\b)', caseSensitive: false);
bool hasLink(String t) => _linkRe.hasMatch(t);
String errText(Object e) => e is PostgrestException ? e.message : 'ارسال نشد. اینترنت را بررسی کنید.';
String snippet(Map<String, dynamic> m) => kindOf(m) == 'text' ? (m['text'] as String) : preview(m);

Future<void> openChat(BuildContext c, String id) => Navigator.push(c, MaterialPageRoute(builder: (_) => ChatPage(peer: id)));

class ChatPage extends StatefulWidget {
  final String? peer;
  final int? gid;
  const ChatPage({super.key, this.peer, this.gid});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctrl = TextEditingController();
  final rec = AudioRecorder();
  bool recording = false, uploading = false;
  int secs = 0;
  Timer? timer;
  Map<String, dynamic>? replyTo;
  int? editing;
  RealtimeChannel? _ch;
  final typers = <String, DateTime>{};
  DateTime _lastTyping = DateTime(2000);
  bool searching = false;
  String q = '';

  bool get isGroup => widget.gid != null;
  int get gid => widget.gid!;
  String get peer => widget.peer!;
  List<Map<String, dynamic>> get msgs => isGroup ? gs.msgsOf(gid) : store.msgsWith(peer);
  bool get textOk => !isGroup || gs.canSend(gid, 'text');
  bool get mediaOk => !isGroup || gs.canSend(gid, 'media');
  bool get isSaved => !isGroup && peer == me;
  String get scope => isGroup ? 'g' : 'd';
  bool get canPin => !isGroup || gs.right(gid, 'info');

  @override
  void initState() {
    super.initState();
    if (!isSaved) {
      final room = isGroup ? 'g$gid' : ([me!, peer]..sort()).join('_');
      _ch = sb.channel('typing:$room')
        ..onBroadcast(
          event: 'typing',
          callback: (p) {
            final u = (p['user'] ?? (p['payload'] as Map?)?['user']) as String?;
            if (u != null && u != me) {
              typers[u] = DateTime.now();
              if (mounted) setState(() {});
              Timer(const Duration(seconds: 4), () {
                if (mounted) setState(() {});
              });
            }
          },
        )
        ..subscribe();
    }
  }

  void typing() {
    final now = DateTime.now();
    if (_ch != null && now.difference(_lastTyping).inSeconds >= 2) {
      _lastTyping = now;
      try {
        _ch!.sendBroadcastMessage(event: 'typing', payload: {'user': me});
      } catch (_) {}
    }
  }

  @override
  void dispose() {
    timer?.cancel();
    rec.dispose();
    ctrl.dispose();
    if (_ch != null) sb.removeChannel(_ch!);
    super.dispose();
  }

  Map<String, dynamic>? byId(int? id) {
    if (id == null) return null;
    for (final m in msgs) {
      if (m['id'] == id) return m;
    }
    return null;
  }

  Future<void> insertMsg(Map<String, dynamic> body) async {
    final data = {...body, if (replyTo != null) 'reply_to': replyTo!['id']};
    if (isGroup) {
      await gs.sendMsg(gid, data);
    } else {
      await store.sendRaw(peer, data);
    }
  }

  Future<void> sendText() async {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    if (editing != null) {
      await doEdit(t);
      return;
    }
    if (isGroup && hasLink(t) && !gs.canSend(gid, 'link')) {
      snack(context, 'ارسال لینک در این گروه مجاز نیست');
      return;
    }
    ctrl.clear();
    setState(() {});
    try {
      await insertMsg({'text': t, 'kind': 'text'});
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
    if (mounted) setState(() => replyTo = null);
  }

  Future<void> doEdit(String t) async {
    final id = editing!;
    try {
      await sb.from(isGroup ? 'group_messages' : 'messages').update({'text': t, 'edited_at': DateTime.now().toUtc().toIso8601String()}).eq('id', id);
    } catch (_) {
      if (mounted) snack(context, 'ویرایش نشد');
    }
    ctrl.clear();
    if (mounted) setState(() => editing = null);
  }

  Future<void> sendFileMsg(String localPath, String name, String kind) async {
    if (!mediaOk) {
      snack(context, 'ارسال رسانه برای شما محدود شده است');
      return;
    }
    setState(() => uploading = true);
    try {
      final f = File(localPath);
      if (await f.length() > 25 * 1024 * 1024) throw 'big';
      final path = '${me!}/${DateTime.now().millisecondsSinceEpoch}${extOf(name)}';
      await sb.storage.from('chat-files').upload(path, f, fileOptions: FileOptions(contentType: mimeOf(name)));
      await insertMsg({'text': '', 'kind': kind, 'file_path': path, 'file_name': name});
      replyTo = null;
    } catch (e) {
      if (mounted) snack(context, e == 'big' ? 'حجم فایل بیشتر از ۲۵ مگابایت است' : errText(e));
    }
    if (mounted) setState(() => uploading = false);
  }

  Future<void> pick(FileType t, String kind) async {
    final r = await FilePicker.platform.pickFiles(type: t);
    final f = r?.files.single;
    if (f == null || f.path == null) return;
    await sendFileMsg(f.path!, f.name, kind);
  }

  void attachMenu() => showModalBottomSheet(
        context: context,
        builder: (c) => Directionality(
          textDirection: TextDirection.rtl,
          child: Wrap(children: [
            ListTile(
              leading: const Icon(Icons.image),
              title: const Text('عکس'),
              onTap: () {
                Navigator.pop(c);
                pick(FileType.image, 'image');
              },
            ),
            ListTile(
              leading: const Icon(Icons.insert_drive_file),
              title: const Text('فایل'),
              onTap: () {
                Navigator.pop(c);
                pick(FileType.any, 'file');
              },
            ),
            ListTile(
              leading: const Icon(Icons.poll),
              title: const Text('نظرسنجی'),
              onTap: () {
                Navigator.pop(c);
                sendPoll();
              },
            ),
          ]),
        ),
      );

  Future<void> startRec() async {
    if (!await rec.hasPermission()) {
      if (mounted) snack(context, 'اجازه‌ی میکروفون داده نشد');
      return;
    }
    final dir = await getTemporaryDirectory();
    await rec.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a');
    secs = 0;
    timer = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => secs++));
    setState(() => recording = true);
  }

  Future<void> stopRec(bool send) async {
    timer?.cancel();
    final p = await rec.stop();
    setState(() => recording = false);
    if (p == null) return;
    if (send && secs >= 1) await sendFileMsg(p, 'voice.m4a', 'audio');
    try {
      File(p).deleteSync();
    } catch (_) {}
  }

  Future<void> sendPoll() async {
    try {
      final r = await createPoll(context);
      if (r == null) return;
      await insertMsg({'text': r['q'], 'kind': 'poll', 'file_name': '${r['id']}'});
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  Future<void> pin(Map<String, dynamic> m) async {
    try {
      await sb.from(isGroup ? 'group_messages' : 'messages').update({'pinned_at': m['pinned_at'] == null ? DateTime.now().toUtc().toIso8601String() : null}).eq('id', m['id'] as int);
    } catch (_) {
      if (mounted) snack(context, 'انجام نشد');
    }
  }

  Future<void> saveMsg(Map<String, dynamic> m) async {
    try {
      await store.sendRaw(me!, {
        'text': m['text'],
        'kind': kindOf(m),
        'file_path': m['file_path'],
        'file_name': m['file_name'],
        'forwarded_from': m['forwarded_from'] ?? store.name(m['sender_id'] as String),
      });
      if (mounted) snack(context, 'در پیام‌های ذخیره‌شده ذخیره شد');
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  Future<void> scheduleCurrent() async {
    final t = ctrl.text.trim();
    if (t.isEmpty) return;
    await scheduleMessage(context, group: isGroup, target: isGroup ? '$gid' : peer, text: t);
    ctrl.clear();
    if (mounted) setState(() {});
  }

  Future<void> deleteMsg(Map<String, dynamic> m) async {
    if (!await confirm(context, 'این پیام حذف شود؟')) return;
    try {
      await sb.from(isGroup ? 'group_messages' : 'messages').delete().eq('id', m['id'] as int);
      if (isGroup) {
        gs.dropMsg(m['id'] as int);
      } else {
        store.dropMsg(m['id'] as int);
      }
    } catch (_) {
      if (mounted) snack(context, 'حذف نشد');
    }
  }

  Future<void> forward(Map<String, dynamic> m) async {
    final dest = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(children: [
          const ListTile(title: Text('بازارسال به...')),
          for (final id in store.contactIds) ListTile(leading: avatarFor(id), title: Text(store.name(id)), onTap: () => Navigator.pop(c, 'u:$id')),
          for (final e in gs.groups.entries)
            if (gs.canSend(e.key, 'text')) ListTile(leading: groupAvatar(e.key), title: Text('${e.value['title']}'), onTap: () => Navigator.pop(c, 'g:${e.key}')),
        ]),
      ),
    );
    if (dest == null) return;
    final body = <String, dynamic>{
      'text': m['text'],
      'kind': kindOf(m),
      'file_path': m['file_path'],
      'file_name': m['file_name'],
      'forwarded_from': m['forwarded_from'] ?? store.name(m['sender_id'] as String),
    };
    try {
      if (dest.startsWith('g:')) {
        await gs.sendMsg(int.parse(dest.substring(2)), body);
      } else {
        await store.sendRaw(dest.substring(2), body);
      }
      if (mounted) snack(context, 'بازارسال شد');
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  void menu(Map<String, dynamic> m) {
    final mine = m['sender_id'] == me;
    final kind = kindOf(m);
    final canDel = mine || (isGroup && gs.right(gid, 'delete'));
    final canEdit = mine && kind == 'text' && textOk;
    Widget item(IconData i, String t, VoidCallback f, {Color? color}) => ListTile(
          leading: Icon(i, color: color),
          title: Text(t),
          onTap: () {
            Navigator.pop(context);
            f();
          },
        );
    showModalBottomSheet(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(
                padding: const EdgeInsets.all(10),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  for (final e in ['❤️', '😂', '👍', '😮', '😢', '🙏'])
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                        rx.toggle(scope, m['id'] as int, e).catchError((_) {});
                      },
                      child: Text(e, style: const TextStyle(fontSize: 28)),
                    ),
                ]),
              ),
              if (textOk)
                item(Icons.reply, 'پاسخ', () {
                  setState(() {
                    replyTo = m;
                    editing = null;
                  });
                }),
              if (kind == 'text')
                item(Icons.copy, 'کپی', () {
                  Clipboard.setData(ClipboardData(text: m['text'] as String));
                  snack(context, 'کپی شد');
                }),
              item(Icons.forward, 'بازارسال', () => forward(m)),
              if (!isSaved) item(Icons.bookmark_add_outlined, 'ذخیره در پیام‌های ذخیره‌شده', () => saveMsg(m)),
              if (canPin) item(m['pinned_at'] == null ? Icons.push_pin_outlined : Icons.push_pin, m['pinned_at'] == null ? 'سنجاق' : 'برداشتن سنجاق', () => pin(m)),
              if (canEdit)
                item(Icons.edit, 'ویرایش', () {
                  setState(() {
                    editing = m['id'] as int;
                    replyTo = null;
                    ctrl.text = m['text'] as String;
                  });
                }),
              if (canDel) item(Icons.delete_outline, 'حذف', () => deleteMsg(m), color: Colors.redAccent),
            ]),
          ),
        ),
      ),
    );
  }

  Widget content(Map<String, dynamic> m) {
    final path = m['file_path'] as String?;
    switch (kindOf(m)) {
      case 'image':
        return ImageBubble(path!);
      case 'audio':
        return VoiceBubble(path!);
      case 'file':
        return FileBubble(path!, (m['file_name'] as String?) ?? 'فایل');
      case 'poll':
        return PollBubble(int.parse(m['file_name'] as String));
      default:
        return richBody(context, m['text'] as String, link: m['sender_id'] == me ? cOnPrimary : null);
    }
  }

  Widget bubble(Map<String, dynamic> m) {
    final mine = m['sender_id'] == me;
    final sid = m['sender_id'] as String;
    final rt = byId(m['reply_to'] as int?);
    final fwd = m['forwarded_from'] as String?;
    final read = m['read_at'] != null;
    final fg = bubbleFg(mine);
    final dim = mine ? Color.lerp(primary, cOnPrimary, 0.7)! : cTextFaint;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => menu(m),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 3),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
          decoration: bubbleDeco(mine),
          child: DefaultTextStyle.merge(
            style: TextStyle(color: fg, fontSize: 15 * settings.chatTextScale),
            child: IconTheme(
              data: IconThemeData(color: fg),
              child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
                if (isGroup && !mine)
                  GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(sid))),
                    child: Text(store.name(sid), style: TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 12)),
                  ),
                if (fwd != null) Text('↪ بازارسال‌شده از $fwd', style: TextStyle(color: dim, fontSize: 11)),
                if (m['reply_to'] != null)
                  Container(
                    margin: const EdgeInsets.only(bottom: 4),
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(color: Color.lerp(Colors.transparent, fg, 0.14), border: Border(right: BorderSide(color: dim, width: 3))),
                    child: Text(rt == null ? 'پیام حذف شده' : snippet(rt), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                  ),
                content(m),
                reactionChips(scope, m['id'] as int),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  if (m['pinned_at'] != null) Icon(Icons.push_pin, size: 11, color: dim),
                  Text(hm(m['created_at'] as String), style: TextStyle(color: dim, fontSize: 10)),
                  if (m['edited_at'] != null) Text(' • ویرایش‌شده', style: TextStyle(color: dim, fontSize: 10)),
                  if (mine && !isGroup && !isSaved) ...[
                    const SizedBox(width: 4),
                    Icon(read ? Icons.done_all : Icons.done, size: 13, color: read ? fg : dim),
                  ],
                ]),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget titleWidget() {
    final now = DateTime.now();
    final active = typers.entries.where((e) => now.difference(e.value).inSeconds < 4).map((e) => e.key).toList();
    final Widget name = isSaved ? const Text('پیام‌های ذخیره‌شده') : isGroup ? Text('${gs.groups[gid]!['title']}') : nameWithBadge(peer);
    return InkWell(
      onTap: isSaved ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => isGroup ? GroupInfoPage(gid) as Widget : ChatInfoPage(peer))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        name,
        if (active.isNotEmpty) Text(isGroup ? '${store.name(active.first)} در حال تایپ...' : 'در حال تایپ...', style: TextStyle(fontSize: 12, color: accent)),
      ]),
    );
  }

  Widget pinBar(List<Map<String, dynamic>> all) {
    final pins = all.where((m) => m['pinned_at'] != null).toList();
    if (pins.isEmpty) return const SizedBox.shrink();
    pins.sort((a, b) => (b['pinned_at'] as String).compareTo(a['pinned_at'] as String));
    return InkWell(
      onTap: () => showModalBottomSheet(
        context: context,
        builder: (c) => Directionality(
          textDirection: TextDirection.rtl,
          child: ListView(children: [
            const ListTile(title: Text('پیام‌های سنجاق‌شده')),
            for (final m in pins)
              ListTile(
                leading: const Icon(Icons.push_pin),
                title: Text(snippet(m), maxLines: 2, overflow: TextOverflow.ellipsis),
                onTap: () {
                  Navigator.pop(c);
                  menu(m);
                },
              ),
          ]),
        ),
      ),
      child: Container(
        width: double.infinity,
        color: card,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(children: [
          Icon(Icons.push_pin, size: 16, color: accent),
          const SizedBox(width: 8),
          Expanded(child: Text(snippet(pins.first), maxLines: 1, overflow: TextOverflow.ellipsis)),
          if (pins.length > 1) Text('+${pins.length - 1}', style: TextStyle(color: accent)),
        ]),
      ),
    );
  }

  Widget banner() {
    final isEdit = editing != null;
    final r = replyTo;
    if (!isEdit && r == null) return const SizedBox.shrink();
    return Container(
      color: card,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(children: [
        Icon(isEdit ? Icons.edit : Icons.reply, size: 18, color: accent),
        const SizedBox(width: 8),
        Expanded(child: Text(isEdit ? 'ویرایش پیام' : 'پاسخ به: ${snippet(r!)}', maxLines: 1, overflow: TextOverflow.ellipsis)),
        IconButton(
          icon: const Icon(Icons.close, size: 18),
          onPressed: () {
            ctrl.clear();
            setState(() {
              editing = null;
              replyTo = null;
            });
          },
        ),
      ]),
    );
  }

  Widget inputBar() {
    if (!textOk) {
      final ch = isGroup && gs.groups[gid]?['kind'] == 'channel';
      return Padding(
        padding: const EdgeInsets.all(12),
        child: Center(child: Text(ch ? 'فقط مدیران می‌توانند پست بگذارند' : 'ارسال پیام برای شما بسته است', style: TextStyle(color: cTextFaint))),
      );
    }
    if (recording) {
      return Row(children: [
        IconButton(icon: const Icon(Icons.delete, color: Colors.redAccent), onPressed: () => stopRec(false)),
        const Icon(Icons.fiber_manual_record, color: Colors.redAccent, size: 14),
        const SizedBox(width: 6),
        Text('${secs ~/ 60}:${(secs % 60).toString().padLeft(2, '0')}'),
        const Spacer(),
        IconButton.filled(icon: const Icon(Icons.send), onPressed: () => stopRec(true)),
      ]);
    }
    final empty = ctrl.text.trim().isEmpty;
    return Row(children: [
      if (mediaOk && editing == null) IconButton(icon: const Icon(Icons.attach_file), onPressed: attachMenu),
      Expanded(
        child: TextField(
          controller: ctrl,
          onChanged: (_) {
            typing();
            setState(() {});
          },
          onSubmitted: (_) => sendText(),
          decoration: fieldDeco(hintText: 'پیام بنویسید...'),
        ),
      ),
      if (!empty && editing == null) IconButton(icon: const Icon(Icons.schedule), tooltip: 'ارسال در زمان دلخواه', onPressed: scheduleCurrent),
      empty && mediaOk && editing == null
          ? IconButton.filledTonal(icon: const Icon(Icons.mic), onPressed: startRec)
          : IconButton.filled(icon: const Icon(Icons.send), onPressed: sendText),
    ]);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Listenable.merge([store, gs, rx]),
        builder: (context, _) {
          if (isGroup && gs.groups[gid] == null) {
            return Scaffold(appBar: AppBar(), body: const Center(child: Text('این گفتگو در دسترس نیست')));
          }
          final all = msgs;
          final list = (q.isEmpty ? all : all.where((m) => snippet(m).toLowerCase().contains(q) || ((m['file_name'] as String?) ?? '').toLowerCase().contains(q)).toList()).reversed.toList();
          if (isGroup && gs.unread(gid) > 0) {
            WidgetsBinding.instance.addPostFrameCallback((_) => gs.markRead(gid));
          }
          if (!isGroup && store.msgs.any((m) => m['sender_id'] == peer && m['receiver_id'] == me && m['read_at'] == null)) {
            WidgetsBinding.instance.addPostFrameCallback((_) => store.markRead(peer));
          }
          return Scaffold(
            appBar: AppBar(
              title: searching
                  ? TextField(
                      autofocus: true,
                      onChanged: (v) => setState(() => q = v.trim().toLowerCase()),
                      decoration: fieldDeco(hintText: 'جستجو در گفتگو...', plain: true),
                    )
                  : titleWidget(),
              actions: [
                IconButton(
                  icon: Icon(searching ? Icons.close : Icons.search),
                  onPressed: () => setState(() {
                    searching = !searching;
                    q = '';
                  }),
                ),
                if (!isSaved)
                  PopupMenuButton<String>(
                    onSelected: (_) => Navigator.push(context, MaterialPageRoute(builder: (_) => ScheduledPage(group: isGroup, target: isGroup ? '$gid' : peer))),
                    itemBuilder: (_) => const [PopupMenuItem(value: 'sched', child: Text('پیام‌های زمان‌بندی‌شده'))],
                  ),
              ],
            ),
            body: Container(
              decoration: wallDecoration(),
              child: Column(children: [
                pinBar(all),
                Expanded(
                  child: ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.all(12),
                    itemCount: list.length,
                    itemBuilder: (c, n) => bubble(list[n]),
                  ),
                ),
                if (uploading) const LinearProgressIndicator(),
                banner(),
                SafeArea(child: Padding(padding: const EdgeInsets.all(8), child: inputBar())),
              ]),
            ),
          );
        },
      );
}
