import 'dart:async';
import 'package:flutter/material.dart';
import 'chat.dart';
import 'groups.dart';
import 'main.dart';
import 'safety.dart';
import 'social.dart';

class NotifStore extends ChangeNotifier {
  List<Map<String, dynamic>> items = [];
  StreamSubscription? _s;

  int get unread => items.where((n) => n['read'] != true).length;

  void start() {
    stop();
    _s = sb.from('notifications').stream(primaryKey: ['id']).order('created_at', ascending: false).limit(100).listen((rows) async {
      items = [...rows]..sort((a, b) => (b['id'] as int).compareTo(a['id'] as int));
      try {
        await store.loadPeople(items.map((n) => n['actor_id'] as String));
      } catch (_) {}
      notifyListeners();
    }, onError: (_) {});
  }

  void stop() {
    _s?.cancel();
    _s = null;
    items = [];
  }

  Future<void> markAllRead() => sb.from('notifications').update({'read': true}).eq('user_id', me!).eq('read', false);
}

final notifs = NotifStore();

Future<List<Map<String, dynamic>>> postById(int id) async => enrich(await sb.from('posts').select(postSel).eq('id', id));

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});
  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  late final Set<int> fresh;

  @override
  void initState() {
    super.initState();
    fresh = notifs.items.where((n) => n['read'] != true).map((n) => n['id'] as int).toSet();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      notifs.markAllRead().catchError((_) {});
    });
  }

  String describe(Map<String, dynamic> n) {
    final who = store.name(n['actor_id'] as String);
    final t = (n['text'] as String?) ?? '';
    switch (n['kind']) {
      case 'like':
        return '$who پست شما را پسندید';
      case 'comment':
        return '$who نظر داد: $t';
      case 'follow':
        return '$who شما را دنبال کرد';
      case 'follow_request':
        return '$who درخواست دنبال‌کردن فرستاد';
      case 'follow_accept':
        return '$who درخواست دنبال‌کردن شما را پذیرفت';
      case 'mention':
        return '$who شما را منشن کرد: $t';
      default:
        return who;
    }
  }

  void open(Map<String, dynamic> n) {
    final kind = n['kind'] as String;
    final pid = n['post_id'] as int?;
    if (pid != null && (kind == 'like' || kind == 'comment' || kind == 'mention')) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => PostListPage('پست', () => postById(pid))));
    } else if (kind == 'follow_request') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const RequestsPage()));
    } else {
      Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(n['actor_id'] as String)));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('اعلان‌ها')),
        body: ListenableBuilder(
          listenable: notifs,
          builder: (c, _) => notifs.items.isEmpty
              ? const Center(child: Text('هنوز اعلانی ندارید'))
              : ListView(children: [
                  for (final n in notifs.items)
                    ListTile(
                      tileColor: fresh.contains(n['id']) ? Color.lerp(bg, primary, 0.14) : null,
                      leading: avatarFor(n['actor_id'] as String),
                      title: Text(describe(n), maxLines: 2, overflow: TextOverflow.ellipsis),
                      subtitle: Text(ago(n['created_at'] as String), style: TextStyle(color: cTextFaint, fontSize: 12)),
                      onTap: () => open(n),
                    ),
                ]),
        ),
      );
}

class MessageSearchPage extends StatefulWidget {
  const MessageSearchPage({super.key});
  @override
  State<MessageSearchPage> createState() => _MessageSearchPageState();
}

class _MessageSearchPageState extends State<MessageSearchPage> {
  String q = '';

  List<Map<String, dynamic>> results() {
    if (q.length < 2) return [];
    final out = <Map<String, dynamic>>[];
    for (final m in store.msgs) {
      final peer = store.peerOf(m);
      if (!safety.visible('d', peer, m)) continue;
      if (snippet(m).toLowerCase().contains(q)) {
        out.add({'m': m, 'title': peer == me ? 'پیام‌های ذخیره‌شده' : store.name(peer), 'peer': peer});
      }
    }
    for (final m in gs.msgs) {
      final gid = m['group_id'] as int;
      if (!gs.groups.containsKey(gid) || !safety.visible('g', '$gid', m)) continue;
      if (snippet(m).toLowerCase().contains(q)) {
        out.add({'m': m, 'title': '${gs.groups[gid]!['title']}', 'gid': gid});
      }
    }
    out.sort((a, b) => ((b['m'] as Map)['created_at'] as String).compareTo((a['m'] as Map)['created_at'] as String));
    return out.take(100).toList();
  }

  @override
  Widget build(BuildContext context) {
    final res = results();
    return Scaffold(
      appBar: AppBar(
        title: TextField(autofocus: true, onChanged: (v) => setState(() => q = v.trim().toLowerCase()), decoration: fieldDeco(hintText: 'جستجو در همه‌ی پیام‌ها...', plain: true)),
      ),
      body: q.length < 2
          ? const Center(child: Text('حداقل دو حرف بنویسید'))
          : res.isEmpty
              ? const Center(child: Text('نتیجه‌ای پیدا نشد'))
              : ListView(children: [
                  for (final r in res)
                    ListTile(
                      title: Text(r['title'] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${store.name((r['m'] as Map)['sender_id'] as String)}: ${snippet(r['m'] as Map<String, dynamic>)}', maxLines: 2, overflow: TextOverflow.ellipsis),
                      trailing: Text(hm((r['m'] as Map)['created_at'] as String), style: const TextStyle(fontSize: 12)),
                      onTap: () => r['gid'] != null ? openGroup(context, r['gid'] as int) : openChat(context, r['peer'] as String),
                    ),
                ]),
    );
  }
}
