import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'cyber.dart';
import 'l10n.dart';
import 'main.dart';

/// راهنمای شروع؛ فقط یک بار و فقط برای حساب‌هایی که همین الان ساخته شده‌اند
/// بعد از ساخته‌شدن حساب تازه صدا زده می‌شود تا راهنما حتی اگر صفحه‌ی اصلی قبلاً ساخته شده باشد نمایش داده شود
final ValueNotifier<int> onboardTick = ValueNotifier<int>(0);
bool _onboardOpen = false;

Future<void> maybeShowOnboarding(BuildContext context) async {
  final uid = me;
  if (uid == null || _onboardOpen) return;
  try {
    final p = await SharedPreferences.getInstance();
    if (p.getBool('onboard_$uid') != true) return;
    if (!context.mounted) return;
    await p.remove('onboard_$uid');
    _onboardOpen = true;
    await Navigator.of(context).push(PageRouteBuilder<void>(
      opaque: true,
      transitionDuration: const Duration(milliseconds: 350),
      pageBuilder: (c, a, b) => FadeTransition(opacity: a, child: const OnboardingPage()),
    ));
  } catch (_) {}
  _onboardOpen = false;
}

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});
  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final _pc = PageController();
  int _i = 0;

  static const _pages = <List<Object>>[
    [Icons.waving_hand_rounded, 'به تیا خوش آمدی', 'گفتگو، گروه، استوری و شبکه‌ی اجتماعی؛ همه در یک برنامه.'],
    [Icons.lock_rounded, 'پیام‌های خصوصی امن‌اند', 'پیام‌های متنی گفتگوهای خصوصی رمزنگاری سرتاسری می‌شوند و فقط تو و طرف مقابل می‌توانید آن‌ها را بخوانید. گروه‌ها و فایل‌ها فعلاً شامل این نمی‌شوند.'],
    [Icons.auto_awesome_rounded, 'ابزارهای هوشمند', 'روی هر پیام انگشت را نگه دار: پاسخ، ترجمه، خلاصه و پیشنهاد پاسخ. بالای کادر پیام هم پاسخ‌های آماده هست.'],
    [Icons.tune_rounded, 'همه‌چیز دست خودته', 'قفل برنامه، پیام زمان‌بندی‌شده، پیام خودحذف‌شونده، پس‌زمینه‌ی هر گفتگو و آخرین بازدید را از تنظیمات و منوی گفتگو پیدا می‌کنی.'],
    [Icons.verified_user_rounded, 'آماده‌ای!', 'کد بازیابی حسابت را جای امنی نگه دار. برای شروع، مخاطبینت را باز کن و اولین پیام را بفرست.'],
  ];

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final last = _i == _pages.length - 1;
    return Directionality(
      textDirection: appDir,
      child: Scaffold(
        body: SafeArea(
          child: Column(children: [
            Align(
              alignment: AlignmentDirectional.centerEnd,
              child: TextButton(onPressed: () => Navigator.pop(context), child: Text(last ? '' : trn('رد کردن'))),
            ),
            Expanded(
              child: PageView.builder(
                controller: _pc,
                itemCount: _pages.length,
                onPageChanged: (v) => setState(() => _i = v),
                itemBuilder: (c, n) {
                  final p = _pages[n];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Container(
                        width: 128,
                        height: 128,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [primary, accent]),
                          boxShadow: [BoxShadow(color: (cy.enabled ? cy.c1 : primary).withOpacity(0.4), blurRadius: 30, spreadRadius: -4)],
                        ),
                        child: Icon(p[0] as IconData, size: 60, color: cOnPrimary),
                      ),
                      const SizedBox(height: 36),
                      Text(trn(p[1] as String), textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: cText)),
                      const SizedBox(height: 14),
                      Text(trn(p[2] as String), textAlign: TextAlign.center, style: TextStyle(fontSize: 15, height: 1.8, color: cTextDim)),
                    ]),
                  );
                },
              ),
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var k = 0; k < _pages.length; k++)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: k == _i ? 22 : 8,
                  height: 8,
                  decoration: BoxDecoration(color: k == _i ? accent : cLine, borderRadius: BorderRadius.circular(4)),
                ),
            ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
              child: SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton(
                  onPressed: () {
                    if (last) {
                      Navigator.pop(context);
                    } else {
                      _pc.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
                    }
                  },
                  child: Text(last ? trn('شروع') : trn('بعدی')),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
