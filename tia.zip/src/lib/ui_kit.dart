import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'cyber.dart';
import 'l10n.dart';
import 'main.dart';

// ===========================================================================
// قاب مشترک برگه‌های پایین صفحه (هماهنگ با تم فعلی)
// ===========================================================================
Future<T?> showTiaSheet<T>(BuildContext context, Widget Function(BuildContext) builder, {double maxHeightFactor = 0.88}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black54,
    useSafeArea: true,
    builder: (c) => Directionality(
      textDirection: appDir,
      child: Align(
        alignment: Alignment.bottomCenter,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 560, maxHeight: MediaQuery.of(c).size.height * maxHeightFactor),
          child: _SheetFrame(child: builder(c)),
        ),
      ),
    ),
  );
}

class _SheetFrame extends StatelessWidget {
  final Widget child;
  const _SheetFrame({required this.child});

  @override
  Widget build(BuildContext context) {
    final glow = cy.enabled;
    final bottom = MediaQuery.of(context).viewPadding.bottom;
    return Container(
      decoration: BoxDecoration(
        color: Color.lerp(card, bg, isDark ? 0.18 : 0.0),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(top: BorderSide(color: glow ? cy.c1.withOpacity(0.55) : cLine, width: glow ? 1.2 : 1)),
        boxShadow: [BoxShadow(color: glow ? cy.c1.withOpacity(0.18 + 0.2 * cy.glow) : Colors.black38, blurRadius: 26, spreadRadius: -4)],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 10),
        Container(width: 42, height: 4.5, decoration: BoxDecoration(color: cTextFaint.withOpacity(0.5), borderRadius: BorderRadius.circular(3))),
        const SizedBox(height: 12),
        Flexible(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 18 + bottom),
            child: child,
          ),
        ),
      ]),
    );
  }
}

// ===========================================================================
// منوی ارسال فایل (شبکه‌ی آیکن‌های رنگی با ورود پله‌ای)
// ===========================================================================
class AttachOption {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const AttachOption(this.icon, this.label, this.color, this.onTap);
}

class AttachGroup {
  final String title;
  final List<AttachOption> items;
  const AttachGroup(this.title, this.items);
}

Future<void> showAttachSheet(BuildContext context, List<AttachGroup> groups) {
  HapticFeedback.selectionClick();
  var idx = 0;
  return showTiaSheet<void>(context, (c) {
    idx = 0;
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(4, 2, 4, 6),
        child: Text(trn('ارسال'), style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: cText)),
      ),
      for (final g in groups) ...[
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 14, 4, 8),
          child: Text(trn(g.title), style: TextStyle(fontSize: 12.5, color: cTextFaint, fontWeight: FontWeight.w700, letterSpacing: 0.3)),
        ),
        LayoutBuilder(builder: (lc, cons) {
          final cols = cons.maxWidth > 420 ? 4 : 3;
          final w = cons.maxWidth / cols;
          return Wrap(children: [
            for (final o in g.items) SizedBox(width: w, child: _AttachTile(o, idx++, () => Navigator.pop(c))),
          ]);
        }),
      ],
    ]);
  });
}

class _AttachTile extends StatelessWidget {
  final AttachOption o;
  final int i;
  final VoidCallback close;
  const _AttachTile(this.o, this.i, this.close);

  @override
  Widget build(BuildContext context) {
    final base = Color.lerp(o.color, primary, 0.18)!;
    final hi = Color.lerp(base, Colors.white, 0.28)!;
    final lo = Color.lerp(base, Colors.black, 0.22)!;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 260 + i * 45),
      curve: Curves.easeOutBack,
      builder: (c, v, ch) => Opacity(opacity: v.clamp(0.0, 1.0), child: Transform.scale(scale: 0.55 + 0.45 * v, child: ch)),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          close();
          o.onTap();
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [hi, lo]),
                boxShadow: [BoxShadow(color: (cy.enabled ? cy.c1 : base).withOpacity(0.38), blurRadius: 14, offset: const Offset(0, 4), spreadRadius: -2)],
              ),
              child: Icon(o.icon, color: Colors.white, size: 28),
            ),
            const SizedBox(height: 7),
            Text(o.label, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, height: 1.25, color: cText)),
          ]),
        ),
      ),
    );
  }
}

// ===========================================================================
// منوی شناور پیام (شبیه تلگرام): واکنش‌ها بالا، گزینه‌ها پایین، پیام برجسته
// ===========================================================================
class MenuAction {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool danger, divider;
  const MenuAction(this.icon, this.label, this.onTap, {this.danger = false, this.divider = false});
}

const List<String> quickReactions = ['❤️', '😂', '👍', '😮', '😢', '🙏', '🔥'];
const List<String> allReactions = [
  '❤️', '😂', '👍', '👎', '🔥', '🥰', '😮', '😢', '🙏', '👏', '🎉', '🤔', '😡', '🤯', //
  '😍', '😎', '💯', '🤝', '😭', '🥳', '🙄', '😴', '💔', '✅', '❌', '⭐', '🤣', '😅',
];

/// عکسی از حباب پیام برای نمایش روی پس‌زمینه‌ی تار
Future<ui.Image?> captureBubble(GlobalKey key, double pixelRatio) async {
  try {
    final ro = key.currentContext?.findRenderObject();
    if (ro is! RenderRepaintBoundary) return null;
    return await ro.toImage(pixelRatio: pixelRatio);
  } catch (_) {
    return null;
  }
}

Rect? rectOf(GlobalKey key) {
  final ro = key.currentContext?.findRenderObject();
  if (ro is! RenderBox || !ro.attached) return null;
  return ro.localToGlobal(Offset.zero) & ro.size;
}

Future<void> showMsgMenu(
  BuildContext context, {
  required Rect anchor,
  required bool mine,
  required List<MenuAction> actions,
  ui.Image? snapshot,
  List<String>? reactions,
  Set<String> mineReactions = const {},
  void Function(String emoji)? onReact,
}) {
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'menu',
    barrierColor: Colors.transparent,
    transitionDuration: const Duration(milliseconds: 230),
    pageBuilder: (c, a, b) => Directionality(
      textDirection: appDir,
      child: _MsgMenuLayer(anim: a, anchor: anchor, mine: mine, actions: actions, snapshot: snapshot, canReact: onReact != null, mineReactions: mineReactions, onReact: onReact),
    ),
  );
}

class _MsgMenuLayer extends StatefulWidget {
  final Animation<double> anim;
  final Rect anchor;
  final bool mine, canReact;
  final List<MenuAction> actions;
  final ui.Image? snapshot;
  final Set<String> mineReactions;
  final void Function(String emoji)? onReact;
  const _MsgMenuLayer({required this.anim, required this.anchor, required this.mine, required this.actions, required this.snapshot, required this.canReact, required this.mineReactions, required this.onReact});

  @override
  State<_MsgMenuLayer> createState() => _MsgMenuLayerState();
}

class _MsgMenuLayerState extends State<_MsgMenuLayer> {
  bool expanded = false;
  static const double _gap = 8, _itemH = 46;

  void _close() => Navigator.of(context).pop();

  Widget _reactionBar(double w) {
    final cyber = cy.enabled;
    return Container(
      width: w,
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 6),
      decoration: _panelDeco(26, cyber),
      child: Row(children: [
        for (final e in quickReactions) Expanded(child: _emojiBtn(e, 26)),
        InkWell(
          customBorder: const CircleBorder(),
          onTap: () => setState(() => expanded = true),
          child: Container(
            width: 34,
            height: 34,
            margin: const EdgeInsets.symmetric(horizontal: 3),
            decoration: BoxDecoration(shape: BoxShape.circle, color: cLine),
            child: Icon(Icons.keyboard_arrow_down_rounded, color: cTextDim, size: 22),
          ),
        ),
      ]),
    );
  }

  Widget _emojiBtn(String e, double size) {
    final mineSel = widget.mineReactions.contains(e);
    return InkWell(
      customBorder: const CircleBorder(),
      onTap: () {
        HapticFeedback.selectionClick();
        _close();
        widget.onReact?.call(e);
      },
      child: Container(
        height: 40,
        alignment: Alignment.center,
        decoration: mineSel ? BoxDecoration(shape: BoxShape.circle, color: accent.withOpacity(0.28)) : null,
        child: Text(e, style: TextStyle(fontSize: size)),
      ),
    );
  }

  Widget _reactionGrid(double w) {
    return Container(
      width: w,
      padding: const EdgeInsets.all(8),
      decoration: _panelDeco(22, cy.enabled),
      child: GridView.count(
        crossAxisCount: 7,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        children: [for (final e in allReactions) _emojiBtn(e, 25)],
      ),
    );
  }

  BoxDecoration _panelDeco(double r, bool cyber) => BoxDecoration(
        color: Color.lerp(card, bg, isDark ? 0.12 : 0.0)!.withOpacity(0.97),
        borderRadius: BorderRadius.circular(r),
        border: Border.all(color: cyber ? cy.c1.withOpacity(0.55) : cLine),
        boxShadow: [BoxShadow(color: cyber ? cy.c1.withOpacity(0.22 + 0.2 * cy.glow) : Colors.black45, blurRadius: 24, spreadRadius: -4)],
      );

  Widget _menuCard(double w, double h) {
    final cyber = cy.enabled;
    final rows = <Widget>[];
    for (final a in widget.actions) {
      if (a.divider && rows.isNotEmpty) rows.add(Container(height: 6, color: Colors.black.withOpacity(isDark ? 0.22 : 0.06)));
      final col = a.danger ? Colors.redAccent : cText;
      rows.add(InkWell(
        onTap: () {
          _close();
          a.onTap();
        },
        child: SizedBox(
          height: _itemH,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Icon(a.icon, size: 21, color: a.danger ? Colors.redAccent : accent),
              const SizedBox(width: 14),
              Expanded(child: Text(a.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: col, fontSize: 15))),
            ]),
          ),
        ),
      ));
    }
    return Container(
      width: w,
      height: h,
      decoration: _panelDeco(20, cyber),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Material(
          color: Colors.transparent,
          child: SingleChildScrollView(physics: const ClampingScrollPhysics(), child: Column(mainAxisSize: MainAxisSize.min, children: rows)),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final sw = mq.size.width, sh = mq.size.height;
    final topLimit = mq.padding.top + 8, bottomLimit = sh - mq.padding.bottom - 8;
    final avail = bottomLimit - topLimit;
    final a = widget.anchor;
    final snap = widget.snapshot;

    final barW = (sw - 24).clamp(240.0, 346.0).toDouble();
    final gridW = (sw - 24).clamp(240.0, 330.0).toDouble();
    final topW = expanded ? gridW : barW;
    final topH = !widget.canReact ? 0.0 : (expanded ? (allReactions.length / 7).ceil() * (gridW - 16) / 7 + 16 : 52.0);
    final menuW = (sw - 32).clamp(200.0, 250.0).toDouble();
    final fullMenuH = widget.actions.length * _itemH + widget.actions.where((x) => x.divider).length * 6.0;

    var bubbleH = snap != null ? a.height : 0.0;
    final maxBubble = avail * 0.40;
    if (bubbleH > maxBubble) bubbleH = maxBubble;
    final topGap = topH > 0 ? _gap : 0.0;
    var menuH = fullMenuH;
    var total = topH + topGap + bubbleH + (snap != null ? _gap : 0) + menuH;
    if (total > avail) {
      final lo = fullMenuH < _itemH * 2 ? fullMenuH : _itemH * 2;
      menuH = (avail - topH - topGap - bubbleH - (snap != null ? _gap : 0)).clamp(lo, fullMenuH).toDouble();
      total = topH + topGap + bubbleH + (snap != null ? _gap : 0) + menuH;
      if (total > avail) {
        bubbleH = (bubbleH - (total - avail)).clamp(0.0, bubbleH).toDouble();
        total = topH + topGap + bubbleH + (snap != null ? _gap : 0) + menuH;
      }
    }

    double y0;
    if (snap != null) {
      y0 = a.top - topH - topGap;
    } else {
      // بدون عکس: حباب اصلی سر جایش می‌ماند؛ واکنش‌ها بالای آن و منو زیر آن
      y0 = a.top - topH - topGap;
    }
    final spanH = snap != null ? total : topH + topGap + a.height + _gap + menuH;
    y0 = y0.clamp(topLimit, (bottomLimit - spanH).clamp(topLimit, bottomLimit)).toDouble();
    final bubbleTop = y0 + topH + topGap;
    final menuTop = snap != null ? bubbleTop + bubbleH + _gap : bubbleTop + a.height + _gap;

    double xFor(double w) {
      final x = widget.mine ? a.right - w : a.left;
      return x.clamp(12.0, (sw - 12 - w).clamp(12.0, sw)).toDouble();
    }

    final curve = CurvedAnimation(parent: widget.anim, curve: Curves.easeOutBack, reverseCurve: Curves.easeIn);
    final al = widget.mine ? Alignment.topRight : Alignment.topLeft;
    const dur = Duration(milliseconds: 200);

    Widget pop(Widget child, Alignment origin) => ScaleTransition(
          scale: Tween<double>(begin: 0.6, end: 1).animate(curve),
          alignment: origin,
          child: FadeTransition(opacity: widget.anim, child: child),
        );

    return Material(
      type: MaterialType.transparency,
      child: Stack(children: [
        Positioned.fill(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _close,
            onSecondaryTap: _close,
            child: AnimatedBuilder(
              animation: widget.anim,
              builder: (c, _) {
                final t = widget.anim.value.clamp(0.0, 1.0).toDouble();
                final scrim = Container(color: Colors.black.withOpacity((snap != null ? 0.42 : 0.30) * t));
                if (snap == null) return scrim;
                return BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 7 * t + 0.01, sigmaY: 7 * t + 0.01), child: scrim);
              },
            ),
          ),
        ),
        if (snap != null)
          AnimatedPositioned(
            duration: dur,
            curve: Curves.easeOutCubic,
            left: a.left,
            top: bubbleTop,
            width: a.width,
            height: bubbleH,
            child: IgnorePointer(
              child: ClipRect(
                child: OverflowBox(
                  alignment: Alignment.topCenter,
                  minHeight: a.height,
                  maxHeight: a.height,
                  minWidth: a.width,
                  maxWidth: a.width,
                  child: RawImage(image: snap, width: a.width, height: a.height, fit: BoxFit.fill),
                ),
              ),
            ),
          ),
        if (widget.canReact)
          AnimatedPositioned(
            duration: dur,
            curve: Curves.easeOutCubic,
            left: xFor(topW),
            top: y0,
            child: pop(expanded ? _reactionGrid(gridW) : _reactionBar(barW), al),
          ),
        AnimatedPositioned(
          duration: dur,
          curve: Curves.easeOutCubic,
          left: xFor(menuW),
          top: menuTop,
          child: pop(_menuCard(menuW, menuH), widget.mine ? Alignment.topRight : Alignment.topLeft),
        ),
      ]),
    );
  }
}
