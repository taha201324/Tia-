import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'main.dart';

String _hash(String pin, String salt) => sha256.convert(utf8.encode('$salt:$pin')).toString();
bool lockEnabled() => settings.lockHash != null;
bool verifyPin(String pin) => settings.lockHash != null && _hash(pin, settings.lockSalt ?? '') == settings.lockHash;

void setPin(String pin) {
  final rnd = Random.secure();
  final salt = List.generate(16, (_) => rnd.nextInt(36).toRadixString(36)).join();
  settings.lockSalt = salt;
  settings.lockHash = _hash(pin, salt);
  settings.save();
}

void clearPin() {
  settings.lockHash = null;
  settings.lockSalt = null;
  settings.save();
}

class LockGate extends StatefulWidget {
  final Widget child;
  const LockGate({super.key, required this.child});
  @override
  State<LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<LockGate> with WidgetsBindingObserver {
  late bool locked = lockEnabled();
  DateTime? _paused;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.paused) _paused = DateTime.now();
    if (s == AppLifecycleState.resumed && _paused != null) {
      if (lockEnabled() && DateTime.now().difference(_paused!).inSeconds >= settings.lockTimeout) {
        setState(() => locked = true);
      }
      _paused = null;
    }
  }

  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
        widget.child,
        if (locked && lockEnabled()) Positioned.fill(child: LockScreen(onUnlock: () => setState(() => locked = false))),
      ]);
}

class LockScreen extends StatefulWidget {
  final VoidCallback onUnlock;
  const LockScreen({super.key, required this.onUnlock});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String pin = '';
  bool bad = false;

  void tap(String d) {
    if (pin.length >= 4) return;
    setState(() {
      pin += d;
      bad = false;
    });
    if (pin.length == 4) {
      if (verifyPin(pin)) {
        widget.onUnlock();
      } else {
        setState(() {
          pin = '';
          bad = true;
        });
      }
    }
  }

  Widget key(String label, {VoidCallback? onTap, IconData? icon}) => InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap ?? () => tap(label),
        child: SizedBox(width: 76, height: 76, child: Center(child: icon != null ? Icon(icon, size: 26) : Text(label, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600)))),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: bg,
        body: SafeArea(
          child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.lock_outline, size: 48, color: primary),
              const SizedBox(height: 12),
              const Text('رمز برنامه را وارد کنید', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 18),
              Row(mainAxisSize: MainAxisSize.min, children: [
                for (var i = 0; i < 4; i++)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: i < pin.length ? primary : Colors.transparent, border: Border.all(color: primary, width: 2)),
                  ),
              ]),
              SizedBox(height: 28, child: bad ? const Center(child: Text('رمز اشتباه است', style: TextStyle(color: Colors.redAccent))) : null),
              for (final row in const [
                ['1', '2', '3'],
                ['4', '5', '6'],
                ['7', '8', '9']
              ])
                Row(mainAxisSize: MainAxisSize.min, children: [for (final d in row) key(d)]),
              Row(mainAxisSize: MainAxisSize.min, children: [
                const SizedBox(width: 76, height: 76),
                key('0'),
                key('', icon: Icons.backspace_outlined, onTap: () => setState(() => pin = pin.isEmpty ? '' : pin.substring(0, pin.length - 1))),
              ]),
            ]),
          ),
        ),
      );
}

Future<String?> pinDialog(BuildContext c, String title) {
  final t = TextEditingController();
  return showDialog<String>(
    context: c,
    builder: (d) => AlertDialog(
      title: Text(title),
      content: TextField(controller: t, autofocus: true, obscureText: true, maxLength: 4, keyboardType: TextInputType.number, decoration: fieldDeco(hintText: 'چهار رقم')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('انصراف')),
        FilledButton(
          onPressed: () {
            if (RegExp(r'^[0-9]{4}$').hasMatch(t.text)) Navigator.pop(d, t.text);
          },
          child: const Text('تایید'),
        ),
      ],
    ),
  );
}

String lockTimeoutLabel(int s) => s == 0 ? 'بلافاصله' : s < 60 ? '$s ثانیه' : '${s ~/ 60} دقیقه';

class AppLockPage extends StatelessWidget {
  const AppLockPage({super.key});

  Future<void> enable(BuildContext c) async {
    final a = await pinDialog(c, 'رمز جدید');
    if (a == null || !c.mounted) return;
    final b = await pinDialog(c, 'تکرار رمز');
    if (b == null || !c.mounted) return;
    if (a != b) {
      snack(c, 'دو رمز یکسان نبودند');
      return;
    }
    setPin(a);
  }

  Future<void> disable(BuildContext c) async {
    final p = await pinDialog(c, 'رمز فعلی');
    if (p == null || !c.mounted) return;
    if (verifyPin(p)) {
      clearPin();
    } else {
      snack(c, 'رمز اشتباه است');
    }
  }

  Future<void> change(BuildContext c) async {
    final old = await pinDialog(c, 'رمز فعلی');
    if (old == null || !c.mounted) return;
    if (!verifyPin(old)) {
      snack(c, 'رمز اشتباه است');
      return;
    }
    await enable(c);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('قفل برنامه')),
        body: ListenableBuilder(
          listenable: settings,
          builder: (c, _) => ListView(children: [
            SwitchListTile(
              secondary: const Icon(Icons.lock_outline),
              title: const Text('قفل برنامه با رمز ۴ رقمی'),
              subtitle: const Text('هنگام باز کردن برنامه رمز پرسیده می‌شود'),
              value: lockEnabled(),
              onChanged: (v) => v ? enable(c) : disable(c),
            ),
            if (lockEnabled()) ...[
              ListTile(leading: const Icon(Icons.password), title: const Text('تغییر رمز'), onTap: () => change(c)),
              ListTile(
                leading: const Icon(Icons.timer_outlined),
                title: const Text('زمان قفل‌شدن بعد از خروج از برنامه'),
                subtitle: Text(lockTimeoutLabel(settings.lockTimeout)),
                onTap: () async {
                  final v = await showDialog<int>(
                    context: c,
                    builder: (d) => SimpleDialog(title: const Text('قفل شود بعد از'), children: [
                      for (final s in const [0, 30, 60, 300]) SimpleDialogOption(onPressed: () => Navigator.pop(d, s), child: Text(lockTimeoutLabel(s))),
                    ]),
                  );
                  if (v != null) {
                    settings.lockTimeout = v;
                    settings.save();
                  }
                },
              ),
            ],
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('رمز فقط روی همین گوشی و به‌صورت رمزشده ذخیره می‌شود. اگر فراموشش کنید، باید برنامه را حذف و دوباره نصب کنید.', style: TextStyle(fontSize: 12)),
            ),
          ]),
        ),
      );
}
