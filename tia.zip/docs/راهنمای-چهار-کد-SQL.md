# چهار کدی که باید در Supabase اجرا کنید
پنل Supabase ← **SQL Editor** ← New query ← محتوای فایل را بچسبانید ← Run. به همین ترتیب (هر فایل جدا):

1. `supabase_u1_e2ee.sql` — رمزنگاری سرتاسری (کلیدها)
2. `supabase_u2_silent.sql` — ارسال بی‌صدا (بعد از supabase_push.sql)
3. `supabase_u3_reminders.sql` — جدول و تابع یادآوری، سپس **جدا**: `supabase_u3b_reminders_cron.sql` (نیاز به pg_cron)
4. `supabase_u4_reaction_push.sql` — اعلان واکنش

هر فایل بدون خطا ("Success") اجرا شد یعنی آن قابلیت روشن است. اگر فایلی را اجرا نکنید فقط همان قابلیت کار نمی‌کند و بقیه‌ی برنامه سالم می‌ماند.
