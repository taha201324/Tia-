-- یک بار در Supabase ← SQL Editor اجرا کنید (برای رمزنگاری سرتاسری)
create table if not exists public.user_keys (
  user_id uuid not null references auth.users(id) on delete cascade,
  device_id text not null,
  public_key text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, device_id)
);
alter table public.user_keys enable row level security;
drop policy if exists "keys_read" on public.user_keys;
create policy "keys_read" on public.user_keys for select to authenticated using (true);
drop policy if exists "keys_write" on public.user_keys;
create policy "keys_write" on public.user_keys for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "keys_update" on public.user_keys;
create policy "keys_update" on public.user_keys for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "keys_delete" on public.user_keys;
create policy "keys_delete" on public.user_keys for delete to authenticated using (user_id = auth.uid());
