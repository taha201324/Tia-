-- اجرا شود بعد از supabase_more.sql
-- ============ استوری ۲۴ ساعته ============
create table stories (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  kind text not null check (kind in ('image', 'text')),
  image_path text,
  text text not null default '',
  bg int not null default 0,
  created_at timestamptz not null default now()
);
create table story_views (
  story_id bigint not null references stories(id) on delete cascade,
  viewer_id uuid not null references profiles(id) on delete cascade,
  viewed_at timestamptz not null default now(),
  primary key (story_id, viewer_id)
);
alter table stories enable row level security;
alter table story_views enable row level security;

create policy "stories read" on stories for select to authenticated using (
  created_at > now() - interval '24 hours'
  and not public.blocked_pair(auth.uid(), user_id)
  and (
    user_id = auth.uid()
    or exists (select 1 from profiles p where p.id = stories.user_id and not p.is_private)
    or exists (select 1 from follows f where f.follower_id = auth.uid() and f.followee_id = stories.user_id and f.status = 'accepted')
  )
);
create policy "stories add" on stories for insert to authenticated with check (user_id = auth.uid());
create policy "stories remove" on stories for delete to authenticated using (user_id = auth.uid());

create policy "story views add" on story_views for insert to authenticated
  with check (viewer_id = auth.uid() and exists (select 1 from stories s where s.id = story_views.story_id));
create policy "story views read" on story_views for select to authenticated using (
  viewer_id = auth.uid()
  or exists (select 1 from stories s where s.id = story_views.story_id and s.user_id = auth.uid())
);

-- عکس استوری‌ها برای کسانی که اجازه‌ی دیدن استوری را دارند قابل مشاهده باشد
drop policy if exists "post images read" on storage.objects;
create policy "post images read" on storage.objects for select to authenticated using (
  bucket_id = 'post-images' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (select 1 from public.posts p where p.image_path = storage.objects.name)
    or exists (select 1 from public.stories s where s.image_path = storage.objects.name)
  )
);

-- ============ پیام‌های خودحذف‌شونده ============
create table chat_ttl (
  scope text not null check (scope in ('d', 'g')),
  key text not null,
  seconds int not null default 0 check (seconds >= 0),
  set_by uuid references profiles(id) on delete set null,
  primary key (scope, key)
);
alter table chat_ttl enable row level security;

create or replace function public.ttl_allowed(sc text, k text, for_write boolean) returns boolean
language sql stable security definer set search_path = public as $$
  select case
    when sc = 'd' then auth.uid()::text in (split_part(k, '_', 1), split_part(k, '_', 2))
    when for_write then public.gm_right(k::bigint, 'info')
    else public.gm_role(k::bigint) is not null
  end
$$;
grant execute on function public.ttl_allowed(text, text, boolean) to authenticated;

create policy "ttl read" on chat_ttl for select to authenticated using (public.ttl_allowed(scope, key, false));
create policy "ttl add" on chat_ttl for insert to authenticated
  with check (public.ttl_allowed(scope, key, true) and set_by = auth.uid());
create policy "ttl change" on chat_ttl for update to authenticated
  using (public.ttl_allowed(scope, key, true)) with check (public.ttl_allowed(scope, key, true) and set_by = auth.uid());

create or replace function public.purge_expired() returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from messages m using chat_ttl t
  where t.scope = 'd' and t.seconds > 0
    and t.key = least(m.sender_id::text, m.receiver_id::text) || '_' || greatest(m.sender_id::text, m.receiver_id::text)
    and m.created_at < now() - make_interval(secs => t.seconds);
  delete from group_messages g using chat_ttl t
  where t.scope = 'g' and t.seconds > 0 and t.key = g.group_id::text
    and g.created_at < now() - make_interval(secs => t.seconds);
  delete from stories where created_at < now() - interval '24 hours';
end $$;
