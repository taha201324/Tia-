-- اجرا شود در Supabase > SQL Editor
-- فهرست و مدیریت دستگاه‌های متصل (نشست‌های فعال)

create or replace function public.my_sessions()
returns table (id uuid, created_at timestamptz, updated_at timestamptz, user_agent text, ip text)
language sql
security definer
set search_path = auth, public
as $$
  select s.id, s.created_at, s.updated_at, s.user_agent, s.ip::text
  from auth.sessions s
  where s.user_id = auth.uid()
  order by coalesce(s.updated_at, s.created_at) desc;
$$;
revoke all on function public.my_sessions() from public;
grant execute on function public.my_sessions() to authenticated;

create or replace function public.revoke_session(p_id uuid)
returns void
language sql
security definer
set search_path = auth, public
as $$
  delete from auth.sessions where id = p_id and user_id = auth.uid();
$$;
revoke all on function public.revoke_session(uuid) from public;
grant execute on function public.revoke_session(uuid) to authenticated;
