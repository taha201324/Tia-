-- اجرا شود بعد از supabase_groups.sql
-- ============ سنجاق پیام ============
alter table messages add column if not exists pinned_at timestamptz;
grant update (read_at, text, edited_at, pinned_at) on messages to authenticated;

alter table group_messages add column if not exists pinned_at timestamptz;
grant update (text, edited_at, pinned_at) on group_messages to authenticated;
create policy "gmsg pin" on group_messages for update to authenticated
  using (public.gm_right(group_id, 'info')) with check (public.gm_right(group_id, 'info'));
create or replace function public.gmsg_guard() returns trigger language plpgsql as $$
begin
  if (new.text is distinct from old.text or new.edited_at is distinct from old.edited_at)
     and auth.uid() is distinct from old.sender_id then
    raise exception 'فقط فرستنده می‌تواند پیام را ویرایش کند';
  end if;
  return new;
end $$;
create trigger gmsg_guard before update on group_messages for each row execute function public.gmsg_guard();

-- ============ خوانده‌نشده‌ها در گروه ============
alter table group_members add column if not exists last_read_id bigint not null default 0;
grant update (role, can_delete, can_manage_members, can_edit_info, can_post, muted_until, last_read_id) on group_members to authenticated;
create policy "members self read" on group_members for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create or replace function public.gm_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role = old.role and new.can_delete = old.can_delete and new.can_manage_members = old.can_manage_members
     and new.can_edit_info = old.can_edit_info and new.can_post = old.can_post
     and new.muted_until is not distinct from old.muted_until then
    if new.last_read_id is distinct from old.last_read_id and old.user_id <> auth.uid() then
      raise exception 'فقط خود کاربر می‌تواند وضعیت خوانده‌شدن خودش را تغییر دهد';
    end if;
    return new;
  end if;
  if old.role = 'owner' or new.role = 'owner' then
    raise exception 'مالک قابل تغییر نیست';
  end if;
  if public.gm_role(old.group_id) is distinct from 'owner' then
    if old.role <> 'member' or new.role <> old.role
       or new.can_delete is distinct from old.can_delete
       or new.can_manage_members is distinct from old.can_manage_members
       or new.can_edit_info is distinct from old.can_edit_info
       or new.can_post is distinct from old.can_post then
      raise exception 'فقط مالک می‌تواند مدیرها و دسترسی‌ها را تغییر دهد';
    end if;
    if not public.gm_right(old.group_id, 'members') then
      raise exception 'دسترسی ندارید';
    end if;
  end if;
  return new;
end $$;

-- ============ واکنش با ایموجی ============
create or replace function public.can_see_msg(sc text, mid bigint) returns boolean
language sql stable security definer set search_path = public as $$
  select case when sc = 'd' then exists (select 1 from messages m where m.id = mid and (m.sender_id = auth.uid() or m.receiver_id = auth.uid()))
              else exists (select 1 from group_messages g where g.id = mid and public.gm_role(g.group_id) is not null) end
$$;
grant execute on function public.can_see_msg(text, bigint) to authenticated;
create table reactions (
  scope text not null check (scope in ('d', 'g')),
  message_id bigint not null,
  user_id uuid not null references profiles(id) on delete cascade,
  emoji text not null,
  created_at timestamptz not null default now(),
  primary key (scope, message_id, user_id)
);
alter table reactions enable row level security;
create policy "reactions read" on reactions for select to authenticated using (public.can_see_msg(scope, message_id));
create policy "reactions add" on reactions for insert to authenticated
  with check (user_id = auth.uid() and public.can_see_msg(scope, message_id));
create policy "reactions change" on reactions for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and public.can_see_msg(scope, message_id));
create policy "reactions remove" on reactions for delete to authenticated using (user_id = auth.uid());
alter publication supabase_realtime add table reactions;

-- ============ نظرسنجی ============
create table polls (
  id bigint generated always as identity primary key,
  question text not null,
  options text[] not null,
  multiple boolean not null default false,
  created_by uuid not null references profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table poll_votes (
  poll_id bigint not null references polls(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  option_idx int not null,
  primary key (poll_id, user_id, option_idx)
);
create or replace function public.can_see_poll(pid bigint) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from messages m where m.kind = 'poll' and m.file_name = pid::text
                 and (m.sender_id = auth.uid() or m.receiver_id = auth.uid()))
      or exists (select 1 from group_messages g where g.kind = 'poll' and g.file_name = pid::text
                 and public.gm_role(g.group_id) is not null)
$$;
grant execute on function public.can_see_poll(bigint) to authenticated;
alter table polls enable row level security;
alter table poll_votes enable row level security;
create policy "polls read" on polls for select to authenticated using (created_by = auth.uid() or public.can_see_poll(id));
create policy "polls create" on polls for insert to authenticated with check (created_by = auth.uid());
create policy "votes read" on poll_votes for select to authenticated using (public.can_see_poll(poll_id));
create policy "votes add" on poll_votes for insert to authenticated
  with check (user_id = auth.uid() and public.can_see_poll(poll_id));
create policy "votes remove" on poll_votes for delete to authenticated using (user_id = auth.uid());
alter publication supabase_realtime add table poll_votes;

-- ============ ارسال زمان‌بندی‌شده ============
create table scheduled_messages (
  id bigint generated always as identity primary key,
  sender_id uuid not null references profiles(id) on delete cascade,
  scope text not null check (scope in ('d', 'g')),
  target text not null,
  text text not null,
  send_at timestamptz not null,
  status text not null default 'pending' check (status in ('pending', 'sent', 'failed')),
  created_at timestamptz not null default now()
);
alter table scheduled_messages enable row level security;
create policy "sched read" on scheduled_messages for select to authenticated using (sender_id = auth.uid());
create policy "sched add" on scheduled_messages for insert to authenticated
  with check (sender_id = auth.uid() and status = 'pending');
create policy "sched remove" on scheduled_messages for delete to authenticated using (sender_id = auth.uid());

create or replace function public.deliver_scheduled() returns integer
language plpgsql security definer set search_path = public as $$
declare r scheduled_messages%rowtype; n integer := 0;
begin
  for r in select * from scheduled_messages where status = 'pending' and send_at <= now() order by send_at for update skip locked loop
    begin
      if r.scope = 'd' then
        insert into messages (sender_id, receiver_id, text) values (r.sender_id, r.target::uuid, r.text);
      else
        insert into group_messages (group_id, sender_id, text) values (r.target::bigint, r.sender_id, r.text);
      end if;
      update scheduled_messages set status = 'sent' where id = r.id;
      n := n + 1;
    exception when others then
      update scheduled_messages set status = 'failed' where id = r.id;
    end;
  end loop;
  return n;
end $$;

-- ============ لینک دعوت ============
create table group_invites (
  code text primary key,
  group_id bigint not null references groups(id) on delete cascade,
  created_by uuid not null references profiles(id) on delete cascade,
  revoked boolean not null default false,
  created_at timestamptz not null default now()
);
alter table group_invites enable row level security;

create or replace function public.create_invite(gid bigint) returns text
language plpgsql security definer set search_path = public as $$
declare c text;
begin
  if not public.gm_right(gid, 'members') then raise exception 'دسترسی ندارید'; end if;
  select code into c from group_invites where group_id = gid and not revoked limit 1;
  if c is null then
    c := substr(md5(random()::text || clock_timestamp()::text), 1, 10);
    insert into group_invites (code, group_id, created_by) values (c, gid, auth.uid());
  end if;
  return c;
end $$;
create or replace function public.revoke_invites(gid bigint) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.gm_right(gid, 'members') then raise exception 'دسترسی ندارید'; end if;
  update group_invites set revoked = true where group_id = gid;
end $$;
create or replace function public.join_group(p_code text) returns bigint
language plpgsql security definer set search_path = public as $$
declare gid bigint;
begin
  select group_id into gid from group_invites where code = p_code and not revoked;
  if gid is null then raise exception 'لینک دعوت معتبر نیست'; end if;
  insert into group_members (group_id, user_id, role) values (gid, auth.uid(), 'member') on conflict do nothing;
  return gid;
end $$;
grant execute on function public.create_invite(bigint) to authenticated;
grant execute on function public.revoke_invites(bigint) to authenticated;
grant execute on function public.join_group(text) to authenticated;
