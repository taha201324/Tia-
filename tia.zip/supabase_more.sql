-- اجرا شود بعد از supabase_safety.sql
-- ============ حالت آهسته و عکس گروه ============
alter table groups add column if not exists slow_mode int not null default 0 check (slow_mode >= 0);
grant update (title, description, avatar_path, members_send_messages, members_send_media, members_send_links, slow_mode) on groups to authenticated;

create or replace function public.group_msg_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare g groups%rowtype; m group_members%rowtype;
begin
  select * into g from groups where id = new.group_id;
  select * into m from group_members where group_id = new.group_id and user_id = new.sender_id;
  if g.id is null or m.user_id is null then
    raise exception 'شما عضو این گفتگو نیستید';
  end if;
  if g.kind = 'channel' then
    if not (m.role = 'owner' or (m.role = 'admin' and m.can_post)) then
      raise exception 'فقط مدیران کانال می‌توانند پست بگذارند';
    end if;
    return new;
  end if;
  if m.role = 'member' then
    if m.muted_until is not null and m.muted_until > now() then
      raise exception 'ارسال پیام برای شما موقتاً مسدود شده است';
    end if;
    if not g.members_send_messages then
      raise exception 'ارسال پیام برای اعضا بسته است';
    end if;
    if new.kind <> 'text' and not g.members_send_media then
      raise exception 'ارسال عکس، فایل، صدا و ویدئو در این گروه مجاز نیست';
    end if;
    if not g.members_send_links and new.text ~* '(https?://|www\.|t\.me/|[a-z0-9-]+\.(com|ir|org|net|me|io)\b)' then
      raise exception 'ارسال لینک در این گروه مجاز نیست';
    end if;
    if g.slow_mode > 0 and exists (
      select 1 from group_messages x
      where x.group_id = new.group_id and x.sender_id = new.sender_id
        and x.created_at > now() - make_interval(secs => g.slow_mode)
    ) then
      raise exception 'حالت آهسته فعال است؛ کمی صبر کنید';
    end if;
  end if;
  return new;
end $$;

-- ============ آنلاین بودن و آخرین بازدید (با کنترل حریم خصوصی در سرور) ============
alter table profiles add column if not exists last_seen timestamptz;
alter table profiles add column if not exists last_seen_visibility text not null default 'contacts'
  check (last_seen_visibility in ('everybody', 'contacts', 'nobody'));
grant select (last_seen_visibility) on profiles to authenticated;
grant update (last_seen_visibility) on profiles to authenticated;

create or replace function public.touch_seen() returns void
language sql security definer set search_path = public as $$
  update profiles set last_seen = now() where id = auth.uid()
$$;
grant execute on function public.touch_seen() to authenticated;

create or replace function public.get_last_seen(ids uuid[])
returns table(id uuid, last_seen timestamptz)
language sql stable security definer set search_path = public as $$
  select p.id, p.last_seen from profiles p
  where p.id = any(ids) and p.last_seen is not null and (
    p.id = auth.uid()
    or p.last_seen_visibility = 'everybody'
    or (p.last_seen_visibility = 'contacts' and exists (
      select 1 from contacts c where c.owner_id = p.id and c.contact_id = auth.uid()))
  );
$$;
grant execute on function public.get_last_seen(uuid[]) to authenticated;
