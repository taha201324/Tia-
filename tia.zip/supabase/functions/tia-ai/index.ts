// Edge Function «tia-ai»: واسطه‌ی امن بین اپ Tia و یک مدل زبانی (سازگار با API چت OpenAI).
// کلید مدل فقط در Secret های Supabase است و هرگز به اپ نمی‌رسد.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

const SYSTEM =
  "You are Tia AI, a helpful assistant inside the Tia messenger app. " +
  "Reply in the same language the user writes in (Persian by default). " +
  "Be accurate, clear and reasonably concise. If you are not sure, say so instead of guessing. " +
  "Refuse requests that are harmful or illegal.";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "method" }, 405);
  try {
    // ۱) احراز هویت کاربر با توکن همان درخواست
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr || !user) return json({ error: "unauthorized" }, 401);

    // ۲) تنظیمات مدل
    const key = Deno.env.get("AI_API_KEY");
    const model = Deno.env.get("AI_MODEL");
    const base = (Deno.env.get("AI_BASE_URL") ?? "https://api.openai.com/v1").replace(/\/+$/, "");
    if (!key || !model) return json({ error: "not_configured" }, 503);

    // ۳) اعتبارسنجی ورودی (فقط ۱۲ پیام آخر، هر کدام حداکثر ۴۰۰۰ نویسه)
    const body = await req.json().catch(() => null);
    const raw = Array.isArray(body?.messages) ? body.messages : [];
    const msgs = raw
      .filter((m: any) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim())
      .slice(-12)
      .map((m: any) => ({ role: m.role, content: String(m.content).slice(0, 4000) }));
    if (!msgs.length || msgs[msgs.length - 1].role !== "user") return json({ error: "bad_request" }, 400);

    // ۴) سهمیه‌ی روزانه
    const limit = Number(Deno.env.get("AI_DAILY_LIMIT") ?? "40");
    const { data: ok } = await supabase.rpc("ai_take_quota", { p_limit: limit });
    if (!ok) return json({ error: "quota" }, 429);

    // ۵) فراخوانی مدل
    const r = await fetch(`${base}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        messages: [{ role: "system", content: SYSTEM }, ...msgs],
        max_tokens: 1024,
        temperature: 0.6,
      }),
      signal: AbortSignal.timeout(50000),
    });
    if (!r.ok) {
      console.error("llm status", r.status);           // متن پیام‌ها هرگز لاگ نمی‌شود
      // ظرفیت رایگان سرویس مدل پر شده (برای مدل‌های رایگان طبیعی است)
      if (r.status === 429) return json({ error: "busy" }, 429);
      return json({ error: "upstream", status: r.status }, 502);
    }
    const j = await r.json();
    const answer = String(j?.choices?.[0]?.message?.content ?? "").trim();
    if (!answer) return json({ error: "empty" }, 502);
    return json({ answer });
  } catch (e) {
    console.error("tia-ai error", String(e));
    return json({ error: "server" }, 500);
  }
});
