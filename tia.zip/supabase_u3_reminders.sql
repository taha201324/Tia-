-- کد ۳ از ۵: یادآوری روی پیام (اعلان حتی وقتی برنامه بسته است). به supabase_push.sql و pg_cron نیاز دارد.
create table if not exists public.message_reminders (
  id bigserial primary key,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  scope text not null check (scope in ('d', 'g')),
  target text not null,
  msg_id bigint not null,
  preview text not null default '',
  remind_at timestamptz not null,
  done boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists message_reminders_due on public.message_reminders (remind_at) where not done;
alter table public.message_reminders enable row level security;
drop policy if exists "rem_own" on public.message_reminders;
create policy "rem_own" on public.message_reminders for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create or replace function public.process_reminders() returns integer
language plpgsql security definer set search_path = public, extensions as $$
declare r record; n integer := 0;
begin
  for r in select * from message_reminders where not done and remind_at <= now() order by remind_at limit 200 for update skip locked loop
    begin
      perform public.push_enqueue('rem:' || r.id, array[r.user_id], jsonb_strip_nulls(jsonb_build_object(
        'event_id', 'rem:' || r.id,
        'kind', case when r.scope = 'd' then 'dm' else 'group' end,
        'peer', case when r.scope = 'd' then r.target else null end,
        'gid', case when r.scope = 'g' then r.target::bigint else null end,
        'msg_id', r.msg_id,
        'title', '⏰ یادآوری',
        'body', r.preview,
        'ts', extract(epoch from now())::bigint)));
    exception when others then
      null;
    end;
    update message_reminders set done = true where id = r.id;
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.process_reminders() from public, anon, authenticated;
