-- کد ۳ (بخش دوم): زمان‌بند هر دقیقه. جدا اجرا شود. اگر خطا داد pg_cron را در Database ← Extensions روشن کنید.
create extension if not exists pg_cron with schema pg_catalog;
select cron.schedule('tia-reminders', '* * * * *', $$select public.process_reminders();$$);
