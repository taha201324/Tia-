# Tia
نمونه اولیه یک اپ پیام‌رسان با Flutter. بعد از push روی GitHub، از تب Actions فایل APK را دانلود کنید.
