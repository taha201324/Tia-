-- اجرا شود بعد از supabase_contacts.sql
-- ============ ۱) امکانات پیام: پاسخ، ویرایش، حذف، بازارسال ============
alter table messages add column if not exists reply_to bigint references messages(id) on delete set null;
alter table messages add column if not exists edited_at timestamptz;
alter table messages add column if not exists forwarded_from text;
grant update (read_at, text, edited_at) on messages to authenticated;
create policy "messages edit own" on messages for update to authenticated
  using (sender_id = auth.uid()) with check (sender_id = auth.uid());
create policy "messages delete own" on messages for delete to authenticated
  using (sender_id = auth.uid());

create or replace function public.messages_guard() returns trigger language plpgsql as $$
begin
  if (new.text is distinct from old.text or new.edited_at is distinct from old.edited_at)
     and auth.uid() is distinct from old.sender_id then
    raise exception 'فقط فرستنده می‌تواند پیام را ویرایش کند';
  end if;
  if new.read_at is distinct from old.read_at and auth.uid() is distinct from old.receiver_id then
    raise exception 'فقط گیرنده می‌تواند وضعیت خوانده‌شدن را تغییر دهد';
  end if;
  return new;
end $$;
create trigger messages_guard before update on messages for each row execute function public.messages_guard();

-- ============ ۲) حریم خصوصی شماره (سمت سرور) ============
alter table profiles add column if not exists phone_visibility text not null default 'contacts'
  check (phone_visibility in ('everybody', 'contacts', 'nobody'));

revoke select on profiles from authenticated;
grant select (id, name, username, bio, avatar_path, is_private, verified, phone_visibility) on profiles to authenticated;
revoke update on profiles from authenticated;
grant update (name, username, bio, avatar_path, is_private, phone_visibility) on profiles to authenticated;

-- شماره فقط برای خود شخص، یا طبق تنظیم او (همه / مخاطبین او / هیچ‌کس)
create or replace function public.get_phones(ids uuid[])
returns table(id uuid, phone text)
language sql stable security definer set search_path = public as $$
  select p.id, p.phone from profiles p
  where p.id = any(ids) and (
    p.id = auth.uid()
    or p.phone_visibility = 'everybody'
    or (p.phone_visibility = 'contacts' and exists (
      select 1 from contacts c where c.owner_id = p.id and c.contact_id = auth.uid()))
  );
$$;
grant execute on function public.get_phones(uuid[]) to authenticated;

-- پیدا کردن کاربر از روی شماره (شماره را برنمی‌گرداند)
drop function if exists public.match_contacts(text[]);
create or replace function public.match_contacts(p_phones text[])
returns table(id uuid, name text, username text, bio text, avatar_path text, is_private boolean, verified boolean, phone_visibility text)
language sql stable security definer set search_path = public as $$
  select p.id, p.name, p.username, p.bio, p.avatar_path, p.is_private, p.verified, p.phone_visibility
  from profiles p
  where right(regexp_replace(translate(p.phone, '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789'), '[^0-9]', '', 'g'), 10) = any(p_phones)
    and p.id <> auth.uid();
$$;
grant execute on function public.match_contacts(text[]) to authenticated;

-- ============ ۳) گروه و کانال ============
create table groups (
  id bigint generated always as identity primary key,
  kind text not null check (kind in ('group', 'channel')),
  title text not null,
  description text not null default '',
  avatar_path text,
  owner_id uuid not null references profiles(id),
  members_send_messages boolean not null default true,
  members_send_media boolean not null default true,
  members_send_links boolean not null default true,
  created_at timestamptz not null default now()
);
create table group_members (
  group_id bigint not null references groups(id) on delete cascade,
  user_id uuid not null references profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner', 'admin', 'member')),
  can_delete boolean not null default false,
  can_manage_members boolean not null default false,
  can_edit_info boolean not null default false,
  can_post boolean not null default true,
  muted_until timestamptz,
  joined_at timestamptz not null default now(),
  primary key (group_id, user_id)
);
create table group_messages (
  id bigint generated always as identity primary key,
  group_id bigint not null references groups(id) on delete cascade,
  sender_id uuid not null references profiles(id),
  text text not null default '',
  kind text not null default 'text',
  file_path text,
  file_name text,
  reply_to bigint references group_messages(id) on delete set null,
  forwarded_from text,
  edited_at timestamptz,
  created_at timestamptz not null default now()
);

create or replace function public.gm_role(gid bigint) returns text
language sql stable security definer set search_path = public as $$
  select role from group_members where group_id = gid and user_id = auth.uid()
$$;
create or replace function public.gm_right(gid bigint, r text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((
    select case
      when m.role = 'owner' then true
      when m.role = 'admin' then case r
        when 'delete' then m.can_delete
        when 'members' then m.can_manage_members
        when 'info' then m.can_edit_info
        when 'post' then m.can_post
        else false end
      else false end
    from group_members m where m.group_id = gid and m.user_id = auth.uid()
  ), false)
$$;
grant execute on function public.gm_role(bigint) to authenticated;
grant execute on function public.gm_right(bigint, text) to authenticated;

create or replace function public.groups_add_owner() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into group_members (group_id, user_id, role) values (new.id, new.owner_id, 'owner');
  return new;
end $$;
create trigger groups_add_owner after insert on groups for each row execute function public.groups_add_owner();

-- قوانین ارسال پیام: سمت سرور اعمال می‌شود و با دست‌کاری برنامه دور زده نمی‌شود
create or replace function public.group_msg_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare g groups%rowtype; m group_members%rowtype;
begin
  select * into g from groups where id = new.group_id;
  select * into m from group_members where group_id = new.group_id and user_id = new.sender_id;
  if g.id is null or m.user_id is null then
    raise exception 'شما عضو این گفتگو نیستید';
  end if;
  if g.kind = 'channel' then
    if not (m.role = 'owner' or (m.role = 'admin' and m.can_post)) then
      raise exception 'فقط مدیران کانال می‌توانند پست بگذارند';
    end if;
    return new;
  end if;
  if m.role = 'member' then
    if m.muted_until is not null and m.muted_until > now() then
      raise exception 'ارسال پیام برای شما موقتاً مسدود شده است';
    end if;
    if not g.members_send_messages then
      raise exception 'ارسال پیام برای اعضا بسته است';
    end if;
    if new.kind <> 'text' and not g.members_send_media then
      raise exception 'ارسال عکس، فایل و صدا در این گروه مجاز نیست';
    end if;
    if not g.members_send_links and new.text ~* '(https?://|www\.|t\.me/|[a-z0-9-]+\.(com|ir|org|net|me|io)\b)' then
      raise exception 'ارسال لینک در این گروه مجاز نیست';
    end if;
  end if;
  return new;
end $$;
create trigger group_msg_guard before insert on group_messages for each row execute function public.group_msg_guard();

-- فقط مالک می‌تواند مدیر تعیین کند یا دسترسی‌ها را عوض کند
create or replace function public.gm_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.role = 'owner' or new.role = 'owner' then
    raise exception 'مالک قابل تغییر نیست';
  end if;
  if public.gm_role(old.group_id) is distinct from 'owner' then
    if old.role <> 'member' or new.role <> old.role
       or new.can_delete is distinct from old.can_delete
       or new.can_manage_members is distinct from old.can_manage_members
       or new.can_edit_info is distinct from old.can_edit_info
       or new.can_post is distinct from old.can_post then
      raise exception 'فقط مالک می‌تواند مدیرها و دسترسی‌ها را تغییر دهد';
    end if;
  end if;
  return new;
end $$;
create trigger gm_guard before update on group_members for each row execute function public.gm_guard();

alter table groups enable row level security;
alter table group_members enable row level security;
alter table group_messages enable row level security;

create policy "groups read" on groups for select to authenticated
  using (owner_id = auth.uid() or public.gm_role(id) is not null);
create policy "groups create" on groups for insert to authenticated with check (owner_id = auth.uid());
create policy "groups edit" on groups for update to authenticated
  using (public.gm_right(id, 'info')) with check (public.gm_right(id, 'info'));
create policy "groups delete" on groups for delete to authenticated using (owner_id = auth.uid());
revoke update on groups from authenticated;
grant update (title, description, avatar_path, members_send_messages, members_send_media, members_send_links) on groups to authenticated;

create policy "members read" on group_members for select to authenticated
  using (public.gm_role(group_id) is not null);
create policy "members add" on group_members for insert to authenticated
  with check (role = 'member' and public.gm_right(group_id, 'members'));
revoke insert on group_members from authenticated;
grant insert (group_id, user_id, role) on group_members to authenticated;
create policy "members edit" on group_members for update to authenticated
  using (public.gm_right(group_id, 'members')) with check (public.gm_right(group_id, 'members'));
revoke update on group_members from authenticated;
grant update (role, can_delete, can_manage_members, can_edit_info, can_post, muted_until) on group_members to authenticated;
create policy "members remove" on group_members for delete to authenticated using (
  (user_id = auth.uid() and role <> 'owner')
  or (public.gm_right(group_id, 'members') and role = 'member')
  or (public.gm_role(group_id) = 'owner' and role <> 'owner')
);

create policy "gmsg read" on group_messages for select to authenticated using (public.gm_role(group_id) is not null);
create policy "gmsg send" on group_messages for insert to authenticated
  with check (sender_id = auth.uid() and public.gm_role(group_id) is not null);
create policy "gmsg edit own" on group_messages for update to authenticated
  using (sender_id = auth.uid()) with check (sender_id = auth.uid());
revoke update on group_messages from authenticated;
grant update (text, edited_at) on group_messages to authenticated;
create policy "gmsg delete" on group_messages for delete to authenticated
  using (sender_id = auth.uid() or public.gm_right(group_id, 'delete'));

alter publication supabase_realtime add table group_messages;
alter publication supabase_realtime add table group_members;

-- فایل‌های گروه برای اعضا قابل مشاهده باشد
drop policy if exists "chat files read" on storage.objects;
create policy "chat files read" on storage.objects for select to authenticated using (
  bucket_id = 'chat-files' and (
    (storage.foldername(name))[1] = auth.uid()::text
    or exists (select 1 from public.messages m where m.file_path = storage.objects.name
               and (m.sender_id = auth.uid() or m.receiver_id = auth.uid()))
    or exists (select 1 from public.group_messages gm where gm.file_path = storage.objects.name
               and public.gm_role(gm.group_id) is not null)
  )
);
