-- اجرا شود بعد از supabase_social.sql
-- پیدا کردن کاربران Tia از روی آخرین ۱۰ رقم شماره (برای همگام‌سازی مخاطبین و افزودن با شماره)
create or replace function public.match_contacts(p_phones text[])
returns setof profiles
language sql stable as $$
  select * from profiles
  where right(regexp_replace(translate(phone, '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789'), '[^0-9]', '', 'g'), 10) = any(p_phones)
    and id <> auth.uid();
$$;
grant execute on function public.match_contacts(text[]) to authenticated;
