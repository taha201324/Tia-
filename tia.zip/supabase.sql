create table profiles (
  id uuid primary key references auth.users on delete cascade,
  phone text unique not null,
  name text not null
);
create table contacts (
  owner_id uuid references profiles(id) on delete cascade,
  contact_id uuid references profiles(id) on delete cascade,
  primary key (owner_id, contact_id)
);
create table messages (
  id bigint generated always as identity primary key,
  sender_id uuid not null references profiles(id),
  receiver_id uuid not null references profiles(id),
  text text not null,
  created_at timestamptz not null default now()
);
alter table profiles enable row level security;
alter table contacts enable row level security;
alter table messages enable row level security;
create policy "profiles read" on profiles for select to authenticated using (true);
create policy "profiles insert own" on profiles for insert to authenticated with check (id = auth.uid());
create policy "profiles update own" on profiles for update to authenticated using (id = auth.uid());
create policy "contacts own" on contacts for all to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "messages read" on messages for select to authenticated using (sender_id = auth.uid() or receiver_id = auth.uid());
create policy "messages send" on messages for insert to authenticated with check (sender_id = auth.uid());
alter publication supabase_realtime add table messages;
