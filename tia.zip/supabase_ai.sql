-- ============================================================================
-- دستیار هوشمند Tia: سهمیه‌ی روزانه‌ی هر کاربر (برای کنترل هزینه)
-- اجرا شود بعد از supabase.sql. چند بار اجرا شدن بی‌خطر است.
-- ============================================================================
create table if not exists public.ai_usage (
  user_id uuid not null references public.profiles(id) on delete cascade,
  day date not null default current_date,
  n integer not null default 0,
  primary key (user_id, day)
);
alter table public.ai_usage enable row level security;
revoke all on public.ai_usage from anon, authenticated;     -- بدون policy: فقط تابع پایین به آن دسترسی دارد

-- یک پرسش از سهمیه‌ی امروز کم می‌کند؛ اگر سهمیه تمام شده باشد false برمی‌گرداند
create or replace function public.ai_take_quota(p_limit integer default 40) returns boolean
language plpgsql security definer set search_path = public as $$
declare v integer;
begin
  if auth.uid() is null then return false; end if;
  insert into ai_usage (user_id, day, n) values (auth.uid(), current_date, 1)
  on conflict (user_id, day) do update set n = ai_usage.n + 1 where ai_usage.n < p_limit
  returning n into v;
  return v is not null;
end $$;
revoke all on function public.ai_take_quota(integer) from public, anon;
grant execute on function public.ai_take_quota(integer) to authenticated;
