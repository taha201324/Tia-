-- ============================================================================
-- نظرسنجی پیشرفته: ناشناس، زمان‌دار و دیدن رأی‌دهندگان
-- اجرا شود بعد از supabase_extras.sql. چند بار اجرا شدن بی‌خطر است.
-- ============================================================================
alter table public.polls add column if not exists anonymous boolean not null default false;
alter table public.polls add column if not exists closes_at timestamptz;

-- خواندن رأی‌ها: همه‌ی کسانی که نظرسنجی را می‌بینند؛ ولی در نظرسنجی ناشناس فقط رأی خود شخص
drop policy if exists "votes read" on public.poll_votes;
create policy "votes read" on public.poll_votes for select to authenticated using (
  public.can_see_poll(poll_id)
  and (user_id = auth.uid()
       or not exists (select 1 from public.polls p where p.id = poll_id and p.anonymous))
);

-- بعد از پایان زمان، رأی‌دادن و پس‌گرفتن رأی ممکن نیست
drop policy if exists "votes add" on public.poll_votes;
create policy "votes add" on public.poll_votes for insert to authenticated with check (
  user_id = auth.uid() and public.can_see_poll(poll_id)
  and not exists (select 1 from public.polls p where p.id = poll_id and p.closes_at is not null and p.closes_at <= now())
);
drop policy if exists "votes remove" on public.poll_votes;
create policy "votes remove" on public.poll_votes for delete to authenticated using (
  user_id = auth.uid()
  and not exists (select 1 from public.polls p where p.id = poll_id and p.closes_at is not null and p.closes_at <= now())
);

-- شمارش رأی‌ها بدون افشای رأی‌دهندگان (برای نظرسنجی ناشناس)
create or replace function public.poll_counts(pid bigint)
returns table (option_idx int, n bigint)
language sql stable security definer set search_path = public as $$
  select v.option_idx, count(*)::bigint
    from poll_votes v
   where v.poll_id = pid and public.can_see_poll(pid)
   group by v.option_idx
$$;
revoke all on function public.poll_counts(bigint) from public, anon;
grant execute on function public.poll_counts(bigint) to authenticated;
