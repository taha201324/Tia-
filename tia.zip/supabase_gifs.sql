-- اجرا شود در Supabase > SQL Editor (بعد از بقیه‌ی فایل‌های sql)
-- گیف‌های من + کتابخانه‌ی عمومی گیف

-- ۱) گیف‌های ذخیره‌شده‌ی هر کاربر
create table if not exists public.saved_gifs (
  id bigint generated always as identity primary key,
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  path text,
  url text,
  name text not null default 'gif.gif',
  created_at timestamptz not null default now(),
  check (path is not null or url is not null)
);
alter table public.saved_gifs enable row level security;
drop policy if exists "saved gifs select" on public.saved_gifs;
drop policy if exists "saved gifs insert" on public.saved_gifs;
drop policy if exists "saved gifs delete" on public.saved_gifs;
create policy "saved gifs select" on public.saved_gifs for select to authenticated using (owner_id = auth.uid());
create policy "saved gifs insert" on public.saved_gifs for insert to authenticated with check (owner_id = auth.uid());
create policy "saved gifs delete" on public.saved_gifs for delete to authenticated using (owner_id = auth.uid());

-- ۲) مدیران برنامه (فقط از همین SQL Editor قابل افزودن هستند)
create table if not exists public.app_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.app_admins enable row level security;
drop policy if exists "app admins self" on public.app_admins;
create policy "app admins self" on public.app_admins for select to authenticated using (user_id = auth.uid());

-- ۳) کتابخانه‌ی عمومی گیف (همه می‌خوانند، فقط مدیر می‌نویسد)
create table if not exists public.gif_library (
  id bigint generated always as identity primary key,
  title text not null default '',
  tags text not null default '',
  path text not null unique,
  created_at timestamptz not null default now()
);
alter table public.gif_library enable row level security;
drop policy if exists "gif library read" on public.gif_library;
drop policy if exists "gif library admin insert" on public.gif_library;
drop policy if exists "gif library admin delete" on public.gif_library;
create policy "gif library read" on public.gif_library for select to authenticated using (true);
create policy "gif library admin insert" on public.gif_library for insert to authenticated
  with check (exists (select 1 from public.app_admins a where a.user_id = auth.uid()));
create policy "gif library admin delete" on public.gif_library for delete to authenticated
  using (exists (select 1 from public.app_admins a where a.user_id = auth.uid()));

-- ۴) فضای ذخیره‌ی گیف‌های کتابخانه (عمومی برای خواندن، ۱۰ مگابایت برای هر فایل)
insert into storage.buckets (id, name, public, file_size_limit)
values ('gif-library', 'gif-library', true, 10485760)
on conflict (id) do nothing;
drop policy if exists "gif library files upload" on storage.objects;
drop policy if exists "gif library files delete" on storage.objects;
create policy "gif library files upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'gif-library' and exists (select 1 from public.app_admins a where a.user_id = auth.uid()));
create policy "gif library files delete" on storage.objects for delete to authenticated
  using (bucket_id = 'gif-library' and exists (select 1 from public.app_admins a where a.user_id = auth.uid()));

-- ۵) ثبت مدیر برنامه
insert into public.app_admins (user_id) values ('d1cf93c4-f784-454f-a4be-ea0a8f387769')
on conflict (user_id) do nothing;
