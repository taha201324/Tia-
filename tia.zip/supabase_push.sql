-- اجرا شود بعد از supabase_safety.sql
create extension if not exists pg_net;

-- ============ تنظیمات اتصال اعلان (مقدارها را جداگانه وارد می‌کنید) ============
create table if not exists app_config (key text primary key, value text not null);
alter table app_config enable row level security;

-- ============ دستگاه‌های دریافت اعلان ============
create table device_tokens (
  token text primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  preview boolean not null default true,
  n_messages boolean not null default true,
  n_groups boolean not null default true,
  n_social boolean not null default true,
  updated_at timestamptz not null default now()
);
alter table device_tokens enable row level security;
create policy "tokens read own" on device_tokens for select to authenticated using (user_id = auth.uid());
create policy "tokens delete own" on device_tokens for delete to authenticated using (user_id = auth.uid());

create or replace function public.register_token(p_token text, p_preview boolean, p_msgs boolean, p_groups boolean, p_social boolean)
returns void language sql security definer set search_path = public as $$
  insert into device_tokens (token, user_id, preview, n_messages, n_groups, n_social)
  values (p_token, auth.uid(), p_preview, p_msgs, p_groups, p_social)
  on conflict (token) do update
    set user_id = auth.uid(), preview = p_preview, n_messages = p_msgs, n_groups = p_groups, n_social = p_social, updated_at = now();
$$;
grant execute on function public.register_token(text, boolean, boolean, boolean, boolean) to authenticated;

-- ============ اعلان‌های فعالیت (لایک، نظر، دنبال‌کردن، منشن) ============
create table notifications (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  actor_id uuid not null references profiles(id) on delete cascade,
  kind text not null check (kind in ('like', 'comment', 'follow', 'follow_request', 'follow_accept', 'mention')),
  post_id bigint references posts(id) on delete cascade,
  text text not null default '',
  read boolean not null default false,
  created_at timestamptz not null default now()
);
alter table notifications enable row level security;
create policy "notif read own" on notifications for select to authenticated using (user_id = auth.uid());
create policy "notif update own" on notifications for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "notif delete own" on notifications for delete to authenticated using (user_id = auth.uid());
revoke update on notifications from authenticated;
grant update (read) on notifications to authenticated;
alter publication supabase_realtime add table notifications;

create or replace function public.notify_mentions(txt text, actor uuid, pid bigint) returns void
language plpgsql security definer set search_path = public as $$
declare m text[]; uid uuid;
begin
  for m in select regexp_matches(txt, '@([A-Za-z0-9_]{3,20})', 'g') loop
    select id into uid from profiles where username = lower(m[1]);
    if uid is not null and uid <> actor then
      insert into notifications (user_id, actor_id, kind, post_id, text) values (uid, actor, 'mention', pid, left(txt, 80));
    end if;
  end loop;
end $$;

create or replace function public.trg_like() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into notifications (user_id, actor_id, kind, post_id)
  select p.author_id, new.user_id, 'like', new.post_id from posts p where p.id = new.post_id and p.author_id <> new.user_id;
  return new;
end $$;
create trigger trg_like after insert on likes for each row execute function public.trg_like();

create or replace function public.trg_comment() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into notifications (user_id, actor_id, kind, post_id, text)
  select p.author_id, new.user_id, 'comment', new.post_id, left(new.body, 80) from posts p where p.id = new.post_id and p.author_id <> new.user_id;
  perform public.notify_mentions(new.body, new.user_id, new.post_id);
  return new;
end $$;
create trigger trg_comment after insert on comments for each row execute function public.trg_comment();

create or replace function public.trg_post() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public.notify_mentions(new.body, new.author_id, new.id);
  return new;
end $$;
create trigger trg_post after insert on posts for each row execute function public.trg_post();

create or replace function public.trg_follow() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into notifications (user_id, actor_id, kind)
  values (new.followee_id, new.follower_id, case when new.status = 'pending' then 'follow_request' else 'follow' end);
  return new;
end $$;
create trigger trg_follow after insert on follows for each row execute function public.trg_follow();

create or replace function public.trg_follow_accept() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.status = 'pending' and new.status = 'accepted' then
    insert into notifications (user_id, actor_id, kind) values (new.follower_id, new.followee_id, 'follow_accept');
  end if;
  return new;
end $$;
create trigger trg_follow_accept after update on follows for each row execute function public.trg_follow_accept();

-- ============ فرستادن اعلان به تابع سرور (Edge Function) ============
create or replace function public.push_hook() returns trigger
language plpgsql security definer set search_path = public as $$
declare u text; s text;
begin
  select value into u from app_config where key = 'push_url';
  select value into s from app_config where key = 'push_secret';
  if u is not null and s is not null then
    perform net.http_post(
      url := u,
      headers := jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', s),
      body := jsonb_build_object('table', TG_TABLE_NAME, 'record', to_jsonb(new))
    );
  end if;
  return new;
exception when others then
  return new; -- خرابی اعلان هرگز نباید ارسال پیام را خراب کند
end $$;
create trigger push_messages after insert on messages for each row execute function public.push_hook();
create trigger push_group_messages after insert on group_messages for each row execute function public.push_hook();
create trigger push_notifications after insert on notifications for each row execute function public.push_hook();
