-- ============================================================================
-- Tia Push (بدون سرور و بدون دامنه) | اجرا شود بعد از همه‌ی فایل‌های SQL قبلی
-- اعلان‌ها در جدول push_outbox ذخیره می‌شوند و گوشی هر وقت آنلاین شد آن‌ها را می‌گیرد.
-- چند بار اجرا شدن بی‌خطر است. به هیچ جدول یا قابلیت قبلی دست نمی‌زند.
-- ============================================================================
create extension if not exists pgcrypto with schema extensions;

-- ---------- ۱) دستگاه‌ها ----------
create table if not exists public.push_devices (
  device_id text primary key check (char_length(device_id) between 8 and 64),
  user_id uuid not null references public.profiles(id) on delete cascade,
  platform text not null default 'android' check (platform in ('android')),
  app_version text,
  token_hash text not null,            -- SHA-256 توکن؛ خود توکن هیچ‌جا ذخیره نمی‌شود
  active boolean not null default true,
  registered_at timestamptz not null default now(),
  last_seen_at timestamptz
);
alter table public.push_devices add column if not exists last_seen_at timestamptz;
create index if not exists push_devices_user_idx on public.push_devices (user_id) where active;
alter table public.push_devices enable row level security;
drop policy if exists "push_devices read own" on public.push_devices;
create policy "push_devices read own" on public.push_devices for select to authenticated using (user_id = auth.uid());
revoke all on public.push_devices from anon, authenticated;
grant select (device_id, platform, app_version, active, registered_at, last_seen_at) on public.push_devices to authenticated;

-- ---------- ۲) صف اعلان‌ها (فقط از طریق توابع امن قابل دسترسی است) ----------
create table if not exists public.push_outbox (
  id bigint generated always as identity primary key,
  device_id text not null references public.push_devices(device_id) on delete cascade,
  event_id text not null,
  payload jsonb not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '3 days',
  delivered_at timestamptz,
  unique (device_id, event_id)          -- جلوگیری از اعلان تکراری
);
create index if not exists push_outbox_pending_idx on public.push_outbox (device_id, id) where delivered_at is null;
alter table public.push_outbox enable row level security;
revoke all on public.push_outbox from anon, authenticated;     -- بدون policy: هیچ کاربری مستقیم نمی‌خواند

-- تنظیمات (فقط سمت دیتابیس)
create table if not exists public.push_config (key text primary key, value text not null);
alter table public.push_config enable row level security;
revoke all on public.push_config from anon, authenticated;

-- ---------- ۳) ثبت و حذف دستگاه (کاربر واردشده) ----------
create or replace function public.register_push_device(p_device_id text, p_platform text default 'android', p_app_version text default null)
returns text language plpgsql security definer set search_path = public, extensions as $$
declare t text; old_user uuid;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if p_device_id is null or char_length(p_device_id) < 8 or char_length(p_device_id) > 64 then raise exception 'bad device id'; end if;
  select user_id into old_user from push_devices where device_id = p_device_id;
  if old_user is not null and old_user <> auth.uid() then
    delete from push_outbox where device_id = p_device_id;     -- اعلان‌های حساب قبلی هرگز به حساب جدید نمی‌رسند
  end if;
  t := encode(gen_random_bytes(32), 'hex');
  insert into push_devices (device_id, user_id, platform, app_version, token_hash, active, registered_at)
  values (p_device_id, auth.uid(), coalesce(p_platform, 'android'), p_app_version, encode(digest(t, 'sha256'), 'hex'), true, now())
  on conflict (device_id) do update
    set user_id = excluded.user_id, platform = excluded.platform, app_version = excluded.app_version,
        token_hash = excluded.token_hash, active = true, registered_at = now();
  return t;
end $$;
revoke all on function public.register_push_device(text, text, text) from public, anon;
grant execute on function public.register_push_device(text, text, text) to authenticated;

create or replace function public.unregister_push_device(p_device_id text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  delete from push_devices where device_id = p_device_id and user_id = auth.uid();   -- صف اعلان‌ها هم cascade پاک می‌شود
end $$;
revoke all on function public.unregister_push_device(text) from public, anon;
grant execute on function public.unregister_push_device(text) to authenticated;

-- ---------- ۴) دریافت و تأیید اعلان‌ها توسط گوشی (با توکن دستگاه؛ نیازی به نشست ورود ندارد) ----------
create or replace function public.push_fetch(p_device_id text, p_token text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare ok boolean; res jsonb;
begin
  select exists (select 1 from push_devices where device_id = p_device_id and active
                 and token_hash = encode(digest(coalesce(p_token, ''), 'sha256'), 'hex')) into ok;
  if not ok then raise exception 'bad device' using errcode = '28000'; end if;
  update push_devices set last_seen_at = now() where device_id = p_device_id;
  delete from push_outbox where device_id = p_device_id and (expires_at < now() or delivered_at < now() - interval '1 day');
  select coalesce(jsonb_agg(jsonb_build_object('id', x.id, 'payload', x.payload) order by x.id), '[]'::jsonb) into res
  from (select id, payload from push_outbox
        where device_id = p_device_id and delivered_at is null and expires_at >= now()
        order by id limit 50) x;
  return res;
end $$;
revoke all on function public.push_fetch(text, text) from public;
grant execute on function public.push_fetch(text, text) to anon, authenticated;

create or replace function public.push_ack(p_device_id text, p_token text, p_ids bigint[]) returns integer
language plpgsql security definer set search_path = public, extensions as $$
declare ok boolean; n integer;
begin
  select exists (select 1 from push_devices where device_id = p_device_id and active
                 and token_hash = encode(digest(coalesce(p_token, ''), 'sha256'), 'hex')) into ok;
  if not ok then raise exception 'bad device' using errcode = '28000'; end if;
  update push_outbox set delivered_at = now()
   where device_id = p_device_id and id = any(p_ids) and delivered_at is null;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.push_ack(text, text, bigint[]) from public;
grant execute on function public.push_ack(text, text, bigint[]) to anon, authenticated;

-- ---------- ۵) صف‌کردن اعلان + «اشاره‌ی» آنی از طریق Realtime ----------
-- پیام اشاره هیچ محتوایی ندارد؛ محتوای اعلان فقط با push_fetch (و توکن دستگاه) خوانده می‌شود.
create or replace function public.push_enqueue(p_event text, p_recipients uuid[], p_payload jsonb) returns void
language plpgsql security definer set search_path = public, extensions as $$
declare r record;
begin
  insert into push_outbox (device_id, event_id, payload)
  select d.device_id, p_event, p_payload from push_devices d
   where d.active and d.user_id = any(p_recipients)
  on conflict (device_id, event_id) do nothing;
  for r in select left(d.token_hash, 32) as th from push_devices d where d.active and d.user_id = any(p_recipients) loop
    begin
      perform realtime.send('{"h":1}'::jsonb, 'hint', 'push:' || r.th, false);
    exception when others then
      null;     -- اگر Realtime در دسترس نبود، گوشی با polling اعلان را می‌گیرد
    end;
  end loop;
end $$;
revoke all on function public.push_enqueue(text, uuid[], jsonb) from public, anon, authenticated;

create or replace function public.push_label(k text, t text, fname text, preview boolean) returns text
language sql immutable as $$
  select case
    when not preview then 'پیام جدید'
    when k = 'image' then '📷 عکس'
    when k = 'audio' then '🎤 پیام صوتی'
    when k = 'file' then '📎 ' || coalesce(nullif(fname, ''), 'فایل')
    when k = 'poll' then '📊 نظرسنجی'
    when k = 'video' then '🎬 ویدئو'
    when k = 'location' then '📍 موقعیت مکانی'
    when k = 'contact' then '👤 مخاطب'
    when coalesce(k, 'text') = 'text' then left(coalesce(t, ''), 120)
    else 'پیام جدید'
  end
$$;

create or replace function public.push_on_message() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
declare nm text; prev boolean;
begin
  begin
    if new.sender_id = new.receiver_id then return new; end if;
    if public.blocked_pair(new.sender_id, new.receiver_id) then return new; end if;
    if exists (select 1 from chat_prefs where user_id = new.receiver_id and scope = 'd'
               and target = new.sender_id::text and muted) then return new; end if;
    if not exists (select 1 from push_devices where user_id = new.receiver_id and active) then return new; end if;
    select name into nm from profiles where id = new.sender_id;
    select coalesce((select value from push_config where key = 'include_preview'), 'true') = 'true' into prev;
    perform public.push_enqueue('dm:' || new.id, array[new.receiver_id], jsonb_build_object(
      'event_id', 'dm:' || new.id, 'kind', 'dm', 'peer', new.sender_id, 'msg_id', new.id,
      'title', coalesce(nm, 'Tia'),
      'body', public.push_label(new.kind, new.text, new.file_name, prev),
      'ts', extract(epoch from new.created_at)::bigint));
  exception when others then
    null;   -- هرگز نباید ارسال پیام را به خاطر اعلان خراب کرد
  end;
  return new;
end $$;
drop trigger if exists push_on_message on public.messages;
create trigger push_on_message after insert on public.messages for each row execute function public.push_on_message();

create or replace function public.push_on_group_message() returns trigger
language plpgsql security definer set search_path = public, extensions as $$
declare gt text; nm text; rec uuid[]; prev boolean;
begin
  begin
    select title into gt from groups where id = new.group_id;
    select coalesce(array_agg(m.user_id), '{}') into rec from (
      select gm.user_id from group_members gm
       where gm.group_id = new.group_id and gm.user_id <> new.sender_id
         and (gm.muted_until is null or gm.muted_until <= now())
         and not exists (select 1 from chat_prefs cp where cp.user_id = gm.user_id and cp.scope = 'g'
                         and cp.target = new.group_id::text and cp.muted)
         and not public.blocked_pair(gm.user_id, new.sender_id)
       limit 2000) m;
    if coalesce(array_length(rec, 1), 0) = 0 then return new; end if;
    select name into nm from profiles where id = new.sender_id;
    select coalesce((select value from push_config where key = 'include_preview'), 'true') = 'true' into prev;
    perform public.push_enqueue('g:' || new.id, rec, jsonb_build_object(
      'event_id', 'g:' || new.id, 'kind', 'group', 'gid', new.group_id, 'msg_id', new.id,
      'title', coalesce(gt, 'Tia'),
      'body', case when prev then coalesce(nm, '') || ': ' else '' end || public.push_label(new.kind, new.text, new.file_name, prev),
      'ts', extract(epoch from new.created_at)::bigint));
  exception when others then
    null;
  end;
  return new;
end $$;
drop trigger if exists push_on_group_message on public.group_messages;
create trigger push_on_group_message after insert on public.group_messages for each row execute function public.push_on_group_message();

-- ---------- ۶) پاک‌سازی (اختیاری؛ push_fetch هم خودش صف هر دستگاه را تمیز می‌کند) ----------
create or replace function public.cleanup_push() returns integer
language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  delete from push_outbox where expires_at < now() or delivered_at < now() - interval '1 day';
  delete from push_devices where coalesce(last_seen_at, registered_at) < now() - interval '60 days';
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.cleanup_push() from public, anon, authenticated;
-- اگر pg_cron فعال است:  select cron.schedule('tia-push-cleanup', '30 3 * * *', $$select public.cleanup_push()$$);

-- از نسخه‌ی قبلی (سرور جدا) اگر چیزی مانده باشد
drop function if exists public.push_send(jsonb);
