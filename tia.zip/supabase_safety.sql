-- اجرا شود بعد از supabase_extras.sql
-- ============ مسدود کردن کاربر ============
create table blocks (
  blocker_id uuid not null references profiles(id) on delete cascade,
  blocked_id uuid not null references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);
alter table blocks enable row level security;
create policy "blocks own" on blocks for all to authenticated
  using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());

create or replace function public.blocked_pair(a uuid, b uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from blocks where (blocker_id = a and blocked_id = b) or (blocker_id = b and blocked_id = a))
$$;
grant execute on function public.blocked_pair(uuid, uuid) to authenticated;

-- اگر یکی از دو طرف دیگری را مسدود کرده باشد، پیام یا دنبال‌کردن ممکن نیست
create or replace function public.block_guard_messages() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.sender_id <> new.receiver_id and public.blocked_pair(new.sender_id, new.receiver_id) then
    raise exception 'امکان ارسال پیام به این کاربر وجود ندارد';
  end if;
  return new;
end $$;
create trigger block_guard_messages before insert on messages for each row execute function public.block_guard_messages();

create or replace function public.block_guard_follows() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.blocked_pair(new.follower_id, new.followee_id) then
    raise exception 'امکان دنبال کردن این کاربر وجود ندارد';
  end if;
  return new;
end $$;
create trigger block_guard_follows before insert on follows for each row execute function public.block_guard_follows();

-- ============ تنظیمات هر گفتگو: پاک‌کردن، سنجاق، بی‌صدا، بایگانی ============
create table chat_prefs (
  user_id uuid not null references profiles(id) on delete cascade,
  scope text not null check (scope in ('d', 'g')),
  target text not null,
  cleared_at timestamptz,
  muted boolean not null default false,
  archived boolean not null default false,
  pinned boolean not null default false,
  primary key (user_id, scope, target)
);
alter table chat_prefs enable row level security;
create policy "prefs own" on chat_prefs for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create or replace function public.clear_chat(sc text, tg text) returns void
language sql as $$
  insert into chat_prefs (user_id, scope, target, cleared_at) values (auth.uid(), sc, tg, now())
  on conflict (user_id, scope, target) do update set cleared_at = now();
$$;
grant execute on function public.clear_chat(text, text) to authenticated;

-- ============ گزارش تخلف ============
create table reports (
  id bigint generated always as identity primary key,
  reporter_id uuid not null references profiles(id) on delete cascade,
  kind text not null check (kind in ('user', 'post', 'message', 'group')),
  target text not null,
  reason text not null,
  details text not null default '',
  status text not null default 'new',
  created_at timestamptz not null default now()
);
alter table reports enable row level security;
create policy "reports add" on reports for insert to authenticated with check (reporter_id = auth.uid());
create policy "reports read own" on reports for select to authenticated using (reporter_id = auth.uid());
-- گزارش‌ها را شما از پنل Supabase در Table Editor ← reports می‌بینید

-- ============ حذف حساب ============
create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public, auth as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'ابتدا وارد شوید'; end if;
  delete from messages where sender_id = uid or receiver_id = uid;
  delete from group_messages where sender_id = uid;
  delete from groups where owner_id = uid;
  delete from profiles where id = uid;
  delete from auth.users where id = uid;
end $$;
grant execute on function public.delete_my_account() to authenticated;
