-- فقط برای ارسال زمان‌بندی‌شده. جدا اجرا شود تا اگر خطا داد بقیه‌ی کارها بی‌اثر نشوند.
-- اگر خطا داد: در پنل Supabase از Database ← Extensions افزونه‌ی pg_cron را روشن کنید و دوباره اجرا کنید.
create extension if not exists pg_cron with schema pg_catalog;
select cron.schedule('tia-deliver-scheduled', '* * * * *', $$select public.deliver_scheduled();$$);
